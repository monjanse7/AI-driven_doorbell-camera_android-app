package com.example.aidoormonitor.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

data class AnimalDetection(
    val label: String,
    val score: Float,
    val box: RectF,
    /** full = normal whole-frame pass, tile = small-object rescue pass. */
    val source: String = "full",
    /** 0..1 lightweight visual evidence for a thin leash-like line. */
    val leashEvidence: Float = 0f
)

class AnimalObjectDetector(
    private val context: Context,
    private val modelFile: File,
    private val onStatus: (String) -> Unit = {}
) {
    private var detector: ObjectDetector? = null
    private var lastRunAt = 0L
    private var lastSmallPetBoostAt = 0L

    fun start() {
        if (detector != null) return
        if (!modelFile.exists()) {
            onStatus("Animal AI model is not downloaded.")
            return
        }

        try {
            detector =
                ObjectDetector.createFromFile(
                    context,
                    modelFile
                )
            onStatus(
                "Object AI active • EfficientDet-Lite0 • COCO objects"
            )
        } catch (e: Exception) {
            onStatus("Animal AI failed: ${e.message}")
        }
    }

    fun analyze(bitmap: Bitmap): List<AnimalDetection> {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRunAt < 240L) return emptyList()
        lastRunAt = now

        return detectBitmap(
            bitmap = bitmap,
            source = "full",
            offsetX = 0f,
            offsetY = 0f,
            scaleX = 1f,
            scaleY = 1f,
            boostedPetThresholds = false
        )
    }

    /**
     * Second-pass rescue for small pets that disappear when a full portrait
     * frame is resized for EfficientDet. The crops cover the whole image with
     * overlap rather than assuming the pet is at the owner's feet; this also
     * catches dogs walking ahead of or behind their owner.
     *
     * This is deliberately rate-limited because it can run four extra model
     * inferences. It should normally be called only when Person is present but
     * Dog/Cat was absent from the first pass.
     */
    fun analyzeSmallPetBoost(
        bitmap: Bitmap,
        people: List<AnimalDetection>
    ): List<AnimalDetection> {
        if (people.isEmpty()) return emptyList()

        val now = SystemClock.elapsedRealtime()
        if (now - lastSmallPetBoostAt < 850L) return emptyList()
        lastSmallPetBoostAt = now

        val task = detector ?: return emptyList()
        if (bitmap.width < 64 || bitmap.height < 64) return emptyList()

        // 64% x 64% crops at each corner => useful overlap through the centre.
        // A small distant pet therefore occupies substantially more pixels in
        // at least one pass without requiring knowledge of walking direction.
        val cropW = (bitmap.width * 0.64f).toInt().coerceIn(48, bitmap.width)
        val cropH = (bitmap.height * 0.64f).toInt().coerceIn(48, bitmap.height)
        val maxLeft = (bitmap.width - cropW).coerceAtLeast(0)
        val maxTop = (bitmap.height - cropH).coerceAtLeast(0)

        val rects =
            listOf(
                Rect(0, 0, cropW, cropH),
                Rect(maxLeft, 0, maxLeft + cropW, cropH),
                Rect(0, maxTop, cropW, maxTop + cropH),
                Rect(maxLeft, maxTop, maxLeft + cropW, maxTop + cropH)
            )
                .distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }

        val candidates = mutableListOf<AnimalDetection>()

        rects.forEach { cropRect ->
            var crop: Bitmap? = null
            try {
                crop = Bitmap.createBitmap(
                    bitmap,
                    cropRect.left,
                    cropRect.top,
                    cropRect.width(),
                    cropRect.height()
                )

                // The ObjectDetector accepts arbitrary image dimensions and
                // internally preprocesses them for the model.
                candidates +=
                    detectBitmap(
                        bitmap = crop,
                        source = "tile",
                        offsetX = cropRect.left.toFloat(),
                        offsetY = cropRect.top.toFloat(),
                        scaleX = 1f,
                        scaleY = 1f,
                        boostedPetThresholds = true,
                        taskOverride = task
                    )
                        .filter {
                            val n = it.label.lowercase(Locale.US)
                            n == "dog" || n == "cat"
                        }
            } catch (_: Throwable) {
                // A rescue pass must never break the main DVR pipeline.
            } finally {
                try {
                    crop?.recycle()
                } catch (_: Throwable) {}
            }
        }

        return candidates
            .map { pet ->
                val nearestPerson =
                    people.minByOrNull { person ->
                        boxDistance(person.box, pet.box)
                    }

                val leash =
                    if (nearestPerson != null &&
                        plausibleCompanionDistance(
                            nearestPerson.box,
                            pet.box,
                            bitmap.width,
                            bitmap.height
                        )
                    ) {
                        estimateThinLeashEvidence(
                            bitmap,
                            nearestPerson.box,
                            pet.box
                        )
                    } else {
                        0f
                    }

                // Leash evidence is only a modest confidence assist. It can
                // rescue an already dog/cat-shaped candidate; it can never
                // create an animal detection by itself.
                pet.copy(
                    score =
                        (pet.score + leash * 0.11f)
                            .coerceAtMost(1f),
                    leashEvidence = leash
                )
            }
            .sortedByDescending { it.score }
            .distinctBy {
                val cx = ((it.box.left + it.box.right) * 0.5f / 40f).toInt()
                val cy = ((it.box.top + it.box.bottom) * 0.5f / 40f).toInt()
                "${it.label}:$cx:$cy"
            }
            .take(6)
    }

    private fun detectBitmap(
        bitmap: Bitmap,
        source: String,
        offsetX: Float,
        offsetY: Float,
        scaleX: Float,
        scaleY: Float,
        boostedPetThresholds: Boolean,
        taskOverride: ObjectDetector? = null
    ): List<AnimalDetection> {
        val task = taskOverride ?: detector ?: return emptyList()
        var converted: Bitmap? = null

        return try {
            val input =
                if (bitmap.config == Bitmap.Config.ARGB_8888) {
                    bitmap
                } else {
                    converted =
                        bitmap.copy(
                            Bitmap.Config.ARGB_8888,
                            false
                        )
                    converted ?: return emptyList()
                }

            val image = BitmapImageBuilder(input).build()
            val result = task.detect(image)
            image.close()

            result.detections()
                .mapNotNull { detection ->
                    val category =
                        detection.categories()
                            .maxByOrNull { it.score() }
                            ?: return@mapNotNull null

                    val raw =
                        category.categoryName()
                            .lowercase(Locale.US)

                    if (raw.isBlank()) return@mapNotNull null

                    val minimumScore =
                        if (boostedPetThresholds) {
                            when (raw) {
                                // The rescue pass is intentionally permissive;
                                // temporal confirmation in the DVR service and
                                // optional leash evidence suppress one-frame
                                // false positives.
                                "dog" -> 0.16f
                                "cat" -> 0.18f
                                else -> 0.50f
                            }
                        } else {
                            when (raw) {
                                "dog" -> 0.28f
                                "cat" -> 0.30f
                                "bird" -> 0.30f
                                "person" -> 0.36f
                                "bicycle" -> 0.34f
                                else -> 0.42f
                            }
                        }

                    if (category.score() < minimumScore) {
                        return@mapNotNull null
                    }

                    val box = detection.boundingBox()

                    AnimalDetection(
                        label =
                            raw.replaceFirstChar {
                                it.uppercase()
                            },
                        score = category.score(),
                        box =
                            RectF(
                                offsetX + box.left.toFloat() * scaleX,
                                offsetY + box.top.toFloat() * scaleY,
                                offsetX + box.right.toFloat() * scaleX,
                                offsetY + box.bottom.toFloat() * scaleY
                            ),
                        source = source
                    )
                }
                .sortedByDescending { it.score }
                .take(if (boostedPetThresholds) 8 else 12)
        } catch (e: Exception) {
            onStatus("Animal AI error: ${e.message}")
            emptyList()
        } finally {
            try {
                if (converted != null && !converted!!.isRecycled) {
                    converted!!.recycle()
                }
            } catch (_: Exception) {}
        }
    }

    private fun boxDistance(a: RectF, b: RectF): Float {
        val ax = (a.left + a.right) * 0.5f
        val ay = (a.top + a.bottom) * 0.5f
        val bx = (b.left + b.right) * 0.5f
        val by = (b.top + b.bottom) * 0.5f
        return hypot(ax - bx, ay - by)
    }

    private fun plausibleCompanionDistance(
        person: RectF,
        pet: RectF,
        frameWidth: Int,
        frameHeight: Int
    ): Boolean {
        val distance = boxDistance(person, pet)
        val personH = person.height().coerceAtLeast(1f)
        val diagonal = hypot(frameWidth.toFloat(), frameHeight.toFloat())

        // Allows a dog several body-widths in front/behind while rejecting a
        // pet candidate on the opposite side of a very wide scene.
        return distance <= max(personH * 2.9f, diagonal * 0.34f)
    }

    /**
     * Very small, dependency-free leash heuristic. Samples the corridor from
     * the person's lower torso/hand region to the pet and looks for a thin,
     * locally contrasting line that persists across multiple points.
     *
     * It is deliberately weak evidence: roads, branches and shadows can also
     * contain thin lines, so this score only boosts an existing pet candidate.
     */
    private fun estimateThinLeashEvidence(
        bitmap: Bitmap,
        person: RectF,
        pet: RectF
    ): Float {
        if (bitmap.width < 8 || bitmap.height < 8) return 0f

        val starts =
            listOf(
                Pair(
                    person.left + person.width() * 0.30f,
                    person.top + person.height() * 0.62f
                ),
                Pair(
                    person.left + person.width() * 0.70f,
                    person.top + person.height() * 0.62f
                ),
                Pair(
                    person.left + person.width() * 0.50f,
                    person.top + person.height() * 0.78f
                )
            )

        val endX = (pet.left + pet.right) * 0.5f
        val endY = pet.top + pet.height() * 0.38f

        return starts.maxOfOrNull { (startX, startY) ->
            thinLineScore(
                bitmap,
                startX,
                startY,
                endX,
                endY
            )
        } ?: 0f
    }

    private fun thinLineScore(
        bitmap: Bitmap,
        x0: Float,
        y0: Float,
        x1: Float,
        y1: Float
    ): Float {
        val dx = x1 - x0
        val dy = y1 - y0
        val length = hypot(dx, dy)
        if (length < 20f) return 0f

        val nx = -dy / length
        val ny = dx / length
        val samples = 28
        var contrastHits = 0
        var longestRun = 0
        var run = 0

        for (i in 3 until samples - 2) {
            val t = i.toFloat() / (samples - 1).toFloat()
            val x = x0 + dx * t
            val y = y0 + dy * t

            val centre = gray(bitmap, x, y) ?: continue
            val sideA = gray(bitmap, x + nx * 3.5f, y + ny * 3.5f) ?: continue
            val sideB = gray(bitmap, x - nx * 3.5f, y - ny * 3.5f) ?: continue
            val surroundings = (sideA + sideB) * 0.5f
            val contrast = abs(centre - surroundings)

            if (contrast >= 24f) {
                contrastHits++
                run++
                longestRun = max(longestRun, run)
            } else {
                run = 0
            }
        }

        val usable = (samples - 5).coerceAtLeast(1)
        val density = contrastHits.toFloat() / usable.toFloat()
        val continuity = (longestRun.toFloat() / 7f).coerceIn(0f, 1f)

        return (density * 0.60f + continuity * 0.40f)
            .coerceIn(0f, 1f)
    }

    private fun gray(bitmap: Bitmap, x: Float, y: Float): Float? {
        val ix = x.toInt()
        val iy = y.toInt()
        if (ix !in 0 until bitmap.width || iy !in 0 until bitmap.height) {
            return null
        }
        val c = bitmap.getPixel(ix, iy)
        val r = (c shr 16) and 0xff
        val g = (c shr 8) and 0xff
        val b = c and 0xff
        return (r * 0.299f + g * 0.587f + b * 0.114f)
    }

    fun stop() {
        try { detector?.close() } catch (_: Exception) {}
        detector = null
    }
}
