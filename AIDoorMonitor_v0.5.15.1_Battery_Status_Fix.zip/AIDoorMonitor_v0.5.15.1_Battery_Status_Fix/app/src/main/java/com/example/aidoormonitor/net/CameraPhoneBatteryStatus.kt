package com.example.aidoormonitor.net

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build

/**
 * Snapshot of the camera phone battery state for the monitor /health overlay.
 *
 * Primary source: ACTION_BATTERY_CHANGED sticky intent.
 * Fallback source: BatteryManager properties. Some OEM / background contexts can
 * fail to return the sticky intent even though BatteryManager can still report
 * capacity and charge status.
 */
data class CameraPhoneBatteryStatus(
    val percent: Int?,
    val status: String,
    val plugged: String,
    val charging: Boolean
)

object CameraPhoneBatteryReader {
    fun read(context: Context): CameraPhoneBatteryStatus {
        val appContext = context.applicationContext
        val batteryManager =
            try {
                appContext.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            } catch (_: Throwable) {
                null
            }

        val batteryIntent = readStickyBatteryIntent(appContext)

        val intentPercent = batteryIntent?.let { intent ->
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) {
                ((level * 100f) / scale)
                    .toInt()
                    .coerceIn(0, 100)
            } else {
                null
            }
        }

        val propertyPercent =
            try {
                batteryManager
                    ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    ?.takeIf { it in 0..100 }
            } catch (_: Throwable) {
                null
            }

        val percent = intentPercent ?: propertyPercent

        val intentStatus =
            batteryIntent?.getIntExtra(
                BatteryManager.EXTRA_STATUS,
                BatteryManager.BATTERY_STATUS_UNKNOWN
            )

        val propertyStatus =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    batteryManager
                        ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)
                        ?.takeIf {
                            it == BatteryManager.BATTERY_STATUS_CHARGING ||
                                it == BatteryManager.BATTERY_STATUS_DISCHARGING ||
                                it == BatteryManager.BATTERY_STATUS_NOT_CHARGING ||
                                it == BatteryManager.BATTERY_STATUS_FULL
                        }
                } catch (_: Throwable) {
                    null
                }
            } else {
                null
            }

        val managerCharging =
            try {
                batteryManager?.isCharging
            } catch (_: Throwable) {
                null
            }

        val rawStatus =
            intentStatus
                ?.takeIf { it != BatteryManager.BATTERY_STATUS_UNKNOWN }
                ?: propertyStatus
                ?: when (managerCharging) {
                    true -> BatteryManager.BATTERY_STATUS_CHARGING
                    false -> BatteryManager.BATTERY_STATUS_DISCHARGING
                    null -> BatteryManager.BATTERY_STATUS_UNKNOWN
                }

        val charging =
            rawStatus == BatteryManager.BATTERY_STATUS_CHARGING ||
                rawStatus == BatteryManager.BATTERY_STATUS_FULL ||
                managerCharging == true

        val status =
            when (rawStatus) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
                BatteryManager.BATTERY_STATUS_FULL -> "Full"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
                else -> if (percent != null) "Unknown" else "Unavailable"
            }

        val rawPlugged =
            batteryIntent?.getIntExtra(
                BatteryManager.EXTRA_PLUGGED,
                0
            ) ?: 0

        val plugged =
            when {
                rawPlugged and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "AC"
                rawPlugged and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "USB"
                rawPlugged and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "Wireless"
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    rawPlugged and BatteryManager.BATTERY_PLUGGED_DOCK != 0 -> "Dock"
                rawPlugged != 0 -> "External power"
                else -> ""
            }

        return CameraPhoneBatteryStatus(
            percent = percent,
            status = status,
            plugged = plugged,
            charging = charging
        )
    }

    private fun readStickyBatteryIntent(context: Context): Intent? {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                // Explicitly allow system-origin broadcasts on modern Android.
                context.registerReceiver(
                    null,
                    filter,
                    Context.RECEIVER_EXPORTED
                )
            } else {
                @Suppress("DEPRECATION")
                context.registerReceiver(null, filter)
            }
        } catch (_: Throwable) {
            // BatteryManager fallback below still gives capacity/status on most devices.
            null
        }
    }
}
