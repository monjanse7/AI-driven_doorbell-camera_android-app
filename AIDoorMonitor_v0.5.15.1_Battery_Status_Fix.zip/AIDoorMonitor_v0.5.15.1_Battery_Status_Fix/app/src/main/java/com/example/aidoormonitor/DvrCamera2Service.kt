package com.example.aidoormonitor

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.os.Build
import android.os.BatteryManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.PowerManager
import android.view.OrientationEventListener
import android.hardware.SensorManager
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.graphics.SurfaceTexture
import android.graphics.Rect
import android.graphics.BitmapFactory
import com.example.aidoormonitor.ai.AnimalObjectDetector
import com.example.aidoormonitor.ai.ModelDownloader
import com.example.aidoormonitor.ai.AudioAiEvent
import com.example.aidoormonitor.dvr.DvrEventLabeler
import java.util.concurrent.atomic.AtomicBoolean
import android.view.Surface
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.aidoormonitor.dvr.DvrGpuPreview
import com.example.aidoormonitor.dvr.DvrMotionAnalyzer
import com.example.aidoormonitor.dvr.DvrSharedAudioEngine
import com.example.aidoormonitor.dvr.DvrCapturedAudio
import com.example.aidoormonitor.net.LanCameraEndpoint
import com.example.aidoormonitor.net.LanCameraHub
import com.example.aidoormonitor.storage.Mp4SegmentMerger
import com.example.aidoormonitor.storage.DvrRecordingLibrary
import com.example.aidoormonitor.net.RemoteRecordingSource
import com.example.aidoormonitor.store.EventStore
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max

/**
 * Stability-first Camera2 DVR engine.
 *
 * The camera has only two active PRIVATE output surfaces:
 *  1) MediaRecorder / 4K or 1080p rolling MP4 buffer.
 *  2) SurfaceTexture preview stream consumed by an off-screen OpenGL analyzer.
 *
 * The second stream deliberately uses PRIVATE/SurfaceTexture rather than YUV.
 * Motorola Edge 30 Ultra camera 0 rejects 3840x2160 MediaRecorder + every tested
 * YUV stream, while Preview + Video recording is the broadly-supported path.
 *
 * The recorder runs continuously into short cache segments. Normal segments
 * are deleted. When motion is detected, the last N completed segments are
 * retained as pre-record, subsequent segments are kept for post-record, then
 * the completed MP4 segments are merged without re-encoding into MediaStore.
 */
class DvrCamera2Service : Service(), LanCameraEndpoint {

    companion object {
        const val ACTION_START = "com.example.aidoormonitor.DVR_START"
        const val ACTION_STOP = "com.example.aidoormonitor.DVR_STOP"
        const val ACTION_RESTART = "com.example.aidoormonitor.DVR_RESTART"
        const val ACTION_SAVE_EVENT = "com.example.aidoormonitor.DVR_SAVE_EVENT"

        private const val CHANNEL_ID = "dvr_camera2"
        private const val NOTIFICATION_ID = 5207
        private const val SEGMENT_SECONDS = 4

        @Volatile var isRunning = false
            private set
        @Volatile var statusText = "DVR stopped"
            private set
        @Volatile var activeRecordingSize = ""
            private set
        @Volatile var activeRecordingFps = 30
            private set
        @Volatile var visualStreamAvailable = true
            private set
        @Volatile var recordingFirstMode = false
            private set
        @Volatile var compatibilityStage = "Camera2 PRIVATE preview DVR • native portrait GPU"
            private set
        @Volatile var activeQualityFallback = ""
            private set
        @Volatile var activeAnalysisSize = ""
            private set
        @Volatile var motionScore = 0f
            private set
        @Volatile var eventActive = false
            private set
        @Volatile var completedPrebufferSeconds = 0
            private set
        @Volatile var lastError = ""
            private set
        @Volatile var currentAiEventLabel = "Motion"
            private set
        @Volatile var lastSavedEventName = ""
            private set
        @Volatile var activeRotationText = "Rotation: starting…"
            private set
        @Volatile var activeOrientationHintDegrees = 0
            private set
        @Volatile var audioAiStatus = "Sound AI: starting…"
            private set
        @Volatile var lastSoundAiEvent = ""
            private set
        @Volatile var customObjectAiReady = false
            private set
        @Volatile var recordingAudioStatus = "Video audio: starting…"
            private set
        @Volatile var activeVideoBitrateText = "Video bitrate: starting…"
            private set
        @Volatile var activeAudioBitrateText = "Audio bitrate: starting…"
            private set
        @Volatile var activeAudioSyncText = "Audio sync: automatic"
            private set
        @Volatile var movingCarDetected = false
            private set
        @Volatile var carMotionScore = 0f
            private set
        @Volatile var carMotionStatus = "Car motion filter: waiting"
            private set
        @Volatile var appliedZoomRatio = 1f
            private set
        @Volatile var zoomControlMode = "starting"
            private set
    }

    private val prefs by lazy {
        getSharedPreferences("camera_settings", MODE_PRIVATE)
    }

    private lateinit var eventStore: EventStore
    private lateinit var recordingLibrary: DvrRecordingLibrary
    private lateinit var cameraManager: CameraManager

    private var cameraThread: HandlerThread? = null
    private var cameraHandler: Handler? = null
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val objectAiExecutor = Executors.newSingleThreadExecutor()
    private val objectAiBusy = AtomicBoolean(false)

    private lateinit var eventLabeler: DvrEventLabeler
    private var objectDetector: AnimalObjectDetector? = null
    private var customObjectDetector: AnimalObjectDetector? = null
    private var sharedAudioEngine: DvrSharedAudioEngine? = null
    private var lastObjectAiAt = 0L

    private val objectTriggerCooldown =
        ConcurrentHashMap<String, Long>()

    /**
     * Temporal tracks for low-confidence pets recovered by the tiled
     * small-object pass. A weak crop-only Dog/Cat must normally survive two
     * nearby analyses before it is promoted to an event label.
     */
    private data class PetRescueTrack(
        val label: String,
        var centerX: Float,
        var centerY: Float,
        var firstSeenAtMs: Long,
        var lastSeenAtMs: Long,
        var hitCount: Int
    )

    private val petRescueTracks =
        mutableListOf<PetRescueTrack>()

    private val petRescueLock = Any()
    private var lastPetRescueLogAtMs = 0L

    private data class CarMotionTrack(
        var baselineBox: android.graphics.RectF,
        var lastBox: android.graphics.RectF,
        var baselineAtMs: Long,
        var lastSeenAtMs: Long,
        var movementEvidence: Int = 0,
        var movingUntilMs: Long = 0L
    )

    private val carMotionTracks =
        mutableListOf<CarMotionTrack>()

    private val carMotionLock =
        Any()

    @Volatile
    private var lastCameraViewChangeAtMs = 0L

    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var gpuPreview: DvrGpuPreview? = null
    private var mediaRecorder: MediaRecorder? = null

    private var selectedCameraId = ""
    private var characteristics: CameraCharacteristics? = null
    private var recordingSize = Size(3840, 2160)
    private var previewCandidates: List<Size> = emptyList()
    private var previewCandidateIndex = 0

    private var repeatingRequestBuilder: CaptureRequest.Builder? = null

    @Volatile
    private var manualFocusSupported = false

    @Volatile
    private var maxFocusDiopters = 0f

    @Volatile
    private var focusManual = false

    @Volatile
    private var focusLinear = 0f

    @Volatile
    private var maxZoomRatio = 1f

    private var minZoomRatio = 1f

    private var zoomRatioApiSupported = false

    @Volatile
    private var cameraZoomLinear = 0f

    @Volatile
    private var cameraPanX = 0f

    @Volatile
    private var cameraPanY = 0f

    private var sensorActiveArray: Rect? = null

    @Volatile
    private var freeformCropSupported = false

    private val cameraViewApplyRunnable =
        Runnable {
            applyCameraViewToActiveSession()
        }

    private val repeatingCaptureCallback =
        object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(
                session: CameraCaptureSession,
                request: CaptureRequest,
                result: TotalCaptureResult
            ) {
                val ratio =
                    if (
                        Build.VERSION.SDK_INT >=
                        Build.VERSION_CODES.R
                    ) {
                        result.get(
                            CaptureResult
                                .CONTROL_ZOOM_RATIO
                        )
                    } else {
                        null
                    }

                if (
                    ratio != null &&
                    ratio > 0f
                ) {
                    appliedZoomRatio =
                        ratio
                } else {
                    val active =
                        sensorActiveArray

                    val crop =
                        result.get(
                            CaptureResult
                                .SCALER_CROP_REGION
                        )

                    if (
                        active != null &&
                        crop != null &&
                        crop.width() > 0
                    ) {
                        appliedZoomRatio =
                            (
                                active.width()
                                    .toFloat() /
                                    crop.width()
                                        .toFloat()
                                )
                                .coerceAtLeast(
                                    1f
                                )
                    }
                }
            }
        }

    private val focusApplyRunnable =
        Runnable {
            applyFocusToActiveSession()
        }

    private var currentSegment: File? = null
    private var nextSegment: File? = null
    private var recorderStarted = false
    private var recorderStartAt = 0L

    private val segmentStartedAtMs =
        ConcurrentHashMap<String, Long>()

    private var eventVideoStartAtMs = 0L

    private val completedSegments = ArrayDeque<File>()
    private val eventSegments = mutableListOf<File>()
    private var eventId = ""
    private var eventRecordingStartedAtMs = 0L

    @Volatile
    private var cachedCameraPhoneTemperatureC: Float? = null
    @Volatile
    private var cachedCameraPhoneTemperatureAtMs = 0L
    private var lastMotionAt = 0L
    private var highMotionFrames = 0
    private var manualEventRequested = false

    private val motionAnalyzer = DvrMotionAnalyzer()

    // Rotation written to MediaRecorder metadata. This includes the native
    // Camera2 sensor orientation.
    private var jpegRotationDegrees = 0

    // Rotation applied physically to the GPU/JPEG preview. SurfaceTexture's
    // transform matrix already handles the sensor buffer transform on this
    // preview path, so only the correction relative to upright is needed.
    private var previewPresentationRotationDegrees = 0

    @Volatile
    private var autoDeviceRotationDegrees = -1

    private var lockedDeviceRotationDegrees = 0

    private var orientationListener:
        OrientationEventListener? =
        null

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private var stopping = false
    private var cameraOpening = false
    private var cameraRetryCount = 0
    private var availabilityRegistered = false
    private var selectedCameraAvailable = false

    private val availabilityCallback =
        object : CameraManager.AvailabilityCallback() {
            override fun onCameraAvailable(cameraId: String) {
                if (cameraId == selectedCameraId) {
                    selectedCameraAvailable = true
                    if (
                        isRunning &&
                        !stopping &&
                        cameraDevice == null &&
                        !cameraOpening
                    ) {
                        cameraHandler?.postDelayed({
                            openSelectedCameraWhenAvailable()
                        }, 250L)
                    }
                }
            }

            override fun onCameraUnavailable(cameraId: String) {
                if (cameraId == selectedCameraId) {
                    selectedCameraAvailable = false
                    statusText =
                        "Waiting for camera $cameraId to be released…"
                    updateNotification(
                        "Waiting for camera release…"
                    )
                }
            }
        }

    override fun onCreate() {
        super.onCreate()

        eventStore = EventStore(this)
        recordingLibrary =
            DvrRecordingLibrary(this)
        eventLabeler = DvrEventLabeler(this)

        if (ModelDownloader.objectReady(this)) {
            objectDetector =
                AnimalObjectDetector(
                    this,
                    ModelDownloader.objectFile(this),
                    onStatus = { status ->
                        if (
                            status.contains("error", true) ||
                            status.contains("failed", true)
                        ) {
                            eventStore.add(
                                "DVR Object AI",
                                status
                            )
                        }
                    }
                ).also {
                    it.start()
                }

            eventStore.add(
                "DVR Object AI ready",
                "EfficientDet-Lite0 labels can name motion recordings."
            )
        } else {
            eventStore.add(
                "DVR Object AI not ready",
                "Motion recording still works, but filenames use Motion until the object model is downloaded."
            )
        }

        if (ModelDownloader.customObjectReady(this)) {
            customObjectDetector =
                AnimalObjectDetector(
                    this,
                    ModelDownloader.customObjectFile(this),
                    onStatus = { status ->
                        if (
                            status.contains("error", true) ||
                            status.contains("failed", true)
                        ) {
                            eventStore.add(
                                "Custom object AI",
                                status
                            )
                        }
                    }
                ).also {
                    it.start()
                }

            customObjectAiReady =
                customObjectDetector != null

            eventStore.add(
                "Custom object AI ready",
                "Custom object labels can trigger and name DVR events, including stroller if the model exposes that class."
            )
        } else {
            customObjectAiReady = false
        }

        cameraManager =
            getSystemService(Context.CAMERA_SERVICE) as CameraManager

        createNotificationChannel()
        startAsCameraForeground(
            buildNotification(
                "Starting DVR camera…"
            )
        )

        acquireLocks()

        cameraThread =
            HandlerThread("AI-Door-Camera2-DVR").apply {
                start()
            }
        cameraHandler =
            Handler(
                cameraThread!!.looper
            )

        startSharedDvrAudio()


        orientationListener =
            object :
                OrientationEventListener(
                    this,
                    SensorManager.SENSOR_DELAY_NORMAL
                ) {
                override fun onOrientationChanged(
                    orientation: Int
                ) {
                    if (
                        orientation ==
                        ORIENTATION_UNKNOWN
                    ) {
                        return
                    }

                    autoDeviceRotationDegrees =
                        when {
                            orientation >= 315 ||
                                orientation < 45 ->
                                0

                            orientation < 135 ->
                                90

                            orientation < 225 ->
                                180

                            else ->
                                270
                        }
                }
            }

        try {
            if (
                orientationListener
                    ?.canDetectOrientation()
                == true
            ) {
                orientationListener?.enable()
            }
        } catch (_: Throwable) {
        }


        try {
            cameraManager.registerAvailabilityCallback(
                availabilityCallback,
                cameraHandler
            )
            availabilityRegistered = true
        } catch (_: Throwable) {
        }

        isRunning = true
        statusText = "Starting Camera2 DVR…"
        lastError = ""

        // A previous CameraX service must not keep the camera or LAN port.
        try {
            stopService(
                Intent(
                    this,
                    DoorMonitoringService::class.java
                )
            )
        } catch (_: Throwable) {
        }

        LanCameraHub.stop(clearFrame = true)
        LanCameraHub.setEndpoint(this)
        LanCameraHub.ensureStarted(this)

        cleanStaleDvrCache()
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        when (intent?.action ?: ACTION_START) {
            ACTION_STOP -> {
                stopSelf()
            }

            ACTION_RESTART -> {
                cameraHandler?.post {
                    stopCameraResources(
                        deleteUnprotected = true
                    )

                    // Do not leave the last JPEG from the old camera rotation
                    // visible while the new Camera2 session is starting.
                    LanCameraHub.latestJpeg.set(
                        null
                    )

                    restartSharedAudioForSettings()

                    startCamera()
                }
            }

            ACTION_SAVE_EVENT -> {
                cameraHandler?.post {
                    triggerManualEvent()
                }
            }

            else -> {
                cameraHandler?.post {
                    if (cameraDevice == null) {
                        startCamera()
                    }
                }
            }
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("MissingPermission")
    private fun startCamera() {
        if (stopping) return

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            failCamera(
                "Camera permission is missing."
            )
            return
        }

        try {
            selectedCameraId = resolveCameraId()
            characteristics =
                cameraManager.getCameraCharacteristics(
                    selectedCameraId
                )

            updateManualFocusCapability()
            updateCameraViewCapability()

            synchronized(
                carMotionLock
            ) {
                carMotionTracks.clear()
                movingCarDetected = false
                carMotionScore = 0f
                carMotionStatus =
                    "Car motion filter: waiting for car tracks"
            }

            val map =
                characteristics?.get(
                    CameraCharacteristics
                        .SCALER_STREAM_CONFIGURATION_MAP
                )
                    ?: throw IllegalStateException(
                        "No stream configuration map"
                    )

            recordingSize =
                chooseRecordingSize(
                    map.getOutputSizes(
                        MediaRecorder::class.java
                    )?.toList().orEmpty()
                )

            previewCandidates =
                choosePreviewCandidates(
                    map.getOutputSizes(
                        SurfaceTexture::class.java
                    )?.toList().orEmpty()
                )

            if (previewCandidates.isEmpty()) {
                throw IllegalStateException(
                    "No PRIVATE/SurfaceTexture preview stream is exposed by camera $selectedCameraId"
                )
            }

            val manualCorrection =
                manualVideoCorrectionDegrees()

            lockedDeviceRotationDegrees =
                if (
                    manualCorrection ==
                    null
                ) {
                    resolveAutoDeviceRotationDegrees()
                } else {
                    // Manual mode does not feed a fake device orientation
                    // into Camera2 rotation math anymore.
                    0
                }

            jpegRotationDegrees =
                calculateOutputRotation(
                    lockedDeviceRotationDegrees
                )

            previewPresentationRotationDegrees =
                calculatePreviewPresentationRotation(
                    jpegRotationDegrees
                )

            activeOrientationHintDegrees =
                jpegRotationDegrees

            val sensorOrientation =
                characteristics
                    ?.get(
                        CameraCharacteristics
                            .SENSOR_ORIENTATION
                    )
                    ?: 0

            activeRotationText =
                buildString {
                    append(
                        mountingRotationModeLabel()
                    )

                    if (
                        manualCorrection !=
                        null
                    ) {
                        append(
                            " • MP4 metadata="
                        )
                        append(
                            jpegRotationDegrees
                        )
                        append(
                            "° • LAN preview correction="
                        )
                        append(
                            previewPresentationRotationDegrees
                        )
                        append("° • preview=9:16 portrait")

                        if (
                            manualCorrection ==
                            0
                        ) {
                            append(
                                " • physical phone: TOP up / USB down"
                            )
                        }
                    } else {
                        append(
                            " • device="
                        )
                        append(
                            lockedDeviceRotationDegrees
                        )
                        append(
                            "° • sensor="
                        )
                        append(
                            sensorOrientation
                        )
                        append(
                            "° • MP4 metadata="
                        )
                        append(
                            jpegRotationDegrees
                        )
                        append(
                            "° • LAN preview correction="
                        )
                        append(
                            previewPresentationRotationDegrees
                        )
                        append("° • preview=9:16 portrait")
                    }
                }

            previewCandidateIndex = 0
            cameraRetryCount = 0

            statusText =
                "Waiting for camera $selectedCameraId • ${recordingSize.width}×${recordingSize.height}"

            // Do not assume that stopService() released CameraX instantly.
            // CameraManager availability is the source of truth.
            openSelectedCameraWhenAvailable()

        } catch (t: Throwable) {
            failCamera(
                "Camera setup failed: " +
                    (t.message ?: t.javaClass.simpleName)
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun openSelectedCameraWhenAvailable() {
        if (
            stopping ||
            cameraDevice != null ||
            cameraOpening
        ) {
            return
        }

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            failCamera("Camera permission is missing.")
            return
        }

        cameraOpening = true
        statusText =
            "Opening camera $selectedCameraId…"
        updateNotification(
            "Opening camera…"
        )

        try {
            cameraManager.openCamera(
                selectedCameraId,
                cameraStateCallback,
                cameraHandler
            )
        } catch (t: Throwable) {
            cameraOpening = false
            scheduleCameraOpenRetry(
                "openCamera threw " +
                    t.javaClass.simpleName +
                    ": " +
                    (t.message ?: "unknown")
            )
        }
    }

    private fun scheduleCameraOpenRetry(
        reason: String
    ) {
        if (stopping) return

        cameraRetryCount++

        val delay =
            when {
                cameraRetryCount <= 3 -> 600L
                cameraRetryCount <= 8 -> 1_200L
                else -> 2_000L
            }

        lastError = reason
        statusText =
            "Camera busy/unavailable • retry $cameraRetryCount • $reason"

        eventStore.add(
            "DVR camera open retry",
            "attempt=$cameraRetryCount • $reason"
        )

        updateNotification(
            "Camera busy • retrying…"
        )

        cameraHandler?.postDelayed({
            if (
                !stopping &&
                cameraDevice == null
            ) {
                openSelectedCameraWhenAvailable()
            }
        }, delay)
    }

    private val cameraStateCallback =
        object : CameraDevice.StateCallback() {
            override fun onOpened(camera: CameraDevice) {
                cameraOpening = false

                if (stopping) {
                    camera.close()
                    return
                }

                cameraRetryCount = 0
                lastError = ""
                cameraDevice = camera
                statusText =
                    "Camera opened • configuring DVR streams…"
                configureRecorderAndSession()
            }

            override fun onDisconnected(camera: CameraDevice) {
                cameraOpening = false
                try {
                    camera.close()
                } catch (_: Throwable) {
                }
                cameraDevice = null

                scheduleCameraOpenRetry(
                    "Camera disconnected before DVR session was ready."
                )
            }

            override fun onError(
                camera: CameraDevice,
                error: Int
            ) {
                cameraOpening = false

                try {
                    camera.close()
                } catch (_: Throwable) {
                }
                cameraDevice = null

                val name =
                    when (error) {
                        ERROR_CAMERA_IN_USE ->
                            "CAMERA_IN_USE"
                        ERROR_MAX_CAMERAS_IN_USE ->
                            "MAX_CAMERAS_IN_USE"
                        ERROR_CAMERA_DISABLED ->
                            "CAMERA_DISABLED"
                        ERROR_CAMERA_DEVICE ->
                            "CAMERA_DEVICE"
                        ERROR_CAMERA_SERVICE ->
                            "CAMERA_SERVICE"
                        else ->
                            "UNKNOWN_$error"
                    }

                if (
                    error == ERROR_CAMERA_IN_USE ||
                    error == ERROR_MAX_CAMERAS_IN_USE ||
                    error == ERROR_CAMERA_DEVICE ||
                    error == ERROR_CAMERA_SERVICE
                ) {
                    scheduleCameraOpenRetry(
                        "Camera2 $name"
                    )
                } else {
                    failCamera(
                        "Camera2 $name"
                    )
                }
            }
        }

    private fun configureRecorderAndSession() {
        if (stopping) return

        val camera =
            cameraDevice ?: return

        closeSessionOnly()

        if (
            previewCandidateIndex !in
            previewCandidates.indices
        ) {
            if (
                is8KSize(
                    recordingSize
                )
            ) {
                configureRecordingOnlySession()
            } else {
                failCamera(
                    "Camera $selectedCameraId rejected every tested PRIVATE preview + " +
                        "${recordingSize.width}×${recordingSize.height} recording combination."
                )
            }
            return
        }

        val previewSize =
            previewCandidates[
                previewCandidateIndex
            ]

        // The SurfaceTexture transform already presents the camera in the
        // requested upright orientation. Render the OpenGL target itself as
        // 9:16 portrait instead of rendering to a 16:9 landscape FBO and
        // cropping a narrow vertical strip afterwards.
        val analyzerSize =
            if (
                previewSize.width >= 1280 &&
                previewSize.height >= 720
            ) {
                Size(540, 960)
            } else {
                Size(360, 640)
            }

        activeRecordingSize =
            "${recordingSize.width}×${recordingSize.height}"

        activeRecordingFps =
            recordingFps()

        visualStreamAvailable =
            true

        recordingFirstMode =
            false

        compatibilityStage =
            "Camera2 PRIVATE preview DVR • native portrait GPU"
        activeAnalysisSize =
            "GPU ${analyzerSize.width}×${analyzerSize.height} @ 10 fps"

        try {
            val gpu =
                DvrGpuPreview(
                    inputWidth = previewSize.width,
                    inputHeight = previewSize.height,
                    outputWidth = analyzerSize.width,
                    outputHeight = analyzerSize.height,
                    rotationDegrees =
                        previewPresentationRotationDegrees,
                    forcePortraitOutput =
                        true,
                    onMotion = { score ->
                        cameraHandler?.post {
                            if (!stopping) {
                                motionScore = score
                                processMotionScore(
                                    score,
                                    System.currentTimeMillis()
                                )
                            }
                        }
                    },
                    onJpeg = { jpeg ->
                        LanCameraHub.latestJpeg.set(jpeg)
                        analyzeJpegForEventNaming(jpeg)
                    },
                    onStatus = { status ->
                        if (
                            status.contains("error", true) ||
                            status.contains("failed", true)
                        ) {
                            eventStore.add(
                                "DVR GPU preview",
                                status
                            )
                        }
                    }
                )

            val previewSurface =
                gpu.surface
                    ?: throw IllegalStateException(
                        "GPU preview surface was not created"
                    )

            gpuPreview = gpu

            val recorder =
                buildMediaRecorder()
            mediaRecorder = recorder

            val surfaces =
                listOf(
                    recorder.surface,
                    previewSurface
                )

            statusText =
                "Configuring $activeRecordingSize + PRIVATE preview " +
                    "${previewSize.width}×${previewSize.height}…"

            camera.createCaptureSession(
                surfaces,
                object :
                    CameraCaptureSession.StateCallback() {

                    override fun onConfigured(
                        session: CameraCaptureSession
                    ) {
                        if (stopping) {
                            session.close()
                            return
                        }

                        captureSession = session

                        try {
                            val requestBuilder =
                                camera.createCaptureRequest(
                                    CameraDevice.TEMPLATE_RECORD
                                ).apply {
                                    addTarget(
                                        recorder.surface
                                    )
                                    addTarget(
                                        previewSurface
                                    )

                                    set(
                                        CaptureRequest.CONTROL_MODE,
                                        CaptureRequest.CONTROL_MODE_AUTO
                                    )

                                    bestRecordingFpsRange(
                                        recordingFps()
                                    )
                                        ?.let { fps ->
                                            set(
                                                CaptureRequest
                                                    .CONTROL_AE_TARGET_FPS_RANGE,
                                                fps
                                            )
                                        }

                                    applyFocusSettingsToBuilder(this)
                                    applyCameraViewSettingsToBuilder(this)
                                }

                            repeatingRequestBuilder =
                                requestBuilder

                            session.setRepeatingRequest(
                                requestBuilder.build(),
                                repeatingCaptureCallback,
                                cameraHandler
                            )

                            recorder.start()
                            recorderStarted = true
                            recorderStartAt =
                                System.currentTimeMillis()

                            currentSegment
                                ?.let { file ->
                                    segmentStartedAtMs[
                                        file.absolutePath
                                    ] = recorderStartAt
                                }

                            highMotionFrames = 0

                            statusText =
                                buildString {
                                    append(
                                        "DVR armed • $activeRecordingSize @ ${activeRecordingFps} fps • "
                                    )
                                    append(
                                        "$activeAnalysisSize • PRIVATE preview"
                                    )

                                    if (
                                        activeQualityFallback
                                            .isNotBlank()
                                    ) {
                                        append(
                                            " • "
                                        )
                                        append(
                                            activeQualityFallback
                                        )
                                    }
                                }

                            lastError = ""

                            eventStore.add(
                                "DVR Camera ready",
                                "$activeRecordingSize rolling recording • " +
                                    "PRIVATE preview ${previewSize.width}×${previewSize.height} • " +
                                    "$activeAnalysisSize • pre-record ${preRecordSeconds()}s"
                            )

                            updateNotification(
                                "DVR armed • $activeRecordingSize • motion 10 fps"
                            )

                        } catch (t: Throwable) {
                            retryPreviewStream(
                                "Capture/recorder start failed: " +
                                    (t.message ?: t.javaClass.simpleName)
                            )
                        }
                    }

                    override fun onConfigureFailed(
                        session: CameraCaptureSession
                    ) {
                        try {
                            session.close()
                        } catch (_: Throwable) {
                        }

                        retryPreviewStream(
                            "Camera rejected $activeRecordingSize + PRIVATE preview " +
                                "${previewSize.width}×${previewSize.height}"
                        )
                    }
                },
                cameraHandler
            )

        } catch (t: Throwable) {
            retryPreviewStream(
                "PRIVATE preview session setup failed: " +
                    (t.message ?: t.javaClass.simpleName)
            )
        }
    }

    private fun configureRecordingOnlySession() {
        if (stopping) return

        val camera =
            cameraDevice
                ?: return

        closeSessionOnly()

        activeRecordingSize =
            "${recordingSize.width}×${recordingSize.height}"

        activeRecordingFps =
            recordingFps()

        activeAnalysisSize =
            "Unavailable in 8K recording-first mode"

        visualStreamAvailable =
            false

        recordingFirstMode =
            true

        compatibilityStage =
            "8K RECORDING-FIRST • no simultaneous PRIVATE preview"

        LanCameraHub.latestJpeg.set(
            null
        )

        try {
            val recorder =
                buildMediaRecorder()

            mediaRecorder =
                recorder

            camera.createCaptureSession(
                listOf(
                    recorder.surface
                ),
                object :
                    CameraCaptureSession.StateCallback() {

                    override fun onConfigured(
                        session: CameraCaptureSession
                    ) {
                        if (stopping) {
                            session.close()
                            return
                        }

                        captureSession =
                            session

                        try {
                            val requestBuilder =
                                camera.createCaptureRequest(
                                    CameraDevice
                                        .TEMPLATE_RECORD
                                ).apply {
                                    addTarget(
                                        recorder.surface
                                    )

                                    set(
                                        CaptureRequest
                                            .CONTROL_MODE,
                                        CaptureRequest
                                            .CONTROL_MODE_AUTO
                                    )

                                    bestRecordingFpsRange(
                                        recordingFps()
                                    )
                                        ?.let { fps ->
                                            set(
                                                CaptureRequest
                                                    .CONTROL_AE_TARGET_FPS_RANGE,
                                                fps
                                            )
                                        }

                                    applyFocusSettingsToBuilder(
                                        this
                                    )

                                    applyCameraViewSettingsToBuilder(
                                        this
                                    )
                                }

                            repeatingRequestBuilder =
                                requestBuilder

                            session.setRepeatingRequest(
                                requestBuilder.build(),
                                repeatingCaptureCallback,
                                cameraHandler
                            )

                            recorder.start()

                            recorderStarted =
                                true

                            recorderStartAt =
                                System.currentTimeMillis()

                            currentSegment
                                ?.let { file ->
                                    segmentStartedAtMs[
                                        file.absolutePath
                                    ] =
                                        recorderStartAt
                                }

                            statusText =
                                "8K DVR armed • $activeRecordingSize @ ${activeRecordingFps} fps • recording-first"

                            lastError =
                                ""

                            eventStore.add(
                                "8K recording-first ready",
                                "$activeRecordingSize @ ${activeRecordingFps} fps • no simultaneous visual preview; Sound AI/manual events remain available."
                            )

                            updateNotification(
                                "8K DVR armed • recording-first"
                            )

                        } catch (t: Throwable) {
                            failCamera(
                                "8K recording-only start failed: " +
                                    (
                                        t.message
                                            ?: t.javaClass
                                                .simpleName
                                        )
                            )
                        }
                    }

                    override fun onConfigureFailed(
                        session: CameraCaptureSession
                    ) {
                        try {
                            session.close()
                        } catch (_: Throwable) {
                        }

                        failCamera(
                            "Camera $selectedCameraId rejected 8K recording-only ${recordingSize.width}×${recordingSize.height}."
                        )
                    }
                },
                cameraHandler
            )

        } catch (t: Throwable) {
            failCamera(
                "8K recording-only setup failed: " +
                    (
                        t.message
                            ?: t.javaClass
                                .simpleName
                        )
            )
        }
    }

    private fun retryPreviewStream(reason: String) {
        eventStore.add(
            "DVR compatibility retry",
            "$reason • next smaller PRIVATE preview stream"
        )

        closeSessionOnly()
        previewCandidateIndex++

        cameraHandler?.postDelayed({
            configureRecorderAndSession()
        }, 300L)
    }

    private fun buildMediaRecorder(): MediaRecorder {
        val recorder =
            if (Build.VERSION.SDK_INT >= 31) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

        val file =
            newSegmentFile()
        currentSegment = file
        nextSegment = null

        val bitrate =
            videoBitrateBps()

        activeVideoBitrateText =
            if (
                prefs.getInt(
                    "dvr_video_bitrate_mbps",
                    0
                ) <= 0
            ) {
                "Video bitrate: Auto • ${bitrate / 1_000_000} Mbps"
            } else {
                "Video bitrate: ${bitrate / 1_000_000} Mbps"
            }

        recorder.setVideoSource(
            MediaRecorder.VideoSource.SURFACE
        )
        recorder.setOutputFormat(
            MediaRecorder.OutputFormat.MPEG_4
        )
        recorder.setVideoEncoder(
            if (
                is8KSize(
                    recordingSize
                ) &&
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.N
            ) {
                MediaRecorder.VideoEncoder.HEVC
            } else {
                MediaRecorder.VideoEncoder.H264
            }
        )
        recorder.setVideoSize(
            recordingSize.width,
            recordingSize.height
        )
        activeRecordingFps =
            recordingFps()

        recorder.setVideoFrameRate(
            activeRecordingFps
        )
        recorder.setVideoEncodingBitRate(
            bitrate
        )
        recorder.setOrientationHint(
            jpegRotationDegrees
        )
        if (Build.VERSION.SDK_INT >= 26) {
            recorder.setOutputFile(file)
        } else {
            recorder.setOutputFile(
                file.absolutePath
            )
        }

        // Approx. 4-second files. The recorder switches seamlessly to
        // setNextOutputFile() on API 26+.
        val targetBytes =
            (
                bitrate.toLong() *
                    SEGMENT_SECONDS.toLong() /
                    8L
                ) +
                512L * 1024L

        recorder.setMaxFileSize(
            targetBytes
        )

        recorder.setOnErrorListener { _, what, extra ->
            cameraHandler?.post {
                eventStore.add(
                    "DVR recorder error",
                    "what=$what extra=$extra"
                )
                statusText =
                    "Recorder error $what/$extra • rebuilding camera"
                restartAfterRecorderFailure()
            }
        }

        recorder.setOnInfoListener { mediaRecorder, what, _ ->
            when (what) {
                MediaRecorder
                    .MEDIA_RECORDER_INFO_MAX_FILESIZE_APPROACHING -> {

                    if (Build.VERSION.SDK_INT >= 26) {
                        try {
                            if (nextSegment == null) {
                                val next =
                                    newSegmentFile()

                                mediaRecorder
                                    .setNextOutputFile(
                                        next
                                    )

                                nextSegment =
                                    next
                            }
                        } catch (t: Throwable) {
                            eventStore.add(
                                "DVR next-segment warning",
                                t.message
                                    ?: t.javaClass.simpleName
                            )
                        }
                    }
                }

                MediaRecorder
                    .MEDIA_RECORDER_INFO_NEXT_OUTPUT_FILE_STARTED -> {

                    cameraHandler?.post {
                        val switchedAt =
                            System.currentTimeMillis()

                        val completed =
                            currentSegment

                        currentSegment =
                            nextSegment

                        currentSegment
                            ?.let { file ->
                                segmentStartedAtMs[
                                    file.absolutePath
                                ] = switchedAt
                            }

                        nextSegment =
                            null

                        if (
                            completed != null &&
                            completed.exists() &&
                            completed.length() > 0L
                        ) {
                            onSegmentCompleted(
                                completed
                            )
                        }
                    }
                }

                MediaRecorder
                    .MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED -> {

                    cameraHandler?.post {
                        // On API 24-25 or if setNextOutputFile missed its
                        // deadline, rebuild the recorder/session.
                        restartAfterRecorderFailure()
                    }
                }
            }
        }

        recorder.prepare()
        return recorder
    }

    private fun restartSharedAudioForSettings() {
        try {
            sharedAudioEngine
                ?.stop()
        } catch (_: Throwable) {
        }

        sharedAudioEngine =
            null

        // Re-submit the foreground notification with the newly selected
        // camera/microphone foreground-service type set.
        try {
            startAsCameraForeground(
                buildNotification(
                    "Applying DVR audio settings…"
                )
            )
        } catch (_: Throwable) {
        }

        startSharedDvrAudio()
    }

    private fun startSharedDvrAudio() {
        updateAudioQualityStatus()

        LanCameraHub.clearLiveAudio()

        if (!audioCaptureRequested()) {
            audioAiStatus =
                "Sound AI: OFF"

            recordingAudioStatus =
                "Video audio: OFF"

            return
        }

        if (!microphonePermissionGranted()) {
            audioAiStatus =
                if (soundAiRequested()) {
                    "Sound AI: microphone permission missing"
                } else {
                    "Sound AI: OFF"
                }

            recordingAudioStatus =
                "Video audio: microphone permission missing"

            eventStore.add(
                "DVR microphone unavailable",
                "RECORD_AUDIO permission is not granted."
            )
            return
        }

        val model =
            if (
                soundAiRequested() &&
                ModelDownloader.yamnetReady(this)
            ) {
                ModelDownloader
                    .yamnetFile(this)
            } else {
                null
            }

        if (
            soundAiRequested() &&
            model == null
        ) {
            audioAiStatus =
                "Sound AI: YamNet model not downloaded"
        }

        val engine =
            DvrSharedAudioEngine(
                context = this,
                modelFile = model,
                enableSoundAi =
                    soundAiRequested(),
                requestedSampleRate =
                    audioSampleRateHz(),
                maxPrebufferSeconds =
                    40,
                onEvent = { event ->
                    cameraHandler?.post {
                        if (!stopping) {
                            handleDvrSoundAiEvent(
                                event
                            )
                        }
                    }
                },
                onLivePcm = {
                        samples,
                        sampleRate ->
                    LanCameraHub
                        .publishLivePcm16Mono(
                            samples,
                            sampleRate
                        )
                },
                onStatus = { status ->
                    recordingAudioStatus =
                        if (
                            recordAudioInVideos()
                        ) {
                            "Video audio: $status"
                        } else {
                            "Video audio: OFF • $status"
                        }

                    if (
                        soundAiRequested()
                    ) {
                        audioAiStatus =
                            "Sound AI: $status"
                    }

                    if (
                        status.contains(
                            "failed",
                            true
                        ) ||
                        status.contains(
                            "error",
                            true
                        )
                    ) {
                        eventStore.add(
                            "Shared DVR audio",
                            status
                        )
                    }
                }
            )

        val started =
            try {
                engine.start()
            } catch (_: Throwable) {
                false
            }

        if (started) {
            sharedAudioEngine =
                engine

            recordingAudioStatus =
                if (recordAudioInVideos()) {
                    "Video audio: ON • 48 kHz mono AAC in saved events"
                } else {
                    "Video audio: OFF"
                }

            if (
                soundAiRequested() &&
                model != null
            ) {
                audioAiStatus =
                    "Sound AI: YamNet active on shared microphone"
            }

            eventStore.add(
                "Shared DVR microphone ready",
                if (recordAudioInVideos()) {
                    "48 kHz mono PCM feeds both saved-video audio and Sound AI."
                } else {
                    "Microphone is used for Sound AI only."
                }
            )

        } else {
            sharedAudioEngine =
                null

            recordingAudioStatus =
                "Video audio: microphone startup failed"
        }
    }

    private fun normalizeAiToken(
        value: String
    ): String =
        value
            .trim()
            .lowercase(Locale.US)
            .replace(' ', '_')
            .replace('-', '_')
            .replace(
                Regex("[^a-z0-9_]+"),
                ""
            )

    private fun handleDvrSoundAiEvent(
        event: AudioAiEvent
    ) {
        val now =
            System.currentTimeMillis()

        val primarySignal =
            when (event.key) {
                "dog_barking" ->
                    "bark"

                "dog_growling" ->
                    "growling"

                "dog_whining" ->
                    "whimper"

                "dog_yelping" ->
                    "yelp"

                "dog_howling" ->
                    "howl"

                "shouting" ->
                    "shouting"

                "impact" ->
                    "impact"

                else ->
                    normalizeAiToken(
                        event.rawLabel
                    )
            }

        eventLabeler.recordSignal(
            primarySignal,
            event.confidence,
            now
        )

        eventLabeler.recordSignal(
            event.key,
            event.confidence,
            now
        )

        val rawSignal =
            normalizeAiToken(
                event.rawLabel
            )

        if (rawSignal.isNotBlank()) {
            eventLabeler.recordSignal(
                rawSignal,
                event.confidence,
                now
            )
        }

        lastSoundAiEvent =
            "${event.label} • " +
                String.format(
                    Locale.US,
                    "%.0f%%",
                    event.confidence *
                        100f
                )

        val triggerEnabled =
            when (event.key) {
                "dog_barking",
                "dog_growling",
                "dog_whining",
                "dog_yelping",
                "dog_howling" ->
                    prefs.getBoolean(
                        "dvr_trigger_dog_sounds",
                        true
                    )

                "shouting" ->
                    prefs.getBoolean(
                        "dvr_trigger_shouting",
                        false
                    )

                "impact" ->
                    prefs.getBoolean(
                        "dvr_trigger_impact_sound",
                        false
                    )

                else ->
                    false
            }

        if (!triggerEnabled) {
            return
        }

        lastMotionAt = now

        if (!eventActive) {
            beginAiTriggeredEvent(
                label = event.label,
                eventLogTitle =
                    "Sound AI trigger",
                detail =
                    "confidence=" +
                        String.format(
                            Locale.US,
                            "%.2f",
                            event.confidence
                        ) +
                        " • raw=${event.rawLabel}"
            )
        } else {
            currentAiEventLabel =
                eventLabeler
                    .currentBestLabel()

            statusText =
                "SOUND AI • $currentAiEventLabel • event extended"
        }
    }

    private fun beginAiTriggeredEvent(
        label: String,
        eventLogTitle: String,
        detail: String
    ) {
        eventActive = true
        manualEventRequested = false
        lastMotionAt =
            System.currentTimeMillis()
        eventRecordingStartedAtMs =
            lastMotionAt

        eventId =
            SimpleDateFormat(
                "yyyyMMdd_HHmmss",
                Locale.US
            ).format(lastMotionAt)

        eventSegments.clear()

        eventLabeler.beginEvent(
            preRecordSeconds =
                preRecordSeconds(),
            manual = false
        )

        currentAiEventLabel =
            eventLabeler
                .currentBestLabel()
                .takeIf {
                    it.isNotBlank() &&
                        it != "Motion"
                }
                ?: label

        completedSegments
            .filter {
                it.exists() &&
                    it.length() > 0L
            }
            .forEach {
                eventSegments += it
            }

        eventVideoStartAtMs =
            resolveEventVideoStartAtMs()

        if (
            recordAudioInVideos()
        ) {
            sharedAudioEngine
                ?.beginEventAt(
                    eventVideoStartAtMs
                )
        }

        eventStore.add(
            eventLogTitle,
            "$label • pre-record buffer=${completedPrebufferSeconds}s • $detail"
        )

        statusText =
            "$label • recording event • pre-record included"

        updateNotification(
            "$label • event recording"
        )
    }

    private fun copyBox(
        box: android.graphics.RectF
    ): android.graphics.RectF =
        android.graphics.RectF(
            box.left,
            box.top,
            box.right,
            box.bottom
        )

    private fun boxIou(
        a: android.graphics.RectF,
        b: android.graphics.RectF
    ): Float {
        val left =
            max(
                a.left,
                b.left
            )

        val top =
            max(
                a.top,
                b.top
            )

        val right =
            kotlin.math.min(
                a.right,
                b.right
            )

        val bottom =
            kotlin.math.min(
                a.bottom,
                b.bottom
            )

        val intersectionWidth =
            (
                right -
                    left
                )
                .coerceAtLeast(
                    0f
                )

        val intersectionHeight =
            (
                bottom -
                    top
                )
                .coerceAtLeast(
                    0f
                )

        val intersection =
            intersectionWidth *
                intersectionHeight

        if (intersection <= 0f) {
            return 0f
        }

        val areaA =
            a.width()
                .coerceAtLeast(0f) *
                a.height()
                    .coerceAtLeast(0f)

        val areaB =
            b.width()
                .coerceAtLeast(0f) *
                b.height()
                    .coerceAtLeast(0f)

        val union =
            areaA +
                areaB -
                intersection

        return if (union <= 0f) {
            0f
        } else {
            (
                intersection /
                    union
                )
                .coerceIn(
                    0f,
                    1f
                )
        }
    }

    private fun normalizedCenterDistance(
        a: android.graphics.RectF,
        b: android.graphics.RectF,
        frameWidth: Int,
        frameHeight: Int
    ): Float {
        val width =
            frameWidth
                .coerceAtLeast(1)
                .toFloat()

        val height =
            frameHeight
                .coerceAtLeast(1)
                .toFloat()

        val dx =
            (
                a.centerX() -
                    b.centerX()
                ) /
                width

        val dy =
            (
                a.centerY() -
                    b.centerY()
                ) /
                height

        return hypot(
            dx,
            dy
        )
    }

    private fun relativeBoxScaleChange(
        baseline: android.graphics.RectF,
        current: android.graphics.RectF
    ): Float {
        val baselineArea =
            (
                baseline.width()
                    .coerceAtLeast(1f) *
                    baseline.height()
                        .coerceAtLeast(1f)
                )
                .coerceAtLeast(
                    1f
                )

        val currentArea =
            (
                current.width()
                    .coerceAtLeast(1f) *
                    current.height()
                        .coerceAtLeast(1f)
                )
                .coerceAtLeast(
                    1f
                )

        return (
            kotlin.math.abs(
                currentArea -
                    baselineArea
            ) /
                baselineArea
            )
            .coerceAtLeast(
                0f
            )
    }

    private fun carCenterMovementThreshold(): Float =
        prefs.getFloat(
            "dvr_car_motion_center_threshold",
            0.015f
        )
            .coerceIn(
                0.006f,
                0.08f
            )

    private fun carScaleMovementThreshold(): Float =
        prefs.getFloat(
            "dvr_car_motion_scale_threshold",
            0.10f
        )
            .coerceIn(
                0.04f,
                0.40f
            )

    /**
     * Returns only car detections that have shown persistent movement.
     *
     * A car must be seen across multiple object-AI frames. Movement is
     * confirmed from cumulative center displacement or bounding-box scale
     * change relative to a short stationary baseline. This deliberately
     * ignores a single jittery detector box.
     */
    private fun movingCarDetections(
        detections:
            List<com.example.aidoormonitor.ai.AnimalDetection>,
        now: Long,
        frameWidth: Int,
        frameHeight: Int
    ): List<com.example.aidoormonitor.ai.AnimalDetection> {
        val cars =
            detections.filter {
                normalizeAiToken(
                    it.label
                ) ==
                    "car" &&
                    it.score >=
                    0.55f
            }

        synchronized(
            carMotionLock
        ) {
            carMotionTracks
                .removeAll {
                    now -
                        it.lastSeenAtMs >
                        2_500L
                }

            movingCarDetected =
                false

            carMotionScore =
                0f

            if (
                now -
                    lastCameraViewChangeAtMs <
                1_500L
            ) {
                carMotionTracks.clear()

                carMotionStatus =
                    "Car motion filter: waiting after camera zoom/pan"

                return emptyList()
            }

            if (cars.isEmpty()) {
                carMotionStatus =
                    "Car motion filter: no car"

                return emptyList()
            }

            val moving =
                mutableListOf<
                    com.example.aidoormonitor.ai.AnimalDetection
                >()

            val unmatchedTracks =
                carMotionTracks
                    .toMutableList()

            cars.forEach {
                    detection ->

                val box =
                    detection.box

                val bestTrack =
                    unmatchedTracks
                        .map { track ->
                            val iou =
                                boxIou(
                                    track.lastBox,
                                    box
                                )

                            val distance =
                                normalizedCenterDistance(
                                    track.lastBox,
                                    box,
                                    frameWidth,
                                    frameHeight
                                )

                            Triple(
                                track,
                                iou,
                                distance
                            )
                        }
                        .filter {
                            it.second >=
                                0.12f ||
                                it.third <=
                                0.12f
                        }
                        .maxByOrNull {
                            it.second -
                                (
                                    it.third *
                                        0.50f
                                    )
                        }
                        ?.first

                val track =
                    if (bestTrack != null) {
                        unmatchedTracks
                            .remove(
                                bestTrack
                            )

                        bestTrack
                    } else {
                        CarMotionTrack(
                            baselineBox =
                                copyBox(
                                    box
                                ),
                            lastBox =
                                copyBox(
                                    box
                                ),
                            baselineAtMs =
                                now,
                            lastSeenAtMs =
                                now
                        ).also {
                            carMotionTracks +=
                                it
                        }
                    }

                val ageMs =
                    now -
                        track.baselineAtMs

                val centerShift =
                    normalizedCenterDistance(
                        track.baselineBox,
                        box,
                        frameWidth,
                        frameHeight
                    )

                val scaleShift =
                    relativeBoxScaleChange(
                        track.baselineBox,
                        box
                    )

                val centerThreshold =
                    carCenterMovementThreshold()

                val scaleThreshold =
                    carScaleMovementThreshold()

                val motionMetric =
                    max(
                        centerShift /
                            centerThreshold,
                        scaleShift /
                            scaleThreshold
                    )

                carMotionScore =
                    max(
                        carMotionScore,
                        motionMetric
                    )

                val movingSample =
                    ageMs >=
                        650L &&
                        (
                            centerShift >=
                                centerThreshold ||
                                scaleShift >=
                                scaleThreshold
                            )

                if (movingSample) {
                    track.movementEvidence =
                        (
                            track.movementEvidence +
                                1
                            )
                            .coerceAtMost(
                                4
                            )
                } else {
                    track.movementEvidence =
                        (
                            track.movementEvidence -
                                1
                            )
                            .coerceAtLeast(
                                0
                            )
                }

                if (
                    track.movementEvidence >=
                    2
                ) {
                    track.movingUntilMs =
                        now +
                            2_000L
                }

                val confirmedMoving =
                    now <=
                        track.movingUntilMs

                if (confirmedMoving) {
                    moving +=
                        detection
                }

                // If the car has remained unconfirmed for a while, refresh
                // the baseline. That absorbs ordinary detector-box jitter
                // instead of allowing it to accumulate forever.
                if (
                    !confirmedMoving &&
                    ageMs >=
                    2_500L
                ) {
                    track.baselineBox =
                        copyBox(
                            box
                        )

                    track.baselineAtMs =
                        now

                    track.movementEvidence =
                        0
                }

                track.lastBox =
                    copyBox(
                        box
                    )

                track.lastSeenAtMs =
                    now
            }

            movingCarDetected =
                moving.isNotEmpty()

            carMotionStatus =
                if (movingCarDetected) {
                    "Car motion filter: MOVING car confirmed"
                } else {
                    "Car motion filter: car present but stationary"
                }

            return moving
        }
    }

    private fun processObjectAiTriggers(
        detections:
            List<com.example.aidoormonitor.ai.AnimalDetection>,
        movingCars:
            List<com.example.aidoormonitor.ai.AnimalDetection>,
        now: Long
    ) {
        if (
            !prefs.getBoolean(
                "dvr_object_trigger_armed",
                true
            )
        ) {
            return
        }

        detections
            .sortedByDescending {
                it.score
            }
            .forEach { detection ->
                val normalized =
                    normalizeAiToken(
                        detection.label
                    )

                val triggerLabel =
                    when (normalized) {
                        "car" ->
                            if (
                                prefs.getBoolean(
                                    "dvr_trigger_car",
                                    true
                                ) &&
                                movingCars.any {
                                    it === detection
                                }
                            ) {
                                "Moving car"
                            } else {
                                null
                            }

                        "bicycle" ->
                            if (
                                prefs.getBoolean(
                                    "dvr_trigger_bicycle",
                                    true
                                )
                            ) {
                                "Bicycle"
                            } else {
                                null
                            }

                        "stroller",
                        "pram",
                        "pushchair",
                        "baby_carriage" ->
                            if (
                                prefs.getBoolean(
                                    "dvr_trigger_stroller",
                                    true
                                )
                            ) {
                                "Stroller"
                            } else {
                                null
                            }

                        else ->
                            null
                    }
                        ?: return@forEach

                val minimumScore =
                    if (
                        normalized ==
                        "stroller" ||
                        normalized ==
                        "pram" ||
                        normalized ==
                        "pushchair" ||
                        normalized ==
                        "baby_carriage"
                    ) {
                        0.50f
                    } else {
                        0.55f
                    }

                if (
                    detection.score <
                    minimumScore
                ) {
                    return@forEach
                }

                val last =
                    objectTriggerCooldown[
                        normalized
                    ] ?: 0L

                if (
                    now - last <
                    6_000L
                ) {
                    return@forEach
                }

                objectTriggerCooldown[
                    normalized
                ] = now

                eventLabeler.recordSignal(
                    normalized,
                    detection.score,
                    now
                )

                lastMotionAt = now

                if (!eventActive) {
                    beginAiTriggeredEvent(
                        label =
                            triggerLabel,
                        eventLogTitle =
                            "Object AI trigger",
                        detail =
                            buildString {
                                append(
                                    "class="
                                )
                                append(
                                    normalized
                                )
                                append(
                                    " • confidence="
                                )
                                append(
                                    String.format(
                                        Locale.US,
                                        "%.2f",
                                        detection.score
                                    )
                                )

                                if (
                                    normalized ==
                                    "car"
                                ) {
                                    append(
                                        " • moving=true • motionScore="
                                    )
                                    append(
                                        String.format(
                                            Locale.US,
                                            "%.2f",
                                            carMotionScore
                                        )
                                    )
                                }
                            }
                    )
                } else {
                    currentAiEventLabel =
                        eventLabeler
                            .currentBestLabel()
                }
            }
    }

    private fun prepareRescuedPetDetections(
        candidates:
            List<com.example.aidoormonitor.ai.AnimalDetection>,
        now: Long,
        frameWidth: Int,
        frameHeight: Int
    ): List<com.example.aidoormonitor.ai.AnimalDetection> {
        if (candidates.isEmpty()) return emptyList()

        val diagonal =
            kotlin.math.hypot(
                frameWidth.toFloat(),
                frameHeight.toFloat()
            ).coerceAtLeast(1f)

        synchronized(petRescueLock) {
            petRescueTracks.removeAll {
                now - it.lastSeenAtMs > 2_200L
            }

            return candidates.mapNotNull { detection ->
                val normalized =
                    normalizeAiToken(
                        detection.label
                    )

                if (
                    normalized != "dog" &&
                    normalized != "cat"
                ) {
                    return@mapNotNull null
                }

                val cx =
                    (detection.box.left +
                        detection.box.right) *
                        0.5f
                val cy =
                    (detection.box.top +
                        detection.box.bottom) *
                        0.5f

                val nearest =
                    petRescueTracks
                        .filter {
                            it.label ==
                                normalized &&
                                now -
                                    it.lastSeenAtMs <=
                                    1_700L
                        }
                        .minByOrNull {
                            kotlin.math.hypot(
                                it.centerX - cx,
                                it.centerY - cy
                            )
                        }

                val track =
                    if (
                        nearest != null &&
                        kotlin.math.hypot(
                            nearest.centerX - cx,
                            nearest.centerY - cy
                        ) <=
                        diagonal * 0.16f
                    ) {
                        nearest.apply {
                            centerX = cx
                            centerY = cy
                            lastSeenAtMs = now
                            hitCount++
                        }
                    } else {
                        PetRescueTrack(
                            label = normalized,
                            centerX = cx,
                            centerY = cy,
                            firstSeenAtMs = now,
                            lastSeenAtMs = now,
                            hitCount = 1
                        ).also {
                            petRescueTracks += it
                        }
                    }

                val rawCombined =
                    detection.score
                        .coerceIn(0f, 1f)

                val promotedScore =
                    when {
                        // A crop can produce a perfectly solid normal dog
                        // detection. Do not force an extra delay in that case.
                        rawCombined >= 0.28f ->
                            rawCombined

                        // Weak small-pet candidates are intentionally kept
                        // below the display threshold on their first frame.
                        // The first hit still enters DvrEventLabeler and thus
                        // becomes temporal evidence for the next pass.
                        track.hitCount < 2 ->
                            rawCombined
                                .coerceAtMost(0.219f)

                        // A repeated candidate plus a visible leash-like line
                        // is stronger evidence, but the leash can never create
                        // a pet on its own.
                        detection.leashEvidence >= 0.42f ->
                            kotlin.math.max(
                                rawCombined,
                                0.27f
                            )

                        track.hitCount >= 3 ->
                            kotlin.math.max(
                                rawCombined,
                                0.25f
                            )

                        else ->
                            kotlin.math.max(
                                rawCombined,
                                0.23f
                            )
                    }

                detection.copy(
                    score = promotedScore,
                    source =
                        if (track.hitCount >= 2) {
                            "tile_confirmed"
                        } else {
                            "tile_candidate"
                        }
                )
            }
        }
    }

    private fun analyzeJpegForEventNaming(
        jpeg: ByteArray
    ) {
        val detector =
            objectDetector
        val customDetector =
            customObjectDetector

        if (
            detector == null &&
            customDetector == null
        ) {
            return
        }

        val now =
            System.currentTimeMillis()

        // Base naming AI runs around 2 fps. The tiled pet-rescue pass has its
        // own slower limiter so a missed small dog does not multiply CPU load
        // on every frame.
        if (now - lastObjectAiAt < 500L) return
        if (!objectAiBusy.compareAndSet(false, true)) return

        lastObjectAiAt = now

        objectAiExecutor.execute {
            var bitmap: android.graphics.Bitmap? = null

            try {
                bitmap =
                    BitmapFactory.decodeByteArray(
                        jpeg,
                        0,
                        jpeg.size
                    )

                val frame =
                    bitmap ?: return@execute

                val firstPassDetections =
                    buildList {
                        detector
                            ?.analyze(frame)
                            ?.let {
                                addAll(it)
                            }

                        customDetector
                            ?.analyze(frame)
                            ?.let {
                                addAll(it)
                            }
                    }
                        .sortedByDescending {
                            it.score
                        }
                        .distinctBy {
                            normalizeAiToken(
                                it.label
                            ) +
                                ":" +
                                (
                                    it.box.left /
                                    32f
                                    ).toInt() +
                                ":" +
                                (
                                    it.box.top /
                                    32f
                                    ).toInt()
                        }
                        .take(12)

                val people =
                    firstPassDetections
                        .filter {
                            normalizeAiToken(
                                it.label
                            ) == "person"
                        }

                val alreadyHasPet =
                    firstPassDetections.any {
                        val n =
                            normalizeAiToken(
                                it.label
                            )
                        n == "dog" ||
                            n == "cat"
                    }

                // Important: do not assume the pet is at the person's feet.
                // Four overlapping tiles scan the whole frame, so a dog can
                // be well in front of, behind, or beside its owner.
                val rescuedPets =
                    if (
                        detector != null &&
                        people.isNotEmpty() &&
                        !alreadyHasPet
                    ) {
                        prepareRescuedPetDetections(
                            candidates =
                                detector
                                    .analyzeSmallPetBoost(
                                        frame,
                                        people
                                    ),
                            now = now,
                            frameWidth = frame.width,
                            frameHeight = frame.height
                        )
                    } else {
                        emptyList()
                    }

                val detections =
                    (firstPassDetections +
                        rescuedPets)
                        .sortedByDescending {
                            it.score
                        }
                        .distinctBy {
                            normalizeAiToken(
                                it.label
                            ) +
                                ":" +
                                (
                                    (
                                        it.box.left +
                                        it.box.right
                                    ) /
                                    80f
                                    ).toInt() +
                                ":" +
                                (
                                    (
                                        it.box.top +
                                        it.box.bottom
                                    ) /
                                    80f
                                    ).toInt()
                        }
                        .take(14)

                val movingCars =
                    movingCarDetections(
                        detections =
                            detections,
                        now =
                            now,
                        frameWidth =
                            frame.width,
                        frameHeight =
                            frame.height
                    )

                processObjectAiTriggers(
                    detections =
                        detections,
                    movingCars =
                        movingCars,
                    now =
                        now
                )

                val namingDetections =
                    detections
                        .filter {
                            detection ->
                            val normalized =
                                normalizeAiToken(
                                    detection.label
                                )

                            normalized !=
                                "car" ||
                                movingCars.any {
                                    it ===
                                        detection
                                }
                        }

                namingDetections
                    // Keep enough slots for Person + one or more smaller pets.
                    .take(12)
                    .forEach {
                            detection ->
                        eventLabeler.recordSignal(
                            detection.label,
                            detection.score,
                            now
                        )
                    }

                if (
                    rescuedPets.any {
                        it.source ==
                            "tile_confirmed"
                    }
                ) {
                    val rescuedSummary =
                        rescuedPets
                            .filter {
                                it.source ==
                                    "tile_confirmed"
                            }
                            .joinToString(
                                ", "
                            ) {
                                buildString {
                                    append(it.label)
                                    append(" ")
                                    append(
                                        String.format(
                                            Locale.US,
                                            "%.2f",
                                            it.score
                                        )
                                    )
                                    if (
                                        it.leashEvidence >
                                        0.05f
                                    ) {
                                        append(" leash=")
                                        append(
                                            String.format(
                                                Locale.US,
                                                "%.2f",
                                                it.leashEvidence
                                            )
                                        )
                                    }
                                }
                            }

                    if (
                        rescuedSummary.isNotBlank() &&
                        now - lastPetRescueLogAtMs >=
                        5_000L
                    ) {
                        lastPetRescueLogAtMs = now
                        eventStore.add(
                            "Small pet AI",
                            "Recovered: $rescuedSummary"
                        )
                    }
                }

                if (
                    eventActive &&
                    namingDetections
                        .isNotEmpty()
                ) {
                    currentAiEventLabel =
                        eventLabeler
                            .currentBestLabel()
                }

            } catch (t: Throwable) {
                eventStore.add(
                    "DVR naming AI warning",
                    t.message
                        ?: t.javaClass.simpleName
                )
            } finally {
                try {
                    bitmap?.recycle()
                } catch (_: Throwable) {
                }

                objectAiBusy.set(false)
            }
        }
    }

    private fun processMotionScore(
        score: Float,
        now: Long
    ) {
        eventLabeler.recordSignal(
            "motion",
            (score / 20f).coerceIn(0.20f, 0.90f),
            now
        )

        // Conservative rapid-motion heuristic. This only emits the
        // fast_toward_door signal at unusually high frame-to-frame motion.
        // A custom/built-in TRAJECTORY rule can use it for naming, but it is
        // intentionally treated as a possible throw rather than certainty.
        if (score >= 22f) {
            eventLabeler.recordSignal(
                "fast_toward_door",
                (score / 35f).coerceIn(0.70f, 0.95f),
                now
            )
        }

        if (
            !prefs.getBoolean(
                "dvr_motion_armed",
                true
            )
        ) {
            highMotionFrames = 0
            return
        }

        val sensitivity =
            prefs.getInt(
                "dvr_motion_sensitivity",
                65
            )

        val threshold =
            motionAnalyzer
                .thresholdForSensitivity(
                    sensitivity
                )

        if (score >= threshold) {
            highMotionFrames++
        } else {
            highMotionFrames =
                (highMotionFrames - 1)
                    .coerceAtLeast(0)
        }

        if (highMotionFrames >= 2) {
            lastMotionAt = now

            if (!eventActive) {
                beginMotionEvent(
                    manual = false
                )
            }
        }
    }

    private fun beginMotionEvent(
        manual: Boolean
    ) {
        eventActive = true
        manualEventRequested = manual
        lastMotionAt =
            System.currentTimeMillis()
        eventRecordingStartedAtMs =
            lastMotionAt

        eventId =
            SimpleDateFormat(
                "yyyyMMdd_HHmmss",
                Locale.US
            ).format(lastMotionAt)

        eventSegments.clear()

        eventLabeler.beginEvent(
            preRecordSeconds = preRecordSeconds(),
            manual = manual
        )
        currentAiEventLabel =
            if (manual) "Manual" else "Motion"

        completedSegments
            .filter {
                it.exists() &&
                    it.length() > 0L
            }
            .forEach {
                eventSegments += it
            }

        eventVideoStartAtMs =
            resolveEventVideoStartAtMs()

        if (
            recordAudioInVideos()
        ) {
            sharedAudioEngine
                ?.beginEventAt(
                    eventVideoStartAtMs
                )
        }

        eventStore.add(
            if (manual)
                "Manual DVR save"
            else
                "Motion AI detected",
            "pre-record buffer=${completedPrebufferSeconds}s • score=${String.format(Locale.US, "%.2f", motionScore)}"
        )

        statusText =
            if (manual) {
                "Saving DVR event • pre-record included"
            } else {
                "MOTION • $currentAiEventLabel • pre-record included"
            }

        updateNotification(
            if (manual)
                "Saving DVR event"
            else
                "Motion detected • event recording"
        )
    }

    private fun triggerManualEvent() {
        if (!eventActive) {
            beginMotionEvent(
                manual = true
            )
        } else {
            lastMotionAt =
                System.currentTimeMillis()
        }
    }

    private fun onSegmentCompleted(
        file: File
    ) {
        if (!file.exists() || file.length() <= 0L) {
            try {
                file.delete()
            } catch (_: Throwable) {
            }
            return
        }

        completedSegments.addLast(
            file
        )

        if (eventActive) {
            if (!eventSegments.contains(file)) {
                eventSegments += file
            }

            val quietLongEnough =
                System.currentTimeMillis() -
                    lastMotionAt >=
                    postRecordSeconds() *
                    1_000L

            if (quietLongEnough) {
                finishMotionEvent()
                return
            }
        }

        trimPreRecordBuffer()
    }

    private fun trimPreRecordBuffer() {
        val keepSegments =
            ceil(
                preRecordSeconds()
                    .toDouble() /
                    SEGMENT_SECONDS.toDouble()
            )
                .toInt()
                .coerceAtLeast(1)

        while (
            completedSegments.size >
            keepSegments
        ) {
            val old =
                completedSegments
                    .removeFirst()

            if (
                !eventActive ||
                !eventSegments.contains(old)
            ) {
                segmentStartedAtMs
                    .remove(
                        old.absolutePath
                    )

                try {
                    old.delete()
                } catch (_: Throwable) {
                }
            }
        }

        completedPrebufferSeconds =
            (
                completedSegments.size *
                    SEGMENT_SECONDS
                )
                .coerceAtMost(
                    preRecordSeconds() +
                        SEGMENT_SECONDS
                )
    }

    private fun finishMotionEvent() {
        if (!eventActive) return

        val files =
            eventSegments
                .distinct()
                .filter {
                    it.exists() &&
                        it.length() > 0L
                }

        val aiName =
            eventLabeler.endEventAndChooseName()

        currentAiEventLabel =
            aiName.displayLabel

        val name =
            "AI_Door_${aiName.filenameLabel}_${eventId}.mp4"

        val eventFolder =
            eventFolderForLabel(
                aiName.displayLabel
            )

        lastSavedEventName = name

        val capturedAudio:
            DvrCapturedAudio? =
            if (
                recordAudioInVideos()
            ) {
                sharedAudioEngine
                    ?.finishEvent()
            } else {
                null
            }

        val finalEventVideoStartAtMs =
            eventVideoStartAtMs

        eventActive = false
        eventRecordingStartedAtMs = 0L
        manualEventRequested = false
        eventSegments.clear()
        completedSegments.clear()
        completedPrebufferSeconds = 0
        eventVideoStartAtMs = 0L

        statusText =
            "Saving motion event…"

        ioExecutor.execute {
            val uri =
                try {
                    Mp4SegmentMerger
                        .mergeToMediaStore(
                            context = this,
                            segments = files,
                            displayName = name,
                            eventFolder =
                                eventFolder,
                            capturedAudio =
                                capturedAudio,
                            videoStartAtMs =
                                finalEventVideoStartAtMs,
                            audioBitrateBps =
                                audioBitrateBps(),
                            audioAdvanceMs =
                                audioAdvanceMs()
                        )
                } catch (t: Throwable) {
                    eventStore.add(
                        "DVR event save failed",
                        t.message
                            ?: t.javaClass.simpleName
                    )
                    null
                }

            files.forEach { file ->
                segmentStartedAtMs
                    .remove(
                        file.absolutePath
                    )

                try {
                    file.delete()
                } catch (_: Throwable) {
                }
            }

            if (uri != null) {
                eventStore.add(
                    "AI-named motion video saved",
                    buildString {
                        append(
                            "$name • folder=$eventFolder • label=${aiName.displayLabel}"
                        )
                        append(
                            " • signals=${aiName.matchedSignals.joinToString(",")}"
                        )
                        if (
                            aiName.evidenceSummary
                                .isNotBlank()
                        ) {
                            append(
                                " • evidence="
                            )
                            append(
                                aiName.evidenceSummary
                            )
                        }
                        append(
                            " • ${files.size} rolling segment(s)"
                        )
                        append(
                            " • PCM captured=${capturedAudio != null}"
                        )
                        append(
                            " • final MP4 audio=${Mp4SegmentMerger.lastOutputHasAudio}"
                        )
                        append(
                            " • ${Mp4SegmentMerger.lastAudioMuxStatus}"
                        )
                    }
                )

                statusText =
                    if (
                        recordAudioInVideos() &&
                        !Mp4SegmentMerger
                            .lastOutputHasAudio
                    ) {
                        "DVR armed • video saved • AUDIO MUX FAILED"
                    } else {
                        "DVR armed • last motion video saved"
                    }
            } else {
                statusText =
                    "DVR armed • event merge failed"
            }

            updateNotification(
                "DVR armed • $activeRecordingSize"
            )
        }
    }

    private fun sanitizeEventFolderName(
        raw: String
    ): String =
        raw
            .trim()
            .replace(
                Regex("[\\\\/:*?\"<>|]+"),
                "_"
            )
            .replace(
                Regex("\\s+"),
                " "
            )
            .trim()
            .take(48)
            .ifBlank {
                "Other"
            }

    private fun eventFolderForLabel(
        rawLabel: String
    ): String {
        val value =
            rawLabel
                .trim()
                .lowercase(
                    Locale.US
                )

        return when {
            value.contains("dog") ||
                value.contains("bark") ||
                value.contains("growl") ->
                "Dog"

            value.contains("cat") ->
                "Cat"

            value.contains("moving car") ||
                value == "car" ||
                value.startsWith("car ") ->
                "Car"

            value.contains("person") ->
                "Person"

            value.contains("bicycle") ||
                value.contains("bike") ->
                "Bicycle"

            value.contains("motorcycle") ->
                "Motorcycle"

            value.contains("truck") ->
                "Truck"

            value.contains("bird") ->
                "Bird"

            value.contains("stroller") ||
                value.contains("barnevogn") ||
                value.contains("pram") ||
                value.contains("pushchair") ||
                value.contains("baby carriage") ->
                "Stroller"

            value.contains("package") ||
                value.contains("parcel") ->
                "Package"

            value.contains("shouting") ||
                value.contains("impact") ||
                value.contains("knock") ||
                value.contains("crash") ->
                "Sound"

            value == "motion" ||
                value.startsWith("motion ") ->
                "Motion"

            value == "manual" ||
                value.startsWith("manual ") ->
                "Manual"

            else ->
                // A custom AI label gets its own folder.
                sanitizeEventFolderName(
                    rawLabel
                )
        }
    }

    private fun restartAfterRecorderFailure() {
        if (stopping) return

        try {
            mediaRecorder?.stop()
        } catch (_: Throwable) {
        }

        currentSegment
            ?.takeIf {
                it.exists() &&
                    it.length() > 0L
            }
            ?.let {
                onSegmentCompleted(it)
            }

        closeSessionOnly()

        cameraHandler?.postDelayed({
            configureRecorderAndSession()
        }, 350L)
    }

    private fun closeSessionOnly() {
        try {
            captureSession?.stopRepeating()
        } catch (_: Throwable) {
        }

        try {
            captureSession?.close()
        } catch (_: Throwable) {
        }
        captureSession = null
        repeatingRequestBuilder = null

        if (recorderStarted) {
            try {
                mediaRecorder?.stop()
            } catch (_: Throwable) {
            }
        }

        recorderStarted = false

        try {
            mediaRecorder?.reset()
        } catch (_: Throwable) {
        }
        try {
            mediaRecorder?.release()
        } catch (_: Throwable) {
        }
        mediaRecorder = null

        try {
            gpuPreview?.close()
        } catch (_: Throwable) {
        }
        gpuPreview = null

        nextSegment
            ?.let {
                try {
                    it.delete()
                } catch (_: Throwable) {
                }
            }
        nextSegment = null
    }

    private fun stopCameraResources(
        deleteUnprotected: Boolean
    ) {
        cameraOpening = false
        closeSessionOnly()

        try {
            cameraDevice?.close()
        } catch (_: Throwable) {
        }
        cameraDevice = null

        if (deleteUnprotected) {
            completedSegments.forEach {
                try {
                    it.delete()
                } catch (_: Throwable) {
                }
            }
            completedSegments.clear()

            currentSegment?.let {
                try {
                    it.delete()
                } catch (_: Throwable) {
                }
            }

            currentSegment = null
            completedPrebufferSeconds = 0
        }
    }

    private fun failCamera(message: String) {
        lastError = message
        statusText = message

        eventStore.add(
            "DVR camera error",
            message
        )

        updateNotification(
            message.take(80)
        )
    }

    private fun resolveCameraId(): String {
        val ids =
            cameraManager.cameraIdList

        val key =
            prefs.getString(
                "camera_choice_key",
                CameraChoiceRepository
                    .DEFAULT_BACK_KEY
            )
                ?: CameraChoiceRepository
                    .DEFAULT_BACK_KEY

        if (key.startsWith("camera_id:")) {
            val wanted =
                key.removePrefix(
                    "camera_id:"
                )
            if (ids.contains(wanted)) {
                return wanted
            }
        }

        val wantedFacing =
            if (
                key ==
                CameraChoiceRepository
                    .DEFAULT_FRONT_KEY
            ) {
                CameraCharacteristics
                    .LENS_FACING_FRONT
            } else {
                CameraCharacteristics
                    .LENS_FACING_BACK
            }

        return ids.firstOrNull { id ->
            try {
                cameraManager
                    .getCameraCharacteristics(
                        id
                    )
                    .get(
                        CameraCharacteristics
                            .LENS_FACING
                    ) == wantedFacing
            } catch (_: Throwable) {
                false
            }
        }
            ?: ids.firstOrNull()
            ?: throw IllegalStateException(
                "No camera IDs"
            )
    }

    /**
     * v0.5 quality schema:
     * 0 = 8K, 1 = 4K, 2 = 1080p.
     */
    private fun recordingQualityMode(): Int {
        val raw =
            prefs.getInt(
                "dvr_quality",
                1
            )

        return if (
            prefs.getBoolean(
                "dvr_quality_schema_8k",
                false
            )
        ) {
            raw.coerceIn(
                0,
                2
            )
        } else {
            when (
                raw.coerceIn(
                    0,
                    1
                )
            ) {
                0 -> 1
                else -> 2
            }
        }
    }

    private fun is8KSize(
        size: Size
    ): Boolean {
        val longSide =
            maxOf(
                size.width,
                size.height
            )

        val shortSide =
            minOf(
                size.width,
                size.height
            )

        return (
            longSide >=
            7_680 &&
            shortSide >=
            4_320
            )
    }

    private fun recordingFps(): Int =
        if (
            is8KSize(
                recordingSize
            )
        ) {
            24
        } else {
            30
        }

    private fun chooseRecordingSize(
        sizes: List<Size>
    ): Size {
        if (sizes.isEmpty()) {
            throw IllegalStateException(
                "Camera exposes no MediaRecorder sizes."
            )
        }

        activeQualityFallback =
            ""

        val quality =
            recordingQualityMode()

        val exact8K =
            sizes.firstOrNull {
                (
                    it.width ==
                    7_680 &&
                    it.height ==
                    4_320
                    ) ||
                    (
                        it.width ==
                        4_320 &&
                        it.height ==
                        7_680
                        )
            }

        val any8K =
            sizes
                .filter {
                    is8KSize(it)
                }
                .sortedByDescending {
                    it.width
                        .toLong() *
                        it.height
                            .toLong()
                }
                .firstOrNull()

        val exact4K =
            sizes.firstOrNull {
                it.width ==
                    3_840 &&
                    it.height ==
                    2_160
            }

        val exact1080 =
            sizes.firstOrNull {
                it.width ==
                    1_920 &&
                    it.height ==
                    1_080
            }

        val best1080OrBelow =
            sizes
                .filter {
                    it.width <=
                        1_920 &&
                    it.height <=
                        1_080
                }
                .maxByOrNull {
                    it.width.toLong() *
                        it.height.toLong()
                }

        if (quality == 0) {
            val eightK =
                exact8K
                    ?: any8K

            if (eightK != null) {
                return eightK
            }

            if (exact4K != null) {
                activeQualityFallback =
                    "8K requested but Camera2 camera $selectedCameraId does not expose 7680×4320 • automatically using 3840×2160 4K"

                eventStore.add(
                    "8K unavailable • 4K fallback",
                    activeQualityFallback
                )

                return exact4K
            }

            val fallback =
                exact1080
                    ?: best1080OrBelow
                    ?: sizes.maxBy {
                        it.width.toLong() *
                            it.height.toLong()
                    }

            activeQualityFallback =
                "8K requested but unavailable on Camera2 camera $selectedCameraId • automatically using ${fallback.width}×${fallback.height}"

            eventStore.add(
                "8K unavailable • resolution fallback",
                activeQualityFallback
            )

            return fallback
        }

        if (quality == 1) {
            if (exact4K != null) {
                return exact4K
            }

            val fallback =
                exact1080
                    ?: best1080OrBelow
                    ?: sizes.maxBy {
                        it.width.toLong() *
                            it.height.toLong()
                    }

            activeQualityFallback =
                "4K requested but Camera2 camera $selectedCameraId does not expose 3840×2160 • automatically using ${fallback.width}×${fallback.height}"

            eventStore.add(
                "4K unavailable • resolution fallback",
                activeQualityFallback
            )

            return fallback
        }

        return exact1080
            ?: best1080OrBelow
            ?: sizes.maxBy {
                it.width.toLong() *
                    it.height.toLong()
            }
    }

    private fun choosePreviewCandidates(
        sizes: List<Size>
    ): List<Size> {
        if (sizes.isEmpty()) return emptyList()

        val targets =
            listOf(
                1280 to 720,
                960 to 540,
                640 to 480,
                640 to 360,
                320 to 240
            )

        val result =
            mutableListOf<Size>()

        fun distance(
            s: Size,
            tw: Int,
            th: Int
        ): Long {
            val aspect =
                abs(
                    s.width.toDouble() /
                        s.height.toDouble() -
                        tw.toDouble() /
                        th.toDouble()
                )

            val pixels =
                abs(
                    s.width.toLong() *
                        s.height.toLong() -
                        tw.toLong() *
                        th.toLong()
                )

            return (
                aspect * 100_000_000.0
                ).toLong() + pixels
        }

        targets.forEach { (tw, th) ->
            sizes
                .filter {
                    it.width <= 1920 &&
                        it.height <= 1080
                }
                .minByOrNull {
                    distance(
                        it,
                        tw,
                        th
                    )
                }
                ?.let {
                    if (
                        result.none { old ->
                            old.width == it.width &&
                                old.height == it.height
                        }
                    ) {
                        result += it
                    }
                }
        }

        return result
    }

    private fun updateCameraViewCapability() {
        val chars =
            characteristics

        sensorActiveArray =
            chars?.get(
                CameraCharacteristics
                    .SENSOR_INFO_ACTIVE_ARRAY_SIZE
            )

        val legacyMax =
            (
                chars?.get(
                    CameraCharacteristics
                        .SCALER_AVAILABLE_MAX_DIGITAL_ZOOM
                )
                    ?: 1f
                )
                .coerceAtLeast(
                    1f
                )

        zoomRatioApiSupported =
            false

        minZoomRatio =
            1f

        maxZoomRatio =
            legacyMax

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.R
        ) {
            val zoomRange =
                try {
                    chars?.get(
                        CameraCharacteristics
                            .CONTROL_ZOOM_RATIO_RANGE
                    )
                } catch (_: Throwable) {
                    null
                }

            if (
                zoomRange != null &&
                zoomRange.upper >
                1.001f
            ) {
                zoomRatioApiSupported =
                    true

                minZoomRatio =
                    1f.coerceIn(
                        zoomRange.lower,
                        zoomRange.upper
                    )

                maxZoomRatio =
                    zoomRange.upper
                        .coerceAtLeast(
                            minZoomRatio
                        )
            }
        }

        val cropType =
            chars?.get(
                CameraCharacteristics
                    .SCALER_CROPPING_TYPE
            )
                ?: CameraMetadata
                    .SCALER_CROPPING_TYPE_CENTER_ONLY

        freeformCropSupported =
            cropType ==
                CameraMetadata
                    .SCALER_CROPPING_TYPE_FREEFORM

        cameraZoomLinear =
            prefs.getFloat(
                "dvr_camera_zoom_linear",
                prefs.getFloat(
                    "camera_zoom_linear",
                    0f
                )
            )
                .coerceIn(0f, 1f)

        cameraPanX =
            prefs.getFloat(
                "dvr_camera_pan_x",
                prefs.getFloat(
                    "camera_pan_x",
                    0f
                )
            )
                .coerceIn(-1f, 1f)

        cameraPanY =
            prefs.getFloat(
                "dvr_camera_pan_y",
                prefs.getFloat(
                    "camera_pan_y",
                    0f
                )
            )
                .coerceIn(-1f, 1f)

        if (
            cameraZoomLinear <=
            0.001f
        ) {
            cameraZoomLinear =
                0f
            cameraPanX =
                0f
            cameraPanY =
                0f
        }

        appliedZoomRatio =
            currentZoomRatio()

        zoomControlMode =
            if (
                zoomRatioApiSupported
            ) {
                "CONTROL_ZOOM_RATIO"
            } else {
                "SCALER_CROP_REGION"
            }

        eventStore.add(
            "DVR camera zoom capability",
            buildString {
                append(
                    "Camera "
                )
                append(
                    selectedCameraId
                )
                append(
                    " • control="
                )
                append(
                    zoomControlMode
                )
                append(
                    " • range="
                )
                append(
                    String.format(
                        Locale.US,
                        "%.2f×..%.2f×",
                        minZoomRatio,
                        maxZoomRatio
                    )
                )
                append(
                    " • crop="
                )
                append(
                    if (
                        freeformCropSupported
                    ) {
                        "FREEFORM"
                    } else {
                        "CENTER_ONLY"
                    }
                )

                val active =
                    sensorActiveArray

                if (active != null) {
                    append(
                        " • activeArray="
                    )
                    append(
                        active.width()
                    )
                    append("×")
                    append(
                        active.height()
                    )
                }
            }
        )
    }

    private fun currentZoomRatio(): Float =
        if (
            maxZoomRatio <=
            minZoomRatio +
                0.001f
        ) {
            minZoomRatio
        } else {
            (
                minZoomRatio +
                    cameraZoomLinear *
                    (
                        maxZoomRatio -
                            minZoomRatio
                        )
                )
                .coerceIn(
                    minZoomRatio,
                    maxZoomRatio
                )
        }

    private fun evenAtLeastTwo(
        value: Int
    ): Int {
        val safe =
            value.coerceAtLeast(2)

        return if (
            safe % 2 == 0
        ) {
            safe
        } else {
            (safe - 1)
                .coerceAtLeast(2)
        }
    }

    private fun alignEven(
        value: Int
    ): Int =
        if (
            value % 2 == 0
        ) {
            value
        } else {
            value - 1
        }

    private fun applyCameraViewSettingsToBuilder(
        builder: CaptureRequest.Builder
    ) {
        val active =
            sensorActiveArray
                ?: return

        val zoom =
            currentZoomRatio()

        val wantsPan =
            freeformCropSupported &&
                zoom > 1.001f &&
                (
                    kotlin.math.abs(
                        cameraPanX
                    ) >
                    0.001f ||
                    kotlin.math.abs(
                        cameraPanY
                    ) >
                    0.001f
                    )

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.R &&
            zoomRatioApiSupported &&
            !wantsPan
        ) {
            try {
                builder.set(
                    CaptureRequest
                        .CONTROL_ZOOM_RATIO,
                    zoom
                )

                builder.set(
                    CaptureRequest
                        .SCALER_CROP_REGION,
                    active
                )

                zoomControlMode =
                    "CONTROL_ZOOM_RATIO"

                return
            } catch (_: Throwable) {
            }
        }

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.R
        ) {
            try {
                builder.set(
                    CaptureRequest
                        .CONTROL_ZOOM_RATIO,
                    1f
                )
            } catch (_: Throwable) {
            }
        }

        zoomControlMode =
            "SCALER_CROP_REGION"

        if (
            zoom <= 1.001f
        ) {
            builder.set(
                CaptureRequest
                    .SCALER_CROP_REGION,
                active
            )
            return
        }

        val cropWidth =
            evenAtLeastTwo(
                (
                    active.width()
                        .toFloat() /
                        zoom
                    )
                    .toInt()
                    .coerceAtMost(
                        active.width()
                    )
            )

        val cropHeight =
            evenAtLeastTwo(
                (
                    active.height()
                        .toFloat() /
                        zoom
                    )
                    .toInt()
                    .coerceAtMost(
                        active.height()
                    )
            )

        val availableX =
            (
                active.width() -
                    cropWidth
                )
                .coerceAtLeast(0)

        val availableY =
            (
                active.height() -
                    cropHeight
                )
                .coerceAtLeast(0)

        val effectivePanX =
            if (
                freeformCropSupported
            ) {
                cameraPanX
            } else {
                0f
            }

        val effectivePanY =
            if (
                freeformCropSupported
            ) {
                cameraPanY
            } else {
                0f
            }

        var left =
            active.left +
                (
                    availableX *
                        (
                            effectivePanX +
                                1f
                            ) /
                        2f
                    )
                    .toInt()

        var top =
            active.top +
                (
                    availableY *
                        (
                            effectivePanY +
                                1f
                            ) /
                        2f
                    )
                    .toInt()

        left =
            alignEven(
                left
            )
                .coerceIn(
                    active.left,
                    active.right -
                        cropWidth
                )

        top =
            alignEven(
                top
            )
                .coerceIn(
                    active.top,
                    active.bottom -
                        cropHeight
                )

        builder.set(
            CaptureRequest
                .SCALER_CROP_REGION,
            Rect(
                left,
                top,
                left +
                    cropWidth,
                top +
                    cropHeight
            )
        )
    }

    private fun scheduleCameraViewApply() {
        val handler =
            cameraHandler
                ?: return

        handler.removeCallbacks(
            cameraViewApplyRunnable
        )

        handler.postDelayed(
            cameraViewApplyRunnable,
            35L
        )
    }

    private fun applyCameraViewToActiveSession() {
        val session =
            captureSession
                ?: return

        val builder =
            repeatingRequestBuilder
                ?: return

        try {
            applyCameraViewSettingsToBuilder(
                builder
            )

            session.setRepeatingRequest(
                builder.build(),
                repeatingCaptureCallback,
                cameraHandler
            )

            val ratio =
                currentZoomRatio()

            statusText =
                buildString {
                    append(
                        "DVR armed • Remote zoom "
                    )
                    append(
                        String.format(
                            Locale.US,
                            "%.2f×",
                            ratio
                        )
                    )

                    if (
                        freeformCropSupported &&
                        ratio > 1.001f
                    ) {
                        append(
                            " • pan "
                        )
                        append(
                            String.format(
                                Locale.US,
                                "X %.0f%% / Y %.0f%%",
                                cameraPanX *
                                    100f,
                                cameraPanY *
                                    100f
                            )
                        )
                    }
                }

        } catch (t: Throwable) {
            lastError =
                "Camera zoom failed: " +
                    (
                        t.message
                            ?: t.javaClass
                                .simpleName
                        )

            eventStore.add(
                "Remote camera zoom failed",
                lastError
            )
        }
    }

    private fun updateManualFocusCapability() {
        val chars = characteristics

        maxFocusDiopters =
            chars?.get(
                CameraCharacteristics
                    .LENS_INFO_MINIMUM_FOCUS_DISTANCE
            ) ?: 0f

        val afModes =
            chars?.get(
                CameraCharacteristics
                    .CONTROL_AF_AVAILABLE_MODES
            ) ?: intArrayOf()

        val capabilities =
            chars?.get(
                CameraCharacteristics
                    .REQUEST_AVAILABLE_CAPABILITIES
            ) ?: intArrayOf()

        val hasManualSensor =
            capabilities.contains(
                CameraCharacteristics
                    .REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR
            )

        val hasAfOff =
            afModes.contains(
                CaptureRequest.CONTROL_AF_MODE_OFF
            )

        manualFocusSupported =
            maxFocusDiopters > 0f &&
                hasManualSensor &&
                hasAfOff

        focusLinear =
            prefs.getFloat(
                "dvr_focus_linear",
                prefs.getFloat(
                    "focus_linear",
                    0f
                )
            ).coerceIn(0f, 1f)

        focusManual =
            manualFocusSupported &&
                prefs.getBoolean(
                    "dvr_focus_manual",
                    prefs.getBoolean(
                        "focus_manual",
                        false
                    )
                )

        eventStore.add(
            "DVR focus capability",
            if (manualFocusSupported) {
                "Camera $selectedCameraId supports remote manual focus • max ${String.format(Locale.US, "%.2f", maxFocusDiopters)} D"
            } else {
                "Camera $selectedCameraId reports no usable manual Camera2 lens focus • minFocus=$maxFocusDiopters • manualSensor=$hasManualSensor • afOff=$hasAfOff"
            }
        )
    }

    private fun preferredAutoFocusMode(): Int {
        val afModes =
            characteristics?.get(
                CameraCharacteristics
                    .CONTROL_AF_AVAILABLE_MODES
            ) ?: intArrayOf()

        return when {
            afModes.contains(
                CaptureRequest
                    .CONTROL_AF_MODE_CONTINUOUS_VIDEO
            ) ->
                CaptureRequest
                    .CONTROL_AF_MODE_CONTINUOUS_VIDEO

            afModes.contains(
                CaptureRequest
                    .CONTROL_AF_MODE_CONTINUOUS_PICTURE
            ) ->
                CaptureRequest
                    .CONTROL_AF_MODE_CONTINUOUS_PICTURE

            afModes.contains(
                CaptureRequest.CONTROL_AF_MODE_AUTO
            ) ->
                CaptureRequest.CONTROL_AF_MODE_AUTO

            else ->
                CaptureRequest.CONTROL_AF_MODE_OFF
        }
    }

    private fun applyFocusSettingsToBuilder(
        builder: CaptureRequest.Builder
    ) {
        if (
            manualFocusSupported &&
            focusManual
        ) {
            builder.set(
                CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_OFF
            )

            builder.set(
                CaptureRequest.LENS_FOCUS_DISTANCE,
                (
                    focusLinear *
                        maxFocusDiopters
                    ).coerceIn(
                        0f,
                        maxFocusDiopters
                    )
            )
        } else {
            builder.set(
                CaptureRequest.CONTROL_AF_MODE,
                preferredAutoFocusMode()
            )

            // Do not keep a stale manual diopter request when returning
            // to autofocus. AF owns the lens again.
            try {
                builder.set(
                    CaptureRequest.LENS_FOCUS_DISTANCE,
                    null
                )
            } catch (_: Throwable) {
            }
        }
    }

    private fun scheduleFocusApply() {
        val handler = cameraHandler ?: return
        handler.removeCallbacks(
            focusApplyRunnable
        )
        handler.postDelayed(
            focusApplyRunnable,
            35L
        )
    }

    private fun applyFocusToActiveSession() {
        val session = captureSession
            ?: return
        val builder = repeatingRequestBuilder
            ?: return

        try {
            applyFocusSettingsToBuilder(
                builder
            )

            session.setRepeatingRequest(
                builder.build(),
                repeatingCaptureCallback,
                cameraHandler
            )

            statusText =
                if (
                    manualFocusSupported &&
                    focusManual
                ) {
                    val diopters =
                        focusLinear *
                            maxFocusDiopters
                    "DVR armed • Manual focus ${String.format(Locale.US, "%.2f", diopters)} D"
                } else {
                    "DVR armed • Auto focus"
                }

        } catch (t: Throwable) {
            lastError =
                "Focus control failed: " +
                    (t.message ?: t.javaClass.simpleName)

            eventStore.add(
                "Remote focus failed",
                lastError
            )
        }
    }

    private fun bestRecordingFpsRange(
        targetFps: Int
    ): Range<Int>? {
        val ranges =
            characteristics
                ?.get(
                    CameraCharacteristics
                        .CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES
                )
                ?: return null

        return ranges
            .filter {
                it.lower <=
                    targetFps &&
                    it.upper >=
                    targetFps
            }
            .minByOrNull {
                (
                    targetFps -
                        it.lower
                    ) +
                    (
                        it.upper -
                            targetFps
                        )
            }
            ?: ranges.minByOrNull {
                kotlin.math.abs(
                    it.upper -
                        targetFps
                ) +
                    kotlin.math.abs(
                        it.lower -
                            targetFps
                    )
            }
    }

    /**
     * Rotation preference semantics in v0.5.3:
     *
     * -1  = Auto: use Android sensor/display orientation math.
     *  0  = Direct output correction 0°. This is the canonical UPRIGHT
     *       position: phone top upward, USB/charger toward the floor.
     * 90  = Rotate output 90° clockwise.
     * 180 = Rotate output 180°.
     * 270 = Rotate output 270° clockwise (= 90° counter-clockwise).
     *
     * Manual values are no longer interpreted as "physical device rotation".
     * They are applied directly and identically to the MP4 orientation hint
     * and the LAN/GPU preview JPEG.
     */
    private fun mountingRotationPreference(): Int =
        prefs.getInt(
            "dvr_mount_rotation",
            -1
        )

    private fun manualVideoCorrectionDegrees():
        Int? =
        mountingRotationPreference()
            .takeIf {
                it == 0 ||
                    it == 90 ||
                    it == 180 ||
                    it == 270
            }

    private fun mountingRotationModeLabel(): String =
        when (
            manualVideoCorrectionDegrees()
        ) {
            0 ->
                "Video correction: 0° UPRIGHT"

            90 ->
                "Video correction: +90° clockwise"

            180 ->
                "Video correction: 180°"

            270 ->
                "Video correction: +270° clockwise / 90° counter-clockwise"

            else ->
                "Video correction: Auto"
        }

    private fun displayRotationDegrees(): Int =
        try {
            val dm =
                getSystemService(
                    Context.DISPLAY_SERVICE
                ) as
                    android.hardware.display.DisplayManager

            when (
                dm.getDisplay(
                    android.view.Display
                        .DEFAULT_DISPLAY
                )?.rotation
                    ?: Surface.ROTATION_0
            ) {
                Surface.ROTATION_90 ->
                    90

                Surface.ROTATION_180 ->
                    180

                Surface.ROTATION_270 ->
                    270

                else ->
                    0
            }
        } catch (_: Throwable) {
            0
        }

    private fun resolveAutoDeviceRotationDegrees():
        Int {
        val sensorRotation =
            autoDeviceRotationDegrees

        return if (
            sensorRotation == 0 ||
            sensorRotation == 90 ||
            sensorRotation == 180 ||
            sensorRotation == 270
        ) {
            sensorRotation
        } else {
            displayRotationDegrees()
        }
    }

    private fun calculateAutoOutputRotation(
        deviceRotationDegrees: Int
    ): Int {
        val sensor =
            characteristics
                ?.get(
                    CameraCharacteristics
                        .SENSOR_ORIENTATION
                )
                ?: 0

        val facing =
            characteristics
                ?.get(
                    CameraCharacteristics
                        .LENS_FACING
                )

        val deviceDegrees =
            (
                (
                    deviceRotationDegrees %
                    360
                ) +
                360
                ) %
                360

        return if (
            facing ==
            CameraCharacteristics
                .LENS_FACING_FRONT
        ) {
            (
                sensor +
                    deviceDegrees
                ) %
                360
        } else {
            (
                sensor -
                    deviceDegrees +
                    360
                ) %
                360
        }
    }

    /**
     * Manual 0/90/180/270 values are corrections relative to the canonical
     * upright phone pose (top up / USB down), not raw sensor-pixel rotation.
     */
    private fun calculateOutputRotation(
        autoDeviceDegrees: Int
    ): Int {
        val manualCorrection =
            manualVideoCorrectionDegrees()

        if (manualCorrection != null) {
            val uprightBasis =
                calculateAutoOutputRotation(
                    0
                )

            return (
                uprightBasis +
                    manualCorrection
                ) %
                360
        }

        return calculateAutoOutputRotation(
            autoDeviceDegrees
        )
    }

    /**
     * SurfaceTexture.getTransformMatrix() is already applied by DvrGpuPreview.
     * Therefore the LAN JPEG must not receive Camera2 SENSOR_ORIENTATION again.
     *
     * Manual mode:
     *   0° upright -> preview rotation 0°
     *   90°       -> preview rotation 90°
     *   180°      -> preview rotation 180°
     *   270°      -> preview rotation 270°
     *
     * Auto mode uses the delta from the canonical upright basis.
     */
    private fun calculatePreviewPresentationRotation(
        recorderRotationDegrees: Int
    ): Int {
        val manual =
            manualVideoCorrectionDegrees()

        if (manual != null) {
            return manual
        }

        val uprightBasis =
            calculateAutoOutputRotation(
                0
            )

        return (
            recorderRotationDegrees -
                uprightBasis +
                360
            ) %
            360
    }

    private fun preRecordSeconds(): Int =
        prefs.getInt(
            "dvr_pre_seconds",
            10
        )
            .coerceIn(4, 30)

    private fun postRecordSeconds(): Int =
        prefs.getInt(
            "dvr_post_seconds",
            20
        )
            .coerceIn(4, 60)

    private fun newSegmentFile(): File {
        val dir =
            File(
                cacheDir,
                "dvr_prebuffer"
            ).apply {
                mkdirs()
            }

        return File(
            dir,
            "seg_${System.currentTimeMillis()}_${System.nanoTime()}.mp4"
        )
    }

    private fun cleanStaleDvrCache() {
        ioExecutor.execute {
            val dir =
                File(
                    cacheDir,
                    "dvr_prebuffer"
                )

            dir.listFiles()
                ?.forEach {
                    try {
                        it.delete()
                    } catch (_: Throwable) {
                    }
                }
        }
    }

    private fun cameraPhoneTemperatureC(): Float? {
        val now =
            android.os.SystemClock.elapsedRealtime()

        if (
            now - cachedCameraPhoneTemperatureAtMs <
            5_000L
        ) {
            return cachedCameraPhoneTemperatureC
        }

        cachedCameraPhoneTemperatureAtMs = now

        cachedCameraPhoneTemperatureC =
            try {
                val battery =
                    registerReceiver(
                        null,
                        IntentFilter(
                            Intent.ACTION_BATTERY_CHANGED
                        )
                    )

                val raw =
                    battery?.getIntExtra(
                        BatteryManager.EXTRA_TEMPERATURE,
                        Int.MIN_VALUE
                    )
                        ?: Int.MIN_VALUE

                if (raw == Int.MIN_VALUE) {
                    null
                } else {
                    raw / 10f
                }
            } catch (_: Throwable) {
                null
            }

        return cachedCameraPhoneTemperatureC
    }

    private fun cameraPhoneThermalStatus(): String {
        if (Build.VERSION.SDK_INT < 29) {
            return "Unavailable"
        }

        val status =
            try {
                (
                    getSystemService(
                        POWER_SERVICE
                    ) as? PowerManager
                    )
                    ?.currentThermalStatus
                    ?: return "Unavailable"
            } catch (_: Throwable) {
                return "Unavailable"
            }

        return when (status) {
            PowerManager.THERMAL_STATUS_NONE ->
                "Normal"

            PowerManager.THERMAL_STATUS_LIGHT ->
                "Light"

            PowerManager.THERMAL_STATUS_MODERATE ->
                "Moderate"

            PowerManager.THERMAL_STATUS_SEVERE ->
                "Severe"

            PowerManager.THERMAL_STATUS_CRITICAL ->
                "Critical"

            PowerManager.THERMAL_STATUS_EMERGENCY ->
                "Emergency"

            PowerManager.THERMAL_STATUS_SHUTDOWN ->
                "Shutdown"

            else ->
                "Unknown"
        }
    }

    override fun statusJson(): String =
        JSONObject().apply {
            put("ok", true)
            put("dvrCamera2", true)
            put("cameraId", selectedCameraId)
            put("quality", activeRecordingSize)
            put("analysisSize", activeAnalysisSize)
            put("motionScore", motionScore.toDouble())
            put("motionArmed", prefs.getBoolean("dvr_motion_armed", true))
            put("eventActive", eventActive)
            put(
                "eventRecordingActive",
                eventActive
            )
            put(
                "eventRecordingLabel",
                if (eventActive) {
                    currentAiEventLabel
                } else {
                    ""
                }
            )
            put(
                "eventRecordingElapsedMs",
                if (
                    eventActive &&
                    eventRecordingStartedAtMs > 0L
                ) {
                    (
                        System.currentTimeMillis() -
                            eventRecordingStartedAtMs
                        ).coerceAtLeast(0L)
                } else {
                    0L
                }
            )
            put("recording", recorderStarted)
            val cameraPhoneTemp =
                cameraPhoneTemperatureC()
            put(
                "cameraPhoneTemperatureC",
                cameraPhoneTemp
                    ?.toDouble()
                    ?: JSONObject.NULL
            )
            put(
                "cameraPhoneTemperatureSource",
                "battery-sensor"
            )
            put(
                "cameraPhoneThermalStatus",
                cameraPhoneThermalStatus()
            )
            put(
                "visualStreamAvailable",
                visualStreamAvailable
            )
            put("frameReady", LanCameraHub.latestJpeg.get() != null)
            put("firstFramePending", LanCameraHub.latestJpeg.get() == null)
            put(
                "recordingFirstMode",
                recordingFirstMode
            )
            put("previewAiBridgeMode", false)
            put(
                "compatibilityStage",
                compatibilityStage
            )
            put(
                "recordingModeName",
                if (
                    recordingFirstMode
                ) {
                    "8K recording-first DVR"
                } else {
                    "$activeRecordingSize + PRIVATE preview motion DVR"
                }
            )
            put(
                "recordingFps",
                activeRecordingFps
            )
            put(
                "requestedQuality",
                when (
                    recordingQualityMode()
                ) {
                    0 -> "8K UHD"
                    1 -> "4K UHD"
                    else -> "1080p Full HD"
                }
            )
            put(
                "qualityFallback",
                activeQualityFallback
            )
            put("preBufferSeconds", completedPrebufferSeconds)
            put(
                "maxZoom",
                maxZoomRatio.toDouble()
            )
            put(
                "zoomRatio",
                currentZoomRatio()
                    .toDouble()
            )
            put(
                "appliedZoomRatio",
                appliedZoomRatio
                    .toDouble()
            )
            put(
                "zoomControlMode",
                zoomControlMode
            )
            put(
                "zoomLinear",
                cameraZoomLinear
                    .toDouble()
            )
            put(
                "panX",
                cameraPanX
                    .toDouble()
            )
            put(
                "panY",
                cameraPanY
                    .toDouble()
            )
            put(
                "freeformPanSupported",
                freeformCropSupported
            )
            put(
                "panMode",
                if (
                    freeformCropSupported
                ) {
                    "sensor-freeform"
                } else {
                    "center-only"
                }
            )
            put("manualFocusSupported", manualFocusSupported)
            put("maxFocusDiopters", maxFocusDiopters.toDouble())
            put("focusManual", focusManual)
            put("focusLinear", focusLinear.toDouble())
            put("status", statusText)
            put("lastError", lastError)
            put("currentAiEventLabel", currentAiEventLabel)
            put("lastSavedEventName", lastSavedEventName)
            put(
                "objectNamingAiReady",
                objectDetector != null
            )
            put(
                "mountingRotationMode",
                mountingRotationModeLabel()
            )
            put(
                "lockedDeviceRotationDegrees",
                lockedDeviceRotationDegrees
            )
            put(
                "orientationHintDegrees",
                activeOrientationHintDegrees
            )
            put(
                "previewPresentationRotationDegrees",
                previewPresentationRotationDegrees
            )
            put(
                "lanPreviewOrientation",
                "portrait-9:16"
            )
            put(
                "mountRotationPreferenceDegrees",
                prefs.getInt(
                    "dvr_mount_rotation",
                    -1
                )
            )
            put(
                "rotationControlSemantics",
                "direct-video-correction"
            )
            put(
                "sensorOrientationDegrees",
                characteristics
                    ?.get(
                        CameraCharacteristics
                            .SENSOR_ORIENTATION
                    )
                    ?: 0
            )
            put(
                "uprightPhysicalMount",
                "top-up-usb-down"
            )
            put(
                "uprightBasisRotationDegrees",
                calculateAutoOutputRotation(
                    0
                )
            )
            put(
                "audioAiStatus",
                audioAiStatus
            )
            put(
                "lastSoundAiEvent",
                lastSoundAiEvent
            )
            put(
                "soundAiArmed",
                soundAiRequested()
            )
            put(
                "customObjectAiReady",
                customObjectAiReady
            )
            put(
                "recordAudioInVideos",
                recordAudioInVideos()
            )
            put(
                "audioSampleRateHz",
                audioSampleRateHz()
            )
            put(
                "liveAudioAvailable",
                sharedAudioEngine !=
                    null
            )
            put(
                "liveAudioFormat",
                "PCM_S16LE_MONO"
            )
            put(
                "audioBitrateBps",
                audioBitrateBps()
            )
            put(
                "videoBitrateBps",
                videoBitrateBps()
            )
            put(
                "recordingAudioStatus",
                recordingAudioStatus
            )
            put(
                "lastSavedMp4HasAudio",
                Mp4SegmentMerger
                    .lastOutputHasAudio
            )
            put(
                "lastAudioMuxStatus",
                Mp4SegmentMerger
                    .lastAudioMuxStatus
            )
            put(
                "movingCarsOnly",
                true
            )
            put(
                "movingCarDetected",
                movingCarDetected
            )
            put(
                "carMotionScore",
                carMotionScore.toDouble()
            )
            put(
                "carMotionStatus",
                carMotionStatus
            )
            put(
                "videoBitrateBps",
                videoBitrateBps()
            )
            put(
                "audioBitrateBps",
                audioBitrateBps()
            )
            put(
                "audioAdvanceMs",
                audioAdvanceMs()
            )
            put(
                "activeVideoBitrateText",
                activeVideoBitrateText
            )
            put(
                "activeAudioBitrateText",
                activeAudioBitrateText
            )
            put(
                "activeAudioSyncText",
                activeAudioSyncText
            )
        }.toString()

    override fun eventsJson(): String =
        eventStore.json()

    override fun recordingsJson(): String =
        try {
            recordingLibrary.listJson()
        } catch (t: Throwable) {
            JSONObject()
                .put(
                    "recordings",
                    org.json.JSONArray()
                )
                .put(
                    "error",
                    t.message
                        ?: t.javaClass.simpleName
                )
                .toString()
        }

    override fun openRecording(
        id: String
    ): RemoteRecordingSource? =
        try {
            recordingLibrary.open(id)
        } catch (_: Throwable) {
            null
        }

    override fun recordingThumbnailJpeg(
        id: String,
        width: Int,
        height: Int
    ): ByteArray? =
        try {
            recordingLibrary.thumbnailJpeg(
                id,
                width,
                height
            )
        } catch (_: Throwable) {
            null
        }

    override fun deleteRecording(
        id: String
    ): Boolean {
        val deleted =
            try {
                recordingLibrary.delete(
                    id
                )
            } catch (_: Throwable) {
                false
            }

        if (deleted) {
            eventStore.add(
                "Remote recording deleted",
                "MediaStore id=$id"
            )
        }

        return deleted
    }

    override fun remoteDvrSettingsJson():
        String =
        JSONObject().apply {
            put(
                "ok",
                true
            )
            put(
                "quality",
                recordingQualityMode()
            )
            put(
                "videoBitrateMbps",
                prefs.getInt(
                    "dvr_video_bitrate_mbps",
                    0
                )
            )
            put(
                "audioBitrateKbps",
                prefs.getInt(
                    "dvr_audio_bitrate_kbps",
                    128
                )
            )
            put(
                "audioSampleRateHz",
                audioSampleRateHz()
            )
            put(
                "audioSyncMs",
                prefs.getInt(
                    "dvr_audio_advance_ms",
                    0
                )
            )
            put(
                "activeRecordingSize",
                activeRecordingSize
            )
            put(
                "activeRecordingFps",
                activeRecordingFps
            )
            put(
                "qualityFallback",
                activeQualityFallback
            )
        }.toString()

    override fun applyRemoteDvrSettings(
        quality: Int?,
        videoBitrateMbps: Int?,
        audioBitrateKbps: Int?,
        audioSampleRateHz: Int?,
        audioSyncMs: Int?
    ): String {
        val editor =
            prefs.edit()

        quality
            ?.coerceIn(
                0,
                2
            )
            ?.let {
                editor.putInt(
                    "dvr_quality",
                    it
                )
                editor.putBoolean(
                    "dvr_quality_schema_8k",
                    true
                )
            }

        videoBitrateMbps
            ?.takeIf {
                it in
                    listOf(
                        0,
                        20,
                        32,
                        50,
                        75,
                        100,
                        150,
                        200
                    )
            }
            ?.let {
                editor.putInt(
                    "dvr_video_bitrate_mbps",
                    it
                )
            }

        audioBitrateKbps
            ?.takeIf {
                it in
                    listOf(
                        64,
                        96,
                        128,
                        192,
                        256,
                        320
                    )
            }
            ?.let {
                editor.putInt(
                    "dvr_audio_bitrate_kbps",
                    it
                )
            }

        audioSampleRateHz
            ?.takeIf {
                it ==
                    44_100 ||
                    it ==
                    48_000
            }
            ?.let {
                editor.putInt(
                    "dvr_audio_sample_rate_hz",
                    it
                )
            }

        audioSyncMs
            ?.coerceIn(
                -5_000,
                5_000
            )
            ?.let {
                editor.putInt(
                    "dvr_audio_advance_ms",
                    it
                )
            }

        editor.apply()

        cameraHandler?.post {
            stopCameraResources(
                deleteUnprotected =
                    true
            )

            restartSharedAudioForSettings()

            startCamera()
        }

        eventStore.add(
            "Remote DVR settings applied",
            "quality=${quality ?: "unchanged"} • videoMbps=${videoBitrateMbps ?: "unchanged"} • audioKbps=${audioBitrateKbps ?: "unchanged"} • audioHz=${audioSampleRateHz ?: "unchanged"} • audioSyncMs=${audioSyncMs ?: "unchanged"}"
        )

        return remoteDvrSettingsJson()
    }

    override fun onZoom(
        linear: Float
    ) {
        onCameraView(
            linear = linear,
            panX = cameraPanX,
            panY = cameraPanY
        )
    }

    override fun onCameraView(
        linear: Float,
        panX: Float,
        panY: Float
    ) {
        lastCameraViewChangeAtMs =
            System.currentTimeMillis()

        synchronized(
            carMotionLock
        ) {
            carMotionTracks.clear()
            movingCarDetected = false
            carMotionScore = 0f
            carMotionStatus =
                "Car motion filter: reset after camera zoom/pan"
        }

        cameraZoomLinear =
            linear.coerceIn(
                0f,
                1f
            )

        if (
            cameraZoomLinear <=
            0.001f
        ) {
            cameraZoomLinear =
                0f
            cameraPanX =
                0f
            cameraPanY =
                0f
        } else {
            cameraPanX =
                panX.coerceIn(
                    -1f,
                    1f
                )

            cameraPanY =
                panY.coerceIn(
                    -1f,
                    1f
                )
        }

        prefs.edit()
            .putFloat(
                "dvr_camera_zoom_linear",
                cameraZoomLinear
            )
            .putFloat(
                "dvr_camera_pan_x",
                cameraPanX
            )
            .putFloat(
                "dvr_camera_pan_y",
                cameraPanY
            )
            // Keep legacy keys synchronized for switching between camera modes.
            .putFloat(
                "camera_zoom_linear",
                cameraZoomLinear
            )
            .putFloat(
                "camera_pan_x",
                cameraPanX
            )
            .putFloat(
                "camera_pan_y",
                cameraPanY
            )
            .apply()

        scheduleCameraViewApply()
    }

    override fun onPreviewQuality(mode: Int) = Unit

    override fun onFocusAuto() {
        focusManual = false

        prefs.edit()
            .putBoolean(
                "dvr_focus_manual",
                false
            )
            .putBoolean(
                "focus_manual",
                false
            )
            .apply()

        scheduleFocusApply()
    }

    override fun onFocusManual(linear: Float) {
        if (!manualFocusSupported) {
            eventStore.add(
                "Remote manual focus ignored",
                "Camera $selectedCameraId does not expose adjustable Camera2 manual focus."
            )
            return
        }

        focusLinear =
            linear.coerceIn(0f, 1f)
        focusManual = true

        // Save continuously so screen-off/restart keeps the remote focus.
        prefs.edit()
            .putBoolean(
                "dvr_focus_manual",
                true
            )
            .putFloat(
                "dvr_focus_linear",
                focusLinear
            )
            .putBoolean(
                "focus_manual",
                true
            )
            .putFloat(
                "focus_linear",
                focusLinear
            )
            .apply()

        scheduleFocusApply()
    }

    override fun onFocusSave() {
        prefs.edit()
            .putBoolean(
                "dvr_focus_manual",
                focusManual
            )
            .putFloat(
                "dvr_focus_linear",
                focusLinear
            )
            .putBoolean(
                "focus_manual",
                focusManual
            )
            .putFloat(
                "focus_linear",
                focusLinear
            )
            .apply()

        eventStore.add(
            "Remote focus default saved",
            if (focusManual) {
                "Manual ${String.format(Locale.US, "%.2f", focusLinear * maxFocusDiopters)} D"
            } else {
                "Auto focus"
            }
        )
    }

    override fun onRecordStart() {
        cameraHandler?.post {
            triggerManualEvent()
        }
    }

    override fun onRecordStop() {
        cameraHandler?.post {
            if (eventActive) {
                lastMotionAt =
                    System.currentTimeMillis() -
                        postRecordSeconds() *
                        1_000L
            }
        }
    }

    override fun onRestartCameraApp(): String {
        eventStore.add(
            "Remote camera app restart",
            "Monitor phone requested a camera/DVR restart."
        )

        // Keep the LAN server alive long enough to return HTTP 202, then
        // rebuild the camera/audio pipeline on the camera thread.
        cameraHandler?.postDelayed(
            {
                if (stopping) {
                    return@postDelayed
                }

                try {
                    stopCameraResources(
                        deleteUnprotected = true
                    )

                    LanCameraHub.latestJpeg.set(
                        null
                    )

                    restartSharedAudioForSettings()
                    startCamera()
                } catch (t: Throwable) {
                    lastError =
                        t.message
                            ?: t.javaClass.simpleName

                    eventStore.add(
                        "Remote camera restart failed",
                        lastError
                    )
                }
            },
            300L
        )

        // Best effort only: Android 10+ may block a background service from
        // forcing an Activity to the foreground. The DVR engine restart above
        // does not depend on this UI launch succeeding.
        Handler(mainLooper).postDelayed(
            {
                try {
                    startActivity(
                        Intent(
                            this,
                            DvrCameraActivity::class.java
                        ).apply {
                            addFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK or
                                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                    Intent.FLAG_ACTIVITY_SINGLE_TOP
                            )
                        }
                    )
                } catch (_: Throwable) {
                }
            },
            700L
        )

        return JSONObject()
            .put("ok", true)
            .put("supported", true)
            .put("action", "camera_app_restart")
            .put("cameraEngineRestartQueued", true)
            .put("uiLaunchBestEffort", true)
            .toString()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)

        if (stopping) {
            return
        }

        // Dismissing the camera UI must not stop the LAN listener or DVR.
        // START_STICKY covers process recreation; this additionally reasserts
        // the endpoint/camera while the service process is still alive.
        cameraHandler?.postDelayed(
            {
                if (stopping) {
                    return@postDelayed
                }

                try {
                    LanCameraHub.setEndpoint(this)
                    LanCameraHub.ensureStarted(this)

                    if (cameraDevice == null) {
                        startCamera()
                    }
                } catch (_: Throwable) {
                }
            },
            1_000L
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager =
                getSystemService(
                    Context.NOTIFICATION_SERVICE
                ) as NotificationManager

            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "DVR camera",
                    NotificationManager
                        .IMPORTANCE_LOW
                )
            )
        }
    }

    private fun buildNotification(
        text: String
    ): Notification =
        NotificationCompat.Builder(
            this,
            CHANNEL_ID
        )
            .setSmallIcon(
                android.R.drawable
                    .ic_menu_camera
            )
            .setContentTitle(
                "AI Door Monitor • DVR"
            )
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    private fun videoBitrateBps(): Int {
        val selectedMbps =
            prefs.getInt(
                "dvr_video_bitrate_mbps",
                0
            )

        if (selectedMbps > 0) {
            return selectedMbps
                .coerceIn(
                    8,
                    200
                ) *
                1_000_000
        }

        return when {
            is8KSize(
                recordingSize
            ) ->
                100_000_000

            recordingSize.width >=
                3000 ||
                recordingSize.height >=
                2000 ->
                32_000_000

            else ->
                12_000_000
        }
    }

    private fun audioSampleRateHz(): Int =
        if (
            prefs.getInt(
                "dvr_audio_sample_rate_hz",
                48_000
            ) ==
            44_100
        ) {
            44_100
        } else {
            48_000
        }

    private fun audioBitrateBps(): Int =
        prefs.getInt(
            "dvr_audio_bitrate_kbps",
            128
        )
            .coerceIn(
                64,
                320
            ) *
            1_000

    /** Positive values advance audio relative to video. */
    private fun audioAdvanceMs(): Int =
        prefs.getInt(
            "dvr_audio_advance_ms",
            0
        )
            .coerceIn(
                -5_000,
                5_000
            )

    private fun updateAudioQualityStatus() {
        activeAudioBitrateText =
            "Audio bitrate: ${audioBitrateBps() / 1_000} kbps AAC-LC"

        val advance =
            audioAdvanceMs()

        activeAudioSyncText =
            when {
                advance > 0 ->
                    "Audio sync: audio ${advance} ms earlier"

                advance < 0 ->
                    "Audio sync: audio ${-advance} ms later"

                else ->
                    "Audio sync: automatic sample-rate + timestamp alignment"
            }
    }

    private fun resolveEventVideoStartAtMs(): Long {
        val firstEvent =
            eventSegments
                .firstOrNull()

        val fromCompleted =
            firstEvent
                ?.let {
                    segmentStartedAtMs[
                        it.absolutePath
                    ]
                }

        if (fromCompleted != null) {
            return fromCompleted
        }

        val current =
            currentSegment
                ?.let {
                    segmentStartedAtMs[
                        it.absolutePath
                    ]
                }

        return current
            ?: lastMotionAt
            .takeIf { it > 0L }
            ?: System.currentTimeMillis()
    }

    private fun soundAiRequested(): Boolean =
        prefs.getBoolean(
            "dvr_sound_ai_armed",
            true
        )

    private fun recordAudioInVideos(): Boolean =
        prefs.getBoolean(
            "dvr_record_audio",
            true
        )

    private fun audioCaptureRequested(): Boolean =
        soundAiRequested() ||
            recordAudioInVideos()

    private fun microphonePermissionGranted(): Boolean =
        ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) ==
            PackageManager.PERMISSION_GRANTED

    private fun startAsCameraForeground(
        notification: Notification
    ) {
        if (Build.VERSION.SDK_INT >= 29) {
            var types =
                ServiceInfo
                    .FOREGROUND_SERVICE_TYPE_CAMERA

            if (
                audioCaptureRequested() &&
                microphonePermissionGranted()
            ) {
                types =
                    types or
                        ServiceInfo
                            .FOREGROUND_SERVICE_TYPE_MICROPHONE
            }

            startForeground(
                NOTIFICATION_ID,
                notification,
                types
            )
        } else {
            startForeground(
                NOTIFICATION_ID,
                notification
            )
        }
    }

    private fun updateNotification(
        text: String
    ) {
        try {
            val manager =
                getSystemService(
                    Context.NOTIFICATION_SERVICE
                ) as NotificationManager

            manager.notify(
                NOTIFICATION_ID,
                buildNotification(text)
            )
        } catch (_: Throwable) {
        }
    }

    private fun acquireLocks() {
        try {
            val pm =
                getSystemService(
                    Context.POWER_SERVICE
                ) as PowerManager

            wakeLock =
                pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "AIDoorMonitor:DvrCamera"
                ).apply {
                    setReferenceCounted(false)
                    acquire()
                }
        } catch (_: Throwable) {
        }

        try {
            val wm =
                applicationContext
                    .getSystemService(
                        Context.WIFI_SERVICE
                    ) as WifiManager

            @Suppress("DEPRECATION")
            wifiLock =
                wm.createWifiLock(
                    WifiManager
                        .WIFI_MODE_FULL_HIGH_PERF,
                    "AIDoorMonitor:DvrWifi"
                ).apply {
                    setReferenceCounted(false)
                    acquire()
                }
        } catch (_: Throwable) {
        }
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Throwable) {
        }
        wakeLock = null

        try {
            if (wifiLock?.isHeld == true) {
                wifiLock?.release()
            }
        } catch (_: Throwable) {
        }
        wifiLock = null
    }

    override fun onDestroy() {
        stopping = true
        isRunning = false
        statusText = "DVR stopped"

        cameraHandler?.post {
            try {
                if (
                    eventActive &&
                    currentSegment != null
                ) {
                    lastMotionAt = 0L
                }

                stopCameraResources(
                    deleteUnprotected = true
                )
            } catch (_: Throwable) {
            }
        }

        try {
            orientationListener?.disable()
        } catch (_: Throwable) {
        }
        orientationListener = null

        if (availabilityRegistered) {
            try {
                cameraManager.unregisterAvailabilityCallback(
                    availabilityCallback
                )
            } catch (_: Throwable) {
            }
            availabilityRegistered = false
        }

        try {
            cameraThread?.quitSafely()
        } catch (_: Throwable) {
        }
        cameraThread = null
        cameraHandler = null

        try {
            sharedAudioEngine
                ?.stop()
        } catch (_: Throwable) {
        }
        sharedAudioEngine = null

        try {
            objectDetector?.stop()
        } catch (_: Throwable) {
        }
        objectDetector = null

        try {
            customObjectDetector?.stop()
        } catch (_: Throwable) {
        }
        customObjectDetector = null
        customObjectAiReady = false

        try {
            objectAiExecutor.shutdownNow()
        } catch (_: Throwable) {
        }

        try {
            ioExecutor.shutdown()
        } catch (_: Throwable) {
        }

        LanCameraHub.setEndpoint(null)
        LanCameraHub.stop(
            clearFrame = true
        )

        releaseLocks()

        super.onDestroy()
    }
}
