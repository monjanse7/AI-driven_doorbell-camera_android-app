# AIDoorMonitor v0.5.7 – Native Portrait GPU Preview

## Fixed narrow/deformed live portrait preview

The v0.5.6 monitor screenshot showed a correct upright scene but a much narrower
field of view than the correctly oriented saved MP4.

The preview pipeline was:

Camera2 PRIVATE 16:9
→ OpenGL 960×540 landscape target
→ upright SurfaceTexture transform
→ crop the already-rendered landscape image down to 9:16

That throws away a large part of the horizontal field of view and can make the
portrait preview look geometrically wrong compared with the saved recording.

v0.5.7 instead renders directly into a portrait OpenGL target:

- high preview: 540×960
- lower preview: 360×640

The final JPEG is already 9:16, so no second portrait crop is performed.

## No horizontal/vertical distortion in MjpegView

The monitor view uses one single uniform scale value for both X and Y. It never
calculates independent horizontal and vertical scale factors.

Therefore a 540×960 JPEG remains 9:16 on screen. FIT_CENTER may add black space
around the picture, but it does not change object proportions.

## Motion AI

The lightweight motion grid now changes from 48×27 in landscape to 27×48 when
the GPU output is portrait, so motion sampling follows the real frame geometry.

All v0.5.6 features remain:
- correct upright live orientation,
- correct orientation metadata for new MP4 files,
- local rotate button for older sideways videos,
- remote 8K/4K/1080p settings,
- remote video/audio bitrates,
- 44.1/48 kHz audio,
- strict final MP4 audio-track verification,
- event folders,
- Sound AI,
- moving-car-only filtering,
- remote zoom/focus/delete.
