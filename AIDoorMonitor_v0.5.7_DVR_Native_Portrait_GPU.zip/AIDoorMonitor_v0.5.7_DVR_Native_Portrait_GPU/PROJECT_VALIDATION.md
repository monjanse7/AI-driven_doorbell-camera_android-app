# AIDoorMonitor v0.5.7 validation

- xml_errors: `[]`
- native_high_portrait_target: `True`
- native_low_portrait_target: `True`
- no_second_crop_for_native_9_16: `True`
- portrait_motion_grid: `True`
- mjpeg_uniform_scale: `True`
- no_independent_xy_scale: `True`
- remote_settings_retained: `True`
- strict_audio_verify_retained: `True`

A full Android assembleDebug still requires Android Studio/Android SDK.
