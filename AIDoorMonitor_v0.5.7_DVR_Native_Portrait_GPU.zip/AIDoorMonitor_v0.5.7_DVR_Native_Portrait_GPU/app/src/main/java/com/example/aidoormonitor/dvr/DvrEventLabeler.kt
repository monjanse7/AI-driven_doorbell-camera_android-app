package com.example.aidoormonitor.dvr

import android.content.Context
import com.example.aidoormonitor.model.BuiltInRules
import com.example.aidoormonitor.model.RuleType
import com.example.aidoormonitor.store.RuleStore
import java.util.ArrayDeque
import java.util.Locale

data class DvrAiSignal(
    val signal: String,
    val confidence: Float,
    val atMs: Long
)

data class DvrEventName(
    val displayLabel: String,
    val filenameLabel: String,
    val matchedSignals: List<String>
)

class DvrEventLabeler(
    context: Context
) {
    private val ruleStore = RuleStore(context)
    private val recentSignals = ArrayDeque<DvrAiSignal>()
    private val eventSignals = mutableListOf<DvrAiSignal>()
    private var eventStartedAt = 0L

    private val builtInIds =
        BuiltInRules.defaults()
            .map { it.id }
            .toSet()

    @Synchronized
    fun recordSignal(
        rawSignal: String,
        confidence: Float,
        atMs: Long = System.currentTimeMillis()
    ) {
        val signal =
            normalizeSignal(rawSignal)

        if (signal.isBlank()) return

        val item =
            DvrAiSignal(
                signal = signal,
                confidence = confidence.coerceIn(0f, 1f),
                atMs = atMs
            )

        recentSignals.addLast(item)

        val recentCutoff = atMs - 15_000L
        while (
            recentSignals.isNotEmpty() &&
            recentSignals.first().atMs < recentCutoff
        ) {
            recentSignals.removeFirst()
        }

        if (eventStartedAt > 0L) {
            eventSignals += item
        }
    }

    @Synchronized
    fun beginEvent(
        preRecordSeconds: Int,
        manual: Boolean
    ) {
        val now = System.currentTimeMillis()
        eventStartedAt = now
        eventSignals.clear()

        val cutoff =
            now -
                preRecordSeconds.coerceAtLeast(1) *
                1_000L

        recentSignals
            .filter { it.atMs >= cutoff }
            .forEach {
                eventSignals += it
            }

        if (manual) {
            eventSignals +=
                DvrAiSignal(
                    signal = "manual",
                    confidence = 1f,
                    atMs = now
                )
        }
    }

    @Synchronized
    fun endEventAndChooseName(): DvrEventName {
        val signals =
            eventSignals.toList()

        eventSignals.clear()
        eventStartedAt = 0L

        if (signals.isEmpty()) {
            return DvrEventName(
                displayLabel = "Motion",
                filenameLabel = "Motion",
                matchedSignals = emptyList()
            )
        }

        val strongestBySignal =
            signals
                .groupBy { it.signal }
                .mapValues { (_, items) ->
                    items.maxOf { it.confidence }
                }

        val rules =
            try {
                ruleStore.load()
            } catch (_: Throwable) {
                mutableListOf()
            }

        data class Candidate(
            val name: String,
            val signal: String,
            val score: Float,
            val custom: Boolean
        )

        val candidates =
            mutableListOf<Candidate>()

        rules
            .filter { it.enabled }
            .forEach { rule ->
                val matchingSignal =
                    strongestBySignal.keys
                        .firstOrNull { detected ->
                            ruleMatchesSignal(
                                rule.type,
                                rule.signal,
                                detected
                            )
                        }
                        ?: return@forEach

                val confidence =
                    strongestBySignal[
                        matchingSignal
                    ] ?: 0f

                if (
                    confidence * 100f <
                    rule.confidence.toFloat()
                ) {
                    return@forEach
                }

                val isCustom =
                    rule.id !in builtInIds

                candidates +=
                    Candidate(
                        name = rule.name,
                        signal = matchingSignal,
                        score =
                            confidence +
                                if (isCustom) 0.35f else 0f,
                        custom = isCustom
                    )
            }

        val sorted =
            candidates
                .sortedWith(
                    compareByDescending<Candidate> {
                        it.custom
                    }.thenByDescending {
                        it.score
                    }
                )

        val chosenNames =
            if (sorted.isNotEmpty()) {
                val first = sorted.first()
                buildList {
                    add(first.name)

                    // Add one more distinct high-confidence event when useful.
                    sorted
                        .drop(1)
                        .firstOrNull {
                            it.name != first.name &&
                                it.score >= first.score - 0.12f
                        }
                        ?.let {
                            add(it.name)
                        }
                }
            } else {
                strongestBySignal
                    .entries
                    .sortedByDescending { it.value }
                    .mapNotNull { (signal, score) ->
                        if (score < 0.42f) {
                            null
                        } else {
                            fallbackDisplayName(signal)
                        }
                    }
                    .distinct()
                    .take(2)
                    .ifEmpty {
                        listOf("Motion")
                    }
            }

        val display =
            chosenNames.joinToString(" + ")

        return DvrEventName(
            displayLabel = display,
            filenameLabel =
                sanitizeFilenamePart(display)
                    .ifBlank { "Motion" },
            matchedSignals =
                strongestBySignal.keys
                    .sorted()
        )
    }

    @Synchronized
    fun currentBestLabel(): String {
        val strongest =
            eventSignals
                .groupBy { it.signal }
                .mapValues { (_, items) ->
                    items.maxOf { it.confidence }
                }
                .maxByOrNull { it.value }
                ?.key
                ?: return "Motion"

        return fallbackDisplayName(strongest)
            ?: "Motion"
    }

    private fun ruleMatchesSignal(
        type: RuleType,
        ruleSignal: String,
        detectedSignal: String
    ): Boolean {
        val normalizedRule =
            ruleSignal
                .lowercase(Locale.US)

        val detected =
            normalizeSignal(detectedSignal)

        if (detected.isBlank()) return false

        // Exact/word match lets custom rules use signals such as dog, cat,
        // person, bird, car, package, motion or fast_toward_door.
        val tokens =
            normalizedRule
                .replace("yamnet:", "")
                .split(
                    Regex("[^a-z0-9_]+")
                )
                .filter {
                    it.isNotBlank()
                }

        return when (type) {
            RuleType.OBJECT ->
                detected in tokens ||
                    normalizedRule.trim() == detected

            RuleType.TRAJECTORY ->
                detected in tokens ||
                    normalizedRule.trim() == detected

            RuleType.TEMPORAL_VIDEO,
            RuleType.COMPOSITE,
            RuleType.AUDIO ->
                detected in tokens
        }
    }

    private fun normalizeSignal(value: String): String =
        value
            .trim()
            .lowercase(Locale.US)
            .replace(' ', '_')
            .replace('-', '_')
            .replace(
                Regex("[^a-z0-9_]+"),
                ""
            )

    private fun fallbackDisplayName(
        signal: String
    ): String? =
        when (normalizeSignal(signal)) {
            "dog" -> "Dog"
            "dog_barking",
            "bark" -> "Dog barking"
            "dog_growling",
            "growl",
            "growling" -> "Dog growling"
            "cat" -> "Cat"
            "bird" -> "Bird"
            "person" -> "Person"
            "car" -> "Car"
            "bicycle" -> "Bicycle"
            "stroller",
            "pram",
            "pushchair",
            "baby_carriage" -> "Stroller"
            "motorcycle" -> "Motorcycle"
            "truck" -> "Truck"
            "package" -> "Package"
            "backpack" -> "Backpack"
            "handbag" -> "Handbag"
            "suitcase" -> "Suitcase"
            "fast_toward_door" ->
                "Something thrown at the door"
            "motion" -> "Motion"
            "manual" -> "Manual"
            else ->
                signal
                    .replace('_', ' ')
                    .trim()
                    .takeIf { it.isNotBlank() }
                    ?.replaceFirstChar {
                        it.uppercase()
                    }
        }

    companion object {
        fun sanitizeFilenamePart(
            input: String
        ): String =
            input
                .trim()
                .replace(
                    Regex("[\\\\/:*?\"<>|]+"),
                    "_"
                )
                .replace(
                    Regex("\\s+"),
                    "_"
                )
                .replace(
                    Regex("_+"),
                    "_"
                )
                .trim('_')
                .take(64)
    }
}
