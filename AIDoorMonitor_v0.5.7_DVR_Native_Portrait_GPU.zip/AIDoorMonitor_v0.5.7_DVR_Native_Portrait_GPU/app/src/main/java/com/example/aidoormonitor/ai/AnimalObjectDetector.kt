package com.example.aidoormonitor.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import java.io.File
import java.util.Locale

data class AnimalDetection(
    val label: String,
    val score: Float,
    val box: RectF
)

class AnimalObjectDetector(
    private val context: Context,
    private val modelFile: File,
    private val onStatus: (String) -> Unit = {}
) {
    private var detector: ObjectDetector? = null
    private var lastRunAt = 0L

    fun start() {
        if (detector != null) return
        if (!modelFile.exists()) {
            onStatus("Animal AI model is not downloaded.")
            return
        }

        try {
            detector =
                ObjectDetector.createFromFile(
                    context,
                    modelFile
                )
            onStatus(
                "Object AI active • EfficientDet-Lite0 • COCO objects"
            )
        } catch (e: Exception) {
            onStatus("Animal AI failed: ${e.message}")
        }
    }

    fun analyze(bitmap: Bitmap): List<AnimalDetection> {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRunAt < 240L) return emptyList()
        lastRunAt = now

        val task = detector ?: return emptyList()
        var converted: Bitmap? = null

        return try {
            val input =
                if (bitmap.config == Bitmap.Config.ARGB_8888) {
                    bitmap
                } else {
                    converted =
                        bitmap.copy(
                            Bitmap.Config.ARGB_8888,
                            false
                        )
                    converted ?: return emptyList()
                }

            val image =
                BitmapImageBuilder(input).build()

            val result =
                task.detect(image)

            image.close()

            result.detections()
                .mapNotNull { detection ->
                    val category =
                        detection.categories()
                            .maxByOrNull { it.score() }
                            ?: return@mapNotNull null

                    val raw =
                        category.categoryName()
                            .lowercase(Locale.US)

                    // Keep all COCO labels for the DVR event namer.
                    // The legacy animal handler still explicitly selects only
                    // Dog/Cat/Bird, so expanding this result list does not
                    // change its trigger semantics.
                    if (raw.isBlank()) {
                        return@mapNotNull null
                    }

                    if (category.score() < 0.42f) {
                        return@mapNotNull null
                    }

                    val box = detection.boundingBox()

                    AnimalDetection(
                        label =
                            raw.replaceFirstChar {
                                it.uppercase()
                            },
                        score = category.score(),
                        box =
                            RectF(
                                box.left.toFloat(),
                                box.top.toFloat(),
                                box.right.toFloat(),
                                box.bottom.toFloat()
                            )
                    )
                }
                .sortedByDescending { it.score }
                .take(6)

        } catch (e: Exception) {
            onStatus("Animal AI error: ${e.message}")
            emptyList()
        } finally {
            try {
                if (
                    converted != null &&
                    !converted!!.isRecycled
                ) {
                    converted!!.recycle()
                }
            } catch (_: Exception) {}
        }
    }

    fun stop() {
        try { detector?.close() } catch (_: Exception) {}
        detector = null
    }
}
