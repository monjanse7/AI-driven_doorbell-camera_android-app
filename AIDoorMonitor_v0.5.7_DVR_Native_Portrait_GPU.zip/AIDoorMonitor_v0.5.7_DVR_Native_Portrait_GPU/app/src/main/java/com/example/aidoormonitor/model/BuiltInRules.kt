package com.example.aidoormonitor.model

object BuiltInRules {
    fun defaults(): MutableList<AiRule> = mutableListOf(
        AiRule("person", "Person", true, RuleType.OBJECT, "person", 65),
        AiRule(
            "possible_seizure_like_motion",
            "Possible seizure-like repetitive motion (experimental)",
            false,
            RuleType.TEMPORAL_VIDEO,
            "repetitive_convulsive_like_motion",
            80,
            minDurationMs = 6000,
            notes = "Experimental non-diagnostic visual alert. It can miss events and create false alarms; do not rely on it for emergency response."
        ),
        AiRule("magpie", "Magpie / skjære", true, RuleType.OBJECT, "magpie", 70,
            notes = "Needs a custom bird-species model; generic COCO only knows bird."),
        AiRule("cat", "Cat", true, RuleType.OBJECT, "cat", 65),
        AiRule("dog", "Dog", true, RuleType.OBJECT, "dog", 65),
        AiRule("dog_bark", "Dog barking", true, RuleType.AUDIO, "yamnet:bark", 60,
            notes = "YamNet audio AI event. Event log label: AI detected: dog barking."),
        AiRule("dog_growl", "Dog growling", true, RuleType.AUDIO, "yamnet:growl|growling", 55,
            notes = "YamNet audio AI event. Can trigger the DVR pre-record buffer."),
        AiRule("bicycle", "Bicycle", true, RuleType.OBJECT, "bicycle", 55,
            notes = "Detected by the standard COCO object model."),
        AiRule("car", "Car", true, RuleType.OBJECT, "car", 55,
            notes = "Detected by the standard COCO object model."),
        AiRule("stroller", "Stroller / barnevogn", true, RuleType.OBJECT, "stroller|pram|pushchair|baby_carriage", 55,
            notes = "Requires a compatible custom Object Detector model that exposes one of these labels."),
        AiRule("shouting", "Shouting / raised voice", true, RuleType.AUDIO, "yamnet:shout|yell|scream", 60,
            notes = "On-device audio AI event."),
        AiRule("impact_sound", "Impact / knock sound", true, RuleType.AUDIO, "yamnet:knock|thump|slam|crash|glass", 65,
            notes = "On-device audio AI event that can complement thrown-object detection."),
        AiRule("person_fall", "Possible person fall", true, RuleType.TEMPORAL_VIDEO, "pose_landmarker_fall", 70,
            notes = "AI-assisted pose + temporal posture rule. Experimental; review the recording."),
        AiRule("aggressive_behavior", "Possible aggressive behavior", true, RuleType.COMPOSITE, "person_pose + rapid_motion + shouting", 70,
            notes = "Uses observable movement and raised voice. It does not infer a person's emotion."),
        AiRule("dog_fight", "Dogs fighting", true, RuleType.TEMPORAL_VIDEO, "dog_fighting", 75,
            minDurationMs = 1200,
            notes = "Requires a temporal/action model; two dogs + high interaction motion is not enough by itself."),
        AiRule("throw_door", "Something thrown at the door", true, RuleType.TRAJECTORY, "fast_toward_door", 70,
            notes = "Tracks a fast object trajectory into the configured door zone; impact sound can be an optional second signal.")
    )
}
