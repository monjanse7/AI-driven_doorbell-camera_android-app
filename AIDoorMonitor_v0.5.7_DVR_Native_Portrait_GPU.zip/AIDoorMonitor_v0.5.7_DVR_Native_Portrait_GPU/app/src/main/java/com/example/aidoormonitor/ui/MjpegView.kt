package com.example.aidoormonitor.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import androidx.appcompat.widget.AppCompatImageView
import com.example.aidoormonitor.net.PairInfo
import java.io.BufferedInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.max
import kotlin.math.min

/**
 * MJPEG monitor view with local viewer pan/zoom.
 *
 * Important distinction:
 * - Remote camera zoom changes CameraX zoom on the camera phone.
 * - Viewer zoom/pan only magnifies/repositions the received image locally.
 *
 * Pinch the live image to magnify it, then drag with one finger to inspect
 * different areas of the zoomed frame.
 */
class MjpegView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {

    @Volatile
    private var running = false

    private var worker: Thread? = null
    private var connection: HttpURLConnection? = null
    private var currentBitmap: Bitmap? = null

    // Never enqueue one UI Runnable per network frame. Keep only the newest
    // decoded bitmap and render at most once per display frame.
    private val pendingBitmap =
        AtomicReference<Bitmap?>(null)

    private val renderScheduled =
        AtomicBoolean(false)

    @Volatile
    private var renderedFps = 0f

    @Volatile
    private var lastReceivedFrameAtMs = 0L

    private var renderFpsStartNs = 0L
    private var renderFpsFrames = 0

    private val drawMatrix = Matrix()
    private var viewerScale = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var downTouchX = 0f
    private var downTouchY = 0f
    private var dragging = false
    private var gestureMoved = false
    private var multiTouchActive = false

    private val touchSlop =
        ViewConfiguration.get(context).scaledTouchSlop.toFloat()

    private var zoomListener: ((Float) -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {

            override fun onScaleBegin(
                detector: ScaleGestureDetector
            ): Boolean {
                multiTouchActive = true
                gestureMoved = true
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }

            override fun onScale(
                detector: ScaleGestureDetector
            ): Boolean {
                val previousScale = viewerScale

                viewerScale =
                    (viewerScale * detector.scaleFactor)
                        .coerceIn(1f, 8f)

                // Keep the point under the fingers approximately stationary.
                // Work in view coordinates around ScaleGestureDetector focus.
                if (previousScale > 0f &&
                    viewerScale != previousScale
                ) {
                    val ratio =
                        viewerScale / previousScale

                    panX =
                        detector.focusX -
                            (detector.focusX - panX) * ratio

                    panY =
                        detector.focusY -
                            (detector.focusY - panY) * ratio
                }

                if (viewerScale <= 1.001f) {
                    viewerScale = 1f
                    panX = 0f
                    panY = 0f
                }

                applyViewerMatrix()
                zoomListener?.invoke(viewerScale)
                return true
            }

            override fun onScaleEnd(
                detector: ScaleGestureDetector
            ) {
                multiTouchActive = false

                if (viewerScale <= 1.001f) {
                    parent?.requestDisallowInterceptTouchEvent(false)
                }
            }
        }
    )

    init {
        scaleType = ScaleType.MATRIX
        adjustViewBounds = false

        // Zoom/pan is owned by ZoomPanFrameLayout in v0.2.4.
        isClickable = false
        isFocusable = false
    }

    fun setOnViewerZoomChanged(listener: ((Float) -> Unit)?) {
        zoomListener = listener
        listener?.invoke(viewerScale)
    }

    fun resetViewerTransform() {
        viewerScale = 1f
        panX = 0f
        panY = 0f
        applyViewerMatrix()
        zoomListener?.invoke(viewerScale)
    }

    private val renderLatestRunnable =
        object : Runnable {
            override fun run() {
                val newest =
                    pendingBitmap.getAndSet(null)

                if (newest != null) {
                    val old =
                        currentBitmap

                    currentBitmap =
                        newest

                    setImageBitmap(newest)
                    applyViewerMatrix()

                    if (old != null &&
                        old !== newest &&
                        !old.isRecycled
                    ) {
                        old.recycle()
                    }

                    val now =
                        System.nanoTime()

                    if (renderFpsStartNs == 0L) {
                        renderFpsStartNs = now
                    }

                    renderFpsFrames++

                    val elapsed =
                        now - renderFpsStartNs

                    if (elapsed >=
                        1_000_000_000L
                    ) {
                        renderedFps =
                            renderFpsFrames.toFloat() /
                                (
                                    elapsed.toDouble() /
                                        1_000_000_000.0
                                    ).toFloat()

                        renderFpsFrames = 0
                        renderFpsStartNs = now
                    }
                }

                renderScheduled.set(false)

                // A newer frame may have arrived while this Runnable was
                // rendering. Schedule exactly one more display callback.
                if (running &&
                    pendingBitmap.get() != null &&
                    renderScheduled.compareAndSet(
                        false,
                        true
                    )
                ) {
                    postOnAnimation(this)
                }
            }
        }

    private fun offerDecodedFrame(
        bitmap: Bitmap
    ) {
        val replaced =
            pendingBitmap.getAndSet(bitmap)

        if (replaced != null &&
            replaced !== currentBitmap &&
            !replaced.isRecycled
        ) {
            // Drop stale decoded frames before they ever reach the UI queue.
            replaced.recycle()
        }

        if (renderScheduled.compareAndSet(
                false,
                true
            )
        ) {
            postOnAnimation(
                renderLatestRunnable
            )
        }
    }

    fun start(pair: PairInfo, onState: (String) -> Unit) {
        stop()
        running = true
        lastReceivedFrameAtMs = 0L

        worker = Thread {
            var attempt = 0

            while (running) {
                try {
                    attempt++
                    post {
                        onState(
                            if (attempt <= 1)
                                "Connecting to ${pair.host}…"
                            else
                                "Reconnecting to ${pair.host}… attempt $attempt"
                        )
                    }

                    val conn = URL(pair.endpoint("/stream"))
                        .openConnection() as HttpURLConnection
                    connection = conn
                    conn.connectTimeout = 4_000
                    // Avoid an infinite wait on a stale no-frame stream.
                    // The same process-wide /stream socket survives the
                    // Activity -> 24/7 Service camera hand-off. CameraX may
                    // need several fallback stages before the first new frame,
                    // so do not tear down an otherwise healthy socket too soon.
                    conn.readTimeout = 30_000
                    conn.useCaches = false
                    conn.setRequestProperty("Connection", "close")
                    conn.connect()

                    if (conn.responseCode != 200) {
                        throw IllegalStateException("HTTP ${conn.responseCode}")
                    }

                    val input = BufferedInputStream(conn.inputStream, 256 * 1024)

                    var fpsWindowStart = System.nanoTime()
                    var framesInWindow = 0
                    var firstFrameShown = false
                    attempt = 0

                    post { onState("Connected • waiting for first camera frame…") }

                    while (running) {
                        var line = readAsciiLine(input) ?: break

                        while (running && !line.startsWith("--frame")) {
                            line = readAsciiLine(input) ?: break
                        }
                        if (!running || !line.startsWith("--frame")) break

                        var contentLength = -1
                        while (running) {
                            val header = readAsciiLine(input) ?: break
                            if (header.isEmpty()) break

                            if (header.startsWith("Content-Length:", ignoreCase = true)) {
                                contentLength =
                                    header.substringAfter(":").trim().toIntOrNull() ?: -1
                            }
                        }

                        if (contentLength <= 0 || contentLength > 10_000_000) {
                            throw IllegalStateException("Invalid MJPEG frame size")
                        }

                        val jpeg = ByteArray(contentLength)
                        readFully(input, jpeg)

                        input.read()
                        input.read()

                        val decodeOptions =
                            BitmapFactory.Options().apply {
                                inPreferredConfig =
                                    Bitmap.Config.RGB_565
                            }

                        val bitmap =
                            BitmapFactory.decodeByteArray(
                                jpeg,
                                0,
                                jpeg.size,
                                decodeOptions
                            ) ?: continue

                        lastReceivedFrameAtMs =
                            android.os.SystemClock.elapsedRealtime()

                        if (!firstFrameShown) {
                            firstFrameShown = true
                            post {
                                onState(
                                    "Connected • live video active • measuring real FPS…"
                                )
                            }
                        }

                        framesInWindow++
                        val now = System.nanoTime()
                        val elapsedNs = now - fpsWindowStart

                        if (elapsedNs >= 1_000_000_000L) {
                            val fps =
                                framesInWindow.toFloat() /
                                    (elapsedNs.toDouble() / 1_000_000_000.0).toFloat()

                            framesInWindow = 0
                            fpsWindowStart = now

                            val receivedShown =
                                String.format("%.1f", fps)

                            val renderedShown =
                                String.format("%.1f", renderedFps)

                            post {
                                onState(
                                    "Connected • received $receivedShown fps • displayed $renderedShown fps"
                                )
                            }
                        }

                        offerDecodedFrame(bitmap)
                    }
                } catch (e: Exception) {
                    if (running) {
                        val reason =
                            (
                                e.message
                                    ?: e.javaClass.simpleName
                                )
                                .replace(
                                    "\n",
                                    " "
                                )
                                .take(
                                    80
                                )

                        post {
                            onState(
                                "Stream interrupted • $reason • reconnecting…"
                            )
                        }
                    }
                } finally {
                    try { connection?.disconnect() } catch (_: Exception) {}
                    connection = null
                }

                if (running) {
                    try {
                        Thread.sleep(500L)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }
        }.apply {
            name = "AI-Door-MJPEG-Reconnect-Reader"
            isDaemon = true
            start()
        }
    }

    fun hasRecentFrame(
        maxAgeMs: Long = 4_000L
    ): Boolean {
        val last = lastReceivedFrameAtMs
        if (last <= 0L) return false

        return android.os.SystemClock.elapsedRealtime() - last <=
            maxAgeMs.coerceAtLeast(250L)
    }

    fun clearFrame() {
        val pending =
            pendingBitmap.getAndSet(null)

        if (
            pending != null &&
            pending !== currentBitmap &&
            !pending.isRecycled
        ) {
            pending.recycle()
        }

        val old =
            currentBitmap

        currentBitmap = null
        renderScheduled.set(false)

        post {
            setImageDrawable(null)
            imageMatrix = Matrix()

            if (
                old != null &&
                !old.isRecycled
            ) {
                old.recycle()
            }
        }
    }

    fun stop() {
        running = false

        try {
            connection?.disconnect()
        } catch (_: Exception) {}

        connection = null

        worker?.interrupt()
        worker = null

        val pending =
            pendingBitmap.getAndSet(null)

        if (pending != null &&
            pending !== currentBitmap &&
            !pending.isRecycled
        ) {
            pending.recycle()
        }

        renderScheduled.set(false)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = false

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onSizeChanged(
        w: Int,
        h: Int,
        oldw: Int,
        oldh: Int
    ) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyViewerMatrix()
    }

    private fun applyViewerMatrix() {
        val bitmap = currentBitmap ?: return
        if (width <= 0 || height <= 0 || bitmap.width <= 0 || bitmap.height <= 0) {
            return
        }

        // At 1x the complete camera frame must remain visible with its
        // original pixel aspect ratio. FIT_CENTER is important when the DVR
        // rotates a 16:9 source into 9:16; CENTER_CROP made the monitor image
        // look heavily cropped/warped inside the fixed viewer box.
        val baseScale = min(
            width.toFloat() / bitmap.width.toFloat(),
            height.toFloat() / bitmap.height.toFloat()
        )
        // One scalar is used for BOTH axes. Never use independent
        // widthScale/heightScale here; that would deform portrait frames.
        val uniformScale =
            baseScale *
                viewerScale

        val contentW =
            bitmap.width *
                uniformScale

        val contentH =
            bitmap.height *
                uniformScale

        val maxPanX = ((contentW - width) / 2f).coerceAtLeast(0f)
        val maxPanY = ((contentH - height) / 2f).coerceAtLeast(0f)

        panX = panX.coerceIn(-maxPanX, maxPanX)
        panY = panY.coerceIn(-maxPanY, maxPanY)

        val left = (width - contentW) / 2f + panX
        val top = (height - contentH) / 2f + panY

        drawMatrix.reset()
        drawMatrix.setScale(uniformScale, uniformScale)
        drawMatrix.postTranslate(left, top)
        imageMatrix = drawMatrix
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    private fun readAsciiLine(input: BufferedInputStream): String? {
        val bytes = ArrayList<Byte>(128)
        while (true) {
            val value = input.read()
            if (value == -1) {
                return if (bytes.isEmpty()) null
                else bytes.toByteArray().toString(StandardCharsets.US_ASCII)
            }

            if (value == '\n'.code) {
                if (bytes.isNotEmpty() && bytes.last() == '\r'.code.toByte()) {
                    bytes.removeAt(bytes.lastIndex)
                }
                return bytes.toByteArray().toString(StandardCharsets.US_ASCII)
            }
            bytes.add(value.toByte())
        }
    }

    private fun readFully(input: BufferedInputStream, target: ByteArray) {
        var offset = 0
        while (offset < target.size) {
            val count = input.read(target, offset, target.size - offset)
            if (count < 0) throw IllegalStateException("Stream ended")
            offset += count
        }
    }
}
