package com.example.aidoormonitor

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.view.View
import android.widget.ImageView
import android.widget.CheckBox
import android.widget.TextView
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.aidoormonitor.databinding.ActivityMonitorBinding
import com.example.aidoormonitor.net.PairInfo
import com.example.aidoormonitor.net.Pairing
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MonitorActivity : AppCompatActivity() {
    private lateinit var b: ActivityMonitorBinding

    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val recordingTransferExecutor =
        Executors.newSingleThreadExecutor()

    private val recordingThumbnailExecutor =
        Executors.newFixedThreadPool(2)

    private data class RemoteRecordingItem(
        val id: String,
        val name: String,
        val sizeBytes: Long,
        val durationMs: Long,
        val dateAddedMs: Long,
        val eventFolder: String
    )

    private var remoteRecordings:
        List<RemoteRecordingItem> =
        emptyList()

    private val selectedRecordingIds =
        linkedSetOf<String>()

    private val openRecordingFolders =
        linkedSetOf<String>()

    private val preferredFolderOrder =
        listOf(
            "Dog",
            "Cat",
            "Car",
            "Person",
            "Bicycle",
            "Motorcycle",
            "Truck",
            "Bird",
            "Stroller",
            "Package",
            "Sound",
            "Motion",
            "Manual"
        )

    private var pendingRecordingDownloadId:
        String? =
        null

    private var currentPair: PairInfo? = null
    private var connected = false
    private var remoteManualFocusSupported = false

    private var remoteMaxZoomRatio = 1f
    private var remoteZoomLinear = 0f
    private var remotePanX = 0f
    private var remotePanY = 0f
    private var remotePanMode = "unknown"

    private val cameraViewHandler =
        Handler(Looper.getMainLooper())

    private var cameraViewSendScheduled = false
    private var pendingViewLinear = 0f
    private var pendingViewPanX = 0f
    private var pendingViewPanY = 0f

    private var ignorePreviewQualityCallback = false

    private val connectionHealthHandler =
        Handler(Looper.getMainLooper())

    private var healthPollRunning = false
    private var lastVisualStreamAvailable: Boolean? = null
    private var lastCompatibilityStage = ""

    private var lastHealthStreamKickAt =
        0L

    private val storagePermission =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                val pendingId =
                    pendingRecordingDownloadId

                pendingRecordingDownloadId =
                    null

                if (pendingId != null) {
                    remoteRecordings
                        .firstOrNull {
                            it.id == pendingId
                        }
                        ?.let {
                            downloadRemoteRecording(
                                it
                            )
                        }
                } else {
                    saveSnapshot()
                }
            } else {
                pendingRecordingDownloadId =
                    null
                toast(
                    "Storage permission was not granted."
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMonitorBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.root.applySystemBarInsets()

        val prefs = getSharedPreferences("monitor_pair", MODE_PRIVATE)
        b.pairingCode.setText(prefs.getString("last_pair", "").orEmpty())

        b.liveGesture.setOnCameraViewChanged {
                linear,
                panX,
                panY ->

            remoteZoomLinear = linear
            remotePanX = panX
            remotePanY = panY

            if (!b.remoteZoom.isPressed) {
                b.remoteZoom.progress =
                    (linear * 1000f).toInt().coerceIn(0, 1000)
            }

            updateCameraViewLabel()
            scheduleCameraViewCommand(linear, panX, panY)
        }

        b.resetViewerPanZoom.setOnClickListener {
            remoteZoomLinear = 0f
            remotePanX = 0f
            remotePanY = 0f
            b.liveGesture.resetCameraView(notify = true)
        }

        setupPreviewQualityUi()
        setupRemoteDvrSettingsUi()

        b.openRules.setOnClickListener {
            startActivity(Intent(this, RuleEditorActivity::class.java))
        }

        b.scanQr.setOnClickListener { scanCameraQr() }

        b.connectButton.setOnClickListener {
            if (connected) disconnect() else connectFromField()
        }

        b.remoteZoom.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    val linear = progress / 1000f
                    val ratio =
                        1f + linear * (remoteMaxZoomRatio - 1f)

                    b.zoomValue.text =
                        String.format(
                            Locale.US,
                            "Camera zoom: %.1f×",
                            ratio
                        )

                    if (fromUser) {
                        remoteZoomLinear = linear

                        if (linear <= 0.001f) {
                            remotePanX = 0f
                            remotePanY = 0f
                        }

                        b.liveGesture.setCameraState(
                            remoteZoomLinear,
                            remotePanX,
                            remotePanY,
                            notify = false
                        )

                        updateCameraViewLabel()

                        if (connected) {
                            scheduleCameraViewCommand(
                                remoteZoomLinear,
                                remotePanX,
                                remotePanY
                            )
                        }
                    }
                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) = Unit

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) = Unit
            }
        )

        b.remoteFocus.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar?,
                progress: Int,
                fromUser: Boolean
            ) {
                val pct = progress / 10
                b.remoteFocusValue.text =
                    if (progress == 0) "Manual focus: Infinity"
                    else "Manual focus: $pct% toward Near"

                if (fromUser && connected && remoteManualFocusSupported) {
                    sendCommand(
                        "/focus?mode=manual&linear=${progress / 1000f}",
                        silent = true
                    )
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        b.remoteAutoFocus.setOnClickListener {
            if (requireConnection()) {
                sendCommand("/focus?mode=auto", successMessage = "Auto Focus enabled.")
            }
        }

        b.remoteFocusFar.setOnClickListener { stepRemoteFocus(-25) }
        b.remoteFocusNear.setOnClickListener { stepRemoteFocus(25) }

        b.remoteSaveFocus.setOnClickListener {
            if (requireConnection()) {
                sendCommand("/focus/save", successMessage = "Camera focus default saved.")
            }
        }

        b.startRemoteRecording.setOnClickListener {
            if (requireConnection()) {
                sendCommand("/record/start", successMessage = "Recording command sent.")
            }
        }

        b.stopRemoteRecording.setOnClickListener {
            if (requireConnection()) {
                sendCommand("/record/stop", successMessage = "Stop/save command sent.")
            }
        }

        b.saveSnapshot.setOnClickListener {
            if (!requireConnection()) return@setOnClickListener

            if (Build.VERSION.SDK_INT <= 28 &&
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            } else {
                saveSnapshot()
            }
        }

        b.refreshEvents.setOnClickListener {
            if (requireConnection()) refreshRemoteEvents()
        }

        b.recordingSort.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "Newest first",
                    "Oldest first",
                    "AI / filename A → Z",
                    "AI / filename Z → A",
                    "Longest first",
                    "Largest first"
                )
            )

        b.recordingSort.setSelection(
            getSharedPreferences(
                "monitor_pair",
                MODE_PRIVATE
            )
                .getInt(
                    "recording_sort_mode",
                    0
                )
                .coerceIn(
                    0,
                    5
                )
        )

        b.recordingSort.onItemSelectedListener =
            object :
                android.widget.AdapterView
                    .OnItemSelectedListener {

                override fun onItemSelected(
                    parent:
                        android.widget.AdapterView<*>?,
                    view:
                        android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    getSharedPreferences(
                        "monitor_pair",
                        MODE_PRIVATE
                    )
                        .edit()
                        .putInt(
                            "recording_sort_mode",
                            position.coerceIn(
                                0,
                                5
                            )
                        )
                        .apply()

                    if (
                        remoteRecordings
                            .isNotEmpty()
                    ) {
                        remoteRecordings =
                            sortRemoteRecordings(
                                remoteRecordings
                            )

                        renderRecordingThumbnailList()

                        if (
                            remoteRecordings
                                .isNotEmpty()
                        ) {
                            updateSelectedRecordingInfo(
                                0
                            )
                        }
                    }
                }

                override fun onNothingSelected(
                    parent:
                        android.widget.AdapterView<*>?
                ) = Unit
            }

        b.refreshRecordings.setOnClickListener {
            if (requireConnection()) {
                refreshRemoteRecordings()
            }
        }

        b.selectAllRecordings
            .setOnClickListener {
                selectedRecordingIds.clear()
                selectedRecordingIds.addAll(
                    remoteRecordings.map {
                        it.id
                    }
                )
                renderRecordingThumbnailList()
                updateRecordingSelectionUi()
            }

        b.clearRecordingSelection
            .setOnClickListener {
                selectedRecordingIds.clear()
                renderRecordingThumbnailList()
                updateRecordingSelectionUi()
            }

        b.downloadCheckedRecordings
            .setOnClickListener {
                if (requireConnection()) {
                    downloadCheckedRecordings()
                }
            }

        b.deleteCheckedRecordings
            .setOnClickListener {
                if (requireConnection()) {
                    confirmDeleteCheckedRecordings()
                }
            }

        b.deleteSelectedRecording
            .setOnClickListener {
                if (requireConnection()) {
                    selectedRemoteRecording()
                        ?.let {
                            confirmDeleteRecordings(
                                listOf(it)
                            )
                        }
                        ?: toast(
                            "Select a recording first."
                        )
                }
            }

        b.recordingsSpinner.onItemSelectedListener =
            object :
                android.widget.AdapterView
                    .OnItemSelectedListener {

                override fun onItemSelected(
                    parent:
                        android.widget.AdapterView<*>?,
                    view:
                        android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    updateSelectedRecordingInfo(
                        position
                    )
                }

                override fun onNothingSelected(
                    parent:
                        android.widget.AdapterView<*>?
                ) = Unit
            }

        b.playSelectedRecording
            .setOnClickListener {
                if (requireConnection()) {
                    playSelectedRecording()
                }
            }

        b.downloadSelectedRecording
            .setOnClickListener {
                if (requireConnection()) {
                    requestDownloadSelectedRecording()
                }
            }

        updateRecordingControls()
        updateRemoteFocusEnabled(false)
    }

    private fun stepRemoteFocus(delta: Int) {
        if (!connected || !remoteManualFocusSupported) return
        val next = (b.remoteFocus.progress + delta).coerceIn(0, 1000)
        b.remoteFocus.progress = next
        sendCommand(
            "/focus?mode=manual&linear=${next / 1000f}",
            silent = true
        )
    }

    private fun setupRemoteDvrSettingsUi() {
        b.remoteDvrQuality.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "8K UHD / 7680×4320",
                    "4K UHD / 3840×2160",
                    "1080p / 1920×1080"
                )
            )

        b.remoteVideoBitrate.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "Auto",
                    "20 Mbps",
                    "32 Mbps",
                    "50 Mbps",
                    "75 Mbps",
                    "100 Mbps",
                    "150 Mbps",
                    "200 Mbps"
                )
            )

        b.remoteAudioSampleRate.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "44.1 kHz",
                    "48 kHz"
                )
            )

        b.remoteAudioBitrate.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "64 kbps",
                    "96 kbps",
                    "128 kbps",
                    "192 kbps",
                    "256 kbps",
                    "320 kbps"
                )
            )

        b.remoteAudioSync.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "Automatic / 0 ms",
                    "Audio 250 ms later",
                    "Audio 500 ms later",
                    "Audio 1000 ms later",
                    "Audio 2000 ms later",
                    "Audio 3000 ms later",
                    "Audio 5000 ms later",
                    "Audio 250 ms earlier",
                    "Audio 500 ms earlier",
                    "Audio 1000 ms earlier"
                )
            )

        b.loadRemoteDvrSettings
            .setOnClickListener {
                if (requireConnection()) {
                    loadRemoteDvrSettings()
                }
            }

        b.applyRemoteDvrSettings
            .setOnClickListener {
                if (requireConnection()) {
                    applyRemoteDvrSettings()
                }
            }
    }

    private fun selectedRemoteVideoBitrateMbps():
        Int =
        intArrayOf(
            0,
            20,
            32,
            50,
            75,
            100,
            150,
            200
        )[
            b.remoteVideoBitrate
                .selectedItemPosition
                .coerceIn(
                    0,
                    7
                )
        ]

    private fun selectedRemoteAudioBitrateKbps():
        Int =
        intArrayOf(
            64,
            96,
            128,
            192,
            256,
            320
        )[
            b.remoteAudioBitrate
                .selectedItemPosition
                .coerceIn(
                    0,
                    5
                )
        ]

    private fun selectedRemoteAudioSampleRateHz():
        Int =
        if (
            b.remoteAudioSampleRate
                .selectedItemPosition ==
            0
        ) {
            44_100
        } else {
            48_000
        }

    private fun selectedRemoteAudioSyncMs():
        Int =
        intArrayOf(
            0,
            -250,
            -500,
            -1000,
            -2000,
            -3000,
            -5000,
            250,
            500,
            1000
        )[
            b.remoteAudioSync
                .selectedItemPosition
                .coerceIn(
                    0,
                    9
                )
        ]

    private fun loadRemoteDvrSettings() {
        val pair =
            currentPair ?: return

        b.remoteDvrSettingsStatus.text =
            "Loading camera DVR settings…"

        networkExecutor.execute {
            try {
                val raw =
                    getBytes(
                        pair.endpoint(
                            "/dvr-settings"
                        )
                    )
                        .toString(
                            Charsets.UTF_8
                        )

                val json =
                    JSONObject(
                        raw
                    )

                runOnUiThread {
                    b.remoteDvrQuality
                        .setSelection(
                            json.optInt(
                                "quality",
                                1
                            )
                                .coerceIn(
                                    0,
                                    2
                                )
                        )

                    val videoValues =
                        intArrayOf(
                            0,
                            20,
                            32,
                            50,
                            75,
                            100,
                            150,
                            200
                        )

                    b.remoteVideoBitrate
                        .setSelection(
                            videoValues
                                .indexOf(
                                    json.optInt(
                                        "videoBitrateMbps",
                                        0
                                    )
                                )
                                .coerceAtLeast(
                                    0
                                )
                        )

                    b.remoteAudioSampleRate
                        .setSelection(
                            if (
                                json.optInt(
                                    "audioSampleRateHz",
                                    48_000
                                ) ==
                                44_100
                            ) {
                                0
                            } else {
                                1
                            }
                        )

                    val audioValues =
                        intArrayOf(
                            64,
                            96,
                            128,
                            192,
                            256,
                            320
                        )

                    b.remoteAudioBitrate
                        .setSelection(
                            audioValues
                                .indexOf(
                                    json.optInt(
                                        "audioBitrateKbps",
                                        128
                                    )
                                )
                                .coerceAtLeast(
                                    0
                                )
                        )

                    val syncValues =
                        intArrayOf(
                            0,
                            -250,
                            -500,
                            -1000,
                            -2000,
                            -3000,
                            -5000,
                            250,
                            500,
                            1000
                        )

                    b.remoteAudioSync
                        .setSelection(
                            syncValues
                                .indexOf(
                                    json.optInt(
                                        "audioSyncMs",
                                        0
                                    )
                                )
                                .coerceAtLeast(
                                    0
                                )
                        )

                    b.remoteDvrSettingsStatus.text =
                        buildString {
                            append(
                                "Camera active: "
                            )
                            append(
                                json.optString(
                                    "activeRecordingSize",
                                    "unknown"
                                )
                            )
                            append(
                                " @ "
                            )
                            append(
                                json.optInt(
                                    "activeRecordingFps",
                                    0
                                )
                            )
                            append(
                                " fps"
                            )

                            val fallback =
                                json.optString(
                                    "qualityFallback",
                                    ""
                                )

                            if (
                                fallback.isNotBlank()
                            ) {
                                append(
                                    "\\n"
                                )
                                append(
                                    fallback
                                )
                            }
                        }
                }

            } catch (
                t: Throwable
            ) {
                runOnUiThread {
                    b.remoteDvrSettingsStatus.text =
                        "Could not load camera settings: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )
                }
            }
        }
    }

    private fun applyRemoteDvrSettings() {
        val pair =
            currentPair ?: return

        val path =
            "/dvr-settings" +
                "?quality=" +
                b.remoteDvrQuality
                    .selectedItemPosition
                    .coerceIn(
                        0,
                        2
                    ) +
                "&videoBitrateMbps=" +
                selectedRemoteVideoBitrateMbps() +
                "&audioBitrateKbps=" +
                selectedRemoteAudioBitrateKbps() +
                "&audioSampleRateHz=" +
                selectedRemoteAudioSampleRateHz() +
                "&audioSyncMs=" +
                selectedRemoteAudioSyncMs()

        b.remoteDvrSettingsStatus.text =
            "Applying settings and restarting camera DVR…"

        networkExecutor.execute {
            var conn:
                HttpURLConnection? =
                null

            try {
                conn =
                    URL(
                        pair.endpoint(
                            path
                        )
                    )
                        .openConnection()
                        as HttpURLConnection

                conn.requestMethod =
                    "POST"
                conn.connectTimeout =
                    8_000
                conn.readTimeout =
                    8_000
                conn.useCaches =
                    false
                conn.connect()

                val response =
                    conn.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                JSONObject(
                    response
                )

                runOnUiThread {
                    b.remoteDvrSettingsStatus.text =
                        "Settings applied. Camera DVR is restarting…"

                    Handler(
                        Looper
                            .getMainLooper()
                    )
                        .postDelayed(
                            {
                                if (connected) {
                                    loadRemoteDvrSettings()
                                }
                            },
                            3_000L
                        )
                }

            } catch (
                t: Throwable
            ) {
                runOnUiThread {
                    b.remoteDvrSettingsStatus.text =
                        "Remote DVR settings failed: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )
                }

            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun setupPreviewQualityUi() {
        val labels =
            listOf(
                "Auto Smooth (recommended)",
                "Smooth • 180p / low bitrate",
                "Balanced • 240p",
                "Sharp • 270p",
                "Max Detail • 270p / high JPEG"
            )

        b.previewQuality.adapter =
            ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                labels
            )

        b.previewQuality.setSelection(0)

        b.previewQuality.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    updatePreviewQualityInfo(position)

                    if (
                        !ignorePreviewQualityCallback &&
                        connected
                    ) {
                        sendCommand(
                            "/preview?mode=$position",
                            silent = true
                        )
                    }
                }

                override fun onNothingSelected(
                    parent: android.widget.AdapterView<*>?
                ) = Unit
            }
    }

    private fun updatePreviewQualityInfo(mode: Int) {
        b.previewQualityInfo.text =
            when (mode) {
                1 ->
                    "Smooth: 320×180 and low JPEG bitrate. Best if FPS collapses during fast motion."
                2 ->
                    "Balanced: about 426×240 with moderate bitrate."
                3 ->
                    "Sharp: native 9:16 portrait render with more detail."
                4 ->
                    "Max Detail: native 9:16 portrait GPU render with high JPEG quality; uses the most Wi-Fi/CPU."
                else ->
                    "Auto Smooth: lowers bitrate when source FPS or thermal headroom drops."
            }
    }

    private fun updateCameraViewLabel() {
        val ratio =
            1f + remoteZoomLinear * (remoteMaxZoomRatio - 1f)

        val panText =
            when (remotePanMode) {
                "sensor-freeform" ->
                    "sensor pan"
                "live-software-fallback" ->
                    "live-view pan fallback"
                "center-only" ->
                    "center zoom"
                else ->
                    "camera pan"
            }

        b.viewerZoomStatus.text =
            String.format(
                Locale.US,
                "Camera view: %.1f× • pan X %.0f%% / Y %.0f%% • %s",
                ratio,
                remotePanX * 100f,
                remotePanY * 100f,
                panText
            )
    }

    private fun scheduleCameraViewCommand(
        linear: Float,
        panX: Float,
        panY: Float
    ) {
        pendingViewLinear = linear.coerceIn(0f, 1f)
        pendingViewPanX = panX.coerceIn(-1f, 1f)
        pendingViewPanY = panY.coerceIn(-1f, 1f)

        if (cameraViewSendScheduled) return

        cameraViewSendScheduled = true

        cameraViewHandler.postDelayed(
            {
                cameraViewSendScheduled = false

                if (!connected) {
                    return@postDelayed
                }

                sendCommand(
                    "/view?linear=$pendingViewLinear" +
                        "&panX=$pendingViewPanX" +
                        "&panY=$pendingViewPanY",
                    silent = true
                )
            },
            35L
        )
    }

    private fun scanCameraQr() {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .enableAutoZoom()
            .build()

        val scanner = GmsBarcodeScanning.getClient(this, options)

        b.connectionState.text = "Opening QR scanner…"

        scanner.startScan()
            .addOnSuccessListener { barcode ->
                val raw = barcode.rawValue.orEmpty()
                val pair = Pairing.parse(raw)
                if (pair == null) {
                    b.connectionState.text =
                        "That QR is not an AI Door Monitor pairing code."
                } else {
                    b.pairingCode.setText(raw)
                    b.connectionState.text =
                        "Camera QR read. Tap Connect live stream."
                }
            }
            .addOnCanceledListener {
                b.connectionState.text = "QR scan canceled."
            }
            .addOnFailureListener { e ->
                b.connectionState.text =
                    "QR scanner failed: ${e.message}. You can paste the pairing code instead."
            }
    }

    private fun startConnectionHealthPolling() {
        if (healthPollRunning) return
        healthPollRunning = true

        connectionHealthHandler.post(
            object : Runnable {
                override fun run() {
                    if (!healthPollRunning || !connected) return
                    pollConnectionHealth()
                    connectionHealthHandler.postDelayed(this, 1_000L)
                }
            }
        )
    }

    private fun stopConnectionHealthPolling() {
        healthPollRunning = false
        connectionHealthHandler.removeCallbacksAndMessages(null)
    }

    private fun pollConnectionHealth() {
        val pair = currentPair ?: return

        networkExecutor.execute {
            try {
                val raw =
                    getBytes(pair.endpoint("/health"))
                        .toString(Charsets.UTF_8)

                val health = JSONObject(raw)
                val visualAvailable =
                    health.optBoolean("visualStreamAvailable", true)
                val recordingFirst =
                    health.optBoolean("recordingFirstMode", false)
                val stage =
                    health.optString("compatibilityStage", "")
                val firstFramePending =
                    health.optBoolean(
                        "firstFramePending",
                        false
                    )

                val activeQuality =
                    health.optString(
                        "quality",
                        "recording quality"
                    )

                val requestedQuality =
                    health.optString(
                        "requestedQuality",
                        ""
                    )

                val recordingModeName =
                    health.optString(
                        "recordingModeName",
                        ""
                    )

                val frameReady =
                    health.optBoolean(
                        "frameReady",
                        false
                    )

                val frameAgeMs =
                    health.optLong(
                        "frameAgeMs",
                        -1L
                    )

                val lanServerRunning =
                    health.optBoolean(
                        "lanServerRunning",
                        true
                    )

                val lanServerError =
                    health.optString(
                        "lanServerError",
                        ""
                    )

                runOnUiThread {
                    if (!connected || currentPair != pair) {
                        return@runOnUiThread
                    }

                    val visualChanged =
                        lastVisualStreamAvailable != visualAvailable
                    val stageChanged =
                        lastCompatibilityStage != stage

                    lastVisualStreamAvailable = visualAvailable
                    lastCompatibilityStage = stage

                    if (!visualAvailable) {
                        b.liveView.stop()
                        b.liveView.clearFrame()

                        b.liveUnavailableOverlay.visibility =
                            android.view.View.VISIBLE

                        b.liveUnavailableOverlay.text =
                            if (recordingFirst) {
                                buildString {
                                    append("RECORDING-FIRST\n\n")
                                    append(activeQuality)
                                    append("\n\nMP4 recording / pre-record is active.")
                                    append("\nVisual preview is unavailable.")

                                    if (
                                        requestedQuality.startsWith("8K") &&
                                        activeQuality.contains("camera max")
                                    ) {
                                        append("\n\n8K was requested; the camera maximum is shown above.")
                                    }
                                }
                            } else {
                                "Visual preview unavailable\n\n$stage"
                            }

                        b.connectionState.text =
                            if (recordingFirst) {
                                "Connected • RECORDING-FIRST • $activeQuality • MP4 active • visual preview unavailable"
                            } else {
                                "Connected • $stage • visual stream unavailable"
                            }
                    } else if (visualChanged && visualAvailable) {
                        b.liveUnavailableOverlay.visibility =
                            android.view.View.GONE
                        b.liveView.clearFrame()

                        b.liveView.start(pair) { state ->
                            b.connectionState.text = state
                        }
                    } else if (firstFramePending && stageChanged) {
                        b.connectionState.text =
                            "Connected • $recordingModeName • trying $stage • waiting for first frame…"
                    }

                    if (
                        visualAvailable &&
                        frameReady &&
                        frameAgeMs in 0L..3_000L &&
                        !b.liveView.hasRecentFrame(4_500L)
                    ) {
                        val now =
                            android.os.SystemClock
                                .elapsedRealtime()

                        if (
                            now - lastHealthStreamKickAt >
                            8_000L
                        ) {
                            lastHealthStreamKickAt =
                                now

                            // Camera /health is fresh, but this monitor has not
                            // received a MJPEG frame recently. Only in that
                            // actual stale-reader case do we restart the reader.
                            b.liveView.start(
                                pair
                            ) { state ->
                                b.connectionState.text =
                                    state
                            }
                        }
                    } else if (!lanServerRunning) {
                        b.connectionState.text =
                            "Camera/AI service active • LAN stream restarting${if (lanServerError.isNotBlank()) " • $lanServerError" else ""}"
                    }
                }
            } catch (_: Exception) {
                // Keep the MJPEG worker's own reconnect behavior on transient
                // health request failures.
            }
        }
    }

    private fun connectFromField() {
        val raw = b.pairingCode.text.toString().trim()
        val pair = Pairing.parse(raw)

        if (pair == null) {
            toast("Scan the camera QR or paste a valid pairing code.")
            return
        }

        currentPair = pair
        getSharedPreferences("monitor_pair", MODE_PRIVATE)
            .edit()
            .putString("last_pair", raw)
            .apply()

        b.connectionState.text = "Checking camera…"

        networkExecutor.execute {
            try {
                val healthRaw = getBytes(pair.endpoint("/health"))
                    .toString(Charsets.UTF_8)
                val health = JSONObject(healthRaw)

                remoteManualFocusSupported =
                    health.optBoolean("manualFocusSupported", false)
                val focusLinear =
                    health.optDouble("focusLinear", 0.0)
                        .toFloat().coerceIn(0f, 1f)

                val maxFocusDiopters =
                    health.optDouble("maxFocusDiopters", 0.0)
                        .toFloat().coerceAtLeast(0f)

                val focusManual =
                    health.optBoolean("focusManual", false)

                val maxZoom =
                    health.optDouble("maxZoom", 1.0)
                        .toFloat().coerceAtLeast(1f)

                val zoomRatio =
                    health.optDouble(
                        "appliedZoomRatio",
                        health.optDouble(
                            "zoomRatio",
                            1.0
                        )
                    )
                        .toFloat()
                        .coerceIn(
                            1f,
                            maxZoom
                        )

                val zoomLinear =
                    if (maxZoom <= 1.001f) 0f
                    else ((zoomRatio - 1f) / (maxZoom - 1f))
                        .coerceIn(0f, 1f)

                val panX =
                    health.optDouble("panX", 0.0)
                        .toFloat().coerceIn(-1f, 1f)

                val panY =
                    health.optDouble("panY", 0.0)
                        .toFloat().coerceIn(-1f, 1f)

                val previewMode =
                    health.optInt("previewQualityMode", 0)
                        .coerceIn(0, 4)

                val panMode =
                    health.optString(
                        "panMode",
                        "unknown"
                    )
                val zoomControlMode =
                    health.optString(
                        "zoomControlMode",
                        "unknown"
                    )

                val recordingFirstMode =
                    health.optBoolean(
                        "recordingFirstMode",
                        false
                    )

                val visualStreamAvailable =
                    health.optBoolean(
                        "visualStreamAvailable",
                        true
                    )

                val compatibilityStage =
                    health.optString(
                        "compatibilityStage",
                        ""
                    )

                val recordingModeName =
                    health.optString(
                        "recordingModeName",
                        ""
                    )

                runOnUiThread {
                    connected = true
                    b.connectButton.text = "Disconnect"

                    lastVisualStreamAvailable = visualStreamAvailable
                    lastCompatibilityStage = compatibilityStage

                    if (visualStreamAvailable) {
                        b.liveUnavailableOverlay.visibility =
                            android.view.View.GONE

                        b.connectionState.text =
                            "Connected • $recordingModeName • ${health.optString("quality", "camera")} • live stream active"

                        b.liveView.start(pair) { state ->
                            b.connectionState.text = state
                        }
                    } else {
                        b.liveView.stop()
                        b.liveView.clearFrame()

                        val activeQuality =
                            health.optString(
                                "quality",
                                "recording quality"
                            )

                        val requestedQuality =
                            health.optString(
                                "requestedQuality",
                                ""
                            )

                        b.liveUnavailableOverlay.visibility =
                            android.view.View.VISIBLE

                        b.liveUnavailableOverlay.text =
                            buildString {
                                append("RECORDING-FIRST\n\n")
                                append(activeQuality)
                                append("\n\nMP4 recording / pre-record is active.")
                                append("\nVisual preview is unavailable in this camera combination.")

                                if (
                                    requestedQuality.startsWith("8K") &&
                                    activeQuality.contains("camera max")
                                ) {
                                    append("\n\nThe 8K request resolved to the camera maximum shown above.")
                                }
                            }

                        b.connectionState.text =
                            "Connected • RECORDING-FIRST • $activeQuality • visual preview unavailable"
                    }

                    remoteMaxZoomRatio = maxZoom
                    remoteZoomLinear = zoomLinear
                    remotePanX = panX
                    remotePanY = panY
                    remotePanMode = panMode

                    b.liveGesture.setMaxZoomRatio(maxZoom)
                    b.liveGesture.setCameraState(
                        zoomLinear,
                        panX,
                        panY,
                        notify = false
                    )

                    b.remoteZoom.progress =
                        (zoomLinear * 1000f).toInt().coerceIn(0, 1000)

                    updateCameraViewLabel()

                    b.zoomValue.text =
                        String.format(
                            Locale.US,
                            "Camera zoom: %.2f× • %s",
                            zoomRatio,
                            zoomControlMode
                        )

                    ignorePreviewQualityCallback = true
                    b.previewQuality.setSelection(previewMode)
                    updatePreviewQualityInfo(previewMode)
                    ignorePreviewQualityCallback = false

                    if (
                        panMode ==
                        "live-software-fallback"
                    ) {
                        b.previewQualityInfo.text =
                            b.previewQualityInfo.text.toString() +
                                "\nPan: camera reports CENTER_ONLY cropping, so drag-pan uses a live-view software fallback."
                    } else if (
                        panMode ==
                        "center-only"
                    ) {
                        b.previewQualityInfo.text =
                            b.previewQualityInfo.text.toString() +
                                "\nZoom: remote Camera2 sensor crop is active. This lens reports CENTER_ONLY crop, so remote zoom works but off-center sensor pan is not available."
                    }

                    b.remoteFocus.progress = (focusLinear * 1000f).toInt()
                    updateRemoteFocusEnabled(remoteManualFocusSupported)

                    b.remoteFocusStatus.text =
                        if (remoteManualFocusSupported) {
                            if (focusManual) {
                                val diopters =
                                    focusLinear * maxFocusDiopters
                                "Remote manual focus active • ${String.format(java.util.Locale.US, "%.2f", diopters)} D"
                            } else {
                                "Manual focus supported • Auto Focus currently active."
                            }
                        } else {
                            "Selected camera/lens reports no adjustable Camera2 manual focus."
                        }

                    if (health.optBoolean("uhdSupported", false)) {
                        b.saveInfo.text =
                            "Camera reports 4K UHD support.\nMP4 saves on camera phone → Movies/AI Door Monitor."
                    }

                    if (recordingFirstMode) {
                        b.saveInfo.text =
                            "Strict Recording Resolution is prioritizing exact ${health.optString("quality", "selected")} MP4. This phone cannot expose visual ImageAnalysis at the same time, so live preview/motion/pose AI are disabled in this session. Continuous recording and Event Pre-Record still run; audio AI can still trigger event clips."
                    } else if (!health.optBoolean("recordingAvailable", true)) {
                        b.saveInfo.text =
                            "Live stream is active, but MP4 is unavailable in this non-strict compatibility session."
                    }

                    startConnectionHealthPolling()
                }

                refreshRemoteEvents()
                refreshRemoteRecordings()
            } catch (e: Exception) {
                runOnUiThread {
                    connected = false
                    updateRemoteFocusEnabled(false)
                    b.connectionState.text =
                        "Could not connect: ${e.message}. Check same Wi-Fi."
                }
            }
        }
    }

    private fun updateRemoteFocusEnabled(enabled: Boolean) {
        b.remoteFocus.isEnabled = enabled
        b.remoteFocusFar.isEnabled = enabled
        b.remoteFocusNear.isEnabled = enabled
        b.remoteSaveFocus.isEnabled = enabled
    }

    private fun disconnect() {
        connected = false
        remoteManualFocusSupported = false
        stopConnectionHealthPolling()
        lastVisualStreamAvailable = null
        lastCompatibilityStage = ""
        lastHealthStreamKickAt = 0L
        b.liveView.stop()
        b.liveView.clearFrame()
        b.liveUnavailableOverlay.visibility =
            android.view.View.GONE

        b.connectButton.text = "Connect live stream"
        b.connectionState.text = "Disconnected"

        remoteRecordings =
            emptyList()
        selectedRecordingIds.clear()
        openRecordingFolders.clear()

        try {
            b.recordingsThumbnailList
                .removeAllViews()
        } catch (_: Throwable) {
        }

        updateRecordingControls()

        updateRemoteFocusEnabled(false)
    }

    private fun requireConnection(): Boolean {
        if (!connected || currentPair == null) {
            toast("Connect to the camera phone first.")
            return false
        }
        return true
    }

    private fun sendCommand(
        path: String,
        successMessage: String? = null,
        silent: Boolean = false
    ) {
        val pair = currentPair ?: return

        networkExecutor.execute {
            try {
                getBytes(pair.endpoint(path))
                if (!silent && successMessage != null) {
                    runOnUiThread { toast(successMessage) }
                }
            } catch (e: Exception) {
                if (!silent) {
                    runOnUiThread { toast("Command failed: ${e.message}") }
                }
            }
        }
    }

    private fun refreshRemoteRecordings() {
        val pair =
            currentPair ?: return

        runOnUiThread {
            b.recordingsStatus.text =
                "Reading recordings from camera phone…"
        }

        networkExecutor.execute {
            try {
                val raw =
                    getBytes(
                        pair.endpoint(
                            "/recordings"
                        )
                    )
                        .toString(
                            Charsets.UTF_8
                        )

                val root =
                    JSONObject(raw)

                val array =
                    root.optJSONArray(
                        "recordings"
                    )
                        ?: JSONArray()

                val items =
                    mutableListOf<
                        RemoteRecordingItem
                    >()

                for (
                    i in 0 until
                        array.length()
                ) {
                    val item =
                        array.optJSONObject(i)
                            ?: continue

                    val id =
                        item.optString("id")

                    if (id.isBlank()) {
                        continue
                    }

                    items +=
                        RemoteRecordingItem(
                            id = id,
                            name =
                                item.optString(
                                    "name",
                                    "Camera recording"
                                ),
                            sizeBytes =
                                item.optLong(
                                    "sizeBytes",
                                    0L
                                ),
                            durationMs =
                                item.optLong(
                                    "durationMs",
                                    0L
                                ),
                            dateAddedMs =
                                item.optLong(
                                    "dateAddedMs",
                                    0L
                                ),
                            eventFolder =
                                item.optString(
                                    "eventFolder",
                                    "Other"
                                )
                                    .ifBlank {
                                        "Other"
                                    }
                        )
                }

                runOnUiThread {
                    remoteRecordings =
                        sortRemoteRecordings(
                            items
                        )

                    selectedRecordingIds
                        .retainAll(
                            items.map {
                                it.id
                            }.toSet()
                        )

                    val labels =
                        if (items.isEmpty()) {
                            listOf(
                                "No camera recordings"
                            )
                        } else {
                            remoteRecordings.map {
                                recordingSpinnerLabel(
                                    it
                                )
                            }
                        }

                    b.recordingsSpinner.adapter =
                        ArrayAdapter(
                            this,
                            android.R.layout
                                .simple_spinner_dropdown_item,
                            labels
                        )

                    b.recordingsStatus.text =
                        if (items.isEmpty()) {
                            root.optString(
                                "error"
                            )
                                .takeIf {
                                    it.isNotBlank()
                                }
                                ?.let {
                                    "Could not list recordings: $it"
                                }
                                ?: "No saved AI Door Monitor recordings on camera phone."
                        } else {
                            "${items.size} recording(s) available on camera phone."
                        }

                    if (
                        openRecordingFolders
                            .isEmpty()
                    ) {
                        remoteRecordings
                            .map {
                                it.eventFolder
                            }
                            .distinct()
                            .take(3)
                            .forEach {
                                openRecordingFolders
                                    .add(it)
                            }
                    }

                    updateRecordingControls()
                    renderRecordingThumbnailList()

                    if (items.isNotEmpty()) {
                        updateSelectedRecordingInfo(
                            0
                        )
                    }
                }

            } catch (t: Throwable) {
                runOnUiThread {
                    remoteRecordings =
                        emptyList()

                    b.recordingsStatus.text =
                        "Could not read camera recordings: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )

                    updateRecordingControls()
                }
            }
        }
    }

    private fun sortRemoteRecordings(
        items:
            List<RemoteRecordingItem>
    ): List<RemoteRecordingItem> {
        val mode =
            if (
                ::b.isInitialized
            ) {
                b.recordingSort
                    .selectedItemPosition
                    .coerceIn(
                        0,
                        5
                    )
            } else {
                0
            }

        return when (mode) {
            1 ->
                items.sortedBy {
                    it.dateAddedMs
                }

            2 ->
                items.sortedBy {
                    it.name
                        .lowercase(
                            Locale.US
                        )
                }

            3 ->
                items.sortedByDescending {
                    it.name
                        .lowercase(
                            Locale.US
                        )
                }

            4 ->
                items.sortedByDescending {
                    it.durationMs
                }

            5 ->
                items.sortedByDescending {
                    it.sizeBytes
                }

            else ->
                items.sortedByDescending {
                    it.dateAddedMs
                }
        }
    }

    private fun confirmDeleteCheckedRecordings() {
        val items =
            remoteRecordings
                .filter {
                    selectedRecordingIds
                        .contains(
                            it.id
                        )
                }

        if (items.isEmpty()) {
            toast(
                "Check one or more recordings first."
            )
            return
        }

        confirmDeleteRecordings(
            items
        )
    }

    private fun confirmDeleteRecordings(
        items:
            List<RemoteRecordingItem>
    ) {
        if (items.isEmpty()) {
            return
        }

        val message =
            if (
                items.size ==
                1
            ) {
                "Delete ${items.first().name} from the camera phone? This removes the original recording."
            } else {
                "Delete ${items.size} checked recordings from the camera phone? This removes the original recordings."
            }

        androidx.appcompat.app
            .AlertDialog
            .Builder(this)
            .setTitle(
                "Delete camera recording?"
            )
            .setMessage(
                message
            )
            .setNegativeButton(
                "Cancel",
                null
            )
            .setPositiveButton(
                "Delete"
            ) {
                    _,
                    _ ->
                deleteRemoteRecordings(
                    items
                )
            }
            .show()
    }

    private fun deleteRemoteRecordings(
        items:
            List<RemoteRecordingItem>
    ) {
        val pair =
            currentPair
                ?: return

        b.recordingsStatus.text =
            "Deleting ${items.size} recording(s) from camera phone…"

        recordingTransferExecutor.execute {
            var deleted =
                0

            val failed =
                mutableListOf<String>()

            items.forEach {
                    item ->

                var conn:
                    HttpURLConnection? =
                    null

                try {
                    val path =
                        "/recording?id=" +
                            Uri.encode(
                                item.id
                            )

                    conn =
                        URL(
                            pair.endpoint(
                                path
                            )
                        )
                            .openConnection()
                            as HttpURLConnection

                    conn.connectTimeout =
                        8_000
                    conn.readTimeout =
                        12_000
                    conn.useCaches =
                        false
                    conn.requestMethod =
                        "DELETE"
                    conn.connect()

                    if (
                        conn.responseCode
                            in 200..299
                    ) {
                        deleted++
                    } else {
                        failed +=
                            item.name
                    }

                } catch (_: Throwable) {
                    failed +=
                        item.name
                } finally {
                    try {
                        conn?.disconnect()
                    } catch (_: Throwable) {
                    }
                }
            }

            runOnUiThread {
                items.forEach {
                    selectedRecordingIds
                        .remove(
                            it.id
                        )
                }

                b.recordingsStatus.text =
                    buildString {
                        append(
                            "Deleted "
                        )
                        append(
                            deleted
                        )
                        append(
                            " recording(s) from camera phone."
                        )

                        if (
                            failed.isNotEmpty()
                        ) {
                            append(
                                " Failed: "
                            )
                            append(
                                failed.size
                            )
                        }
                    }

                refreshRemoteRecordings()
            }
        }
    }

    private fun renderRecordingThumbnailList() {
        if (!::b.isInitialized) return

        b.recordingsThumbnailList
            .removeAllViews()

        val grouped =
            remoteRecordings
                .groupBy {
                    it.eventFolder
                        .ifBlank {
                            "Other"
                        }
                }

        val folders =
            grouped.keys
                .sortedWith(
                    compareBy<String> {
                        val index =
                            preferredFolderOrder
                                .indexOf(it)

                        if (index >= 0) {
                            index
                        } else {
                            1_000
                        }
                    }.thenBy {
                        it.lowercase(
                            Locale.US
                        )
                    }
                )

        if (folders.isEmpty()) {
            b.recordingsThumbnailList
                .addView(
                    TextView(this).apply {
                        text =
                            "No event folders."
                        setPadding(
                            8,
                            12,
                            8,
                            12
                        )
                    }
                )

            return
        }

        folders.forEach {
                folder ->

            val folderItems =
                sortRemoteRecordings(
                    grouped[
                        folder
                    ].orEmpty()
                )

            val checkedCount =
                folderItems.count {
                    selectedRecordingIds
                        .contains(
                            it.id
                        )
                }

            val expanded =
                openRecordingFolders
                    .contains(
                        folder
                    )

            val header =
                android.widget.Button(
                    this
                ).apply {
                    isAllCaps =
                        false

                    text =
                        buildString {
                            append(
                                if (expanded) {
                                    "📂 "
                                } else {
                                    "📁 "
                                }
                            )
                            append(folder)
                            append(" (")
                            append(
                                folderItems.size
                            )
                            append(")")

                            if (
                                checkedCount >
                                0
                            ) {
                                append(" • ")
                                append(
                                    checkedCount
                                )
                                append(
                                    " checked"
                                )
                            }
                        }

                    setOnClickListener {
                        if (
                            openRecordingFolders
                                .contains(
                                    folder
                                )
                        ) {
                            openRecordingFolders
                                .remove(
                                    folder
                                )
                        } else {
                            openRecordingFolders
                                .add(
                                    folder
                                )
                        }

                        renderRecordingThumbnailList()
                    }
                }

            b.recordingsThumbnailList
                .addView(
                    header
                )

            if (!expanded) {
                return@forEach
            }

            val actions =
                android.widget.LinearLayout(
                    this
                ).apply {
                    orientation =
                        android.widget
                            .LinearLayout
                            .HORIZONTAL

                    setPadding(
                        20,
                        4,
                        0,
                        4
                    )
                }

            val checkFolder =
                android.widget.Button(
                    this
                ).apply {
                    isAllCaps =
                        false
                    text =
                        "Check folder"

                    setOnClickListener {
                        folderItems
                            .forEach {
                                selectedRecordingIds
                                    .add(
                                        it.id
                                    )
                            }

                        updateRecordingSelectionUi()
                        renderRecordingThumbnailList()
                    }
                }

            val clearFolder =
                android.widget.Button(
                    this
                ).apply {
                    isAllCaps =
                        false
                    text =
                        "Clear folder"

                    setOnClickListener {
                        folderItems
                            .forEach {
                                selectedRecordingIds
                                    .remove(
                                        it.id
                                    )
                            }

                        updateRecordingSelectionUi()
                        renderRecordingThumbnailList()
                    }
                }

            actions.addView(
                checkFolder,
                android.widget
                    .LinearLayout
                    .LayoutParams(
                        0,
                        android.widget
                            .LinearLayout
                            .LayoutParams
                            .WRAP_CONTENT,
                        1f
                    )
            )

            actions.addView(
                clearFolder,
                android.widget
                    .LinearLayout
                    .LayoutParams(
                        0,
                        android.widget
                            .LinearLayout
                            .LayoutParams
                            .WRAP_CONTENT,
                        1f
                    )
            )

            b.recordingsThumbnailList
                .addView(
                    actions
                )

            folderItems.forEach {
                    item ->

                val globalIndex =
                    remoteRecordings
                        .indexOfFirst {
                            it.id ==
                                item.id
                        }

                val row =
                    layoutInflater.inflate(
                        R.layout
                            .item_remote_recording,
                        b.recordingsThumbnailList,
                        false
                    )

                row.setPadding(
                    row.paddingLeft +
                        28,
                    row.paddingTop,
                    row.paddingRight,
                    row.paddingBottom
                )

                val image =
                    row.findViewById<ImageView>(
                        R.id.recordingThumbnail
                    )

                val checkbox =
                    row.findViewById<CheckBox>(
                        R.id.recordingCheckbox
                    )

                val title =
                    row.findViewById<TextView>(
                        R.id.recordingItemTitle
                    )

                val meta =
                    row.findViewById<TextView>(
                        R.id.recordingItemMeta
                    )

                title.text =
                    item.name

                val dateText =
                    if (
                        item.dateAddedMs >
                        0L
                    ) {
                        SimpleDateFormat(
                            "yyyy-MM-dd HH:mm:ss",
                            Locale.getDefault()
                        )
                            .format(
                                Date(
                                    item.dateAddedMs
                                )
                            )
                    } else {
                        "Unknown time"
                    }

                meta.text =
                    "$dateText • " +
                        formatDurationMs(
                            item.durationMs
                        ) +
                        " • " +
                        formatFileSize(
                            item.sizeBytes
                        )

                image.tag =
                    item.id

                image.setImageResource(
                    android.R.drawable
                        .ic_menu_gallery
                )

                checkbox.setOnCheckedChangeListener(
                    null
                )

                checkbox.isChecked =
                    selectedRecordingIds
                        .contains(
                            item.id
                        )

                checkbox.setOnCheckedChangeListener {
                        _,
                        checked ->

                    if (checked) {
                        selectedRecordingIds
                            .add(
                                item.id
                            )
                    } else {
                        selectedRecordingIds
                            .remove(
                                item.id
                            )
                    }

                    updateRecordingSelectionUi()
                    renderRecordingThumbnailList()
                }

                row.setOnClickListener {
                    if (
                        globalIndex >=
                        0
                    ) {
                        b.recordingsSpinner
                            .setSelection(
                                globalIndex
                            )

                        updateSelectedRecordingInfo(
                            globalIndex
                        )
                    }
                }

                image.setOnClickListener {
                    if (
                        globalIndex >=
                        0
                    ) {
                        b.recordingsSpinner
                            .setSelection(
                                globalIndex
                            )

                        updateSelectedRecordingInfo(
                            globalIndex
                        )
                    }

                    playRemoteRecording(
                        item
                    )
                }

                b.recordingsThumbnailList
                    .addView(
                        row
                    )

                loadRemoteRecordingThumbnail(
                    item,
                    image
                )
            }
        }
    }

    private fun loadRemoteRecordingThumbnail(
        item: RemoteRecordingItem,
        image: ImageView
    ) {
        val pair =
            currentPair ?: return

        recordingThumbnailExecutor.execute {
            var connection:
                HttpURLConnection? =
                null

            try {
                val path =
                    "/recording-thumbnail?id=" +
                        Uri.encode(
                            item.id
                        ) +
                        "&w=320&h=180"

                connection =
                    URL(
                        pair.endpoint(path)
                    )
                        .openConnection()
                        as HttpURLConnection

                connection.connectTimeout =
                    4_000
                connection.readTimeout =
                    8_000
                connection.useCaches =
                    true
                connection.requestMethod =
                    "GET"
                connection.connect()

                if (
                    connection.responseCode
                        !in 200..299
                ) {
                    return@execute
                }

                val bitmap =
                    connection.inputStream
                        .use { input ->
                            BitmapFactory
                                .decodeStream(input)
                        }
                        ?: return@execute

                runOnUiThread {
                    if (
                        image.tag ==
                        item.id
                    ) {
                        image.setImageBitmap(
                            bitmap
                        )
                    } else {
                        try {
                            bitmap.recycle()
                        } catch (_: Throwable) {
                        }
                    }
                }

            } catch (_: Throwable) {
                // Keep the placeholder if a thumbnail cannot be generated.
            } finally {
                try {
                    connection?.disconnect()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun updateRecordingSelectionUi() {
        if (!::b.isInitialized) return

        val checked =
            selectedRecordingIds.size

        b.recordingSelectionStatus.text =
            if (checked == 1) {
                "1 recording checked"
            } else {
                "$checked recordings checked"
            }

        val available =
            connected &&
                remoteRecordings
                    .isNotEmpty()

        b.selectAllRecordings.isEnabled =
            available

        b.clearRecordingSelection.isEnabled =
            checked > 0

        b.downloadCheckedRecordings.isEnabled =
            connected &&
                checked > 0

        b.deleteCheckedRecordings.isEnabled =
            connected &&
                checked > 0

        b.deleteSelectedRecording.isEnabled =
            connected &&
                remoteRecordings
                    .isNotEmpty()
    }

    private fun downloadCheckedRecordings() {
        val items =
            remoteRecordings
                .filter {
                    selectedRecordingIds
                        .contains(
                            it.id
                        )
                }

        if (items.isEmpty()) {
            toast(
                "Check one or more recordings first."
            )
            return
        }

        b.recordingsStatus.text =
            "Queued ${items.size} checked recording(s) for download…"

        items.forEach { item ->
            downloadRemoteRecording(
                item
            )
        }
    }

    private fun recordingSpinnerLabel(
        item: RemoteRecordingItem
    ): String {
        val whenText =
            if (item.dateAddedMs > 0L) {
                SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss",
                    Locale.getDefault()
                )
                    .format(
                        Date(
                            item.dateAddedMs
                        )
                    )
            } else {
                "unknown time"
            }

        return item.name +
            " • " +
            whenText
    }

    private fun updateSelectedRecordingInfo(
        position: Int
    ) {
        val item =
            remoteRecordings
                .getOrNull(position)

        if (item == null) {
            b.selectedRecordingInfo.text =
                "No recording selected."
            return
        }

        val duration =
            formatDurationMs(
                item.durationMs
            )

        val size =
            formatFileSize(
                item.sizeBytes
            )

        val whenText =
            if (item.dateAddedMs > 0L) {
                SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss",
                    Locale.getDefault()
                )
                    .format(
                        Date(
                            item.dateAddedMs
                        )
                    )
            } else {
                "Unknown recording time"
            }

        b.selectedRecordingInfo.text =
            "${item.name}\n$whenText • $duration • $size"
    }

    private fun selectedRemoteRecording():
        RemoteRecordingItem? =
        remoteRecordings
            .getOrNull(
                b.recordingsSpinner
                    .selectedItemPosition
            )

    private fun updateRecordingControls() {
        val available =
            connected &&
                remoteRecordings
                    .isNotEmpty()

        b.recordingsSpinner.isEnabled =
            available
        b.playSelectedRecording.isEnabled =
            available
        b.downloadSelectedRecording.isEnabled =
            available

        updateRecordingSelectionUi()

        if (!available) {
            b.selectedRecordingInfo.text =
                if (connected) {
                    "No recording selected."
                } else {
                    "Connect to camera phone first."
                }
        }
    }

    private fun playSelectedRecording() {
        val item =
            selectedRemoteRecording()
                ?: run {
                    toast(
                        "Select a recording first."
                    )
                    return
                }

        playRemoteRecording(
            item
        )
    }

    private fun playRemoteRecording(
        item: RemoteRecordingItem
    ) {
        val pair =
            currentPair ?: return

        val path =
            "/recording?id=" +
                Uri.encode(
                    item.id
                )

        val url =
            pair.endpoint(path)

        startActivity(
            Intent(
                this,
                RemoteRecordingActivity::class.java
            ).apply {
                putExtra(
                    "recording_url",
                    url
                )
                putExtra(
                    "recording_name",
                    item.name
                )
            }
        )
    }

    private fun requestDownloadSelectedRecording() {
        val item =
            selectedRemoteRecording()
                ?: run {
                    toast(
                        "Select a recording first."
                    )
                    return
                }

        if (
            Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission
                    .WRITE_EXTERNAL_STORAGE
            ) != PackageManager
                .PERMISSION_GRANTED
        ) {
            pendingRecordingDownloadId =
                item.id

            storagePermission.launch(
                Manifest.permission
                    .WRITE_EXTERNAL_STORAGE
            )
            return
        }

        downloadRemoteRecording(
            item
        )
    }

    private fun downloadRemoteRecording(
        item: RemoteRecordingItem
    ) {
        val pair =
            currentPair ?: return

        b.recordingsStatus.text =
            "Downloading ${item.name}…"

        recordingTransferExecutor.execute {
            var conn:
                HttpURLConnection? =
                null

            var targetUri:
                android.net.Uri? =
                null

            try {
                val path =
                    "/recording?id=" +
                        Uri.encode(
                            item.id
                        )

                conn =
                    URL(
                        pair.endpoint(path)
                    )
                        .openConnection()
                        as HttpURLConnection

                conn.connectTimeout =
                    8_000
                conn.readTimeout =
                    30_000
                conn.useCaches =
                    false
                conn.requestMethod =
                    "GET"
                conn.connect()

                if (
                    conn.responseCode !in
                    200..299
                ) {
                    val error =
                        try {
                            conn.errorStream
                                ?.bufferedReader()
                                ?.use {
                                    it.readText()
                                }
                        } catch (_: Throwable) {
                            null
                        }

                    throw IllegalStateException(
                        "HTTP ${conn.responseCode}" +
                            if (
                                error.isNullOrBlank()
                            ) {
                                ""
                            } else {
                                ": $error"
                            }
                    )
                }

                val safeName =
                    item.name
                        .ifBlank {
                            "AI_Door_Remote_" +
                                System.currentTimeMillis() +
                                ".mp4"
                        }

                val values =
                    ContentValues().apply {
                        put(
                            MediaStore.Video.Media
                                .DISPLAY_NAME,
                            safeName
                        )
                        put(
                            MediaStore.Video.Media
                                .MIME_TYPE,
                            "video/mp4"
                        )

                        if (
                            Build.VERSION.SDK_INT >=
                            Build.VERSION_CODES.Q
                        ) {
                            put(
                                MediaStore.Video.Media
                                    .RELATIVE_PATH,
                                "Movies/AI Door Monitor/Camera Phone"
                            )
                            put(
                                MediaStore.Video.Media
                                    .IS_PENDING,
                                1
                            )
                        }
                    }

                targetUri =
                    contentResolver.insert(
                        MediaStore.Video.Media
                            .EXTERNAL_CONTENT_URI,
                        values
                    )
                        ?: throw IllegalStateException(
                            "Could not create video on monitor phone."
                        )

                val total =
                    if (
                        item.sizeBytes > 0L
                    ) {
                        item.sizeBytes
                    } else {
                        conn.contentLengthLong
                    }

                contentResolver
                    .openOutputStream(
                        targetUri
                    )
                    ?.use { output ->
                        conn.inputStream
                            .use { input ->
                                val buffer =
                                    ByteArray(
                                        256 * 1024
                                    )

                                var copied =
                                    0L

                                var lastUi =
                                    0L

                                while (true) {
                                    val read =
                                        input.read(
                                            buffer
                                        )

                                    if (read < 0) {
                                        break
                                    }

                                    output.write(
                                        buffer,
                                        0,
                                        read
                                    )

                                    copied +=
                                        read.toLong()

                                    val now =
                                        System.currentTimeMillis()

                                    if (
                                        now - lastUi >=
                                        500L
                                    ) {
                                        lastUi = now

                                        val status =
                                            if (total > 0L) {
                                                val pct =
                                                    (
                                                        copied *
                                                        100L /
                                                        total
                                                        )
                                                        .coerceIn(
                                                            0L,
                                                            100L
                                                        )

                                                "Downloading ${item.name} • $pct%"
                                            } else {
                                                "Downloading ${item.name} • ${formatFileSize(copied)}"
                                            }

                                        runOnUiThread {
                                            b.recordingsStatus.text =
                                                status
                                        }
                                    }
                                }

                                output.flush()
                            }
                    }
                        ?: throw IllegalStateException(
                            "Could not write monitor video."
                        )

                if (
                    Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.Q
                ) {
                    val done =
                        ContentValues().apply {
                            put(
                                MediaStore.Video.Media
                                    .IS_PENDING,
                                0
                            )
                        }

                    contentResolver.update(
                        targetUri,
                        done,
                        null,
                        null
                    )
                }

                runOnUiThread {
                    b.recordingsStatus.text =
                        "Saved on monitor phone → Movies/AI Door Monitor/Camera Phone/${item.name}"
                    toast(
                        "Recording saved on monitor phone."
                    )
                }

            } catch (t: Throwable) {
                if (targetUri != null) {
                    try {
                        contentResolver.delete(
                            targetUri,
                            null,
                            null
                        )
                    } catch (_: Throwable) {
                    }
                }

                runOnUiThread {
                    b.recordingsStatus.text =
                        "Recording download failed: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )
                }
            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun formatFileSize(
        bytes: Long
    ): String {
        if (bytes <= 0L) {
            return "unknown size"
        }

        val mb =
            bytes.toDouble() /
                1024.0 /
                1024.0

        return if (mb >= 1024.0) {
            String.format(
                Locale.US,
                "%.2f GB",
                mb / 1024.0
            )
        } else {
            String.format(
                Locale.US,
                "%.1f MB",
                mb
            )
        }
    }

    private fun formatDurationMs(
        durationMs: Long
    ): String {
        if (durationMs <= 0L) {
            return "unknown duration"
        }

        val totalSeconds =
            durationMs / 1_000L

        val hours =
            totalSeconds / 3_600L
        val minutes =
            (
                totalSeconds %
                3_600L
                ) /
                60L
        val seconds =
            totalSeconds %
                60L

        return if (hours > 0L) {
            String.format(
                Locale.US,
                "%d:%02d:%02d",
                hours,
                minutes,
                seconds
            )
        } else {
            String.format(
                Locale.US,
                "%d:%02d",
                minutes,
                seconds
            )
        }
    }

    private fun refreshRemoteEvents() {
        val pair = currentPair ?: return
        networkExecutor.execute {
            try {
                val raw = getBytes(pair.endpoint("/events")).toString(Charsets.UTF_8)
                val arr = JSONObject(raw).optJSONArray("events")
                val lines = mutableListOf<String>()

                if (arr != null) {
                    val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    for (i in 0 until minOf(arr.length(), 15)) {
                        val o = arr.getJSONObject(i)
                        val whenText = fmt.format(Date(o.optLong("timestamp")))
                        val type = o.optString("type")
                        val details = o.optString("details")
                        lines += "$whenText • $type" +
                            if (details.isBlank()) "" else " • $details"
                    }
                }

                runOnUiThread {
                    b.remoteEvents.text =
                        if (lines.isEmpty()) "No saved camera events."
                        else lines.joinToString("\n")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.remoteEvents.text = "Could not read event log: ${e.message}"
                }
            }
        }
    }

    private fun saveSnapshot() {
        if (lastVisualStreamAvailable == false) {
            toast(
                "No live visual frame is available in Recording-First mode."
            )
            return
        }

        val pair = currentPair ?: return

        b.saveInfo.text = "Saving snapshot…"

        networkExecutor.execute {
            try {
                val jpeg = getBytes(pair.endpoint("/snapshot"))

                val name = "AI_Door_Monitor_" +
                    SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                        .format(System.currentTimeMillis()) +
                    ".jpg"

                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(
                            MediaStore.Images.Media.RELATIVE_PATH,
                            "Pictures/AI Door Monitor"
                        )
                    }
                }

                val uri = contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    values
                ) ?: throw IllegalStateException("MediaStore insert failed")

                contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(jpeg)
                } ?: throw IllegalStateException("Could not open MediaStore output")

                runOnUiThread {
                    b.saveInfo.text =
                        "Snapshot saved on monitor phone → Gallery/Pictures/AI Door Monitor"
                    toast("Snapshot saved.")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.saveInfo.text = "Snapshot save failed: ${e.message}"
                }
            }
        }
    }

    private fun getBytes(url: String): ByteArray {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 6_000
            conn.readTimeout = 10_000
            conn.useCaches = false
            conn.requestMethod = "GET"
            conn.connect()

            if (conn.responseCode !in 200..299) {
                val body = try {
                    conn.errorStream?.readBytes()?.toString(Charsets.UTF_8)
                } catch (_: Exception) {
                    null
                }
                throw IllegalStateException(
                    "HTTP ${conn.responseCode}${body?.let { ": $it" } ?: ""}"
                )
            }

            return conn.inputStream.use { it.readBytes() }
        } finally {
            conn.disconnect()
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        stopConnectionHealthPolling()
        b.liveView.stop()
        networkExecutor.shutdownNow()
        recordingTransferExecutor.shutdownNow()
        recordingThumbnailExecutor.shutdownNow()
        super.onDestroy()
    }
}
