package com.example.aidoormonitor

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.net.ConnectivityManager
import android.media.MediaMetadataRetriever
import android.net.Network
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.ScaleGestureDetector
import android.view.MotionEvent
import android.view.WindowManager
import android.view.View
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture as CameraXVideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import com.example.aidoormonitor.ai.SimpleMotionDetector
import com.example.aidoormonitor.ai.SeizureLikeMotionDetector
import com.example.aidoormonitor.ai.ModelDownloader
import com.example.aidoormonitor.ai.PreviewAiBridge
import com.example.aidoormonitor.databinding.ActivityCameraBinding
import com.example.aidoormonitor.net.LanCameraServer
import com.example.aidoormonitor.net.LanCameraEndpoint
import com.example.aidoormonitor.net.LanCameraHub
import com.example.aidoormonitor.net.LocalNetwork
import com.example.aidoormonitor.net.PairInfo
import com.example.aidoormonitor.net.Pairing
import com.example.aidoormonitor.store.EventStore
import com.example.aidoormonitor.storage.VideoRetentionManager
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.round
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

@OptIn(ExperimentalCamera2Interop::class)
class CameraActivity : AppCompatActivity() {
    private lateinit var b: ActivityCameraBinding
    private var cameraChoices: List<CameraChoice> = emptyList()

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var videoCapture: CameraXVideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recordingReason: String? = null

    private var minZoom = 1f
    private var maxZoom = 1f
    private var currentZoom = 1f
    private var cameraZoomLinear = 0f
    private var cameraPanX = 0f
    private var cameraPanY = 0f
    private var sensorActiveArray: Rect? = null
    private var cropCoordinateArray: Rect? = null
    private var freeformCropSupported = false
    private var distortionCorrectionOffAvailable = false

    private var manualFocusSupported = false
    private var maxFocusDiopters = 0f
    private var currentFocusLinear = 0f
    private var focusModeManual = false
    private var targetFpsRange: Range<Int>? = null
    private var eightKSupported = false
    private var uhdSupported = false
    private var highestVideoResolution: Size? = null
    private var recordingAvailable = false

    private val latestJpeg = LanCameraHub.latestJpeg
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val motionDetector = SimpleMotionDetector()
    private val seizureLikeDetector = SeizureLikeMotionDetector()
    private lateinit var eventStore: EventStore

    private var server: LanCameraServer? = null
    private var pairInfo: PairInfo? = null
    private var previewAiBridge: PreviewAiBridge? = null
    private var localPreviewUsesBridge = false
    @Volatile private var latestFrameAtMs = 0L

    private var motionTriggerFrames = 0
    private var motionRecordingUntil = 0L
    private var lastMotionUiUpdate = 0L

    private val segmentHandler = Handler(Looper.getMainLooper())
    private val continuousSegmentMs = 60_000L
    private var continuousRollover = false
    private var currentSegmentName: String? = null
    private var lastMotionMomentAt = 0L
    private var lastSeizureLikeAt = 0L

    private lateinit var connectivityManager: ConnectivityManager
    private var networkWasAvailable = true
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    // Transactional Activity -> foreground-service camera hand-off.
    private var backgroundHandoffRequested = false
    private var backgroundServicePrepared = false

    private val backgroundDashboardHandler =
        Handler(Looper.getMainLooper())

    private val backgroundDashboardExecutor =
        Executors.newSingleThreadExecutor()

    @Volatile
    private var backgroundDashboardRunning = false

    @Volatile
    private var backgroundDashboardStreamStarted = false

    @Volatile
    private var backgroundServiceRecording = false

    private var dashboardActivationWaitStartedAt =
        0L

    private val prefs by lazy {
        getSharedPreferences("camera_settings", MODE_PRIVATE)
    }

    private fun dashboardPinned(): Boolean =
        prefs.getBoolean(
            "keep_camera_dashboard_open",
            false
        )

    private fun setDashboardPinned(
        pinned: Boolean
    ) {
        prefs.edit()
            .putBoolean(
                "keep_camera_dashboard_open",
                pinned
            )
            .apply()
    }

    private fun backgroundHandoffPending(): Boolean =
        prefs.getBoolean(
            "background_handoff_pending",
            false
        )

    private fun setBackgroundHandoffPending(
        pending: Boolean
    ) {
        prefs.edit()
            .putBoolean(
                "background_handoff_pending",
                pending
            )
            .apply()
    }

    private fun serviceOwnsCamera(): Boolean =
        DoorMonitoringService.isRunning &&
            DoorMonitoringService
                .isCameraActivationRequested

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) {
                startAutomaticScreenOffCameraService()
            } else {
                b.status.text = "Camera permission is required."
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                toast("Android may hide the monitoring notification, but the camera service can still appear in system task controls.")
            }
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                startAutomaticScreenOffCameraService()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.root.applySystemBarInsets()

        eventStore = EventStore(this)

        // q7 SAFE migration:
        // Previous builds enabled several recorder/native-AI workloads by
        // default. That meant simply opening Camera Mode could immediately
        // start a rolling MP4 pre-buffer and MediaPipe engines. Reset these
        // once so Camera Mode starts as a plain camera/viewer first.
        if (prefs.getInt("safe_camera_schema_version", 0) < 1) {
            prefs.edit()
                .putInt("safe_camera_schema_version", 1)
                .putBoolean("continuous_recording", false)
                .putBoolean("event_pre_record_enabled", false)
                .putBoolean("offline_guard", false)
                .putBoolean("audio_ai_detection", false)
                .putBoolean("fall_detection", false)
                .putBoolean("aggressive_detection", false)
                .putBoolean("animal_tracking", false)
                .putBoolean("recording_audio_enabled", false)
                .apply()

            eventStore.add(
                "Safe Camera migration",
                "Automatic recording, advanced AI and MP4 audio were disabled once to stabilise Camera Mode. They can be enabled manually later."
            )
        }

        connectivityManager =
            getSystemService(
                Context.CONNECTIVITY_SERVICE
            ) as ConnectivityManager

        onBackPressedDispatcher.addCallback(
            this,
            object :
                OnBackPressedCallback(
                    true
                ) {
                override fun handleOnBackPressed() {
                    eventStore.add(
                        "Camera Mode navigation",
                        "User pressed Back • stopping automatic screen-off camera service."
                    )

                    stopAutomaticScreenOffCameraService(
                        stopLanServer = true
                    )

                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        )

        // The camera is owned by a foreground service, so the display is free
        // to sleep normally. The user can press the hardware power button at
        // any time without stopping camera/AI/LAN monitoring.
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setupCameraSelectionUi()
        setupQualityUi()
        setupZoomUi()
        setupFocusUi()
        setupMotionGuardUi()
        setupContinuousRecordingUi()
        setupSeizureLikeUi()
        setupStorageUi()
        setupAiDetectionUi()
        setupBackgroundMonitoringUi()
        setupButtons()
        registerNetworkWatcher()

        b.eventLog.text = eventStore.readable()

        // Camera Mode is now service-owned from the beginning. There is no
        // separate "Start 24/7" transition and therefore no CameraX ownership
        // hand-off when the display is turned off.
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startAutomaticScreenOffCameraService()
        } else {
            val requested = mutableListOf(
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
            )
            if (Build.VERSION.SDK_INT <= 28) {
                requested += Manifest.permission.WRITE_EXTERNAL_STORAGE
            }
            if (Build.VERSION.SDK_INT >= 33) {
                requested += Manifest.permission.POST_NOTIFICATIONS
            }
            permissionLauncher.launch(requested.toTypedArray())
        }
    }

    private fun setupCameraSelectionUi() {
        cameraChoices =
            try {
                CameraChoiceRepository.discover(this)
            } catch (t: Throwable) {
                eventStore.add(
                    "Camera list warning",
                    "Camera discovery failed; using safe rear/front choices: ${t.message ?: t.javaClass.simpleName}"
                )
                listOf(
                    CameraChoice(CameraChoiceRepository.DEFAULT_BACK_KEY, "Rear camera • automatic"),
                    CameraChoice(CameraChoiceRepository.DEFAULT_FRONT_KEY, "Front camera • automatic")
                )
            }

        if (cameraChoices.isEmpty()) {
            cameraChoices = listOf(
                CameraChoice(CameraChoiceRepository.DEFAULT_BACK_KEY, "Rear camera • automatic"),
                CameraChoice(CameraChoiceRepository.DEFAULT_FRONT_KEY, "Front camera • automatic")
            )
        }

        b.cameraSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            cameraChoices.map { it.label }
        )

        val savedKey = prefs.getString(
            "camera_choice_key",
            CameraChoiceRepository.DEFAULT_BACK_KEY
        ) ?: CameraChoiceRepository.DEFAULT_BACK_KEY

        val savedIndex = cameraChoices.indexOfFirst { it.key == savedKey }
            .takeIf { it >= 0 } ?: 0
        b.cameraSpinner.setSelection(savedIndex)

        fun updateLabel(position: Int) {
            val choice = cameraChoices.getOrNull(position) ?: return
            val activeKey = prefs.getString(
                "camera_choice_key",
                CameraChoiceRepository.DEFAULT_BACK_KEY
            )
            b.cameraStatus.text =
                if (choice.key == activeKey)
                    "${choice.label}\nSaved camera. It is used the next time Camera Mode starts its camera service."
                else
                    "${choice.label}\nTap Save selected camera, then leave and reopen Camera Mode to apply it safely."
        }

        b.cameraSpinner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    updateLabel(position)
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }

        b.applyCamera.setOnClickListener {
            val choice = cameraChoices.getOrNull(
                b.cameraSpinner.selectedItemPosition
            ) ?: return@setOnClickListener

            prefs.edit()
                .putString("camera_choice_key", choice.key)
                .putString("camera_choice_label", choice.label)
                .apply()

            eventStore.add(
                "Camera selection saved",
                "${choice.label} • applies on next Camera Mode camera-service start"
            )
            refreshEventLog()
            updateLabel(b.cameraSpinner.selectedItemPosition)
            toast("Camera saved. Leave Camera Mode and open it again to apply safely.")
        }

        updateLabel(savedIndex)
    }

    private fun setupQualityUi() {
        // CameraX 1.6.1 is intentionally used for stability. QHD was not added
        // to the public VideoCapture Quality API until CameraX 1.7, so this
        // stable build exposes only qualities that CameraX 1.6.1 can request.
        val labels = listOf(
            "8K UHD / 4320p • 30 fps (if supported)",
            "4K UHD / 2160p • 30 fps",
            "1080p Full HD • 30 fps",
            "720p HD • 30 fps"
        )

        // Schema history:
        // v1: 0=4K, 1=1080p, 2=720p
        // v2: 0=4K, 1=QHD, 2=1080p, 3=720p
        // v3: 0=8K/HIGHEST, 1=4K, 2=QHD, 3=1080p, 4=720p
        // v4: 0=8K/HIGHEST, 1=4K, 2=1080p, 3=720p
        val schema = prefs.getInt("quality_schema_version", 1)
        if (schema < 4) {
            val oldIndex = prefs.getInt("quality_index", 0)
            val migrated = when (schema) {
                1 -> when (oldIndex) {
                    1 -> 2 // old 1080p
                    2 -> 3 // old 720p
                    else -> 1 // old 4K
                }
                2 -> when (oldIndex) {
                    0 -> 1 // 4K
                    1 -> 2 // QHD -> stable FHD
                    2 -> 2 // FHD
                    3 -> 3 // HD
                    else -> 1
                }
                else -> when (oldIndex) {
                    0 -> 0 // HIGHEST
                    1 -> 1 // UHD
                    2 -> 2 // QHD -> stable FHD
                    3 -> 2 // FHD
                    4 -> 3 // HD
                    else -> 1
                }
            }

            prefs.edit()
                .putInt("quality_index", migrated)
                .putInt("quality_schema_version", 4)
                .apply()
        }

        b.qualitySpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            labels
        )
        b.qualitySpinner.setSelection(
            prefs.getInt("quality_index", 1)
                .coerceIn(0, labels.lastIndex)
        )

        val modeLabels =
            listOf(
                "Strict Recording Quality",
                "Best Simultaneous Quality (recommended)",
                "Preview / AI Priority"
            )

        b.recordingMode.adapter =
            android.widget.ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                modeLabels
            )

        // Migrate old strict boolean once.
        if (!prefs.contains("recording_mode")) {
            prefs.edit()
                .putInt(
                    "recording_mode",
                    if (
                        prefs.getBoolean(
                            "strict_recording_quality",
                            true
                        )
                    ) 0 else 1
                )
                .apply()
        }

        b.recordingMode.setSelection(
            recordingMode()
        )

        fun updateRecordingModeInfo() {
            b.recordingModeInfo.text =
                when (recordingMode()) {
                    0 ->
                        "Strict: selected MP4 quality is preserved exactly. If ImageAnalysis cannot run beside 4K/high-resolution recording, a low-resolution Preview bridge keeps the LAN preview and visual AI alive without lowering the MP4 quality."

                    2 ->
                        "Preview / AI Priority: live visual preview and ImageAnalysis are preserved. Recording may fall to a lower compatible quality."

                    else ->
                        "Best Simultaneous Quality: automatically tries 4K → 1080p → 720p and keeps the highest stable quality that works with VideoCapture + ImageAnalysis together."
                }
        }

        updateRecordingModeInfo()

        b.recordingMode.onItemSelectedListener =
            object :
                android.widget.AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    prefs.edit()
                        .putInt(
                            "recording_mode",
                            position.coerceIn(0, 2)
                        )
                        .apply()

                    updateRecordingModeInfo()
                }

                override fun onNothingSelected(
                    parent: android.widget.AdapterView<*>?
                ) = Unit
            }

        b.applyQuality.setOnClickListener {
            prefs.edit()
                .putInt(
                    "quality_index",
                    b.qualitySpinner.selectedItemPosition
                )
                .putInt(
                    "recording_mode",
                    b.recordingMode.selectedItemPosition.coerceIn(0, 2)
                )
                .apply()

            if (serviceOwnsCamera()) {
                toast(
                    "Quality saved. Leave Camera Mode and open it again to apply the new camera resolution safely."
                )
            } else if (recording != null) {
                toast("Stop the current recording before changing quality.")
            } else {
                startAutomaticScreenOffCameraService()
            }
        }
    }

    private fun setupZoomUi() {
        b.zoomSlider.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    if (fromUser) {
                        setCameraView(
                            progress / 1000f,
                            cameraPanX,
                            cameraPanY
                        )
                    }
                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) = Unit

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) = Unit
            }
        )

        var lastX = 0f
        var lastY = 0f

        val scale =
            ScaleGestureDetector(
                this,
                object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    override fun onScale(
                        detector: ScaleGestureDetector
                    ): Boolean {
                        val wantedRatio =
                            (currentZoom * detector.scaleFactor)
                                .coerceIn(minZoom, maxZoom)

                        val linear =
                            if (maxZoom <= minZoom + 0.001f) {
                                0f
                            } else {
                                ((wantedRatio - minZoom) /
                                    (maxZoom - minZoom))
                                    .coerceIn(0f, 1f)
                            }

                        setCameraView(
                            linear,
                            cameraPanX,
                            cameraPanY
                        )
                        return true
                    }
                }
            )

        b.preview.setOnTouchListener { view, event ->
            scale.onTouchEvent(event)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.x
                    lastY = event.y
                    view.parent?.requestDisallowInterceptTouchEvent(true)
                }

                MotionEvent.ACTION_MOVE -> {
                    if (
                        event.pointerCount == 1 &&
                        !scale.isInProgress &&
                        cameraZoomLinear > 0.001f
                    ) {
                        val dx = event.x - lastX
                        val dy = event.y - lastY

                        val nextPanX =
                            (
                                cameraPanX +
                                    dx /
                                        view.width.coerceAtLeast(1).toFloat() *
                                        2f
                            ).coerceIn(-1f, 1f)

                        val nextPanY =
                            (
                                cameraPanY +
                                    dy /
                                        view.height.coerceAtLeast(1).toFloat() *
                                        2f
                            ).coerceIn(-1f, 1f)

                        setCameraView(
                            cameraZoomLinear,
                            nextPanX,
                            nextPanY
                        )
                    }

                    lastX = event.x
                    lastY = event.y
                }

                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL -> {
                    view.parent?.requestDisallowInterceptTouchEvent(false)
                }
            }

            true
        }
    }

    private fun setupFocusUi() {
        b.focusSlider.progress = (prefs.getFloat("focus_linear", 0f) * 1000f).toInt().coerceIn(0, 1000)
        focusModeManual = prefs.getBoolean("focus_manual", false)

        b.autoFocus.setOnClickListener {
            focusModeManual = false
            applyCamera2Controls()
        }

        b.focusSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val linear = progress / 1000f
                updateFocusLabel(linear)
                if (fromUser && manualFocusSupported) {
                    focusModeManual = true
                    currentFocusLinear = linear
                    applyCamera2Controls()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        b.focusFar.setOnClickListener { stepFocus(-25) }
        b.focusNear.setOnClickListener { stepFocus(25) }

        b.saveFocusDefault.setOnClickListener {
            saveFocusDefault()
            toast("Focus default saved.")
        }
    }

    private fun setupMotionGuardUi() {
        b.offlineGuard.isChecked = prefs.getBoolean("offline_guard", false)
        b.motionSensitivity.progress = prefs.getInt("motion_sensitivity", 55).coerceIn(0, 100)
        updateMotionSensitivityLabel()

        b.offlineGuard.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("offline_guard", enabled).apply()
            motionDetector.reset()
            motionTriggerFrames = 0
            eventStore.add(
                if (enabled) "Offline Motion Guard enabled" else "Offline Motion Guard disabled"
            )
            refreshEventLog()
        }

        b.motionSensitivity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateMotionSensitivityLabel()
                if (fromUser) prefs.edit().putInt("motion_sensitivity", progress).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }


    private fun setupContinuousRecordingUi() {
        val labels = listOf(
            "5 seconds",
            "10 seconds",
            "15 seconds",
            "30 seconds"
        )
        b.preRecordSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            labels
        )

        val savedPre = prefs.getInt("pre_record_seconds", 10)
        val index = when (savedPre) {
            5 -> 0
            15 -> 2
            30 -> 3
            else -> 1
        }
        b.preRecordSpinner.setSelection(index)

        b.continuousRecording.isChecked =
            prefs.getBoolean("continuous_recording", false)

        b.eventPreRecord.isChecked =
            prefs.getBoolean("event_pre_record_enabled", false)

        val postLabels = listOf("10 seconds", "20 seconds", "30 seconds", "60 seconds")
        val postValues = intArrayOf(10, 20, 30, 60)
        b.postRecordSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            postLabels
        )
        val savedPost = prefs.getInt("post_record_seconds", 20)
        val postIndex = postValues.indexOf(savedPost).takeIf { it >= 0 } ?: 1
        b.postRecordSpinner.setSelection(postIndex)
        b.postRecordSpinner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    prefs.edit()
                        .putInt("post_record_seconds", postValues[position])
                        .apply()
                    updateEventPreRecordStatus()
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }

        b.eventPreRecord.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("event_pre_record_enabled", enabled).apply()
            updateEventPreRecordStatus()
        }

        b.preRecordSpinner.setSelection(index)
        b.preRecordSpinner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    val seconds = when (position) {
                        0 -> 5
                        2 -> 15
                        3 -> 30
                        else -> 10
                    }
                    prefs.edit().putInt("pre_record_seconds", seconds).apply()
                    updateEventPreRecordStatus()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }

        b.continuousRecording.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("continuous_recording", enabled).apply()

            if (enabled) {
                b.continuousStatus.text =
                    "Starting continuous 60-second segments… Motion Moments will be bookmarked."
                if (recording == null && recordingAvailable) {
                    startRecording("continuous")
                }
            } else {
                b.continuousStatus.text = "Continuous recording off."
                if (recordingReason == "continuous") {
                    continuousRollover = false
                    segmentHandler.removeCallbacksAndMessages(null)
                    stopRecording()
                }
            }
            updateEventPreRecordStatus()
        }

        updateEventPreRecordStatus()
    }

    private fun updateEventPreRecordStatus() {
        val pre = prefs.getInt("pre_record_seconds", 10)
        val post = prefs.getInt("post_record_seconds", 20)
        b.eventPreRecordStatus.text = when {
            b.continuousRecording.isChecked ->
                "24/7 continuous is active: pre-event context already exists in continuous video."
            b.eventPreRecord.isChecked ->
                "Event buffer armed for Screen-Off monitoring: ${pre}s before + ${post}s after AI/motion events. Cache segments are deleted when unused."
            else ->
                "Event pre-record buffer off: events can still be detected, but no video from before detection is kept."
        }
    }

    private fun setupSeizureLikeUi() {
        b.seizureLikeAlert.isChecked =
            prefs.getBoolean("seizure_like_alert", false)

        b.seizureLikeAlert.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("seizure_like_alert", enabled).apply()
            seizureLikeDetector.reset()

            eventStore.add(
                if (enabled)
                    "Experimental seizure-like motion alert enabled"
                else
                    "Experimental seizure-like motion alert disabled",
                "Non-diagnostic visual pattern alert"
            )
            refreshEventLog()
        }
    }

    private fun selectedPreRecordSeconds(): Int =
        when (b.preRecordSpinner.selectedItemPosition) {
            0 -> 5
            2 -> 15
            3 -> 30
            else -> 10
        }

    private fun scheduleContinuousSegmentRollover() {
        segmentHandler.removeCallbacksAndMessages(null)
        if (!b.continuousRecording.isChecked) return
        if (recordingReason != "continuous") return

        segmentHandler.postDelayed({
            if (b.continuousRecording.isChecked &&
                recordingReason == "continuous" &&
                recording != null
            ) {
                continuousRollover = true
                stopRecording()
            }
        }, continuousSegmentMs)
    }


    private fun setupStorageUi() {
        val storageLabels = listOf("5 GB", "10 GB", "20 GB", "50 GB", "Unlimited")
        val storageValues = intArrayOf(5, 10, 20, 50, 0)
        b.storageLimitSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            storageLabels
        )

        val savedGb = prefs.getInt("storage_max_gb", 20)
        val storageIndex =
            storageValues.indexOf(savedGb).takeIf { it >= 0 } ?: 2
        b.storageLimitSpinner.setSelection(storageIndex)

        val dayLabels = listOf("1 day", "3 days", "7 days", "14 days", "30 days", "Keep forever")
        val dayValues = intArrayOf(1, 3, 7, 14, 30, 0)
        b.retentionDaysSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            dayLabels
        )

        val savedDays = prefs.getInt("retention_days", 7)
        val dayIndex =
            dayValues.indexOf(savedDays).takeIf { it >= 0 } ?: 2
        b.retentionDaysSpinner.setSelection(dayIndex)

        val freeLabels = listOf("1 GB free", "2 GB free", "5 GB free", "No free-space reserve")
        val freeValues = intArrayOf(1, 2, 5, 0)
        b.minFreeSpaceSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            freeLabels
        )
        val savedFree = prefs.getInt("storage_min_free_gb", 2)
        val freeIndex = freeValues.indexOf(savedFree).takeIf { it >= 0 } ?: 1
        b.minFreeSpaceSpinner.setSelection(freeIndex)

        b.storageLimitSpinner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    prefs.edit()
                        .putInt("storage_max_gb", storageValues[position])
                        .apply()
                    updateStorageStatus()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }

        b.retentionDaysSpinner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    prefs.edit()
                        .putInt("retention_days", dayValues[position])
                        .apply()
                    updateStorageStatus()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }

        b.minFreeSpaceSpinner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    prefs.edit()
                        .putInt("storage_min_free_gb", freeValues[position])
                        .apply()
                    updateStorageStatus()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }

        b.runStorageCleanup.setOnClickListener {
            b.storageStatus.text = "Scanning AI Door Monitor recordings…"
            val maxGb = prefs.getInt("storage_max_gb", 20)
            val days = prefs.getInt("retention_days", 7)
            val minFreeGb = prefs.getInt("storage_min_free_gb", 2)

            VideoRetentionManager.cleanupAsync(
                this,
                maxGb,
                days,
                minFreeGb
            ) { result ->
                runOnUiThread {
                    b.storageStatus.text =
                        "Cleanup finished • deleted ${result.deletedFiles} file(s) • freed ${formatBytes(result.freedBytes)} • remaining ${formatBytes(result.remainingBytes)}"
                    if (result.deletedFiles > 0) {
                        eventStore.add(
                            "Storage cleanup",
                            "deleted=${result.deletedFiles} • freed=${formatBytes(result.freedBytes)}"
                        )
                        refreshEventLog()
                    }
                }
            }
        }

        updateStorageStatus()
    }

    private fun updateStorageStatus() {
        val maxGb = prefs.getInt("storage_max_gb", 20)
        val days = prefs.getInt("retention_days", 7)
        val minFreeGb = prefs.getInt("storage_min_free_gb", 2)

        b.storageStatus.text =
            "Automatic cleanup: max ${if (maxGb == 0) "unlimited" else "$maxGb GB"} • keep ${if (days == 0) "forever" else "$days days"} • reserve ${if (minFreeGb == 0) "off" else "$minFreeGb GB free"}"
    }

    private fun setupAiDetectionUi() {
        b.audioAiDetection.isChecked =
            prefs.getBoolean("audio_ai_detection", false)
        b.recordingAudio.isChecked =
            prefs.getBoolean("recording_audio_enabled", false)
        b.fallDetection.isChecked =
            prefs.getBoolean("fall_detection", false)
        b.aggressiveDetection.isChecked =
            prefs.getBoolean("aggressive_detection", false)
        b.animalTracking.isChecked =
            prefs.getBoolean("animal_tracking", false)

        b.audioAiDetection.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("audio_ai_detection", checked).apply()
        }

        b.recordingAudio.setOnCheckedChangeListener { _, checked ->
            prefs.edit()
                .putBoolean(
                    "recording_audio_enabled",
                    checked
                )
                .apply()
        }
        b.fallDetection.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("fall_detection", checked).apply()
        }
        b.aggressiveDetection.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("aggressive_detection", checked).apply()
        }
        b.animalTracking.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("animal_tracking", checked).apply()
        }

        updateAiModelStatus()

        b.prepareAiModels.setOnClickListener {
            b.prepareAiModels.isEnabled = false
            b.aiModelStatus.text =
                "Preparing AI models. Keep internet connected until this finishes…"

            ModelDownloader.prepareAll(
                this,
                onStatus = { text ->
                    runOnUiThread {
                        b.aiModelStatus.text = text
                    }
                },
                onDone = { ok, text ->
                    runOnUiThread {
                        b.prepareAiModels.isEnabled = true
                        b.aiModelStatus.text = text
                        if (ok) {
                            eventStore.add(
                                "AI models ready",
                                "YamNet audio + Pose Landmarker + EfficientDet dog/cat/bird detector stored locally for offline use"
                            )
                            refreshEventLog()
                        }
                    }
                }
            )
        }
    }

    private fun updateAiModelStatus() {
        b.aiModelStatus.text =
            if (ModelDownloader.modelsReady(this))
                "AI models ready locally • audio and pose detection can work without Wi-Fi."
            else
                "AI models not downloaded yet. Tap Prepare / download AI models while online."
    }

    private fun startAutomaticScreenOffCameraService() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            b.status.text = "Camera permission is required."
            return
        }

        // Persist the visible selections before the service opens CameraX.
        prefs.edit()
            .putInt(
                "quality_index",
                b.qualitySpinner.selectedItemPosition
            )
            .putInt(
                "recording_mode",
                b.recordingMode.selectedItemPosition.coerceIn(0, 2)
            )
            .putBoolean("background_handoff_pending", false)
            .apply()

        // Do not claim the dashboard/service is active before Android has
        // actually created the foreground service.  Stale true flags were a
        // major part of the old menu<->camera blinking loop.
        setDashboardPinned(false)
        backgroundHandoffRequested = false
        backgroundServicePrepared = false
        setBackgroundHandoffPending(false)
        dashboardActivationWaitStartedAt =
            System.currentTimeMillis()

        // Never force the display to remain on in service-owned Camera Mode.
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        b.preview.visibility = View.GONE
        b.startBackgroundMonitoring.visibility = View.GONE
        b.stopBackgroundMonitoring.visibility = View.VISIBLE
        b.stopBackgroundMonitoring.isEnabled = true

        if (serviceOwnsCamera()) {
            dashboardActivationWaitStartedAt = 0L
            b.status.text =
                "Camera service active • you may turn off/lock the display."
            b.backgroundStatus.text =
                "Screen-off camera monitoring is active automatically."
            showPairingForBackgroundService()
            startBackgroundServiceDashboard()
            return
        }

        try {
            ContextCompat.startForegroundService(
                this,
                Intent(
                    this,
                    DoorMonitoringService::class.java
                ).apply {
                    action =
                        DoorMonitoringService.ACTION_START_CAMERA_MODE
                }
            )

            eventStore.add(
                "Automatic screen-off camera",
                "Foreground camera service requested directly from visible Camera Mode; no 24/7 hand-off."
            )

            b.status.text =
                "Starting camera service… You can turn off the screen when preview appears."
            b.backgroundStatus.text =
                "Automatic screen-off camera service is starting."

            showPairingForBackgroundService()
            startBackgroundServiceDashboard()

        } catch (t: Throwable) {
            prefs.edit()
                .putBoolean("background_service_running", false)
                .apply()
            setDashboardPinned(false)

            eventStore.add(
                "Automatic camera service start rejected",
                t.toString()
            )

            b.status.text =
                "Camera service could not start: ${t.message ?: t.javaClass.simpleName}"
            b.backgroundStatus.text =
                "Screen-off camera monitoring could not start."
            refreshEventLog()
        }
    }

    private fun stopAutomaticScreenOffCameraService(
        stopLanServer: Boolean
    ) {
        backgroundHandoffRequested = false
        backgroundServicePrepared = false
        setBackgroundHandoffPending(false)
        setDashboardPinned(false)

        prefs.edit()
            .putBoolean("background_service_running", false)
            .apply()

        stopBackgroundServiceDashboard()

        try {
            startService(
                Intent(
                    this,
                    DoorMonitoringService::class.java
                ).apply {
                    action = DoorMonitoringService.ACTION_STOP
                }
            )
        } catch (_: Throwable) {
            try {
                stopService(
                    Intent(
                        this,
                        DoorMonitoringService::class.java
                    )
                )
            } catch (_: Throwable) {}
        }

        if (stopLanServer) {
            LanCameraHub.stop(clearFrame = true)
        }
    }

    private fun setupBackgroundMonitoringUi() {
        b.cool247Mode.isChecked =
            prefs.getBoolean("cool_24_7_mode", true)

        fun updateCoolInfo() {
            b.cool247Info.text =
                if (b.cool247Mode.isChecked)
                    "Cool mode: camera service stays screen-off capable. Thermal Guard may reduce live/AI workload only when the phone warms up; selected Strict 4K recording is preserved unless thermal safety requires intervention."
                else
                    "Cool mode OFF: full live/AI workload is allowed while the screen is on or off. High-resolution continuous recording can make the camera phone warmer."
        }

        updateCoolInfo()

        b.cool247Mode.setOnCheckedChangeListener { _, enabled ->
            prefs.edit()
                .putBoolean("cool_24_7_mode", enabled)
                .apply()
            updateCoolInfo()
        }

        updateBackgroundStatus()

        b.startBackgroundMonitoring.visibility = View.GONE

        b.stopBackgroundMonitoring.setOnClickListener {
            eventStore.add(
                "Automatic screen-off camera",
                "User stopped Camera Mode service."
            )
            stopAutomaticScreenOffCameraService(
                stopLanServer = true
            )
            finish()
        }
    }

    private fun updateBackgroundStatus() {
        val running =
            serviceOwnsCamera()

        if (
            !running &&
            prefs.getBoolean(
                "background_service_running",
                false
            )
        ) {
            prefs.edit()
                .putBoolean(
                    "background_service_running",
                    false
                )
                .apply()
        }

        b.backgroundStatus.text =
            if (running)
                "Screen-off camera monitoring is active automatically. You may lock/turn off the display; the foreground service owns the camera."
            else
                "Camera service is not active."

        b.startBackgroundMonitoring.visibility = View.GONE
        b.stopBackgroundMonitoring.isEnabled = running
    }

    private fun showPairingForBackgroundService() {
        val ip = LocalNetwork.bestIpv4Address() ?: return
        val token = Pairing.getOrCreateCameraToken(this)
        val info = PairInfo(ip, 8787, token)
        pairInfo = info

        b.serverStatus.text =
            "Screen-off camera LAN service: http://${info.host}:${info.port}"
        b.pairingAddress.text =
            "Use this QR while Camera Mode is running, including with the display off.\n${info.pairingUri()}"

        try {
            b.pairingQr.setImageBitmap(
                Pairing.qrBitmap(info.pairingUri(), 600)
            )
        } catch (_: Exception) {}
    }

    private fun beginBackgroundCameraHandoff() {
        segmentHandler.removeCallbacksAndMessages(null)
        continuousRollover = false

        // Do not unbind CameraX while Recorder is still finalizing. If a
        // foreground continuous segment is active, wait for Finalize. Its
        // callback will call completeBackgroundCameraHandoff().
        val activeRecording = recording
        if (activeRecording != null) {
            b.status.text =
                "24/7 hand-off: closing the current foreground MP4 cleanly…"
            try {
                activeRecording.stop()
            } catch (e: Exception) {
                eventStore.add(
                    "24/7 hand-off warning",
                    "Could not stop foreground recording cleanly: ${e.message}"
                )
                recording = null
                completeBackgroundCameraHandoff()
            }
        } else {
            completeBackgroundCameraHandoff()
        }
    }

    private fun completeBackgroundCameraHandoff() {
        if (!backgroundHandoffRequested) return

        segmentHandler.removeCallbacksAndMessages(null)

        // Keep the process-wide LAN server/socket alive. The Service will
        // replace the active endpoint callbacks and frame producer after the
        // camera ownership transfer, so existing /stream clients stay connected.
        server = LanCameraHub.server()

        networkCallback?.let {
            try {
                connectivityManager.unregisterNetworkCallback(it)
            } catch (_: Exception) {}
        }
        networkCallback = null

        // At this point the Activity Recorder has finalized. It is now safe to
        // release Activity-owned CameraX use cases.
        try { previewAiBridge?.stop() } catch (_: Exception) {}
        previewAiBridge = null
        localPreviewUsesBridge = false

        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        camera = null
        videoCapture = null
        recording = null
        recordingReason = null

        // Activity CameraX is released, but Camera Mode itself stays open.
        // The top camera area becomes a dashboard for the foreground service
        // rather than disappearing/looking like the Activity was closed.
        b.preview.visibility =
            View.GONE

        b.backgroundLiveView.visibility =
            View.GONE

        b.backgroundPreviewOverlay.visibility =
            View.VISIBLE

        b.backgroundPreviewOverlay.text =
            "24/7 service is taking over the camera…\n\nCamera Mode will remain open."

        window.clearFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        // The LAN ServerSocket is process-wide and remains open in LanCameraHub.
        // Only CameraX ownership changes here. Existing /stream clients therefore
        // keep the same TCP connection while the Service becomes the frame producer.
        dashboardActivationWaitStartedAt =
            System.currentTimeMillis()

        b.status.text =
            "24/7 hand-off: Activity camera released • starting service camera…"

        b.backgroundStatus.text =
            "24/7 service takeover in progress. Viewer connection stays on port 8787."

        b.backgroundPreviewOverlay.visibility =
            View.VISIBLE

        b.backgroundPreviewOverlay.text =
            "24/7 service is taking over the camera…\n\nLAN viewer connection is being kept alive."

        val activateIntent =
            Intent(
                this,
                DoorMonitoringService::class.java
            ).apply {
                action =
                    DoorMonitoringService.ACTION_ACTIVATE_CAMERA
            }

        try {
            // No artificial delay: CameraX has already been unbound above and
            // the persistent LAN socket does not need to be released/rebound.
            startService(activateIntent)

            setBackgroundHandoffPending(false)

            eventStore.add(
                "24/7 camera hand-off",
                "Activity CameraX released; service activation requested on the persistent LAN endpoint."
            )

            b.status.text =
                "24/7 background camera activation requested. Waiting for real camera frames…"

            b.backgroundStatus.text =
                "24/7 service activation requested. Existing viewer socket remains active."

            startBackgroundServiceDashboard()

            backgroundHandoffRequested =
                false

            refreshEventLog()

        } catch (e: Exception) {
            backgroundHandoffRequested =
                false

            backgroundServicePrepared =
                false

            setBackgroundHandoffPending(false)
            setDashboardPinned(false)

            prefs.edit()
                .putBoolean(
                    "background_service_running",
                    false
                )
                .apply()

            stopBackgroundServiceDashboard()

            b.preview.visibility =
                View.VISIBLE

            b.startBackgroundMonitoring.isEnabled =
                true

            b.stopBackgroundMonitoring.isEnabled =
                false

            b.status.text =
                "24/7 hand-off failed: ${e.message}"

            eventStore.add(
                "24/7 hand-off failed",
                e.message ?:
                    "unknown service activation error"
            )
        }

        return
    }

    private fun backgroundServiceLoopbackPair(): PairInfo =
        PairInfo(
            host = "127.0.0.1",
            port = 8787,
            token =
                Pairing.getOrCreateCameraToken(
                    this
                )
        )

    private fun startBackgroundServiceDashboard() {
        if (!serviceOwnsCamera()) {
            val waitingForActivation =
                backgroundHandoffRequested ||
                    backgroundServicePrepared ||
                    (
                        dashboardActivationWaitStartedAt >
                            0L &&
                            System.currentTimeMillis() -
                                dashboardActivationWaitStartedAt <
                            5_000L
                    )

            if (waitingForActivation) {
                b.preview.visibility =
                    View.GONE

                b.backgroundLiveView.visibility =
                    View.GONE

                b.backgroundPreviewOverlay.visibility =
                    View.VISIBLE

                b.backgroundPreviewOverlay.text =
                    "Camera service is starting…\n\nWaiting for camera/LAN stream."

                backgroundDashboardHandler
                    .postDelayed({
                        if (::b.isInitialized) {
                            val stillWaiting =
                                dashboardActivationWaitStartedAt > 0L &&
                                    System.currentTimeMillis() -
                                        dashboardActivationWaitStartedAt <
                                    5_000L

                            if (serviceOwnsCamera() || stillWaiting) {
                                startBackgroundServiceDashboard()
                            }
                        }
                    }, 200L)

                return
            }

            prefs.edit()
                .putBoolean(
                    "background_service_running",
                    false
                )
                .apply()

            stopBackgroundServiceDashboard()

            b.backgroundLiveView.visibility =
                View.GONE

            b.backgroundPreviewOverlay.visibility =
                View.VISIBLE
            b.backgroundPreviewOverlay.text =
                "Camera service did not become ready. Return to the menu and open Camera Mode again."

            b.preview.visibility =
                View.GONE

            b.status.text =
                "Camera service startup timed out."

            return
        }

        dashboardActivationWaitStartedAt =
            0L

        if (backgroundDashboardRunning) {
            return
        }

        backgroundDashboardRunning =
            true

        b.preview.visibility =
            View.GONE

        b.backgroundPreviewOverlay.visibility =
            View.VISIBLE

        b.backgroundPreviewOverlay.text =
            "Screen-off camera service active\\n\\nWaiting for camera state…"

        b.backgroundLiveView.visibility =
            View.GONE

        backgroundDashboardStreamStarted =
            false

        val poller =
            object : Runnable {
                override fun run() {
                    if (
                        !backgroundDashboardRunning ||
                        !DoorMonitoringService.isRunning ||
                        !DoorMonitoringService
                            .isCameraActivationRequested
                    ) {
                        return
                    }

                    pollBackgroundServiceHealth()

                    backgroundDashboardHandler
                        .postDelayed(
                            this,
                            1_000L
                        )
                }
            }

        backgroundDashboardHandler.post(
            poller
        )
    }

    private fun stopBackgroundServiceDashboard() {
        backgroundDashboardRunning =
            false

        backgroundDashboardHandler
            .removeCallbacksAndMessages(
                null
            )

        try {
            b.backgroundLiveView.stop()
            b.backgroundLiveView.clearFrame()
        } catch (_: Exception) {}

        backgroundDashboardStreamStarted =
            false

        b.backgroundLiveView.visibility =
            View.GONE

        b.backgroundPreviewOverlay.visibility =
            View.GONE
    }

    private fun pollBackgroundServiceHealth() {
        if (!backgroundDashboardRunning) {
            return
        }

        val pair =
            backgroundServiceLoopbackPair()

        backgroundDashboardExecutor.execute {
            try {
                val connection =
                    URL(
                        pair.endpoint(
                            "/health"
                        )
                    )
                        .openConnection()
                        as HttpURLConnection

                connection.connectTimeout =
                    1_500

                connection.readTimeout =
                    1_500

                connection.requestMethod =
                    "GET"

                val code =
                    connection.responseCode

                if (code !in 200..299) {
                    connection.disconnect()
                    return@execute
                }

                val raw =
                    connection.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                connection.disconnect()

                val health =
                    JSONObject(raw)

                val visualAvailable =
                    health.optBoolean(
                        "visualStreamAvailable",
                        true
                    )

                val serviceRecording =
                    health.optBoolean(
                        "recording",
                        false
                    )

                val recordingFirst =
                    health.optBoolean(
                        "recordingFirstMode",
                        false
                    )

                val previewBridge =
                    health.optBoolean(
                        "previewAiBridgeMode",
                        false
                    )

                val firstFramePending =
                    health.optBoolean(
                        "firstFramePending",
                        false
                    )

                val stage =
                    health.optString(
                        "compatibilityStage",
                        ""
                    )

                val activeQuality =
                    health.optString(
                        "quality",
                        "camera"
                    )

                val mode =
                    health.optString(
                        "recordingModeName",
                        ""
                    )

                runOnUiThread {
                    backgroundServiceRecording = serviceRecording
                    b.recordButton.text =
                        if (serviceRecording)
                            "STOP / SAVE MP4 RECORDING"
                        else
                            "START MP4 RECORDING"

                    if (
                        !backgroundDashboardRunning ||
                        !DoorMonitoringService.isRunning ||
                        !DoorMonitoringService
                            .isCameraActivationRequested
                    ) {
                        return@runOnUiThread
                    }

                    if (visualAvailable) {
                        b.backgroundPreviewOverlay.visibility =
                            if (firstFramePending)
                                View.VISIBLE
                            else
                                View.GONE

                        if (firstFramePending) {
                            b.backgroundPreviewOverlay.text =
                                "Camera Mode service dashboard\\n\\nTrying $stage\\nWaiting for first camera frame…"
                        }

                        b.backgroundLiveView.visibility =
                            View.VISIBLE

                        if (!backgroundDashboardStreamStarted) {
                            backgroundDashboardStreamStarted =
                                true

                            b.backgroundLiveView.start(
                                pair
                            ) { state ->
                                if (
                                    backgroundDashboardRunning
                                ) {
                                    b.status.text =
                                        "Camera service preview • $state"
                                }
                            }
                        }

                        b.backgroundStatus.text =
                            buildString {
                                append(
                                    "Camera service active • "
                                )
                                append(
                                    activeQuality
                                )

                                if (previewBridge) {
                                    append(
                                        " • High-resolution Preview AI Bridge"
                                    )
                                }

                                if (
                                    mode.isNotBlank()
                                ) {
                                    append(
                                        " • "
                                    )
                                    append(
                                        mode
                                    )
                                }

                                append(
                                    " • Camera Mode remains open."
                                )
                            }

                    } else {
                        if (backgroundDashboardStreamStarted) {
                            try {
                                b.backgroundLiveView.stop()
                                b.backgroundLiveView.clearFrame()
                            } catch (_: Exception) {}

                            backgroundDashboardStreamStarted =
                                false
                        }

                        b.backgroundLiveView.visibility =
                            View.GONE

                        b.backgroundPreviewOverlay.visibility =
                            View.VISIBLE

                        b.backgroundPreviewOverlay.text =
                            if (recordingFirst) {
                                "RECORDING-FIRST\\n\\n$activeQuality\\n\\nExact recording is active.\\nVisual preview/AI is unavailable in this final camera combination.\\n\\nCamera Mode is still open."
                            } else {
                                "24/7 service active\\n\\n$stage\\n\\nVisual preview is temporarily unavailable.\\nCamera Mode remains open."
                            }

                        b.backgroundStatus.text =
                            "24/7 active • $activeQuality • ${if (recordingFirst) "Recording-First" else stage} • Camera Mode remains open."
                    }
                }

            } catch (_: Exception) {
                runOnUiThread {
                    if (!backgroundDashboardRunning) {
                        return@runOnUiThread
                    }

                    if (!DoorMonitoringService.isRunning) {
                        prefs.edit()
                            .putBoolean(
                                "background_service_running",
                                false
                            )
                            .apply()

                        stopBackgroundServiceDashboard()

                        b.backgroundStatus.text =
                            "24/7 service is not running. Local Camera Mode restored."

                        b.status.text =
                            "Restoring local camera preview…"

                        startCamera()

                    } else {
                        b.backgroundPreviewOverlay.visibility =
                            View.VISIBLE

                        b.backgroundPreviewOverlay.text =
                            "24/7 service is starting/rebuilding the camera…\\n\\nCamera Mode remains open."
                    }
                }
            }
        }
    }

    private fun sendBackgroundServiceCommand(
        path: String,
        successMessage: String
    ) {
        val pair = backgroundServiceLoopbackPair()

        backgroundDashboardExecutor.execute {
            try {
                val connection =
                    URL(pair.endpoint(path))
                        .openConnection() as HttpURLConnection

                connection.connectTimeout = 2_000
                connection.readTimeout = 2_000
                connection.requestMethod = "GET"

                val code = connection.responseCode

                if (code !in 200..299) {
                    val errorText =
                        try {
                            connection.errorStream
                                ?.bufferedReader()
                                ?.use { it.readText() }
                                .orEmpty()
                        } catch (_: Exception) {
                            ""
                        }

                    connection.disconnect()

                    runOnUiThread {
                        toast(
                            "Recording command failed" +
                                if (errorText.isBlank())
                                    " (HTTP $code)."
                                else
                                    ": $errorText"
                        )
                    }
                    return@execute
                }

                try {
                    connection.inputStream.close()
                } catch (_: Exception) {
                }
                connection.disconnect()

                runOnUiThread {
                    toast(successMessage)
                    backgroundDashboardHandler.postDelayed({
                        if (backgroundDashboardRunning) {
                            pollBackgroundServiceHealth()
                        }
                    }, 250L)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    toast(
                        "Recording command failed: " +
                            (t.message ?: t.javaClass.simpleName)
                    )
                }
            }
        }
    }

    private fun formatBytes(bytes: Long): String {
        val gb = bytes.toDouble() / 1024.0 / 1024.0 / 1024.0
        return String.format(Locale.US, "%.2f GB", gb)
    }

    private fun setupButtons() {
        b.openRules.setOnClickListener {
            startActivity(Intent(this, RuleEditorActivity::class.java))
        }

        b.copyPairing.setOnClickListener {
            val text = pairInfo?.pairingUri()
            if (text.isNullOrBlank()) {
                toast("Pairing code is not ready yet.")
            } else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("AI Door Monitor pairing", text))
                toast("Pairing code copied.")
            }
        }

        b.recordButton.setOnClickListener {
            if (serviceOwnsCamera()) {
                val starting = !backgroundServiceRecording
                sendBackgroundServiceCommand(
                    if (starting) "/record/start" else "/record/stop",
                    if (starting)
                        "MP4 recording start requested."
                    else
                        "MP4 recording stop/save requested."
                )
            } else {
                if (recording == null) {
                    startRecording("manual")
                } else {
                    stopRecording()
                }
            }
        }

        b.saveSnapshot.setOnClickListener { saveSnapshotOnCameraPhone() }
    }

    private fun selectedQuality(): Quality =
        when (b.qualitySpinner.selectedItemPosition) {
            0 -> Quality.HIGHEST
            1 -> Quality.UHD
            2 -> Quality.FHD
            3 -> Quality.HD
            else -> Quality.UHD
        }

    private fun selectedQualityName(): String =
        when (b.qualitySpinner.selectedItemPosition) {
            0 -> "8K UHD / 4320p requested"
            1 -> "4K UHD"
            2 -> "1080p Full HD"
            3 -> "720p HD"
            else -> "4K UHD"
        }

    private fun recordingMode(): Int =
        prefs.getInt(
            "recording_mode",
            1
        ).coerceIn(0, 2)

    private fun strictRecordingQuality(): Boolean =
        recordingMode() == 0

    private fun bestSimultaneousMode(): Boolean =
        recordingMode() == 1

    private fun previewAiPriorityMode(): Boolean =
        recordingMode() == 2

    private fun recordingModeName(): String =
        when (recordingMode()) {
            0 -> "Strict Recording Quality"
            2 -> "Preview / AI Priority"
            else -> "Best Simultaneous Quality"
        }

    private fun isAtLeast8K(size: Size?): Boolean {
        if (size == null) return false
        val longSide = maxOf(size.width, size.height)
        val shortSide = minOf(size.width, size.height)
        return longSide >= 7680 && shortSide >= 4320
    }

    private fun formatResolution(size: Size?): String =
        if (size == null) "unknown"
        else "${size.width}×${size.height}"

    private fun startCamera() {
        if (serviceOwnsCamera()) {
            startBackgroundServiceDashboard()
            return
        }

        stopBackgroundServiceDashboard()

        b.backgroundLiveView.visibility =
            View.GONE

        b.backgroundPreviewOverlay.visibility =
            View.GONE

        b.preview.visibility =
            View.VISIBLE

        b.preview.implementationMode =
            androidx.camera.view.PreviewView
                .ImplementationMode.COMPATIBLE

        val providerFuture = ProcessCameraProvider.getInstance(this)

        providerFuture.addListener({
            val provider = providerFuture.get()
            cameraProvider = provider

            try { previewAiBridge?.stop() } catch (_: Exception) {}
            previewAiBridge = null
            localPreviewUsesBridge = false

            try {
                provider.unbindAll()
            } catch (_: Exception) {}

            val preview = Preview.Builder().build().also {
                it.surfaceProvider = b.preview.surfaceProvider
            }

            val wantedQuality =
                selectedQuality()

            val strictQuality =
                strictRecordingQuality()

            val analysisTarget =
                if (
                    strictQuality &&
                    (
                        wantedQuality == Quality.HIGHEST ||
                        wantedQuality == Quality.UHD
                    )
                ) {
                    Size(320, 180)
                } else {
                    Size(640, 480)
                }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(
                    ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
                )
                .setTargetResolution(
                    analysisTarget
                )
                .build()

            analysis.setAnalyzer(
                analysisExecutor
            ) { image ->
                processStreamFrame(image)
            }

            val orderedQualityCandidates =
                when (wantedQuality) {
                    Quality.HIGHEST ->
                        listOf(
                            Quality.HIGHEST,
                            Quality.UHD,
                            Quality.FHD,
                            Quality.HD
                        )

                    Quality.UHD ->
                        listOf(
                            Quality.UHD,
                            Quality.FHD,
                            Quality.HD
                        )

                    Quality.FHD ->
                        listOf(
                            Quality.FHD,
                            Quality.HD
                        )

                    else ->
                        listOf(
                            Quality.HD
                        )
                }

            val qualitySelector =
                when {
                    strictQuality ->
                        QualitySelector.from(
                            wantedQuality
                        )

                    bestSimultaneousMode() ->
                        QualitySelector.fromOrderedList(
                            orderedQualityCandidates,
                            FallbackStrategy
                                .lowerQualityOrHigherThan(
                                    orderedQualityCandidates.last()
                                )
                        )

                    else ->
                        QualitySelector.fromOrderedList(
                            orderedQualityCandidates +
                                listOf(Quality.SD),
                            FallbackStrategy
                                .lowerQualityOrHigherThan(
                                    Quality.SD
                                )
                        )
                }

            val recorder = Recorder.Builder()
                .setQualitySelector(qualitySelector)
                .build()
            val capture = CameraXVideoCapture.withOutput(recorder)

            try {
                camera =
                    provider.bindToLifecycle(
                        this,
                        CameraSelector
                            .DEFAULT_BACK_CAMERA,
                        preview,
                        analysis,
                        capture
                    )

                videoCapture = capture
                recordingAvailable = true
                b.recordButton.isEnabled = true

            } catch (tripleError: Exception) {
                provider.unbindAll()

                if (strictQuality) {
                    // Some phones cannot expose 4K VideoCapture + ImageAnalysis
                    // simultaneously even though 4K VideoCapture + Preview is
                    // supported. Preserve exact recording quality and turn the
                    // Preview stream into low-resolution MJPEG/AI frames instead
                    // of disabling the monitor preview.
                    val bridgePreview =
                        Preview.Builder()
                            .setTargetResolution(
                                Size(1280, 720)
                            )
                            .build()

                    val bridge =
                        PreviewAiBridge(
                            outputWidth = 1280,
                            outputHeight = 720,
                            maxFps = 10,
                            onFrame = { bitmap ->
                                processActivityPreviewBridgeFrame(
                                    bitmap
                                )
                            },
                            onStatus = { text ->
                                if (
                                    text.contains("failed", true) ||
                                    text.contains("error", true)
                                ) {
                                    eventStore.add(
                                        "Foreground Preview bridge",
                                        text
                                    )
                                }
                            }
                        )

                    bridgePreview.setSurfaceProvider(
                        bridge
                    )

                    try {
                        camera =
                            provider.bindToLifecycle(
                                this,
                                CameraSelector
                                    .DEFAULT_BACK_CAMERA,
                                bridgePreview,
                                capture
                            )

                        previewAiBridge = bridge
                        localPreviewUsesBridge = true
                        videoCapture = capture
                        recordingAvailable = true
                        b.recordButton.isEnabled = true

                        b.status.text =
                            "${selectedQualityName()} exact recording + live Preview bridge enabled."

                        eventStore.add(
                            "Strict 4K/high-resolution bridge",
                            "${selectedQualityName()} preserved • 1280×720 Preview AI bridge @ 10 fps + VideoCapture supplies live monitor/AI frames without ImageAnalysis."
                        )

                    } catch (
                        strictVideoError: Exception
                    ) {
                        try { bridge.stop() } catch (_: Exception) {}
                        previewAiBridge = null
                        localPreviewUsesBridge = false
                        videoCapture = null
                        recordingAvailable = false
                        b.recordButton.isEnabled = false

                        b.status.text =
                            "Selected recording resolution unavailable: ${strictVideoError.message}"

                        eventStore.add(
                            "Strict recording resolution unavailable",
                            "${selectedQualityName()} • ${strictVideoError.message ?: strictVideoError.javaClass.simpleName}"
                        )

                        return@addListener
                    }

                } else {
                    try {
                        camera =
                            provider.bindToLifecycle(
                                this,
                                CameraSelector
                                    .DEFAULT_BACK_CAMERA,
                                preview,
                                analysis
                            )

                        videoCapture = null
                        recordingAvailable = false
                        b.recordButton.isEnabled = false

                        b.status.text =
                            "${recordingModeName()}: live stream + visual AI work, but this camera session cannot bind video recording simultaneously."

                    } catch (e: Exception) {
                        b.status.text =
                            "Camera failed: ${e.message}"
                        return@addListener
                    }
                }
            }

            configureCameraCapabilities()
            observeZoom()
            startLanServer()

            if (localPreviewUsesBridge) {
                showLocalPreviewBridge()
            }

            if (recordingAvailable) {
                b.status.text =
                    "Camera ready • ${selectedQualityName()} requested • Offline Motion Guard can record without Wi-Fi."

                if (b.continuousRecording.isChecked && recording == null) {
                    startRecording("continuous")
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun configureCameraCapabilities() {
        val cam = camera ?: return

        try {
            val info = Camera2CameraInfo.from(cam.cameraInfo)

            sensorActiveArray =
                info.getCameraCharacteristic(
                    CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE
                )

            val cropType =
                info.getCameraCharacteristic(
                    CameraCharacteristics.SCALER_CROPPING_TYPE
                ) ?: CameraMetadata.SCALER_CROPPING_TYPE_CENTER_ONLY

            freeformCropSupported =
                cropType ==
                    CameraMetadata.SCALER_CROPPING_TYPE_FREEFORM

            val distortionModes =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    info.getCameraCharacteristic(
                        CameraCharacteristics
                            .DISTORTION_CORRECTION_AVAILABLE_MODES
                    ) ?: intArrayOf()
                } else {
                    intArrayOf()
                }

            distortionCorrectionOffAvailable =
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                    distortionModes.contains(
                        CaptureRequest.DISTORTION_CORRECTION_MODE_OFF
                    )

            val preCorrection =
                info.getCameraCharacteristic(
                    CameraCharacteristics
                        .SENSOR_INFO_PRE_CORRECTION_ACTIVE_ARRAY_SIZE
                )

            // When distortion correction is OFF, Camera2 defines cropRegion
            // coordinates in preCorrectionActiveArraySize. Otherwise it uses
            // activeArraySize.
            cropCoordinateArray =
                if (
                    distortionCorrectionOffAvailable &&
                    preCorrection != null
                ) {
                    preCorrection
                } else {
                    sensorActiveArray
                }

            maxZoom =
                (
                    info.getCameraCharacteristic(
                        CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM
                    ) ?: 1f
                ).coerceAtLeast(1f)

            minZoom = 1f

            cameraZoomLinear =
                prefs.getFloat("camera_zoom_linear", 0f)
                    .coerceIn(0f, 1f)

            cameraPanX =
                prefs.getFloat("camera_pan_x", 0f)
                    .coerceIn(-1f, 1f)

            cameraPanY =
                prefs.getFloat("camera_pan_y", 0f)
                    .coerceIn(-1f, 1f)

            currentZoom =
                1f +
                    cameraZoomLinear *
                        (maxZoom - 1f)

            maxFocusDiopters =
                info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)
                    ?: 0f

            val capabilities =
                info.getCameraCharacteristic(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                    ?: intArrayOf()

            manualFocusSupported =
                maxFocusDiopters > 0f &&
                capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)

            val ranges =
                info.getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                    ?: emptyArray()

            targetFpsRange = ranges
                .filter { it.contains(30) }
                .minWithOrNull(
                    compareBy<Range<Int>> { it.upper - it.lower }
                        .thenByDescending { it.lower }
                )

            val supported = try {
                QualitySelector.getSupportedQualities(cam.cameraInfo)
            } catch (_: Exception) {
                emptyList()
            }
            highestVideoResolution = try {
                QualitySelector.getResolution(
                    cam.cameraInfo,
                    Quality.HIGHEST
                )
            } catch (_: Exception) {
                null
            }

            eightKSupported =
                isAtLeast8K(highestVideoResolution)

            uhdSupported =
                supported.contains(Quality.UHD)

            val fpsText = when (val fps = targetFpsRange) {
                null -> "30 fps camera range not reported"
                else -> if (fps.lower == 30 && fps.upper == 30)
                    "fixed 30 fps supported"
                else
                    "30 fps requested via ${fps.lower}-${fps.upper} fps camera range"
            }

            b.qualityStatus.text =
                "8K: ${if (eightKSupported) "supported" else "not exposed by CameraX"} " +
                "(highest=${formatResolution(highestVideoResolution)}) • " +
                "4K: ${if (uhdSupported) "supported" else "not supported"} • " +
                "1080p/720p stable fallback • " +
                fpsText +
                " • camera pan: " +
                if (freeformCropSupported)
                    "FREEFORM sensor crop"
                else
                    "CENTER_ONLY → live-view software pan fallback"

            if (b.qualitySpinner.selectedItemPosition == 0) {
                b.status.text =
                    if (eightKSupported) {
                        "8K requested • CameraX highest=${formatResolution(highestVideoResolution)}"
                    } else {
                        "8K requested, but CameraX highest is ${formatResolution(highestVideoResolution)}. Recording will use the highest available resolution."
                    }
            }

            b.focusSlider.isEnabled = manualFocusSupported
            b.focusFar.isEnabled = manualFocusSupported
            b.focusNear.isEnabled = manualFocusSupported

            if (manualFocusSupported) {
                b.focusStatus.text =
                    "Manual lens focus supported • max ${formatDiopters(maxFocusDiopters)} D"
            } else {
                b.focusStatus.text =
                    "This camera reports fixed/automatic focus only. Auto Focus remains available."
                focusModeManual = false
            }

            currentFocusLinear =
                if (focusModeManual) prefs.getFloat("focus_linear", 0f).coerceIn(0f, 1f)
                else 0f
            b.focusSlider.progress = (currentFocusLinear * 1000f).toInt()
            updateFocusLabel(currentFocusLinear)

            applyCamera2Controls()
        } catch (e: Exception) {
            manualFocusSupported = false
            b.focusStatus.text = "Camera focus capability check failed: ${e.message}"
        }
    }

    private fun applyCamera2Controls() {
        val cam = camera ?: return

        try {
            val builder = CaptureRequestOptions.Builder()

            targetFpsRange?.let {
                builder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE,
                    it
                )
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Android requires zoomRatio=1.0 when using FREEFORM cropRegion
                // for window-boxing / off-center sensor crop.
                builder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_ZOOM_RATIO,
                    1.0f
                )
            }

            if (
                distortionCorrectionOffAvailable &&
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
            ) {
                builder.setCaptureRequestOption(
                    CaptureRequest.DISTORTION_CORRECTION_MODE,
                    CaptureRequest.DISTORTION_CORRECTION_MODE_OFF
                )
            }

            cropCoordinateArray?.let { active ->
                val zoom =
                    currentZoom.coerceIn(
                        1f,
                        maxZoom.coerceAtLeast(1f)
                    )

                val cropWidth =
                    (active.width() / zoom)
                        .toInt()
                        .coerceIn(2, active.width())

                val cropHeight =
                    (active.height() / zoom)
                        .toInt()
                        .coerceIn(2, active.height())

                val availableX =
                    (active.width() - cropWidth)
                        .coerceAtLeast(0)

                val availableY =
                    (active.height() - cropHeight)
                        .coerceAtLeast(0)

                val effectivePanX =
                    if (freeformCropSupported) cameraPanX else 0f

                val effectivePanY =
                    if (freeformCropSupported) cameraPanY else 0f

                val left =
                    (
                        active.left +
                            (
                                availableX *
                                    (effectivePanX + 1f) /
                                    2f
                            ).toInt()
                    ).coerceIn(
                        active.left,
                        active.right - cropWidth
                    )

                val top =
                    (
                        active.top +
                            (
                                availableY *
                                    (effectivePanY + 1f) /
                                    2f
                            ).toInt()
                    ).coerceIn(
                        active.top,
                        active.bottom - cropHeight
                    )

                builder.setCaptureRequestOption(
                    CaptureRequest.SCALER_CROP_REGION,
                    Rect(
                        left,
                        top,
                        left + cropWidth,
                        top + cropHeight
                    )
                )
            }

            if (manualFocusSupported && focusModeManual) {
                val diopters = (currentFocusLinear * maxFocusDiopters)
                    .coerceIn(0f, maxFocusDiopters)

                builder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_OFF
                )
                builder.setCaptureRequestOption(
                    CaptureRequest.LENS_FOCUS_DISTANCE,
                    diopters
                )
                b.focusStatus.text =
                    "Manual focus active • ${formatDiopters(diopters)} D"
            } else {
                builder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                )
                b.focusStatus.text =
                    if (manualFocusSupported) "Auto Focus • continuous video AF"
                    else "Auto/fixed focus camera"
            }

            Camera2CameraControl
                .from(cam.cameraControl)
                .setCaptureRequestOptions(builder.build())
        } catch (e: Exception) {
            b.focusStatus.text = "Could not apply focus control: ${e.message}"
        }
    }

    private fun setManualFocusLinear(linear: Float) {
        if (!manualFocusSupported) return
        focusModeManual = true
        currentFocusLinear = linear.coerceIn(0f, 1f)
        b.focusSlider.progress = (currentFocusLinear * 1000f).toInt()
        updateFocusLabel(currentFocusLinear)
        applyCamera2Controls()
    }

    private fun stepFocus(delta: Int) {
        val next = (b.focusSlider.progress + delta).coerceIn(0, 1000)
        b.focusSlider.progress = next
        setManualFocusLinear(next / 1000f)
    }

    private fun setAutoFocus() {
        focusModeManual = false
        applyCamera2Controls()
    }

    private fun saveFocusDefault() {
        prefs.edit()
            .putBoolean("focus_manual", focusModeManual)
            .putFloat("focus_linear", currentFocusLinear)
            .apply()
    }

    private fun updateFocusLabel(linear: Float) {
        if (!manualFocusSupported || maxFocusDiopters <= 0f) {
            b.focusValue.text = "Manual focus unavailable"
            return
        }

        val diopters = linear.coerceIn(0f, 1f) * maxFocusDiopters
        val distanceText =
            if (diopters <= 0.001f) "Infinity"
            else {
                val meters = 1f / diopters
                if (meters >= 1f) String.format(Locale.US, "%.2f m", meters)
                else String.format(Locale.US, "%.0f cm", meters * 100f)
            }

        b.focusValue.text =
            "Manual focus: $distanceText • ${formatDiopters(diopters)} D"
    }

    private fun formatDiopters(value: Float): String =
        String.format(Locale.US, "%.2f", value)

    private fun observeZoom() {
        updateCameraZoomUi()
    }

    private fun setCameraView(
        linear: Float,
        panX: Float,
        panY: Float
    ) {
        cameraZoomLinear =
            linear.coerceIn(0f, 1f)

        cameraPanX =
            if (cameraZoomLinear <= 0.001f) {
                0f
            } else {
                panX.coerceIn(-1f, 1f)
            }

        cameraPanY =
            if (cameraZoomLinear <= 0.001f) {
                0f
            } else {
                panY.coerceIn(-1f, 1f)
            }

        currentZoom =
            1f +
                cameraZoomLinear *
                    (maxZoom - 1f)

        prefs.edit()
            .putFloat("camera_zoom_linear", cameraZoomLinear)
            .putFloat("camera_pan_x", cameraPanX)
            .putFloat("camera_pan_y", cameraPanY)
            .apply()

        applyCamera2Controls()
        updateCameraZoomUi()
    }

    private fun updateCameraZoomUi() {
        if (!b.zoomSlider.isPressed) {
            b.zoomSlider.progress =
                (cameraZoomLinear * 1000f)
                    .toInt()
                    .coerceIn(0, 1000)
        }

        b.zoomText.text =
            String.format(
                Locale.US,
                "Camera zoom %.1f× (max %.1f×) • pan X %.0f%% / Y %.0f%%",
                currentZoom,
                maxZoom,
                cameraPanX * 100f,
                cameraPanY * 100f
            )
    }

    private fun previewQualityMode(): Int =
        prefs.getInt("preview_quality_mode", 0)
            .coerceIn(0, 4)

    private fun previewTargetWidth(): Int =
        when (previewQualityMode()) {
            1 -> 320
            2 -> 426
            3 -> 480
            4 -> 480
            else -> 360
        }

    private fun previewJpegQuality(): Int =
        when (previewQualityMode()) {
            1 -> 35
            2 -> 45
            3 -> 55
            4 -> 72
            else -> 40
        }

    private fun applySoftwareLivePan(
        source: Bitmap
    ): Bitmap {
        if (
            freeformCropSupported ||
            cameraZoomLinear <= 0.001f ||
            (
                kotlin.math.abs(cameraPanX) < 0.01f &&
                kotlin.math.abs(cameraPanY) < 0.01f
            )
        ) {
            return source
        }

        // CENTER_ONLY cameras cannot move SCALER_CROP_REGION off-center.
        // For the LAN live view, crop inside the already zoomed frame so the
        // drag gesture is still visibly useful. This is a preview fallback;
        // saved MP4 remains governed by the camera HAL's centered crop.
        val extraScale =
            1f +
                cameraZoomLinear *
                    0.35f

        val cropW =
            (source.width / extraScale)
                .toInt()
                .coerceIn(2, source.width)

        val cropH =
            (source.height / extraScale)
                .toInt()
                .coerceIn(2, source.height)

        val maxLeft =
            (source.width - cropW)
                .coerceAtLeast(0)

        val maxTop =
            (source.height - cropH)
                .coerceAtLeast(0)

        val left =
            (
                maxLeft *
                    (cameraPanX + 1f) /
                    2f
            )
                .toInt()
                .coerceIn(0, maxLeft)

        val top =
            (
                maxTop *
                    (cameraPanY + 1f) /
                    2f
            )
                .toInt()
                .coerceIn(0, maxTop)

        return Bitmap.createBitmap(
            source,
            left,
            top,
            cropW,
            cropH
        )
    }


    private fun processActivityPreviewBridgeFrame(
        sourceBitmap: Bitmap
    ) {
        var bitmap = sourceBitmap

        try {
            val motionScore = motionDetector.score(bitmap)
            handleMotionScore(motionScore)

            if (!freeformCropSupported) {
                val panned =
                    applySoftwareLivePan(bitmap)

                if (panned !== bitmap) {
                    if (!bitmap.isRecycled) {
                        bitmap.recycle()
                    }
                    bitmap = panned
                }
            }

            val maxWidth =
                previewTargetWidth()

            if (bitmap.width > maxWidth) {
                val height =
                    (
                        bitmap.height *
                            (maxWidth.toFloat() / bitmap.width.toFloat())
                    ).toInt().coerceAtLeast(1)

                val scaled =
                    Bitmap.createScaledBitmap(
                        bitmap,
                        maxWidth,
                        height,
                        true
                    )

                if (
                    scaled !== bitmap &&
                    !bitmap.isRecycled
                ) {
                    bitmap.recycle()
                }

                bitmap = scaled
            }

            val out = ByteArrayOutputStream()
            bitmap.compress(
                Bitmap.CompressFormat.JPEG,
                previewJpegQuality(),
                out
            )

            latestJpeg.set(
                out.toByteArray()
            )
            latestFrameAtMs = System.currentTimeMillis()
        } catch (_: Exception) {
        } finally {
            try {
                if (!bitmap.isRecycled) {
                    bitmap.recycle()
                }
            } catch (_: Exception) {}
        }
    }

    private fun showLocalPreviewBridge() {
        val pair =
            PairInfo(
                host = "127.0.0.1",
                port = 8787,
                token = Pairing.getOrCreateCameraToken(this)
            )

        b.preview.visibility =
            View.GONE

        b.backgroundPreviewOverlay.visibility =
            View.GONE

        b.backgroundLiveView.visibility =
            View.VISIBLE

        b.backgroundLiveView.start(pair) { state ->
            if (
                localPreviewUsesBridge &&
                !serviceOwnsCamera()
            ) {
                b.status.text =
                    "${selectedQualityName()} exact recording • $state"
            }
        }
    }

    private fun processStreamFrame(image: ImageProxy) {
        try {
            var bitmap = image.toBitmap()
            val rotation = image.imageInfo.rotationDegrees

            if (rotation != 0) {
                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                val rotated = Bitmap.createBitmap(
                    bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true
                )
                if (rotated !== bitmap && !bitmap.isRecycled) bitmap.recycle()
                bitmap = rotated
            }

            val motionScore = motionDetector.score(bitmap)
            handleMotionScore(motionScore)

            if (!freeformCropSupported) {
                val panned =
                    applySoftwareLivePan(bitmap)

                if (panned !== bitmap) {
                    if (!bitmap.isRecycled) {
                        bitmap.recycle()
                    }
                    bitmap = panned
                }
            }

            val maxWidth =
                previewTargetWidth()

            if (bitmap.width > maxWidth) {
                val height =
                    (
                        bitmap.height *
                            (maxWidth.toFloat() / bitmap.width.toFloat())
                    ).toInt().coerceAtLeast(1)

                val scaled =
                    Bitmap.createScaledBitmap(
                        bitmap,
                        maxWidth,
                        height,
                        true
                    )

                if (
                    scaled !== bitmap &&
                    !bitmap.isRecycled
                ) {
                    bitmap.recycle()
                }

                bitmap = scaled
            }

            val out = ByteArrayOutputStream()

            bitmap.compress(
                Bitmap.CompressFormat.JPEG,
                previewJpegQuality(),
                out
            )
            latestJpeg.set(out.toByteArray())
            latestFrameAtMs = System.currentTimeMillis()

            if (!bitmap.isRecycled) bitmap.recycle()
        } catch (_: Exception) {
        } finally {
            image.close()
        }
    }

    private fun handleMotionScore(score: Float) {
        val now = System.currentTimeMillis()
        if (now - lastMotionUiUpdate > 500) {
            lastMotionUiUpdate = now
            runOnUiThread {
                b.motionStatus.text =
                    String.format(Locale.US, "Motion score: %.1f • %s", score, if (networkWasAvailable) "network online" else "OFFLINE")
            }
        }

        if (prefs.getBoolean("seizure_like_alert", false)) {
            if (seizureLikeDetector.update(score, now) &&
                now - lastSeizureLikeAt > 60_000L
            ) {
                lastSeizureLikeAt = now
                eventStore.add(
                    "Possible seizure-like repetitive motion",
                    "EXPERIMENTAL / NON-DIAGNOSTIC visual pattern alert"
                )
                runOnUiThread {
                    refreshEventLog()
                    toast("Experimental alert: possible seizure-like repetitive motion")
                }
            }
        }

        if (!prefs.getBoolean("offline_guard", false)) return

        // High UI sensitivity -> lower trigger threshold.
        val sensitivity = prefs.getInt("motion_sensitivity", 55).coerceIn(0, 100)
        val threshold = 12f - (sensitivity / 100f * 9f)  // ~12 down to ~3

        if (score >= threshold) {
            motionTriggerFrames++
        } else {
            motionTriggerFrames = (motionTriggerFrames - 1).coerceAtLeast(0)
        }

        if (motionTriggerFrames >= 2) {
            motionRecordingUntil = now + 20_000L
            motionTriggerFrames = 0

            if (b.continuousRecording.isChecked && recordingReason == "continuous") {
                if (now - lastMotionMomentAt > 3_000L) {
                    lastMotionMomentAt = now
                    val pre = selectedPreRecordSeconds()
                    eventStore.add(
                        "Motion Moment",
                        "pre-record context=${pre}s • segment=${currentSegmentName ?: "current"} • score=${String.format(Locale.US, "%.1f", score)}"
                    )
                    runOnUiThread {
                        b.continuousStatus.text =
                            "Motion Moment saved • ${pre}s pre-event context available in continuous recording."
                        refreshEventLog()
                    }
                }
            } else if (recording == null && recordingAvailable) {
                eventStore.add(
                    "Motion detected",
                    if (networkWasAvailable) "network available" else "OFFLINE • local recording"
                )
                runOnUiThread {
                    refreshEventLog()
                    startRecording("motion")
                }
            }
        }

        if (recordingReason == "motion" &&
            recording != null &&
            motionRecordingUntil > 0L &&
            now >= motionRecordingUntil
        ) {
            motionRecordingUntil = 0L
            runOnUiThread { stopRecording() }
        }
    }

    private fun updateMotionSensitivityLabel() {
        val v = b.motionSensitivity.progress
        val label = when {
            v < 30 -> "Low"
            v < 70 -> "Normal"
            else -> "High"
        }
        b.motionSensitivityText.text = "Motion sensitivity: $label ($v%)"
    }

    private fun startLanServer() {
        val ip = LocalNetwork.bestIpv4Address()
        if (ip == null) {
            b.serverStatus.text =
                "No local LAN IP. Offline recording still works; monitor connection will return with Wi-Fi."
            b.pairingAddress.text = ""
            b.pairingQr.setImageDrawable(null)
            return
        }

        val token = Pairing.getOrCreateCameraToken(this)
        val info = PairInfo(ip, 8787, token)
        pairInfo = info

        LanCameraHub.setEndpoint(
            object : LanCameraEndpoint {
                override fun statusJson(): String =
                    """{"ok":true,"backgroundService":false,"lanServerRunning":${LanCameraHub.isRunning()},"zoomRatio":$currentZoom,"maxZoom":$maxZoom,"zoomLinear":$cameraZoomLinear,"panX":$cameraPanX,"panY":$cameraPanY,"previewQualityMode":${previewQualityMode()},"freeformPanSupported":$freeformCropSupported,"panMode":"${if (freeformCropSupported) "sensor-freeform" else "live-software-fallback"}","recording":${recording != null},"recordingAvailable":$recordingAvailable,"strictRecordingQuality":${strictRecordingQuality()},"recordingMode":${recordingMode()},"recordingModeName":"${recordingModeName()}","recordingFirstMode":false,"previewAiBridgeMode":$localPreviewUsesBridge,"visualStreamAvailable":true,"frameReady":${latestJpeg.get() != null},"frameAgeMs":${if (latestFrameAtMs == 0L) -1 else System.currentTimeMillis() - latestFrameAtMs},"manualFocusSupported":$manualFocusSupported,"maxFocusDiopters":$maxFocusDiopters,"focusManual":$focusModeManual,"focusLinear":$currentFocusLinear,"eightKSupported":$eightKSupported,"highestVideoResolution":"${formatResolution(highestVideoResolution)}","uhdSupported":$uhdSupported,"quality":"${selectedQualityName()}","requestedQuality":"${selectedQualityName()}","networkOnline":$networkWasAvailable}"""

                override fun eventsJson(): String =
                    eventStore.json()

                override fun onZoom(linear: Float) {
                    runOnUiThread {
                        setCameraView(
                            linear,
                            cameraPanX,
                            cameraPanY
                        )
                    }
                }

                override fun onCameraView(
                    linear: Float,
                    panX: Float,
                    panY: Float
                ) {
                    runOnUiThread {
                        setCameraView(
                            linear,
                            panX,
                            panY
                        )
                    }
                }

                override fun onPreviewQuality(mode: Int) {
                    prefs.edit()
                        .putInt(
                            "preview_quality_mode",
                            mode.coerceIn(0, 4)
                        )
                        .apply()
                }

                override fun onFocusAuto() {
                    runOnUiThread { setAutoFocus() }
                }

                override fun onFocusManual(linear: Float) {
                    runOnUiThread {
                        setManualFocusLinear(linear)
                    }
                }

                override fun onFocusSave() {
                    runOnUiThread { saveFocusDefault() }
                }

                override fun onRecordStart() {
                    runOnUiThread {
                        startRecording("remote")
                    }
                }

                override fun onRecordStop() {
                    runOnUiThread { stopRecording() }
                }
            }
        )

        server =
            LanCameraHub.ensureStarted(this)

        if (server?.isRunning() != true) {
            b.serverStatus.text =
                "LAN camera server failed: ${LanCameraHub.startError()}"
            return
        }

        b.serverStatus.text =
            "LAN camera server: http://${info.host}:${info.port} • persistent hand-off endpoint"

        b.pairingAddress.text =
            "Scan this QR on the monitor phone.\n${info.pairingUri()}"

        try {
            b.pairingQr.setImageBitmap(
                Pairing.qrBitmap(
                    info.pairingUri(),
                    600
                )
            )
        } catch (e: Exception) {
            b.pairingQr.setImageDrawable(null)
            b.status.text =
                "QR generation failed: ${e.message}"
        }
    }

    private fun actualVideoHasAudio(
        uri: android.net.Uri
    ): Boolean {
        if (
            uri ==
            android.net.Uri.EMPTY
        ) {
            return false
        }

        val retriever =
            MediaMetadataRetriever()

        return try {
            retriever.setDataSource(
                this,
                uri
            )

            retriever.extractMetadata(
                MediaMetadataRetriever
                    .METADATA_KEY_HAS_AUDIO
            ) == "yes"

        } catch (_: Exception) {
            false

        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun actualVideoResolution(
        uri: android.net.Uri
    ): String {
        if (uri == android.net.Uri.EMPTY) {
            return "unknown"
        }

        val retriever =
            MediaMetadataRetriever()

        return try {
            retriever.setDataSource(
                this,
                uri
            )

            val width =
                retriever.extractMetadata(
                    MediaMetadataRetriever
                        .METADATA_KEY_VIDEO_WIDTH
                )
                    ?.toIntOrNull()

            val height =
                retriever.extractMetadata(
                    MediaMetadataRetriever
                        .METADATA_KEY_VIDEO_HEIGHT
                )
                    ?.toIntOrNull()

            if (
                width != null &&
                height != null
            ) {
                "${width}×${height}"
            } else {
                "unknown"
            }
        } catch (_: Exception) {
            "unknown"
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun startRecording(reason: String) {
        if (recording != null) return

        val capture = videoCapture
        if (capture == null || !recordingAvailable) {
            toast("MP4 recording is not available with this camera configuration.")
            return
        }

        val name = "AI_Door_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                .format(System.currentTimeMillis()) +
            "_${reason}_${selectedQualityName().replace(" ", "_")}.mp4"

        currentSegmentName = name

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AI Door Monitor")
            }
        }

        val outputOptions = MediaStoreOutputOptions.Builder(
            contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pending = capture.output.prepareRecording(this, outputOptions)

        val includeAudio =
            prefs.getBoolean(
                "recording_audio_enabled",
                true
            ) &&
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.RECORD_AUDIO
                ) ==
                PackageManager.PERMISSION_GRANTED

        if (includeAudio) {
            pending =
                pending.withAudioEnabled()
        }

        recordingReason = reason

        try {
            recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        b.recordButton.text = "Stop and save MP4"
                        b.status.text =
                            "Recording ${selectedQualityName()} • reason: $reason"

                        if (reason == "continuous") {
                            b.continuousStatus.text =
                                "Continuous recording active • 60-second segments • Motion Moments enabled."
                            scheduleContinuousSegmentRollover()
                        }
                    }

                    is VideoRecordEvent.Finalize -> {
                        val finishedReason = recordingReason
                        recording = null
                        recordingReason = null
                        b.recordButton.text = "Start MP4 recording"

                        if (event.hasError()) {
                            val handoffEmptySegment =
                                backgroundHandoffRequested &&
                                event.error ==
                                    VideoRecordEvent.Finalize.ERROR_NO_VALID_DATA

                            if (handoffEmptySegment) {
                                val uri = event.outputResults.outputUri
                                if (uri != android.net.Uri.EMPTY) {
                                    try {
                                        contentResolver.delete(uri, null, null)
                                    } catch (_: Exception) {}
                                }
                                eventStore.add(
                                    "24/7 hand-off",
                                    "Empty foreground segment discarded before service takeover."
                                )
                            } else {
                                b.status.text =
                                    "Recording interrupted: ${event.error}"
                                eventStore.add(
                                    "Recording interrupted",
                                    "reason=$finishedReason • error=${event.error}"
                                )
                            }
                        } else {
                            val savedUri =
                                event.outputResults.outputUri

                            val actualResolution =
                                actualVideoResolution(
                                    savedUri
                                )

                            val hasAudio =
                                actualVideoHasAudio(
                                    savedUri
                                )

                            b.status.text =
                                "Saved MP4 • actual $actualResolution • audio=${if (hasAudio) "yes" else "NO"} → Gallery → Movies → AI Door Monitor"

                            eventStore.add(
                                "MP4 saved",
                                "reason=$finishedReason • requested=${selectedQualityName()} • actual=$actualResolution • audio=${if (hasAudio) "present" else "absent"}"
                            )
                            val maxGb = prefs.getInt("storage_max_gb", 20)
                            val days = prefs.getInt("retention_days", 7)
                            val minFreeGb = prefs.getInt("storage_min_free_gb", 2)
                            VideoRetentionManager.cleanupAsync(
                                this,
                                maxGb,
                                days,
                                minFreeGb
                            ) { result ->
                                if (result.deletedFiles > 0) {
                                    eventStore.add(
                                        "Storage cleanup",
                                        "deleted=${result.deletedFiles} • freed=${formatBytes(result.freedBytes)}"
                                    )
                                    runOnUiThread { refreshEventLog() }
                                }
                            }
                        }
                        refreshEventLog()

                        if (backgroundHandoffRequested) {
                            continuousRollover = false
                            completeBackgroundCameraHandoff()
                        } else {
                            val shouldContinue =
                                b.continuousRecording.isChecked &&
                                (finishedReason == "continuous" ||
                                    continuousRollover)

                            continuousRollover = false

                            if (shouldContinue && recordingAvailable) {
                                b.continuousStatus.text =
                                    "Starting next continuous segment…"
                                startRecording("continuous")
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            recording = null
            recordingReason = null
            toast("Could not start recording: ${e.message}")
        }
    }

    private fun stopRecording() {
        recording?.stop()
    }

    private fun saveSnapshotOnCameraPhone() {
        val jpeg = latestJpeg.get()
        if (jpeg == null) {
            toast("No camera frame available yet.")
            return
        }

        try {
            val name = "AI_Door_Snapshot_" +
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                    .format(System.currentTimeMillis()) +
                ".jpg"

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Door Monitor")
                }
            }

            val uri = contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            ) ?: throw IllegalStateException("MediaStore insert failed")

            contentResolver.openOutputStream(uri)?.use { it.write(jpeg) }
                ?: throw IllegalStateException("Could not open snapshot output")

            eventStore.add("Snapshot saved")
            refreshEventLog()
            toast("Snapshot saved.")
        } catch (e: Exception) {
            toast("Snapshot save failed: ${e.message}")
        }
    }

    private fun registerNetworkWatcher() {
        if (DoorMonitoringService.isRunning) return
        networkWasAvailable = connectivityManager.activeNetwork != null

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (!networkWasAvailable) {
                    networkWasAvailable = true
                    eventStore.add("Network restored", "Monitor can reconnect.")
                    runOnUiThread {
                        refreshEventLog()
                        startLanServer()
                    }
                } else {
                    networkWasAvailable = true
                }
            }

            override fun onLost(network: Network) {
                networkWasAvailable = connectivityManager.activeNetwork != null
                if (!networkWasAvailable) {
                    eventStore.add(
                        "Network lost",
                        "Offline Motion Guard continues locally on phone battery."
                    )
                    runOnUiThread {
                        b.serverStatus.text =
                            "NETWORK OFFLINE • local motion detection/recording continues"
                        refreshEventLog()
                    }
                }
            }
        }

        networkCallback = callback
        try {
            connectivityManager.registerDefaultNetworkCallback(callback)
        } catch (_: Exception) {}
    }

    private fun refreshEventLog() {
        b.eventLog.text = eventStore.readable()
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onNewIntent(
        intent: Intent
    ) {
        super.onNewIntent(
            intent
        )

        setIntent(
            intent
        )

        if (
            ::b.isInitialized &&
            serviceOwnsCamera()
        ) {
            setDashboardPinned(
                false
            )

            eventStore.add(
                "Camera Mode navigation",
                "CameraActivity brought to front by 24/7 notification/dashboard recovery."
            )

            startBackgroundServiceDashboard()
        }
    }

    override fun onPause() {
        if (
            ::eventStore.isInitialized &&
            (
                serviceOwnsCamera() ||
                backgroundHandoffRequested
            )
        ) {
            eventStore.add(
                "CameraActivity lifecycle",
                "onPause • finishing=$isFinishing • changingConfig=$isChangingConfigurations • serviceOwnsCamera=${serviceOwnsCamera()} • pinned=${dashboardPinned()}"
            )
        }

        super.onPause()
    }

    override fun onStop() {
        if (
            ::eventStore.isInitialized &&
            (
                serviceOwnsCamera() ||
                backgroundHandoffRequested
            )
        ) {
            eventStore.add(
                "CameraActivity lifecycle",
                "onStop • finishing=$isFinishing • changingConfig=$isChangingConfigurations • serviceOwnsCamera=${serviceOwnsCamera()} • pinned=${dashboardPinned()}"
            )
        }

        super.onStop()
    }

    override fun onResume() {
        super.onResume()

        if (!::b.isInitialized) {
            return
        }

        if (serviceOwnsCamera()) {
            setBackgroundHandoffPending(false)

            prefs.edit()
                .putBoolean(
                    "background_service_running",
                    true
                )
                .apply()

            startBackgroundServiceDashboard()

        } else if (
            (
                dashboardActivationWaitStartedAt > 0L &&
                    System.currentTimeMillis() -
                        dashboardActivationWaitStartedAt <
                    5_000L
            ) ||
            DoorMonitoringService.isRunning
        ) {
            // The service is created while Camera Mode is visible and may need
            // a short moment before ACTION_START_CAMERA_MODE reaches
            // onStartCommand(). Keep the Activity in dashboard mode instead of
            // falling back to a second local CameraX owner.
            setDashboardPinned(false)
            b.preview.visibility = View.GONE
            b.backgroundLiveView.visibility = View.GONE
            b.backgroundPreviewOverlay.visibility = View.VISIBLE
            b.backgroundPreviewOverlay.text =
                "Camera service is starting…\n\nWaiting for the first camera frame."
            startBackgroundServiceDashboard()
        } else {
            if (
                prefs.getBoolean(
                    "background_service_running",
                    false
                )
            ) {
                prefs.edit()
                    .putBoolean(
                        "background_service_running",
                        false
                    )
                    .apply()
            }

            stopBackgroundServiceDashboard()

            b.backgroundLiveView.visibility =
                View.GONE

            b.backgroundPreviewOverlay.visibility =
                View.VISIBLE
            b.backgroundPreviewOverlay.text =
                "Camera service is not active. Return to the menu and open Camera Mode again."

            b.preview.visibility =
                View.GONE
        }
    }

    override fun onDestroy() {
        if (
            ::eventStore.isInitialized &&
            (
                serviceOwnsCamera() ||
                backgroundHandoffRequested
            )
        ) {
            eventStore.add(
                "CameraActivity lifecycle",
                "onDestroy • finishing=$isFinishing • changingConfig=$isChangingConfigurations • serviceOwnsCamera=${serviceOwnsCamera()} • pinned=${dashboardPinned()}"
            )
        }

        stopBackgroundServiceDashboard()

        try {
            backgroundDashboardExecutor
                .shutdownNow()
        } catch (_: Exception) {}

        val backgroundOwnsCamera =
            serviceOwnsCamera()

        try { recording?.stop() } catch (_: Exception) {}
        recording = null

        try { previewAiBridge?.stop() } catch (_: Exception) {}
        previewAiBridge = null
        localPreviewUsesBridge = false

        // LanCameraHub owns the process-wide socket. Do not tear it down from
        // Activity lifecycle callbacks; doing so would disconnect the monitor
        // during configuration changes or 24/7 ownership transfers.
        server = LanCameraHub.server()

        // ProcessCameraProvider is a singleton. Calling unbindAll() here while
        // the foreground service is active would also unbind the Service's
        // VideoCapture/ImageAnalysis use cases and cause ERROR_SOURCE_INACTIVE.
        if (!backgroundOwnsCamera) {
            try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        }
        cameraProvider = null

        networkCallback?.let {
            try { connectivityManager.unregisterNetworkCallback(it) } catch (_: Exception) {}
        }
        segmentHandler.removeCallbacksAndMessages(null)
        analysisExecutor.shutdownNow()
        super.onDestroy()
    }
}
