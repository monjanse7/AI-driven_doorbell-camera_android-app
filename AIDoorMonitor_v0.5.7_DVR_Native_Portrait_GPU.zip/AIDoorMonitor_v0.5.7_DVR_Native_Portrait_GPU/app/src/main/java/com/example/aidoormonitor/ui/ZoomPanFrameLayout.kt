package com.example.aidoormonitor.ui

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * Remote camera PTZ-style gesture surface.
 *
 * Pinch controls the camera phone's digital sensor-crop zoom.
 * One-finger drag while zoomed changes the crop position (digital pan).
 * The MJPEG child itself is NOT scaled or translated locally.
 */
class ZoomPanFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private var zoomLinear = 0f
    private var panX = 0f
    private var panY = 0f
    private var maxZoomRatio = 1f

    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var dragging = false

    private val slop =
        ViewConfiguration.get(context).scaledTouchSlop.toFloat()

    private var viewListener:
        ((Float, Float, Float) -> Unit)? = null

    private val scaler =
        ScaleGestureDetector(
            context,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleBegin(
                    detector: ScaleGestureDetector
                ): Boolean {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }

                override fun onScale(
                    detector: ScaleGestureDetector
                ): Boolean {
                    val maxRatio =
                        maxZoomRatio.coerceAtLeast(1f)

                    val currentRatio =
                        if (maxRatio <= 1.001f) 1f
                        else 1f + zoomLinear * (maxRatio - 1f)

                    val nextRatio =
                        (currentRatio * detector.scaleFactor)
                            .coerceIn(1f, maxRatio)

                    zoomLinear =
                        if (maxRatio <= 1.001f) 0f
                        else ((nextRatio - 1f) / (maxRatio - 1f))
                            .coerceIn(0f, 1f)

                    if (zoomLinear <= 0.001f) {
                        zoomLinear = 0f
                        panX = 0f
                        panY = 0f
                    }

                    notifyViewChanged()
                    return true
                }
            }
        )

    init {
        isClickable = true
        isFocusable = true
        clipChildren = true
    }

    fun setOnCameraViewChanged(
        listener: ((Float, Float, Float) -> Unit)?
    ) {
        viewListener = listener
    }

    fun setMaxZoomRatio(value: Float) {
        maxZoomRatio = value.coerceAtLeast(1f)
    }

    fun setCameraState(
        linear: Float,
        newPanX: Float,
        newPanY: Float,
        notify: Boolean = false
    ) {
        zoomLinear = linear.coerceIn(0f, 1f)
        panX =
            if (zoomLinear <= 0.001f) 0f
            else newPanX.coerceIn(-1f, 1f)
        panY =
            if (zoomLinear <= 0.001f) 0f
            else newPanY.coerceIn(-1f, 1f)

        if (notify) notifyViewChanged()
    }

    fun resetCameraView(
        notify: Boolean = true
    ) {
        zoomLinear = 0f
        panX = 0f
        panY = 0f
        dragging = false
        if (notify) notifyViewChanged()
    }

    private fun notifyViewChanged() {
        viewListener?.invoke(zoomLinear, panX, panY)
    }

    override fun onInterceptTouchEvent(
        ev: MotionEvent
    ): Boolean {
        // The live-view container owns all gestures that start on the video.
        // Previously interception could begin only after MOVE; on some devices
        // the child/ScrollView had already taken the gesture, so one-finger
        // pan never reached this class.
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            parent?.requestDisallowInterceptTouchEvent(true)
        }

        return true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaler.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                lastX = event.x
                lastY = event.y
                dragging = false
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (
                    event.pointerCount >= 2 ||
                    scaler.isInProgress
                ) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }

                val dx = event.x - lastX
                val dy = event.y - lastY

                if (
                    !dragging &&
                    zoomLinear > 0.001f &&
                    (
                        abs(event.x - downX) > slop ||
                        abs(event.y - downY) > slop
                    )
                ) {
                    dragging = true
                }

                if (dragging && zoomLinear > 0.001f) {
                    panX =
                        (
                            panX +
                                dx /
                                    width.coerceAtLeast(1).toFloat() *
                                    2f
                        ).coerceIn(-1f, 1f)

                    panY =
                        (
                            panY +
                                dy /
                                    height.coerceAtLeast(1).toFloat() *
                                    2f
                        ).coerceIn(-1f, 1f)

                    notifyViewChanged()
                    parent?.requestDisallowInterceptTouchEvent(true)
                }

                lastX = event.x
                lastY = event.y
                return true
            }

            MotionEvent.ACTION_POINTER_UP -> {
                val removed = event.actionIndex
                val remaining =
                    if (removed == 0 && event.pointerCount > 1) 1 else 0

                if (remaining < event.pointerCount) {
                    lastX = event.getX(remaining)
                    lastY = event.getY(remaining)
                    downX = lastX
                    downY = lastY
                }

                dragging = false
                return true
            }

            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                if (event.actionMasked == MotionEvent.ACTION_UP) {
                    performClick()
                }
                return true
            }
        }

        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
