package com.example.aidoormonitor.net

import android.content.Context
import java.io.InputStream
import java.util.concurrent.atomic.AtomicReference

/**
 * Process-wide LAN endpoint used by both CameraActivity and DoorMonitoringService.
 *
 * The important property is that the ServerSocket and /stream client sockets do
 * not change during the Activity -> 24/7 foreground-service camera hand-off.
 * Only the active endpoint callbacks and the producer writing latestJpeg change.
 */
data class RemoteRecordingSource(
    val displayName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val openInputStream: (offset: Long) -> InputStream
)

interface LanCameraEndpoint {
    fun statusJson(): String
    fun eventsJson(): String

    fun recordingsJson(): String =
        """{"recordings":[]}"""

    fun openRecording(
        id: String
    ): RemoteRecordingSource? =
        null

    fun recordingThumbnailJpeg(
        id: String,
        width: Int,
        height: Int
    ): ByteArray? =
        null

    fun deleteRecording(
        id: String
    ): Boolean =
        false

    fun remoteDvrSettingsJson():
        String =
        "{}"

    fun applyRemoteDvrSettings(
        quality: Int?,
        videoBitrateMbps: Int?,
        audioBitrateKbps: Int?,
        audioSampleRateHz: Int?,
        audioSyncMs: Int?
    ): String =
        """{"ok":false}"""

    fun onZoom(linear: Float)
    fun onCameraView(linear: Float, panX: Float, panY: Float)
    fun onPreviewQuality(mode: Int)
    fun onFocusAuto()
    fun onFocusManual(linear: Float)
    fun onFocusSave()
    fun onRecordStart()
    fun onRecordStop()
}

object LanCameraHub {
    val latestJpeg = AtomicReference<ByteArray?>(null)

    @Volatile
    private var endpoint: LanCameraEndpoint? = null

    @Volatile
    private var server: LanCameraServer? = null

    @Volatile
    private var lastError: String = ""

    fun setEndpoint(value: LanCameraEndpoint?) {
        endpoint = value
    }

    fun activeEndpoint(): LanCameraEndpoint? = endpoint

    @Synchronized
    fun ensureStarted(context: Context, port: Int = 8787): LanCameraServer? {
        val existing = server
        if (existing?.isRunning() == true) {
            return existing
        }

        val token = Pairing.getOrCreateCameraToken(context.applicationContext)

        val candidate = LanCameraServer(
            port = port,
            token = token,
            latestJpeg = latestJpeg,
            statusJson = {
                endpoint?.statusJson()
                    ?: """{"ok":true,"handoff":true,"visualStreamAvailable":true,"frameReady":${latestJpeg.get() != null}}"""
            },
            eventsJson = {
                endpoint?.eventsJson() ?: "[]"
            },
            recordingsJson = {
                endpoint?.recordingsJson()
                    ?: """{"recordings":[]}"""
            },
            openRecording = { id ->
                endpoint?.openRecording(id)
            },
            recordingThumbnailJpeg = {
                    id,
                    width,
                    height ->
                endpoint?.recordingThumbnailJpeg(
                    id,
                    width,
                    height
                )
            },
            deleteRecording = { id ->
                endpoint?.deleteRecording(
                    id
                ) ?: false
            },
            remoteDvrSettingsJson = {
                endpoint
                    ?.remoteDvrSettingsJson()
                    ?: "{}"
            },
            applyRemoteDvrSettings = {
                    quality,
                    videoMbps,
                    audioKbps,
                    audioHz,
                    audioSyncMs ->
                endpoint
                    ?.applyRemoteDvrSettings(
                        quality,
                        videoMbps,
                        audioKbps,
                        audioHz,
                        audioSyncMs
                    )
                    ?: """{"ok":false}"""
            },
            onZoom = { linear ->
                endpoint?.onZoom(linear)
            },
            onCameraView = { linear, panX, panY ->
                endpoint?.onCameraView(linear, panX, panY)
            },
            onPreviewQuality = { mode ->
                endpoint?.onPreviewQuality(mode)
            },
            onFocusAuto = {
                endpoint?.onFocusAuto()
            },
            onFocusManual = { linear ->
                endpoint?.onFocusManual(linear)
            },
            onFocusSave = {
                endpoint?.onFocusSave()
            },
            onRecordStart = {
                endpoint?.onRecordStart()
            },
            onRecordStop = {
                endpoint?.onRecordStop()
            }
        )

        return if (candidate.start()) {
            server = candidate
            lastError = ""
            candidate
        } else {
            lastError = candidate.startError() ?: "Port $port bind failed"
            try {
                candidate.stop()
            } catch (_: Exception) {}
            null
        }
    }

    fun server(): LanCameraServer? = server

    fun isRunning(): Boolean = server?.isRunning() == true

    fun startError(): String = lastError

    @Synchronized
    fun stop(clearFrame: Boolean = true) {
        try {
            server?.stop()
        } catch (_: Exception) {}
        server = null
        endpoint = null
        if (clearFrame) {
            latestJpeg.set(null)
        }
    }
}
