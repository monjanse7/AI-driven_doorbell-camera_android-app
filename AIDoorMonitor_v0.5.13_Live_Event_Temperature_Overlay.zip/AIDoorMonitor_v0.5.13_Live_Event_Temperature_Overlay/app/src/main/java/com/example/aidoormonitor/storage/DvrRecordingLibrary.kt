package com.example.aidoormonitor.storage

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.util.LruCache
import java.io.ByteArrayOutputStream
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import com.example.aidoormonitor.net.RemoteRecordingSource
import org.json.JSONArray
import org.json.JSONObject

/**
 * LAN library for recordings created by AI Door Monitor.
 *
 * Only media inside Movies/AI Door Monitor is exposed. The LAN pairing token
 * is still required by LanCameraServer before this class can be reached.
 */
class DvrRecordingLibrary(
    private val context: Context
) {
    private val thumbnailCache =
        object : LruCache<String, ByteArray>(
            12 * 1024
        ) {
            override fun sizeOf(
                key: String,
                value: ByteArray
            ): Int =
                (value.size / 1024)
                    .coerceAtLeast(1)
        }

    private val resolver
        get() = context.contentResolver

    private val collection: Uri
        get() = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    private fun eventFolderFromPath(
        relativePath: String
    ): String? {
        val normalized =
            relativePath
                .replace(
                    '\\',
                    '/'
                )
                .trim('/')

        val marker =
            "/Events/"

        val padded =
            "/$normalized/"

        val index =
            padded.indexOf(
                marker,
                ignoreCase = true
            )

        if (index < 0) {
            return null
        }

        val after =
            padded
                .substring(
                    index +
                        marker.length
                )
                .trim('/')

        return after
            .substringBefore('/')
            .trim()
            .takeIf {
                it.isNotBlank()
            }
    }

    private fun legacyLabelFromFilename(
        name: String
    ): String =
        name
            .removePrefix(
                "AI_Door_"
            )
            .removeSuffix(
                ".mp4"
            )
            .replace(
                Regex(
                    "_\\d{8}_\\d{6}$"
                ),
                ""
            )
            .replace(
                '_',
                ' '
            )
            .trim()
            .ifBlank {
                "Other"
            }

    private fun eventFolderFromFilename(
        name: String
    ): String {
        val label =
            legacyLabelFromFilename(
                name
            )

        val value =
            label.lowercase()

        return when {
            value.contains("dog") ||
                value.contains("bark") ||
                value.contains("growl") ->
                "Dog"

            value.contains("cat") ->
                "Cat"

            value.contains("moving car") ||
                value == "car" ||
                value.startsWith("car ") ->
                "Car"

            value.contains("person") ->
                "Person"

            value.contains("bicycle") ||
                value.contains("bike") ->
                "Bicycle"

            value.contains("motorcycle") ->
                "Motorcycle"

            value.contains("truck") ->
                "Truck"

            value.contains("bird") ->
                "Bird"

            value.contains("stroller") ||
                value.contains("barnevogn") ||
                value.contains("pram") ||
                value.contains("pushchair") ->
                "Stroller"

            value.contains("package") ||
                value.contains("parcel") ->
                "Package"

            value.contains("shouting") ||
                value.contains("impact") ||
                value.contains("knock") ||
                value.contains("crash") ->
                "Sound"

            value.contains("motion") ->
                "Motion"

            value.contains("manual") ->
                "Manual"

            else ->
                label.take(48)
        }
    }

    fun listJson(maxItems: Int = 100): String {
        val result = JSONArray()

        val projection =
            buildList {
                add(MediaStore.Video.Media._ID)
                add(MediaStore.Video.Media.DISPLAY_NAME)
                add(MediaStore.Video.Media.SIZE)
                add(MediaStore.Video.Media.DURATION)
                add(MediaStore.Video.Media.DATE_ADDED)
                add(MediaStore.Video.Media.MIME_TYPE)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    add(MediaStore.Video.Media.RELATIVE_PATH)
                }
            }.toTypedArray()

        val selection: String
        val args: Array<String>

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            selection =
                "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?"
            args =
                arrayOf(
                    "Movies/AI Door Monitor/%"
                )
        } else {
            selection =
                "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
            args =
                arrayOf(
                    "AI_Door_%"
                )
        }

        resolver.query(
            collection,
            projection,
            selection,
            args,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Video.Media._ID
                )
            val nameCol =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Video.Media.DISPLAY_NAME
                )
            val sizeCol =
                cursor.getColumnIndex(
                    MediaStore.Video.Media.SIZE
                )
            val durationCol =
                cursor.getColumnIndex(
                    MediaStore.Video.Media.DURATION
                )
            val dateCol =
                cursor.getColumnIndex(
                    MediaStore.Video.Media.DATE_ADDED
                )
            val mimeCol =
                cursor.getColumnIndex(
                    MediaStore.Video.Media.MIME_TYPE
                )
            val pathCol =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(
                        MediaStore.Video.Media.RELATIVE_PATH
                    )
                } else {
                    -1
                }

            var count = 0
            while (
                cursor.moveToNext() &&
                count < maxItems
            ) {
                val id =
                    cursor.getLong(idCol)

                val name =
                    cursor.getString(nameCol)
                        ?: "AI_Door_$id.mp4"

                val relativePath =
                    if (pathCol >= 0) {
                        cursor.getString(pathCol)
                            .orEmpty()
                    } else {
                        ""
                    }

                if (
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                    !relativePath.startsWith(
                        "Movies/AI Door Monitor/"
                    )
                ) {
                    continue
                }

                val item =
                    JSONObject().apply {
                        put("id", id.toString())
                        put("name", name)
                        put(
                            "sizeBytes",
                            if (sizeCol >= 0 && !cursor.isNull(sizeCol)) {
                                cursor.getLong(sizeCol)
                            } else {
                                0L
                            }
                        )
                        put(
                            "durationMs",
                            if (
                                durationCol >= 0 &&
                                !cursor.isNull(durationCol)
                            ) {
                                cursor.getLong(durationCol)
                            } else {
                                0L
                            }
                        )
                        put(
                            "dateAddedMs",
                            if (
                                dateCol >= 0 &&
                                !cursor.isNull(dateCol)
                            ) {
                                cursor.getLong(dateCol) * 1_000L
                            } else {
                                0L
                            }
                        )
                        put(
                            "mimeType",
                            if (
                                mimeCol >= 0 &&
                                !cursor.isNull(mimeCol)
                            ) {
                                cursor.getString(mimeCol)
                                    ?: "video/mp4"
                            } else {
                                "video/mp4"
                            }
                        )
                        put(
                            "relativePath",
                            relativePath
                        )
                        put(
                            "eventFolder",
                            eventFolderFromPath(
                                relativePath
                            )
                                ?: eventFolderFromFilename(
                                    name
                                )
                        )
                    }

                result.put(item)
                count++
            }
        }

        return JSONObject()
            .put("recordings", result)
            .toString()
    }

    fun thumbnailJpeg(
        idText: String,
        requestedWidth: Int = 320,
        requestedHeight: Int = 180
    ): ByteArray? {
        // Re-use open() as the permission/path check. The source stream itself
        // is not opened here.
        if (open(idText) == null) {
            return null
        }

        val id =
            idText.toLongOrNull()
                ?: return null

        val width =
            requestedWidth
                .coerceIn(120, 640)

        val height =
            requestedHeight
                .coerceIn(68, 360)

        val key =
            "$id:${width}x$height"

        thumbnailCache.get(key)
            ?.let {
                return it
            }

        val uri =
            ContentUris.withAppendedId(
                collection,
                id
            )

        val retriever =
            MediaMetadataRetriever()

        var frame: Bitmap? = null
        var rotatedFrame: Bitmap? = null
        var scaled: Bitmap? = null

        return try {
            retriever.setDataSource(
                context,
                uri
            )

            // Pick a frame shortly after the start so the thumbnail normally
            // shows the actual event rather than an encoder startup frame.
            frame =
                retriever.getFrameAtTime(
                    750_000L,
                    MediaMetadataRetriever
                        .OPTION_CLOSEST_SYNC
                )
                    ?: retriever.getFrameAtTime(
                        -1L,
                        MediaMetadataRetriever
                            .OPTION_CLOSEST_SYNC
                    )

            val rawSource =
                frame
                    ?: return null

            val videoRotation =
                retriever.extractMetadata(
                    MediaMetadataRetriever
                        .METADATA_KEY_VIDEO_ROTATION
                )
                    ?.toIntOrNull()
                    ?: 0

            rotatedFrame =
                if (
                    videoRotation == 90 ||
                    videoRotation == 180 ||
                    videoRotation == 270
                ) {
                    val matrix =
                        Matrix().apply {
                            postRotate(
                                videoRotation.toFloat()
                            )
                        }

                    try {
                        Bitmap.createBitmap(
                            rawSource,
                            0,
                            0,
                            rawSource.width,
                            rawSource.height,
                            matrix,
                            true
                        )
                    } catch (_: Throwable) {
                        rawSource
                    }
                } else {
                    rawSource
                }

            val source =
                rotatedFrame
                    ?: rawSource

            val sourceRatio =
                source.width.toFloat() /
                    source.height
                        .coerceAtLeast(1)
                        .toFloat()

            val targetRatio =
                width.toFloat() /
                    height.toFloat()

            val outWidth: Int
            val outHeight: Int

            if (sourceRatio >= targetRatio) {
                outWidth = width
                outHeight =
                    (width / sourceRatio)
                        .toInt()
                        .coerceAtLeast(1)
            } else {
                outHeight = height
                outWidth =
                    (height * sourceRatio)
                        .toInt()
                        .coerceAtLeast(1)
            }

            scaled =
                if (
                    source.width == outWidth &&
                    source.height == outHeight
                ) {
                    source
                } else {
                    Bitmap.createScaledBitmap(
                        source,
                        outWidth,
                        outHeight,
                        true
                    )
                }

            val output =
                ByteArrayOutputStream(
                    32 * 1024
                )

            val ok =
                scaled?.compress(
                    Bitmap.CompressFormat.JPEG,
                    72,
                    output
                )
                    ?: false

            if (!ok) {
                null
            } else {
                output.toByteArray()
                    .also {
                        thumbnailCache.put(
                            key,
                            it
                        )
                    }
            }

        } catch (_: Throwable) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Throwable) {
            }

            try {
                if (
                    scaled != null &&
                    scaled !== rotatedFrame &&
                    scaled !== frame &&
                    scaled?.isRecycled == false
                ) {
                    scaled?.recycle()
                }
            } catch (_: Throwable) {
            }

            try {
                if (
                    rotatedFrame != null &&
                    rotatedFrame !== frame &&
                    rotatedFrame?.isRecycled == false
                ) {
                    rotatedFrame?.recycle()
                }
            } catch (_: Throwable) {
            }

            try {
                if (
                    frame?.isRecycled == false
                ) {
                    frame?.recycle()
                }
            } catch (_: Throwable) {
            }
        }
    }

    fun delete(
        idText: String
    ): Boolean {
        val id =
            idText.toLongOrNull()
                ?: return false

        if (
            open(
                idText
            ) == null
        ) {
            return false
        }

        val uri =
            ContentUris.withAppendedId(
                collection,
                id
            )

        return try {
            val deleted =
                resolver.delete(
                    uri,
                    null,
                    null
                )

            if (deleted > 0) {
                thumbnailCache.evictAll()
                true
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        }
    }

    fun open(
        idText: String
    ): RemoteRecordingSource? {
        val id =
            idText.toLongOrNull()
                ?: return null

        val uri =
            ContentUris.withAppendedId(
                collection,
                id
            )

        val projection =
            buildList {
                add(MediaStore.Video.Media._ID)
                add(MediaStore.Video.Media.DISPLAY_NAME)
                add(MediaStore.Video.Media.SIZE)
                add(MediaStore.Video.Media.MIME_TYPE)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    add(MediaStore.Video.Media.RELATIVE_PATH)
                }
            }.toTypedArray()

        var displayName: String? = null
        var sizeBytes = 0L
        var mimeType = "video/mp4"
        var permitted = false

        resolver.query(
            uri,
            projection,
            null,
            null,
            null
        )?.use { cursor ->
            if (!cursor.moveToFirst()) {
                return null
            }

            val nameCol =
                cursor.getColumnIndex(
                    MediaStore.Video.Media.DISPLAY_NAME
                )
            val sizeCol =
                cursor.getColumnIndex(
                    MediaStore.Video.Media.SIZE
                )
            val mimeCol =
                cursor.getColumnIndex(
                    MediaStore.Video.Media.MIME_TYPE
                )

            displayName =
                if (
                    nameCol >= 0 &&
                    !cursor.isNull(nameCol)
                ) {
                    cursor.getString(nameCol)
                } else {
                    "AI_Door_$id.mp4"
                }

            sizeBytes =
                if (
                    sizeCol >= 0 &&
                    !cursor.isNull(sizeCol)
                ) {
                    cursor.getLong(sizeCol)
                } else {
                    0L
                }

            mimeType =
                if (
                    mimeCol >= 0 &&
                    !cursor.isNull(mimeCol)
                ) {
                    cursor.getString(mimeCol)
                        ?: "video/mp4"
                } else {
                    "video/mp4"
                }

            permitted =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val pathCol =
                        cursor.getColumnIndex(
                            MediaStore.Video.Media.RELATIVE_PATH
                        )

                    val path =
                        if (
                            pathCol >= 0 &&
                            !cursor.isNull(pathCol)
                        ) {
                            cursor.getString(pathCol)
                                .orEmpty()
                        } else {
                            ""
                        }

                    path.startsWith(
                        "Movies/AI Door Monitor/"
                    )
                } else {
                    (displayName ?: "").startsWith(
                        "AI_Door_"
                    )
                }
        }

        if (!permitted) {
            return null
        }

        if (sizeBytes <= 0L) {
            sizeBytes =
                try {
                    resolver
                        .openAssetFileDescriptor(
                            uri,
                            "r"
                        )
                        ?.use {
                            it.length
                        }
                        ?: 0L
                } catch (_: Throwable) {
                    0L
                }
        }

        if (sizeBytes <= 0L) {
            return null
        }

        val safeName =
            displayName
                ?.takeIf { it.isNotBlank() }
                ?: "AI_Door_$id.mp4"

        return RemoteRecordingSource(
            displayName = safeName,
            sizeBytes = sizeBytes,
            mimeType = mimeType,
            openInputStream = { offset ->
                val pfd =
                    resolver.openFileDescriptor(
                        uri,
                        "r"
                    )
                        ?: throw IllegalStateException(
                            "Could not open camera recording."
                        )

                val input =
                    ParcelFileDescriptor
                        .AutoCloseInputStream(
                            pfd
                        )

                if (offset > 0L) {
                    input.channel.position(
                        offset
                    )
                }

                input
            }
        )
    }
}
