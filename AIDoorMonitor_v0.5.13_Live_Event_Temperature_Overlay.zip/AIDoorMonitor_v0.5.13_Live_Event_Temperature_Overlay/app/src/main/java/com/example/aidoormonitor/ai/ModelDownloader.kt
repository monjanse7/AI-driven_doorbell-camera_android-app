package com.example.aidoormonitor.ai

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object ModelDownloader {
    const val YAMNET_URL =
        "https://storage.googleapis.com/mediapipe-models/audio_classifier/yamnet/float32/latest/yamnet.tflite"

    const val POSE_URL =
        "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task"

    const val OBJECT_URL =
        "https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/int8/latest/efficientdet_lite0.tflite"

    private val executor = Executors.newSingleThreadExecutor()

    fun modelDir(context: Context): File =
        File(context.filesDir, "ai_models").apply { mkdirs() }

    fun yamnetFile(context: Context): File =
        File(modelDir(context), "yamnet.tflite")

    fun poseFile(context: Context): File =
        File(modelDir(context), "pose_landmarker_lite.task")

    fun objectFile(context: Context): File =
        File(modelDir(context), "efficientdet_lite0.tflite")

    fun customObjectFile(context: Context): File =
        File(
            modelDir(context),
            "custom_object_detector.tflite"
        )

    fun customObjectReady(context: Context): Boolean =
        customObjectFile(context).length() >
            100_000L

    fun yamnetReady(context: Context): Boolean =
        yamnetFile(context).length() > 1_000_000L

    fun poseReady(context: Context): Boolean =
        poseFile(context).length() > 1_000_000L

    fun objectReady(context: Context): Boolean =
        objectFile(context).length() > 1_000_000L

    fun modelsReady(context: Context): Boolean =
        yamnetReady(context) &&
            poseReady(context) &&
            objectReady(context)

    fun prepareAll(
        context: Context,
        onStatus: (String) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        executor.execute {
            try {
                val y = yamnetFile(context)
                if (y.length() <= 1_000_000L) {
                    onStatus("Downloading YamNet audio AI model…")
                    download(YAMNET_URL, y)
                }

                val p = poseFile(context)
                if (p.length() <= 1_000_000L) {
                    onStatus("Downloading MediaPipe Pose Landmarker model…")
                    download(POSE_URL, p)
                }

                val o = objectFile(context)
                if (o.length() <= 1_000_000L) {
                    onStatus("Downloading EfficientDet-Lite0 dog / cat / bird detector…")
                    download(OBJECT_URL, o)
                }

                onDone(
                    modelsReady(context),
                    if (modelsReady(context))
                        "AI models ready for offline use."
                    else
                        "AI model download did not complete."
                )
            } catch (e: Exception) {
                onDone(false, "AI model download failed: ${e.message}")
            }
        }
    }

    private fun download(url: String, target: File) {
        val temp = File(target.parentFile, "${target.name}.part")
        if (temp.exists()) temp.delete()

        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = true
            conn.connect()

            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${conn.responseCode}")
            }

            conn.inputStream.use { input ->
                temp.outputStream().use { output ->
                    input.copyTo(output, 256 * 1024)
                }
            }

            if (temp.length() < 1_000_000L) {
                throw IllegalStateException("Downloaded model is unexpectedly small")
            }

            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
        } finally {
            conn.disconnect()
        }
    }
}
