package com.example.aidoormonitor.dvr

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.example.aidoormonitor.ai.AudioAiEvent
import com.google.mediapipe.tasks.audio.audioclassifier.AudioClassifier
import com.google.mediapipe.tasks.components.containers.AudioData
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

data class DvrCapturedAudio(
    val rawPcmFile: File,
    val sampleRate: Int,
    val channelCount: Int,
    val sampleCount: Long,
    val startedAtMs: Long,
    val endedAtMs: Long
)

/**
 * Owns the microphone for the Camera2 DVR.
 *
 * One AudioRecord captures 48 kHz mono PCM. The same PCM stream is:
 * - retained in a rolling ring for event pre-record,
 * - appended to the active event raw PCM file,
 * - downsampled to 16 kHz and fed into MediaPipe/YamNet.
 *
 * This avoids opening a second AudioRecord while the DVR is running.
 */
class DvrSharedAudioEngine(
    private val context: Context,
    private val modelFile: File?,
    private val enableSoundAi: Boolean,
    private val requestedSampleRate: Int = 48_000,
    private val maxPrebufferSeconds: Int = 40,
    private val onEvent: (AudioAiEvent) -> Unit,
    private val onLivePcm:
        (
            ShortArray,
            Int
        ) -> Unit =
        {
                _,
                _ ->
        },
    private val onStatus: (String) -> Unit = {}
) {
    companion object {
        const val CAPTURE_SAMPLE_RATE = 48_000
        const val AI_SAMPLE_RATE = 16_000
        const val CHANNEL_COUNT = 1
        const val PCM_BYTES_PER_SAMPLE = 2
        const val AI_WINDOW_SAMPLES = 15_600
    }

    private data class PcmChunk(
        val data: ShortArray,
        val startMs: Long,
        val endMs: Long
    )

    private val pcmLock = Any()
    private val aiBufferLock = Any()

    private val ring =
        ArrayDeque<PcmChunk>()

    private var eventOutput:
        BufferedOutputStream? =
        null

    private var eventRawFile:
        File? =
        null

    private var eventSamples = 0L
    private var eventStartedAtMs = 0L

    private var recorder:
        AudioRecord? =
        null

    @Volatile
    private var captureSampleRate =
        CAPTURE_SAMPLE_RATE

    private var classifier:
        AudioClassifier? =
        null

    private var audioData:
        AudioData? =
        null

    private val captureExecutor =
        Executors.newSingleThreadExecutor()

    private val aiExecutor =
        Executors.newSingleThreadExecutor()

    private val aiBusy =
        AtomicBoolean(false)

    private val running =
        AtomicBoolean(false)

    private val aiRing =
        ShortArray(
            AI_WINDOW_SAMPLES
        )

    private var aiWriteIndex = 0
    private var aiFilled = 0
    private var lastAiSubmitAt = 0L

    private val lastEventAt =
        mutableMapOf<String, Long>()

    private fun targetCaptureSampleRate(): Int =
        if (
            requestedSampleRate ==
            44_100
        ) {
            44_100
        } else {
            48_000
        }

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (running.get()) {
            return true
        }

        if (
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            onStatus(
                "Microphone permission missing."
            )
            return false
        }

        val channelMask =
            AudioFormat.CHANNEL_IN_MONO

        val targetRate =
            targetCaptureSampleRate()

        val format =
            AudioFormat.Builder()
                .setSampleRate(
                    targetRate
                )
                .setEncoding(
                    AudioFormat.ENCODING_PCM_16BIT
                )
                .setChannelMask(
                    channelMask
                )
                .build()

        val minBuffer =
            AudioRecord.getMinBufferSize(
                targetRate,
                channelMask,
                AudioFormat.ENCODING_PCM_16BIT
            )

        if (minBuffer <= 0) {
            onStatus(
                "AudioRecord reports invalid buffer size: $minBuffer"
            )
            return false
        }

        return try {
            recorder =
                AudioRecord.Builder()
                    .setAudioSource(
                        MediaRecorder.AudioSource.MIC
                    )
                    .setAudioFormat(
                        format
                    )
                    .setBufferSizeInBytes(
                        max(
                            minBuffer * 4,
                            targetRate *
                                PCM_BYTES_PER_SAMPLE /
                                2
                        )
                    )
                    .build()

            if (
                recorder?.state !=
                AudioRecord.STATE_INITIALIZED
            ) {
                throw IllegalStateException(
                    "AudioRecord did not initialize."
                )
            }

            captureSampleRate =
                recorder
                    ?.sampleRate
                    ?.takeIf {
                        it > 0
                    }
                    ?: CAPTURE_SAMPLE_RATE

            if (
                enableSoundAi &&
                modelFile != null &&
                modelFile.exists()
            ) {
                classifier =
                    AudioClassifier.createFromFile(
                        context,
                        modelFile
                    )

                val aiFormat =
                    AudioData.AudioDataFormat
                        .builder()
                        .setNumOfChannels(
                            1
                        )
                        .setSampleRate(
                            AI_SAMPLE_RATE.toFloat()
                        )
                        .build()

                audioData =
                    AudioData.create(
                        aiFormat,
                        AI_WINDOW_SAMPLES
                    )
            }

            recorder!!.startRecording()

            running.set(true)

            captureExecutor.execute {
                captureLoop()
            }

            onStatus(
                if (classifier != null) {
                    "Microphone audio + YamNet active • ${captureSampleRate} Hz"
                } else {
                    "Microphone audio active • ${captureSampleRate} Hz"
                }
            )

            true

        } catch (t: Throwable) {
            onStatus(
                "Shared microphone failed: " +
                    (
                        t.message
                            ?: t.javaClass.simpleName
                        )
            )
            stop()
            false
        }
    }

    private fun captureLoop() {
        try {
            Process.setThreadPriority(
                Process.THREAD_PRIORITY_AUDIO
            )
        } catch (_: Throwable) {
        }

        val readBuffer =
            ShortArray(
                4_800
            )

        while (running.get()) {
            val rec =
                recorder ?: break

            val count =
                try {
                    rec.read(
                        readBuffer,
                        0,
                        readBuffer.size,
                        AudioRecord.READ_BLOCKING
                    )
                } catch (_: Throwable) {
                    -1
                }

            if (count <= 0) {
                if (running.get()) {
                    SystemClock.sleep(
                        10L
                    )
                }
                continue
            }

            val now =
                System.currentTimeMillis()

            val durationMs =
                count.toLong() *
                    1_000L /
                    captureSampleRate
                        .coerceAtLeast(
                            1
                        )

            val startMs =
                now - durationMs

            val copy =
                readBuffer.copyOf(
                    count
                )

            synchronized(pcmLock) {
                ring.addLast(
                    PcmChunk(
                        data = copy,
                        startMs = startMs,
                        endMs = now
                    )
                )

                trimRingLocked(
                    now
                )

                eventOutput
                    ?.let { output ->
                        writeShortsLittleEndian(
                            output,
                            copy,
                            0,
                            copy.size
                        )

                        eventSamples +=
                            copy.size.toLong()
                    }
            }

            try {
                onLivePcm(
                    copy,
                    captureSampleRate
                )
            } catch (_: Throwable) {
                // Live monitoring must never interrupt DVR audio capture.
            }

            if (
                classifier != null &&
                audioData != null
            ) {
                val downsampled =
                    resampleToAiRate(
                        copy,
                        captureSampleRate
                    )

                appendAiSamples(
                    downsampled
                )

                maybeSubmitAi()
            }
        }
    }

    private fun trimRingLocked(
        nowMs: Long
    ) {
        val keepMs =
            maxPrebufferSeconds
                .coerceAtLeast(5) *
                1_000L

        val cutoff =
            nowMs - keepMs

        while (
            ring.isNotEmpty() &&
            ring.first().endMs < cutoff
        ) {
            ring.removeFirst()
        }
    }

    fun beginEvent(
        prebufferSeconds: Int
    ): Boolean =
        beginEventAt(
            System.currentTimeMillis() -
                prebufferSeconds
                    .coerceIn(
                        0,
                        maxPrebufferSeconds
                    )
                    .toLong() *
                1_000L
        )

    fun beginEventAt(
        requestedStartAtMs: Long
    ): Boolean {
        if (!running.get()) {
            return false
        }

        synchronized(pcmLock) {
            if (eventOutput != null) {
                return true
            }

            val dir =
                File(
                    context.cacheDir,
                    "dvr_event_audio"
                ).apply {
                    mkdirs()
                }

            val file =
                File(
                    dir,
                    "event_audio_" +
                        System.currentTimeMillis() +
                        "_" +
                        System.nanoTime() +
                        ".pcm"
                )

            val output =
                BufferedOutputStream(
                    FileOutputStream(file),
                    256 * 1024
                )

            val now =
                System.currentTimeMillis()

            val earliestAllowed =
                now -
                    maxPrebufferSeconds
                        .coerceAtLeast(5)
                        .toLong() *
                    1_000L

            val cutoff =
                requestedStartAtMs
                    .coerceIn(
                        earliestAllowed,
                        now
                    )

            var copiedSamples =
                0L

            var actualStart =
                now

            ring.forEach { chunk ->
                if (
                    chunk.endMs <
                    cutoff
                ) {
                    return@forEach
                }

                val durationMs =
                    (
                        chunk.endMs -
                            chunk.startMs
                        )
                        .coerceAtLeast(1L)

                val offsetSamples =
                    if (
                        cutoff <=
                        chunk.startMs
                    ) {
                        0
                    } else {
                        (
                            (
                                cutoff -
                                    chunk.startMs
                                ) *
                                captureSampleRate /
                                1_000L
                            )
                            .toInt()
                            .coerceIn(
                                0,
                                chunk.data.size
                            )
                    }

                val count =
                    chunk.data.size -
                        offsetSamples

                if (count > 0) {
                    if (copiedSamples == 0L) {
                        actualStart =
                            chunk.startMs +
                                offsetSamples
                                    .toLong() *
                                1_000L /
                                captureSampleRate
                                    .coerceAtLeast(
                                        1
                                    )
                    }

                    writeShortsLittleEndian(
                        output,
                        chunk.data,
                        offsetSamples,
                        count
                    )

                    copiedSamples +=
                        count.toLong()
                }
            }

            eventRawFile =
                file

            eventOutput =
                output

            eventSamples =
                copiedSamples

            eventStartedAtMs =
                actualStart

            return true
        }
    }

    fun finishEvent():
        DvrCapturedAudio? {
        synchronized(pcmLock) {
            val output =
                eventOutput
                    ?: return null

            val file =
                eventRawFile

            try {
                output.flush()
            } catch (_: Throwable) {
            }

            try {
                output.close()
            } catch (_: Throwable) {
            }

            eventOutput =
                null

            eventRawFile =
                null

            val samples =
                eventSamples

            eventSamples =
                0L

            val startedAt =
                eventStartedAtMs

            eventStartedAtMs =
                0L

            if (
                file == null ||
                !file.exists() ||
                file.length() <= 0L ||
                samples <= 0L
            ) {
                try {
                    file?.delete()
                } catch (_: Throwable) {
                }
                return null
            }

            return DvrCapturedAudio(
                rawPcmFile = file,
                sampleRate =
                    captureSampleRate,
                channelCount =
                    CHANNEL_COUNT,
                sampleCount =
                    samples,
                startedAtMs =
                    startedAt,
                endedAtMs =
                    System.currentTimeMillis()
            )
        }
    }

    fun discardEvent() {
        synchronized(pcmLock) {
            try {
                eventOutput?.close()
            } catch (_: Throwable) {
            }

            eventOutput =
                null

            try {
                eventRawFile?.delete()
            } catch (_: Throwable) {
            }

            eventRawFile =
                null
            eventSamples = 0L
            eventStartedAtMs = 0L
        }
    }

    private fun resampleToAiRate(
        input: ShortArray,
        sourceRate: Int
    ): ShortArray {
        if (
            input.isEmpty() ||
            sourceRate <= 0
        ) {
            return ShortArray(0)
        }

        if (
            sourceRate ==
            AI_SAMPLE_RATE
        ) {
            return input.copyOf()
        }

        val outputSize =
            (
                input.size.toLong() *
                    AI_SAMPLE_RATE.toLong() /
                    sourceRate.toLong()
                )
                .toInt()
                .coerceAtLeast(
                    1
                )

        val output =
            ShortArray(
                outputSize
            )

        val step =
            sourceRate.toDouble() /
                AI_SAMPLE_RATE.toDouble()

        for (
            outIndex in
            0 until
            outputSize
        ) {
            val srcPosition =
                outIndex *
                    step

            val left =
                srcPosition
                    .toInt()
                    .coerceIn(
                        0,
                        input.lastIndex
                    )

            val right =
                (
                    left +
                        1
                    )
                    .coerceAtMost(
                        input.lastIndex
                    )

            val fraction =
                (
                    srcPosition -
                        left
                    )
                    .toFloat()

            val value =
                input[left] *
                    (
                        1f -
                            fraction
                        ) +
                    input[right] *
                    fraction

            output[outIndex] =
                value
                    .toInt()
                    .coerceIn(
                        Short.MIN_VALUE.toInt(),
                        Short.MAX_VALUE.toInt()
                    )
                    .toShort()
        }

        return output
    }

    private fun appendAiSamples(
        samples: ShortArray
    ) {
        if (samples.isEmpty()) return

        synchronized(aiBufferLock) {
            for (sample in samples) {
                aiRing[
                    aiWriteIndex
                ] =
                    sample

                aiWriteIndex =
                    (
                        aiWriteIndex +
                            1
                        ) %
                        aiRing.size

                if (
                    aiFilled <
                    aiRing.size
                ) {
                    aiFilled++
                }
            }
        }
    }

    private fun maybeSubmitAi() {
        if (
            classifier == null ||
            audioData == null ||
            aiBusy.get()
        ) {
            return
        }

        val now =
            SystemClock.elapsedRealtime()

        if (
            now -
            lastAiSubmitAt <
            850L
        ) {
            return
        }

        val snapshot =
            synchronized(
                aiBufferLock
            ) {
                if (
                    aiFilled <
                    aiRing.size
                ) {
                    return
                }

                ShortArray(
                    aiRing.size
                ).also { result ->
                    val first =
                        aiWriteIndex

                    val tail =
                        aiRing.size -
                            first

                    System.arraycopy(
                        aiRing,
                        first,
                        result,
                        0,
                        tail
                    )

                    if (first > 0) {
                        System.arraycopy(
                            aiRing,
                            0,
                            result,
                            tail,
                            first
                        )
                    }
                }
            }

        lastAiSubmitAt =
            now

        if (
            !aiBusy.compareAndSet(
                false,
                true
            )
        ) {
            return
        }

        aiExecutor.execute {
            try {
                val cls =
                    classifier
                        ?: return@execute

                val data =
                    audioData
                        ?: return@execute

                data.load(
                    snapshot,
                    0,
                    snapshot.size
                )

                val result =
                    cls.classify(
                        data
                    )

                result.classificationResults()
                    .flatMap {
                        it.classifications()
                    }
                    .flatMap {
                        it.categories()
                    }
                    .sortedByDescending {
                        it.score()
                    }
                    .take(24)
                    .forEach {
                        category ->

                        processCategory(
                            category.categoryName(),
                            category.score()
                        )
                    }

            } catch (t: Throwable) {
                if (running.get()) {
                    onStatus(
                        "Sound AI error: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )
                    )
                }
            } finally {
                aiBusy.set(
                    false
                )
            }
        }
    }

    private fun processCategory(
        rawLabel: String,
        score: Float
    ) {
        val label =
            rawLabel.lowercase(
                Locale.US
            )

        when {
            score >= 0.25f &&
                (
                    label.contains("bark") ||
                    label.contains("bow-wow") ||
                    label.contains("bow wow") ||
                    label.contains(
                        "dog barking"
                    )
                ) ->
                emit(
                    "dog_barking",
                    "Dog barking",
                    score,
                    rawLabel,
                    4_000L
                )

            score >= 0.25f &&
                (
                    label.contains("growl") ||
                    label.contains(
                        "growling"
                    )
                ) ->
                emit(
                    "dog_growling",
                    "Dog growling",
                    score,
                    rawLabel,
                    4_000L
                )

            score >= 0.20f &&
                (
                    label.contains("whimper") ||
                    label.contains("whimpering") ||
                    label.contains("whine") ||
                    label.contains("whining")
                ) ->
                emit(
                    "dog_whining",
                    "Dog whining / whimpering",
                    score,
                    rawLabel,
                    4_000L
                )

            score >= 0.22f &&
                (
                    label.contains("yelp") ||
                    label.contains("yelping") ||
                    label.contains("yip") ||
                    label.contains("yipping")
                ) ->
                emit(
                    "dog_yelping",
                    "Dog yelping / yipping",
                    score,
                    rawLabel,
                    4_000L
                )

            score >= 0.25f &&
                (
                    label.contains("howl") ||
                    label.contains("howling")
                ) ->
                emit(
                    "dog_howling",
                    "Dog howling",
                    score,
                    rawLabel,
                    5_000L
                )

            score >= 0.33f &&
                (
                    label.contains("shout") ||
                    label.contains("yell") ||
                    label.contains("scream")
                ) ->
                emit(
                    "shouting",
                    "Shouting / raised voice",
                    score,
                    rawLabel,
                    8_000L
                )

            score >= 0.36f &&
                (
                    label.contains("knock") ||
                    label.contains("thump") ||
                    label.contains("slam") ||
                    label.contains("crash") ||
                    label.contains("glass") ||
                    label.contains("impact")
                ) ->
                emit(
                    "impact",
                    "Impact / knock sound",
                    score,
                    rawLabel,
                    6_000L
                )
        }
    }

    private fun emit(
        key: String,
        label: String,
        confidence: Float,
        rawLabel: String,
        cooldownMs: Long
    ) {
        val now =
            SystemClock.elapsedRealtime()

        synchronized(
            lastEventAt
        ) {
            val last =
                lastEventAt[key]
                    ?: 0L

            if (
                now -
                last <
                cooldownMs
            ) {
                return
            }

            lastEventAt[key] =
                now
        }

        onEvent(
            AudioAiEvent(
                key = key,
                label = label,
                confidence = confidence,
                rawLabel = rawLabel
            )
        )
    }

    private fun writeShortsLittleEndian(
        output: BufferedOutputStream,
        samples: ShortArray,
        offset: Int,
        count: Int
    ) {
        if (count <= 0) return

        val bytes =
            ByteArray(
                count * 2
            )

        ByteBuffer
            .wrap(bytes)
            .order(
                ByteOrder.LITTLE_ENDIAN
            )
            .asShortBuffer()
            .put(
                samples,
                offset,
                count
            )

        output.write(
            bytes
        )
    }

    fun stop() {
        running.set(
            false
        )

        try {
            recorder?.stop()
        } catch (_: Throwable) {
        }

        try {
            recorder?.release()
        } catch (_: Throwable) {
        }
        recorder = null

        try {
            captureExecutor.shutdownNow()
        } catch (_: Throwable) {
        }

        try {
            aiExecutor.shutdownNow()
        } catch (_: Throwable) {
        }

        try {
            classifier?.close()
        } catch (_: Throwable) {
        }
        classifier = null
        audioData = null

        discardEvent()

        synchronized(pcmLock) {
            ring.clear()
        }

        onStatus(
            "Microphone audio stopped"
        )
    }
}
