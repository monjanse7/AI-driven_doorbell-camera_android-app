package com.example.aidoormonitor.ai

import android.graphics.Bitmap
import kotlin.math.abs

/**
 * Offline frame-difference motion detector.
 *
 * This is deliberately independent of Wi-Fi/cloud/AI models. It allows the
 * spare phone to trigger local recordings during an internet/router outage.
 * Later AI models can filter/classify these same motion events.
 */
class SimpleMotionDetector(
    private val sampleWidth: Int = 32,
    private val sampleHeight: Int = 24
) {
    private var previous: IntArray? = null

    fun reset() {
        previous = null
    }

    /**
     * Returns an approximate 0..100 motion score.
     */
    fun score(bitmap: Bitmap): Float {
        val small = Bitmap.createScaledBitmap(bitmap, sampleWidth, sampleHeight, true)
        val pixels = IntArray(sampleWidth * sampleHeight)
        small.getPixels(pixels, 0, sampleWidth, 0, 0, sampleWidth, sampleHeight)
        if (small !== bitmap && !small.isRecycled) small.recycle()

        val luma = IntArray(pixels.size)
        for (i in pixels.indices) {
            val c = pixels[i]
            val r = (c shr 16) and 0xff
            val g = (c shr 8) and 0xff
            val b = c and 0xff
            luma[i] = (r * 30 + g * 59 + b * 11) / 100
        }

        val old = previous
        previous = luma
        if (old == null || old.size != luma.size) return 0f

        var total = 0L
        for (i in luma.indices) {
            total += abs(luma[i] - old[i])
        }

        val averageDifference = total.toFloat() / luma.size.toFloat()
        return (averageDifference / 255f * 100f).coerceIn(0f, 100f)
    }
}
