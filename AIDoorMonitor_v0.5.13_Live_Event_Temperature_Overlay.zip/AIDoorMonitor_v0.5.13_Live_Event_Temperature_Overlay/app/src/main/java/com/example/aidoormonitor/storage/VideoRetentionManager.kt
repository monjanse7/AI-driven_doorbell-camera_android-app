package com.example.aidoormonitor.storage

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.os.StatFs
import android.provider.MediaStore
import java.util.concurrent.Executors

data class RetentionResult(
    val deletedFiles: Int,
    val freedBytes: Long,
    val remainingBytes: Long,
    val note: String
)

object VideoRetentionManager {
    private val executor = Executors.newSingleThreadExecutor()

    fun cleanupAsync(
        context: Context,
        maxGb: Int,
        keepDays: Int,
        minFreeGb: Int = 2,
        callback: (RetentionResult) -> Unit
    ) {
        executor.execute {
            callback(cleanup(context, maxGb, keepDays, minFreeGb))
        }
    }

    fun cleanup(
        context: Context,
        maxGb: Int,
        keepDays: Int,
        minFreeGb: Int = 2
    ): RetentionResult {
        val resolver = context.contentResolver
        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection = mutableListOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.Video.Media.RELATIVE_PATH)
            }
        }.toTypedArray()

        val selection: String
        val args: Array<String>

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            selection =
                "(${MediaStore.Video.Media.RELATIVE_PATH}=? OR ${MediaStore.Video.Media.RELATIVE_PATH}=?) AND " +
                "(${MediaStore.Video.Media.DISPLAY_NAME} LIKE ? OR ${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?)"
            args = arrayOf(
                "Movies/AI Door Monitor/",
                "Movies/AI Door Monitor/Events/",
                "AI_Door_%",
                "AI_Event_%"
            )
        } else {
            selection =
                "(${MediaStore.Video.Media.DISPLAY_NAME} LIKE ? OR ${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?)"
            args = arrayOf("AI_Door_%", "AI_Event_%")
        }

        data class Item(
            val id: Long,
            val size: Long,
            val dateAddedSeconds: Long
        )

        val items = mutableListOf<Item>()

        try {
            resolver.query(
                uri,
                projection,
                selection,
                args,
                "${MediaStore.Video.Media.DATE_ADDED} ASC"
            )?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val sizeI = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateI = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)

                while (c.moveToNext()) {
                    items += Item(
                        c.getLong(idI),
                        c.getLong(sizeI).coerceAtLeast(0L),
                        c.getLong(dateI)
                    )
                }
            }
        } catch (e: Exception) {
            return RetentionResult(
                0, 0, 0,
                "Storage scan failed: ${e.message}"
            )
        }

        var total = items.sumOf { it.size }
        val maxBytes =
            if (maxGb <= 0) Long.MAX_VALUE
            else maxGb.toLong() * 1024L * 1024L * 1024L

        val cutoff =
            if (keepDays <= 0) Long.MIN_VALUE
            else (System.currentTimeMillis() / 1000L) - keepDays.toLong() * 86_400L

        var deleted = 0
        var freed = 0L

        val minFreeBytes =
            if (minFreeGb <= 0) 0L
            else minFreeGb.toLong() * 1024L * 1024L * 1024L

        fun availableBytes(): Long = try {
            val probe = context.getExternalFilesDir(null) ?: context.filesDir
            StatFs(probe.absolutePath).availableBytes
        } catch (_: Exception) {
            Long.MAX_VALUE
        }

        for (item in items) {
            val tooOld = keepDays > 0 && item.dateAddedSeconds < cutoff
            val overLimit = total > maxBytes
            val belowFreeReserve =
                minFreeBytes > 0L && availableBytes() < minFreeBytes

            if (!tooOld && !overLimit && !belowFreeReserve) continue

            try {
                val itemUri = ContentUris.withAppendedId(uri, item.id)
                val rows = resolver.delete(itemUri, null, null)
                if (rows > 0) {
                    deleted++
                    freed += item.size
                    total -= item.size
                }
            } catch (_: Exception) {
                // Continue with other app-created recordings.
            }
        }

        return RetentionResult(
            deletedFiles = deleted,
            freedBytes = freed,
            remainingBytes = total.coerceAtLeast(0L),
            note = "Retention: max ${if (maxGb <= 0) "unlimited" else "${maxGb}GB"}, keep ${if (keepDays <= 0) "forever" else "${keepDays}d"}, reserve ${if (minFreeGb <= 0) "off" else "${minFreeGb}GB free"}"
        )
    }
}
