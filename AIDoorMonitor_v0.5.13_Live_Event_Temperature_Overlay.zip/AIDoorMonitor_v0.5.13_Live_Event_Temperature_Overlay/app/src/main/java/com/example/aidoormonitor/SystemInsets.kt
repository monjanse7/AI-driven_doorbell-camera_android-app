package com.example.aidoormonitor

import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Keeps controls clear of Android's status/navigation bars while preserving
 * any padding already defined in XML.
 */
fun View.applySystemBarInsets(
    addTop: Boolean = true,
    addBottom: Boolean = true
) {
    val startLeft = paddingLeft
    val startTop = paddingTop
    val startRight = paddingRight
    val startBottom = paddingBottom

    ViewCompat.setOnApplyWindowInsetsListener(this) { view, insets ->
        val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        view.setPadding(
            startLeft + bars.left,
            startTop + if (addTop) bars.top else 0,
            startRight + bars.right,
            startBottom + if (addBottom) bars.bottom else 0
        )
        insets
    }
    ViewCompat.requestApplyInsets(this)
}
