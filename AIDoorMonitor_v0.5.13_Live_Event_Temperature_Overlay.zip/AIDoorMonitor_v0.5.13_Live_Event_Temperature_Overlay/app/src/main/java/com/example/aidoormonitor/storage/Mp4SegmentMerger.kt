package com.example.aidoormonitor.storage

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.aidoormonitor.dvr.DvrCapturedAudio
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.nio.ByteBuffer

/** Merges short DVR MP4 segments without re-encoding the video. */
object Mp4SegmentMerger {

    @Volatile
    var lastAudioMuxStatus =
        "Audio mux: not run"
        private set

    @Volatile
    var lastOutputHasAudio =
        false
        private set

    fun mergeToMediaStore(
        context: Context,
        segments: List<File>,
        displayName: String,
        eventFolder: String = "Other",
        capturedAudio: DvrCapturedAudio? = null,
        videoStartAtMs: Long = 0L,
        audioBitrateBps: Int = 128_000,
        audioAdvanceMs: Int = 0
    ): Uri? {
        lastAudioMuxStatus =
            if (capturedAudio != null) {
                "Audio mux: PCM captured • preparing AAC"
            } else {
                "Audio mux: no PCM attached to event"
            }

        lastOutputHasAudio =
            false

        val existing =
            segments.filter {
                it.exists() &&
                    it.length() > 0L
            }

        if (existing.isEmpty()) {
            try {
                capturedAudio
                    ?.rawPcmFile
                    ?.delete()
            } catch (_: Throwable) {
            }
            return null
        }

        val mergeDir =
            File(
                context.cacheDir,
                "event_merge"
            ).apply {
                mkdirs()
            }

        val stamp =
            System.currentTimeMillis()

        val mergedVideo =
            File(
                mergeDir,
                "video_$stamp.mp4"
            )

        val encodedAudio =
            File(
                mergeDir,
                "audio_$stamp.m4a"
            )

        val combined =
            File(
                mergeDir,
                "combined_$stamp.mp4"
            )

        try {
            mergeFiles(
                existing,
                mergedVideo,
                includeAudio =
                    capturedAudio == null
            )

            val finalFile =
                if (
                    capturedAudio != null &&
                    capturedAudio.rawPcmFile.exists() &&
                    capturedAudio.rawPcmFile.length() > 0L
                ) {
                    val videoDurationUs =
                        mediaDurationUs(
                            mergedVideo
                        )

                    val requestedAudioBitrate =
                        audioBitrateBps
                            .coerceIn(
                                64_000,
                                320_000
                            )

                    val bitrateFallbacks =
                        listOf(
                            requestedAudioBitrate,
                            256_000,
                            192_000,
                            128_000,
                            96_000
                        )
                            .filter {
                                it <=
                                    requestedAudioBitrate
                            }
                            .distinct()

                    var audioReady =
                        false

                    var successfulBitrate =
                        0

                    var lastAudioError =
                        ""

                    for (
                        bitrate in
                        bitrateFallbacks
                    ) {
                        try {
                            if (
                                encodedAudio
                                    .exists()
                            ) {
                                encodedAudio
                                    .delete()
                            }

                            audioReady =
                                encodePcmToAac(
                                    capturedAudio =
                                        capturedAudio,
                                    outputFile =
                                        encodedAudio,
                                    maxDurationUs =
                                        videoDurationUs,
                                    videoStartAtMs =
                                        videoStartAtMs,
                                    audioBitrateBps =
                                        bitrate,
                                    audioAdvanceMs =
                                        audioAdvanceMs
                                )

                            if (audioReady) {
                                successfulBitrate =
                                    bitrate
                                break
                            }

                            lastAudioError =
                                "AAC encoder produced no verified audio track at ${bitrate / 1000} kbps"

                        } catch (
                            t: Throwable
                        ) {
                            audioReady =
                                false

                            lastAudioError =
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                        }
                    }

                    if (
                        audioReady &&
                        hasMediaTrack(
                            encodedAudio,
                            "audio/"
                        )
                    ) {
                        try {
                            muxVideoAndAudio(
                                videoFile =
                                    mergedVideo,
                                audioFile =
                                    encodedAudio,
                                outputFile =
                                    combined
                            )

                            if (
                                hasMediaTrack(
                                    combined,
                                    "audio/"
                                ) &&
                                hasMediaTrack(
                                    combined,
                                    "video/"
                                )
                            ) {
                                lastAudioMuxStatus =
                                    "Audio mux: OK • AAC ${successfulBitrate / 1000} kbps • final MP4 has audio track"

                                combined
                            } else {
                                lastAudioMuxStatus =
                                    "Audio mux FAILED verification • final combined MP4 has no audio track • video-only fallback"

                                mergedVideo
                            }

                        } catch (
                            t: Throwable
                        ) {
                            lastAudioMuxStatus =
                                "Audio mux exception: " +
                                    (
                                        t.message
                                            ?: t.javaClass
                                                .simpleName
                                        ) +
                                    " • video-only fallback"

                            mergedVideo
                        }
                    } else {
                        lastAudioMuxStatus =
                            "AAC encode failed: " +
                                lastAudioError
                                    .ifBlank {
                                        "no verified audio track"
                                    } +
                                " • video-only fallback"

                        mergedVideo
                    }
                } else {
                    lastAudioMuxStatus =
                        if (
                            capturedAudio ==
                            null
                        ) {
                            "Audio mux: event had no captured PCM"
                        } else {
                            "Audio mux: captured PCM file was empty"
                        }

                    mergedVideo
                }

            lastOutputHasAudio =
                hasMediaTrack(
                    finalFile,
                    "audio/"
                )

            val values =
                ContentValues().apply {
                    put(
                        MediaStore.Video.Media
                            .DISPLAY_NAME,
                        displayName
                    )

                    put(
                        MediaStore.Video.Media
                            .MIME_TYPE,
                        "video/mp4"
                    )

                    if (
                        Build.VERSION.SDK_INT >=
                        Build.VERSION_CODES.Q
                    ) {
                        put(
                            MediaStore.Video.Media
                                .RELATIVE_PATH,
                            "Movies/AI Door Monitor/Events/" +
                                sanitizeFolderName(
                                    eventFolder
                                ) +
                                "/"
                        )
                    }
                }

            val uri =
                context.contentResolver
                    .insert(
                        MediaStore.Video.Media
                            .EXTERNAL_CONTENT_URI,
                        values
                    )
                    ?: return null

            context.contentResolver
                .openOutputStream(
                    uri
                )
                ?.use { out ->
                    finalFile
                        .inputStream()
                        .use { input ->
                            input.copyTo(
                                out,
                                256 * 1024
                            )
                        }
                }
                ?: run {
                    try {
                        context.contentResolver
                            .delete(
                                uri,
                                null,
                                null
                            )
                    } catch (_: Throwable) {
                    }
                    return null
                }

            return uri

        } finally {
            try {
                mergedVideo.delete()
            } catch (_: Throwable) {
            }

            try {
                encodedAudio.delete()
            } catch (_: Throwable) {
            }

            try {
                combined.delete()
            } catch (_: Throwable) {
            }

            try {
                capturedAudio
                    ?.rawPcmFile
                    ?.delete()
            } catch (_: Throwable) {
            }
        }
    }

    private fun sanitizeFolderName(
        raw: String
    ): String =
        raw
            .trim()
            .replace(
                Regex("[\\\\/:*?\"<>|]+"),
                "_"
            )
            .replace(
                Regex("\\s+"),
                " "
            )
            .trim()
            .take(48)
            .ifBlank {
                "Other"
            }

    private fun mergeFiles(
        files: List<File>,
        output: File,
        includeAudio: Boolean
    ) {
        val first =
            MediaExtractor()

        first.setDataSource(
            files.first()
                .absolutePath
        )

        val trackMimes =
            mutableListOf<String>()

        val trackFormats =
            mutableListOf<MediaFormat>()

        for (
            i in 0 until
            first.trackCount
        ) {
            val format =
                first.getTrackFormat(i)

            val mime =
                format.getString(
                    MediaFormat.KEY_MIME
                )
                    ?: continue

            val wanted =
                mime.startsWith(
                    "video/"
                ) ||
                    (
                        includeAudio &&
                        mime.startsWith(
                            "audio/"
                        )
                        )

            if (wanted) {
                trackMimes +=
                    mime

                trackFormats +=
                    format
            }
        }

        first.release()

        if (trackMimes.isEmpty()) {
            throw IllegalStateException(
                "No video/audio tracks."
            )
        }

        val muxer =
            MediaMuxer(
                output.absolutePath,
                MediaMuxer.OutputFormat
                    .MUXER_OUTPUT_MPEG_4
            )

        val rotation =
            videoRotationDegrees(
                files.first()
            )

        if (
            rotation == 90 ||
            rotation == 180 ||
            rotation == 270
        ) {
            muxer.setOrientationHint(
                rotation
            )
        }

        val outputTracks =
            trackFormats.map {
                muxer.addTrack(it)
            }

        val bases =
            LongArray(
                outputTracks.size
            )

        muxer.start()

        try {
            files.forEach { file ->
                trackMimes
                    .forEachIndexed {
                            outIndex,
                            wantedMime ->

                        val extractor =
                            MediaExtractor()

                        try {
                            extractor.setDataSource(
                                file.absolutePath
                            )

                            var inputTrack =
                                -1

                            var format:
                                MediaFormat? =
                                null

                            for (
                                i in 0 until
                                extractor.trackCount
                            ) {
                                val candidate =
                                    extractor
                                        .getTrackFormat(i)

                                if (
                                    candidate.getString(
                                        MediaFormat.KEY_MIME
                                    ) ==
                                    wantedMime
                                ) {
                                    inputTrack =
                                        i

                                    format =
                                        candidate

                                    break
                                }
                            }

                            if (
                                inputTrack < 0
                            ) {
                                return@forEachIndexed
                            }

                            extractor.selectTrack(
                                inputTrack
                            )

                            val maxInput =
                                try {
                                    format
                                        ?.getInteger(
                                            MediaFormat
                                                .KEY_MAX_INPUT_SIZE
                                        )
                                        ?: 2 * 1024 * 1024
                                } catch (_: Throwable) {
                                    2 * 1024 * 1024
                                }

                            var buffer =
                                ByteBuffer
                                    .allocateDirect(
                                        maxInput
                                            .coerceAtLeast(
                                                512 * 1024
                                            )
                                    )

                            val info =
                                MediaCodec.BufferInfo()

                            var firstPts =
                                -1L

                            var lastNormalizedPts =
                                0L

                            var previousNormalizedPts =
                                -1L

                            var sampleGap =
                                if (
                                    wantedMime.startsWith(
                                        "video/"
                                    )
                                ) {
                                    33_333L
                                } else {
                                    20_000L
                                }

                            while (true) {
                                buffer.clear()

                                var size =
                                    extractor
                                        .readSampleData(
                                            buffer,
                                            0
                                        )

                                if (size < 0) {
                                    break
                                }

                                if (
                                    size >
                                    buffer.capacity()
                                ) {
                                    buffer =
                                        ByteBuffer
                                            .allocateDirect(
                                                size * 2
                                            )

                                    buffer.clear()

                                    size =
                                        extractor
                                            .readSampleData(
                                                buffer,
                                                0
                                            )

                                    if (size < 0) {
                                        break
                                    }
                                }

                                val pts =
                                    extractor.sampleTime

                                if (firstPts < 0L) {
                                    firstPts =
                                        pts
                                }

                                val normalized =
                                    (
                                        pts -
                                            firstPts
                                        )
                                        .coerceAtLeast(
                                            0L
                                        )

                                if (
                                    previousNormalizedPts >=
                                    0L &&
                                    normalized >
                                    previousNormalizedPts
                                ) {
                                    sampleGap =
                                        normalized -
                                            previousNormalizedPts
                                }

                                previousNormalizedPts =
                                    normalized

                                lastNormalizedPts =
                                    normalized

                                info.set(
                                    0,
                                    size,
                                    bases[outIndex] +
                                        normalized,
                                    extractor.sampleFlags
                                )

                                muxer.writeSampleData(
                                    outputTracks[
                                        outIndex
                                    ],
                                    buffer,
                                    info
                                )

                                extractor.advance()
                            }

                            bases[outIndex] +=
                                lastNormalizedPts +
                                    sampleGap
                                        .coerceIn(
                                            1_000L,
                                            100_000L
                                        )

                        } finally {
                            extractor.release()
                        }
                    }
            }

        } finally {
            try {
                muxer.stop()
            } finally {
                muxer.release()
            }
        }
    }

    private fun encodePcmToAac(
        capturedAudio: DvrCapturedAudio,
        outputFile: File,
        maxDurationUs: Long,
        videoStartAtMs: Long,
        audioBitrateBps: Int,
        audioAdvanceMs: Int
    ): Boolean {
        val reportedSampleRate =
            capturedAudio.sampleRate
                .coerceAtLeast(
                    8_000
                )

        val wallClockDurationMs =
            (
                capturedAudio.endedAtMs -
                    capturedAudio.startedAtMs
                )
                .coerceAtLeast(
                    1L
                )

        val measuredSampleRate =
            capturedAudio.sampleCount
                .toDouble() *
                1_000.0 /
                wallClockDurationMs
                    .toDouble()

        val standardRates =
            intArrayOf(
                8_000,
                11_025,
                12_000,
                16_000,
                22_050,
                24_000,
                32_000,
                44_100,
                48_000
            )

        val measuredStandard =
            standardRates.minByOrNull {
                kotlin.math.abs(
                    it.toDouble() -
                        measuredSampleRate
                )
            }
                ?: reportedSampleRate

        val sampleRate =
            if (
                kotlin.math.abs(
                    measuredSampleRate -
                        reportedSampleRate
                ) /
                    reportedSampleRate
                        .toDouble() >
                0.015 &&
                kotlin.math.abs(
                    measuredSampleRate -
                        measuredStandard
                ) /
                    measuredStandard
                        .toDouble() <
                0.035
            ) {
                measuredStandard
            } else {
                reportedSampleRate
            }

        val channels =
            capturedAudio.channelCount
                .coerceAtLeast(1)

        val bytesPerFrame =
            channels * 2

        val targetFrames =
            if (maxDurationUs > 0L) {
                (
                    maxDurationUs *
                        sampleRate.toLong() /
                        1_000_000L
                    )
                    .coerceAtLeast(1L)
            } else {
                capturedAudio.sampleCount
                    .coerceAtLeast(1L)
            }

        // Natural positive delta means audio capture starts after the first
        // video segment and therefore needs leading silence. Negative means
        // captured audio begins before video and must be trimmed. Positive
        // audioAdvanceMs intentionally moves audible content earlier.
        val naturalDeltaMs =
            if (
                videoStartAtMs > 0L &&
                capturedAudio.startedAtMs > 0L
            ) {
                capturedAudio.startedAtMs -
                    videoStartAtMs
            } else {
                0L
            }

        val effectiveDeltaMs =
            naturalDeltaMs -
                audioAdvanceMs.toLong()

        var prependFrames =
            if (effectiveDeltaMs > 0L) {
                effectiveDeltaMs *
                    sampleRate.toLong() /
                    1_000L
            } else {
                0L
            }

        val skipFrames =
            if (effectiveDeltaMs < 0L) {
                -effectiveDeltaMs *
                    sampleRate.toLong() /
                    1_000L
            } else {
                0L
            }

        val format =
            MediaFormat
                .createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_AAC,
                    sampleRate,
                    channels
                )
                .apply {
                    setInteger(
                        MediaFormat.KEY_AAC_PROFILE,
                        MediaCodecInfo
                            .CodecProfileLevel
                            .AACObjectLC
                    )

                    setInteger(
                        MediaFormat.KEY_BIT_RATE,
                        audioBitrateBps
                            .coerceIn(
                                64_000,
                                320_000
                            )
                    )

                    setInteger(
                        MediaFormat.KEY_MAX_INPUT_SIZE,
                        32 * 1024
                    )
                }

        val codec =
            MediaCodec
                .createEncoderByType(
                    MediaFormat.MIMETYPE_AUDIO_AAC
                )

        val muxer =
            MediaMuxer(
                outputFile.absolutePath,
                MediaMuxer.OutputFormat
                    .MUXER_OUTPUT_MPEG_4
            )

        var muxerStarted =
            false

        var audioTrack =
            -1

        var inputDone =
            false

        var outputDone =
            false

        var totalFrames =
            0L

        var totalPcmBytes =
            0L

        val info =
            MediaCodec.BufferInfo()

        val input =
            FileInputStream(
                capturedAudio.rawPcmFile
            )

        var sourceExhausted =
            false

        if (skipFrames > 0L) {
            skipFully(
                input,
                skipFrames *
                    bytesPerFrame.toLong()
            )
        }

        var encodeCompleted =
            false

        var muxerStopSucceeded =
            false

        try {
            codec.configure(
                format,
                null,
                null,
                MediaCodec.CONFIGURE_FLAG_ENCODE
            )

            codec.start()

            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex =
                        codec.dequeueInputBuffer(
                            10_000L
                        )

                    if (inputIndex >= 0) {
                        val buffer =
                            codec.getInputBuffer(
                                inputIndex
                            )

                        if (buffer != null) {
                            buffer.clear()

                            val remainingFrames =
                                (
                                    targetFrames -
                                        totalFrames
                                    )
                                    .coerceAtLeast(0L)

                            if (remainingFrames <= 0L) {
                                val ptsUs =
                                    totalFrames *
                                        1_000_000L /
                                        sampleRate

                                codec.queueInputBuffer(
                                    inputIndex,
                                    0,
                                    0,
                                    ptsUs,
                                    MediaCodec
                                        .BUFFER_FLAG_END_OF_STREAM
                                )

                                inputDone =
                                    true

                            } else {
                                val maxFramesInBuffer =
                                    buffer.remaining() /
                                        bytesPerFrame

                                val wantedFrames =
                                    minOf(
                                        maxFramesInBuffer.toLong(),
                                        remainingFrames
                                    )
                                        .toInt()

                                val wantedBytes =
                                    wantedFrames *
                                        bytesPerFrame

                                val temp =
                                    ByteArray(
                                        wantedBytes
                                    )

                                var writtenFrames =
                                    0

                                if (prependFrames > 0L) {
                                    val silenceFrames =
                                        minOf(
                                            prependFrames,
                                            wantedFrames.toLong()
                                        )
                                            .toInt()

                                    // ByteArray is already zero-filled.
                                    writtenFrames +=
                                        silenceFrames

                                    prependFrames -=
                                        silenceFrames.toLong()
                                }

                                if (
                                    writtenFrames <
                                    wantedFrames &&
                                    !sourceExhausted
                                ) {
                                    val dataOffset =
                                        writtenFrames *
                                            bytesPerFrame

                                    val dataWanted =
                                        (
                                            wantedFrames -
                                                writtenFrames
                                            ) *
                                            bytesPerFrame

                                    val read =
                                        readPcmAligned(
                                            input,
                                            temp,
                                            dataOffset,
                                            dataWanted,
                                            bytesPerFrame
                                        )

                                    if (read <= 0) {
                                        sourceExhausted =
                                            true
                                    } else {
                                        writtenFrames +=
                                            read /
                                                bytesPerFrame

                                        if (read < dataWanted) {
                                            sourceExhausted =
                                                true
                                        }
                                    }
                                }

                                // If the microphone prebuffer ended a little
                                // early, the rest remains zero-filled so the
                                // AAC track stays exactly as long as video.
                                writtenFrames =
                                    wantedFrames

                                val alignedBytes =
                                    writtenFrames *
                                        bytesPerFrame

                                buffer.put(
                                    temp,
                                    0,
                                    alignedBytes
                                )

                                val ptsUs =
                                    totalFrames *
                                        1_000_000L /
                                        sampleRate

                                codec.queueInputBuffer(
                                    inputIndex,
                                    0,
                                    alignedBytes,
                                    ptsUs,
                                    0
                                )

                                totalFrames +=
                                    writtenFrames.toLong()
                            }
                        }
                    }
                }

                var draining =
                    true

                while (draining) {
                    val outputIndex =
                        codec.dequeueOutputBuffer(
                            info,
                            10_000L
                        )

                    when {
                        outputIndex ==
                            MediaCodec
                                .INFO_TRY_AGAIN_LATER -> {
                            draining =
                                false
                        }

                        outputIndex ==
                            MediaCodec
                                .INFO_OUTPUT_FORMAT_CHANGED -> {
                            if (muxerStarted) {
                                throw IllegalStateException(
                                    "AAC output format changed twice."
                                )
                            }

                            audioTrack =
                                muxer.addTrack(
                                    codec.outputFormat
                                )

                            muxer.start()

                            muxerStarted =
                                true
                        }

                        outputIndex >= 0 -> {
                            val outBuffer =
                                codec.getOutputBuffer(
                                    outputIndex
                                )

                            if (
                                outBuffer != null &&
                                info.size > 0 &&
                                (
                                    info.flags and
                                    MediaCodec
                                        .BUFFER_FLAG_CODEC_CONFIG
                                    ) == 0 &&
                                muxerStarted
                            ) {
                                outBuffer.position(
                                    info.offset
                                )

                                outBuffer.limit(
                                    info.offset +
                                        info.size
                                )

                                muxer.writeSampleData(
                                    audioTrack,
                                    outBuffer,
                                    info
                                )
                            }

                            val eos =
                                (
                                    info.flags and
                                    MediaCodec
                                        .BUFFER_FLAG_END_OF_STREAM
                                    ) != 0

                            codec.releaseOutputBuffer(
                                outputIndex,
                                false
                            )

                            if (eos) {
                                outputDone =
                                    true
                                draining =
                                    false
                            }
                        }
                    }
                }
            }

            encodeCompleted =
                muxerStarted &&
                    outputDone

        } finally {
            try {
                input.close()
            } catch (_: Throwable) {
            }

            try {
                codec.stop()
            } catch (_: Throwable) {
            }

            try {
                codec.release()
            } catch (_: Throwable) {
            }

            if (muxerStarted) {
                try {
                    muxer.stop()

                    muxerStopSucceeded =
                        true
                } catch (_: Throwable) {
                    muxerStopSucceeded =
                        false
                }
            }

            try {
                muxer.release()
            } catch (_: Throwable) {
            }
        }

        // IMPORTANT: verify only AFTER MediaMuxer.stop() has finalized the
        // MP4/M4A container. v0.4.x-v0.5.3 checked file length before stop(),
        // which could incorrectly report AAC failure and silently save the
        // video-only file.
        return (
            encodeCompleted &&
                muxerStopSucceeded &&
                outputFile.exists() &&
                outputFile.length() >
                0L &&
                hasMediaTrack(
                    outputFile,
                    "audio/"
                )
            )
    }

    private fun readPcmAligned(
        input: InputStream,
        buffer: ByteArray,
        offset: Int,
        wanted: Int,
        frameBytes: Int
    ): Int {
        var total = 0

        while (total < wanted) {
            val read =
                input.read(
                    buffer,
                    offset + total,
                    wanted - total
                )

            if (read < 0) {
                break
            }

            if (read == 0) {
                break
            }

            total +=
                read
        }

        return total -
            (
                total %
                frameBytes
                )
    }

    private fun skipFully(
        input: InputStream,
        bytes: Long
    ) {
        var remaining =
            bytes
                .coerceAtLeast(0L)

        val scratch =
            ByteArray(
                16 * 1024
            )

        while (remaining > 0L) {
            val skipped =
                input.skip(remaining)

            if (skipped > 0L) {
                remaining -=
                    skipped
                continue
            }

            val read =
                input.read(
                    scratch,
                    0,
                    minOf(
                        scratch.size.toLong(),
                        remaining
                    ).toInt()
                )

            if (read <= 0) {
                break
            }

            remaining -=
                read.toLong()
        }
    }

    private fun muxVideoAndAudio(
        videoFile: File,
        audioFile: File,
        outputFile: File
    ) {
        val videoExtractor =
            MediaExtractor()

        val audioExtractor =
            MediaExtractor()

        videoExtractor.setDataSource(
            videoFile.absolutePath
        )

        audioExtractor.setDataSource(
            audioFile.absolutePath
        )

        try {
            val videoTrack =
                findTrack(
                    videoExtractor,
                    "video/"
                )

            val audioTrack =
                findTrack(
                    audioExtractor,
                    "audio/"
                )

            if (
                videoTrack < 0 ||
                audioTrack < 0
            ) {
                throw IllegalStateException(
                    "Could not find both video and audio track."
                )
            }

            val videoFormat =
                videoExtractor
                    .getTrackFormat(
                        videoTrack
                    )

            val audioFormat =
                audioExtractor
                    .getTrackFormat(
                        audioTrack
                    )

            val muxer =
                MediaMuxer(
                    outputFile.absolutePath,
                    MediaMuxer.OutputFormat
                        .MUXER_OUTPUT_MPEG_4
                )

            val rotation =
                videoRotationDegrees(
                    videoFile
                )

            if (
                rotation == 90 ||
                rotation == 180 ||
                rotation == 270
            ) {
                muxer.setOrientationHint(
                    rotation
                )
            }

            val outVideo =
                muxer.addTrack(
                    videoFormat
                )

            val outAudio =
                muxer.addTrack(
                    audioFormat
                )

            muxer.start()

            try {
                copyTrack(
                    extractor =
                        videoExtractor,
                    inputTrack =
                        videoTrack,
                    muxer =
                        muxer,
                    outputTrack =
                        outVideo
                )

                copyTrack(
                    extractor =
                        audioExtractor,
                    inputTrack =
                        audioTrack,
                    muxer =
                        muxer,
                    outputTrack =
                        outAudio
                )

            } finally {
                try {
                    muxer.stop()
                } finally {
                    muxer.release()
                }
            }

        } finally {
            videoExtractor.release()
            audioExtractor.release()
        }
    }

    private fun findTrack(
        extractor: MediaExtractor,
        mimePrefix: String
    ): Int {
        for (
            i in 0 until
            extractor.trackCount
        ) {
            val format =
                extractor.getTrackFormat(i)

            val mime =
                format.getString(
                    MediaFormat.KEY_MIME
                )
                    ?: continue

            if (
                mime.startsWith(
                    mimePrefix
                )
            ) {
                return i
            }
        }

        return -1
    }

    private fun copyTrack(
        extractor: MediaExtractor,
        inputTrack: Int,
        muxer: MediaMuxer,
        outputTrack: Int
    ) {
        extractor.selectTrack(
            inputTrack
        )

        val format =
            extractor.getTrackFormat(
                inputTrack
            )

        val maxInput =
            try {
                format.getInteger(
                    MediaFormat.KEY_MAX_INPUT_SIZE
                )
            } catch (_: Throwable) {
                2 * 1024 * 1024
            }

        var buffer =
            ByteBuffer.allocateDirect(
                maxInput
                    .coerceAtLeast(
                        512 * 1024
                    )
            )

        val info =
            MediaCodec.BufferInfo()

        var firstPts =
            -1L

        while (true) {
            buffer.clear()

            var size =
                extractor.readSampleData(
                    buffer,
                    0
                )

            if (size < 0) {
                break
            }

            if (
                size >
                buffer.capacity()
            ) {
                buffer =
                    ByteBuffer.allocateDirect(
                        size * 2
                    )

                buffer.clear()

                size =
                    extractor.readSampleData(
                        buffer,
                        0
                    )

                if (size < 0) {
                    break
                }
            }

            val pts =
                extractor.sampleTime

            if (firstPts < 0L) {
                firstPts =
                    pts
            }

            info.set(
                0,
                size,
                (
                    pts -
                        firstPts
                    )
                    .coerceAtLeast(
                        0L
                    ),
                extractor.sampleFlags
            )

            muxer.writeSampleData(
                outputTrack,
                buffer,
                info
            )

            extractor.advance()
        }
    }

    private fun hasMediaTrack(
        file: File,
        mimePrefix: String
    ): Boolean {
        if (
            !file.exists() ||
            file.length() <= 0L
        ) {
            return false
        }

        val extractor =
            MediaExtractor()

        return try {
            extractor.setDataSource(
                file.absolutePath
            )

            for (
                i in
                0 until
                extractor.trackCount
            ) {
                val mime =
                    extractor
                        .getTrackFormat(i)
                        .getString(
                            MediaFormat.KEY_MIME
                        )
                        ?: continue

                if (
                    mime.startsWith(
                        mimePrefix
                    )
                ) {
                    return true
                }
            }

            false

        } catch (_: Throwable) {
            false

        } finally {
            try {
                extractor.release()
            } catch (_: Throwable) {
            }
        }
    }

    private fun mediaDurationUs(
        file: File
    ): Long {
        val retriever =
            MediaMetadataRetriever()

        return try {
            retriever.setDataSource(
                file.absolutePath
            )

            val durationMs =
                retriever.extractMetadata(
                    MediaMetadataRetriever
                        .METADATA_KEY_DURATION
                )
                    ?.toLongOrNull()
                    ?: 0L

            durationMs *
                1_000L

        } catch (_: Throwable) {
            0L
        } finally {
            try {
                retriever.release()
            } catch (_: Throwable) {
            }
        }
    }

    private fun videoRotationDegrees(
        file: File
    ): Int {
        val retriever =
            MediaMetadataRetriever()

        return try {
            retriever.setDataSource(
                file.absolutePath
            )

            retriever.extractMetadata(
                MediaMetadataRetriever
                    .METADATA_KEY_VIDEO_ROTATION
            )
                ?.toIntOrNull()
                ?: 0

        } catch (_: Throwable) {
            0
        } finally {
            try {
                retriever.release()
            } catch (_: Throwable) {
            }
        }
    }
}
