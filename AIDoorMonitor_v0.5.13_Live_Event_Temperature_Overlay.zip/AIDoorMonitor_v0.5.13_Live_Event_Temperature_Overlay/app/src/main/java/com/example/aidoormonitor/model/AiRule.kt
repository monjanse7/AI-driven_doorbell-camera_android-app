package com.example.aidoormonitor.model

data class AiRule(
    val id: String,
    var name: String,
    var enabled: Boolean,
    var type: RuleType,
    var signal: String,
    var confidence: Int,
    var minDurationMs: Long = 0,
    var notes: String = ""
)

enum class RuleType {
    OBJECT,
    AUDIO,
    TEMPORAL_VIDEO,
    TRAJECTORY,
    COMPOSITE
}
