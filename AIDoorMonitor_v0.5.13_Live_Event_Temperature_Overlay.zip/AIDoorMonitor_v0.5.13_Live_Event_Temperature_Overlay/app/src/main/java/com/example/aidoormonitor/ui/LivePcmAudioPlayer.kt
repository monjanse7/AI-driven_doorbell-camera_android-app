package com.example.aidoormonitor.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.aidoormonitor.net.PairInfo
import java.io.BufferedInputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

/**
 * Plays the Camera2 DVR's existing shared AudioRecord stream on the monitor.
 *
 * It does not request microphone access on the monitor and it does not open a
 * second microphone on the camera phone. The camera's one AudioRecord feeds:
 * saved-event audio, Sound AI, and this live PCM stream.
 */
class LivePcmAudioPlayer {
    @Volatile
    private var running =
        false

    @Volatile
    private var connection:
        HttpURLConnection? =
        null

    @Volatile
    private var audioTrack:
        AudioTrack? =
        null

    private var worker:
        Thread? =
        null

    fun start(
        pair: PairInfo,
        onState:
            (
                String
            ) -> Unit
    ) {
        stop()

        running =
            true

        worker =
            Thread {
                var attempt =
                    0

                while (running) {
                    var conn:
                        HttpURLConnection? =
                        null

                    var track:
                        AudioTrack? =
                        null

                    try {
                        attempt++

                        onState(
                            if (
                                attempt <=
                                1
                            ) {
                                "Live audio: connecting…"
                            } else {
                                "Live audio: reconnecting…"
                            }
                        )

                        conn =
                            URL(
                                pair.endpoint(
                                    "/audio-stream"
                                )
                            )
                                .openConnection()
                                as HttpURLConnection

                        connection =
                            conn

                        conn.connectTimeout =
                            4_000

                        conn.readTimeout =
                            12_000

                        conn.useCaches =
                            false

                        conn.setRequestProperty(
                            "Connection",
                            "close"
                        )

                        conn.connect()

                        if (
                            conn.responseCode !=
                            200
                        ) {
                            throw IllegalStateException(
                                "HTTP ${conn.responseCode}"
                            )
                        }

                        val sampleRate =
                            conn.getHeaderField(
                                "X-Audio-Sample-Rate"
                            )
                                ?.toIntOrNull()
                                ?.coerceIn(
                                    8_000,
                                    96_000
                                )
                                ?: 48_000

                        val channels =
                            conn.getHeaderField(
                                "X-Audio-Channels"
                            )
                                ?.toIntOrNull()
                                ?: 1

                        val channelMask =
                            if (
                                channels >=
                                2
                            ) {
                                AudioFormat
                                    .CHANNEL_OUT_STEREO
                            } else {
                                AudioFormat
                                    .CHANNEL_OUT_MONO
                            }

                        val minBuffer =
                            AudioTrack
                                .getMinBufferSize(
                                    sampleRate,
                                    channelMask,
                                    AudioFormat
                                        .ENCODING_PCM_16BIT
                                )
                                .coerceAtLeast(
                                    4_096
                                )

                        track =
                            AudioTrack.Builder()
                                .setAudioAttributes(
                                    AudioAttributes
                                        .Builder()
                                        .setUsage(
                                            AudioAttributes
                                                .USAGE_MEDIA
                                        )
                                        .setContentType(
                                            AudioAttributes
                                                .CONTENT_TYPE_SPEECH
                                        )
                                        .build()
                                )
                                .setAudioFormat(
                                    AudioFormat
                                        .Builder()
                                        .setEncoding(
                                            AudioFormat
                                                .ENCODING_PCM_16BIT
                                        )
                                        .setSampleRate(
                                            sampleRate
                                        )
                                        .setChannelMask(
                                            channelMask
                                        )
                                        .build()
                                )
                                .setTransferMode(
                                    AudioTrack
                                        .MODE_STREAM
                                )
                                .setBufferSizeInBytes(
                                    max(
                                        minBuffer *
                                            3,
                                        sampleRate *
                                            channels *
                                            2 /
                                            2
                                    )
                                )
                                .build()

                        audioTrack =
                            track

                        track.play()

                        onState(
                            "Live audio: ON • " +
                                if (
                                    sampleRate ==
                                    44_100
                                ) {
                                    "44.1 kHz"
                                } else {
                                    "${sampleRate / 1000} kHz"
                                } +
                                if (
                                    channels >=
                                    2
                                ) {
                                    " stereo"
                                } else {
                                    " mono"
                                }
                        )

                        val input =
                            BufferedInputStream(
                                conn.inputStream,
                                64 *
                                    1024
                            )

                        val buffer =
                            ByteArray(
                                8 *
                                    1024
                            )

                        attempt =
                            0

                        while (running) {
                            val read =
                                input.read(
                                    buffer
                                )

                            if (
                                read <
                                0
                            ) {
                                break
                            }

                            if (
                                read ==
                                0
                            ) {
                                continue
                            }

                            var offset =
                                0

                            while (
                                running &&
                                offset <
                                read
                            ) {
                                val written =
                                    track.write(
                                        buffer,
                                        offset,
                                        read -
                                            offset,
                                        AudioTrack
                                            .WRITE_BLOCKING
                                    )

                                if (
                                    written <=
                                    0
                                ) {
                                    break
                                }

                                offset +=
                                    written
                            }
                        }

                    } catch (
                        t: Throwable
                    ) {
                        if (running) {
                            onState(
                                "Live audio: waiting for camera microphone…"
                            )
                        }

                    } finally {
                        try {
                            track?.pause()
                        } catch (_: Throwable) {
                        }

                        try {
                            track?.flush()
                        } catch (_: Throwable) {
                        }

                        try {
                            track?.stop()
                        } catch (_: Throwable) {
                        }

                        try {
                            track?.release()
                        } catch (_: Throwable) {
                        }

                        if (
                            audioTrack ===
                            track
                        ) {
                            audioTrack =
                                null
                        }

                        try {
                            conn?.disconnect()
                        } catch (_: Throwable) {
                        }

                        if (
                            connection ===
                            conn
                        ) {
                            connection =
                                null
                        }
                    }

                    if (running) {
                        try {
                            Thread.sleep(
                                700L
                            )
                        } catch (_: Throwable) {
                        }
                    }
                }
            }
                .apply {
                    name =
                        "AI-Door-Live-Audio"

                    isDaemon =
                        true

                    start()
                }
    }

    fun stop() {
        running =
            false

        try {
            connection
                ?.disconnect()
        } catch (_: Throwable) {
        }

        connection =
            null

        try {
            audioTrack
                ?.pause()
        } catch (_: Throwable) {
        }

        try {
            audioTrack
                ?.flush()
        } catch (_: Throwable) {
        }

        try {
            audioTrack
                ?.stop()
        } catch (_: Throwable) {
        }

        try {
            audioTrack
                ?.release()
        } catch (_: Throwable) {
        }

        audioTrack =
            null

        try {
            worker
                ?.interrupt()
        } catch (_: Throwable) {
        }

        worker =
            null
    }
}
