package com.example.aidoormonitor.dvr

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.Image
import java.io.ByteArrayOutputStream

object YuvJpeg {
    fun toJpeg(
        image: Image,
        quality: Int = 58,
        rotationDegrees: Int = 0
    ): ByteArray? {
        if (image.format != ImageFormat.YUV_420_888) return null
        if (image.planes.size < 3) return null

        val width = image.width
        val height = image.height
        if (width <= 0 || height <= 0) return null

        val nv21 = ByteArray(width * height * 3 / 2)

        fun sample(
            planeIndex: Int,
            row: Int,
            col: Int
        ): Byte? {
            val plane = image.planes[planeIndex]
            val buffer = plane.buffer
            val index =
                buffer.position() +
                    row * plane.rowStride +
                    col * plane.pixelStride

            return if (index >= buffer.position() && index < buffer.limit()) {
                buffer.get(index)
            } else {
                null
            }
        }

        var p = 0
        for (y in 0 until height) {
            for (x in 0 until width) {
                nv21[p++] = sample(0, y, x) ?: return null
            }
        }

        val chromaWidth = width / 2
        val chromaHeight = height / 2
        for (y in 0 until chromaHeight) {
            for (x in 0 until chromaWidth) {
                nv21[p++] = sample(2, y, x) ?: return null // V
                nv21[p++] = sample(1, y, x) ?: return null // U
            }
        }

        val raw = ByteArrayOutputStream(width * height / 3)
        val ok =
            YuvImage(
                nv21,
                ImageFormat.NV21,
                width,
                height,
                null
            ).compressToJpeg(
                Rect(0, 0, width, height),
                quality.coerceIn(30, 85),
                raw
            )

        if (!ok) return null

        val bytes = raw.toByteArray()
        val normalizedRotation =
            ((rotationDegrees % 360) + 360) % 360

        if (normalizedRotation == 0) {
            return bytes
        }

        val bitmap =
            BitmapFactory.decodeByteArray(
                bytes,
                0,
                bytes.size
            ) ?: return bytes

        val matrix =
            Matrix().apply {
                postRotate(
                    normalizedRotation.toFloat()
                )
            }

        val rotated =
            try {
                Bitmap.createBitmap(
                    bitmap,
                    0,
                    0,
                    bitmap.width,
                    bitmap.height,
                    matrix,
                    true
                )
            } catch (_: Throwable) {
                bitmap
            }

        val output =
            ByteArrayOutputStream(
                rotated.width * rotated.height / 3
            )

        rotated.compress(
            Bitmap.CompressFormat.JPEG,
            quality.coerceIn(30, 85),
            output
        )

        if (rotated !== bitmap && !rotated.isRecycled) {
            rotated.recycle()
        }
        if (!bitmap.isRecycled) {
            bitmap.recycle()
        }

        return output.toByteArray()
    }
}
