package com.example.aidoormonitor.ai

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioRecord
import android.os.SystemClock
import com.google.mediapipe.tasks.audio.audioclassifier.AudioClassifier
import com.google.mediapipe.tasks.components.containers.AudioData
import java.io.File
import java.util.Locale
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap

data class AudioAiEvent(
    val key: String,
    val label: String,
    val confidence: Float,
    val rawLabel: String
)

class YamNetAudioDetector(
    private val context: Context,
    private val modelFile: File,
    private val onEvent: (AudioAiEvent) -> Unit,
    private val onStatus: (String) -> Unit = {}
) {
    private var classifier: AudioClassifier? = null
    private var recorder: AudioRecord? = null
    private var executor: ScheduledThreadPoolExecutor? = null
    private var audioData: AudioData? = null
    private val lastEventAt = ConcurrentHashMap<String, Long>()

    private val inferenceLock = Any()

    @Volatile
    private var stopping = false

    @SuppressLint("MissingPermission")
    fun start() {
        if (classifier != null) return
        stopping = false
        if (!modelFile.exists()) {
            onStatus("YamNet model is not downloaded.")
            return
        }

        try {
            classifier = AudioClassifier.createFromFile(context, modelFile)
            recorder = classifier!!.createAudioRecord()
            audioData = AudioData.create(recorder!!.format, 15_600)

            recorder!!.startRecording()
            executor = ScheduledThreadPoolExecutor(1)
            executor!!.scheduleAtFixedRate(
                { classifyOnce() },
                1000L,
                850L,
                TimeUnit.MILLISECONDS
            )
            onStatus("Audio AI active • YamNet")
        } catch (e: Exception) {
            onStatus("Audio AI failed: ${e.message}")
            stop()
        }
    }

    private fun classifyOnce() {
        if (stopping) return

        synchronized(inferenceLock) {
            if (stopping) return

            val cls =
                classifier ?: return
            val rec =
                recorder ?: return
            val data =
                audioData ?: return

            try {
                data.load(rec)

                if (stopping) return

                val result =
                    cls.classify(data)

                if (stopping) return

                val categories =
                    result.classificationResults()
                        .flatMap {
                            it.classifications()
                        }
                        .flatMap {
                            it.categories()
                        }
                        .sortedByDescending {
                            it.score()
                        }

                categories
                    .take(24)
                    .forEach { category ->
                        val raw =
                            category.categoryName()

                        val label =
                            raw.lowercase(
                                Locale.US
                            )

                        val score =
                            category.score()

                        when {
                            score >= 0.25f &&
                                (
                                    label.contains("bark") ||
                                    label.contains("bow-wow") ||
                                    label.contains("bow wow") ||
                                    label.contains("dog barking")
                                ) ->
                                emit(
                                    "dog_barking",
                                    "Dog barking",
                                    score,
                                    raw,
                                    4_000L
                                )

                            score >= 0.25f &&
                                (
                                    label.contains("growl") ||
                                    label.contains("growling")
                                ) ->
                                emit(
                                    "dog_growling",
                                    "Dog growling",
                                    score,
                                    raw,
                                    4_000L
                                )

                            score >= 0.20f &&
                                (
                                    label.contains("whimper") ||
                                    label.contains("whimpering") ||
                                    label.contains("whine") ||
                                    label.contains("whining")
                                ) ->
                                emit(
                                    "dog_whining",
                                    "Dog whining / whimpering",
                                    score,
                                    raw,
                                    4_000L
                                )

                            score >= 0.22f &&
                                (
                                    label.contains("yelp") ||
                                    label.contains("yelping") ||
                                    label.contains("yip") ||
                                    label.contains("yipping")
                                ) ->
                                emit(
                                    "dog_yelping",
                                    "Dog yelping / yipping",
                                    score,
                                    raw,
                                    4_000L
                                )

                            score >= 0.25f &&
                                (
                                    label.contains("howl") ||
                                    label.contains("howling")
                                ) ->
                                emit(
                                    "dog_howling",
                                    "Dog howling",
                                    score,
                                    raw,
                                    5_000L
                                )

                            score >= 0.33f &&
                                (
                                    label.contains("shout") ||
                                    label.contains("yell") ||
                                    label.contains("scream")
                                ) ->
                                emit(
                                    "shouting",
                                    "Shouting / raised voice",
                                    score,
                                    raw,
                                    8_000L
                                )

                            score >= 0.36f &&
                                (
                                    label.contains("knock") ||
                                    label.contains("thump") ||
                                    label.contains("slam") ||
                                    label.contains("crash") ||
                                    label.contains("glass") ||
                                    label.contains("impact")
                                ) ->
                                emit(
                                    "impact",
                                    "Impact / knock sound",
                                    score,
                                    raw,
                                    6_000L
                                )
                        }
                    }

            } catch (t: Throwable) {
                if (!stopping) {
                    onStatus(
                        "Audio AI error: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )
                    )
                }
            }
        }
    }

    private fun emit(
        key: String,
        label: String,
        confidence: Float,
        rawLabel: String,
        cooldownMs: Long
    ) {
        val now = SystemClock.elapsedRealtime()
        val last = lastEventAt[key] ?: 0L
        if (now - last < cooldownMs) return
        lastEventAt[key] = now
        onEvent(AudioAiEvent(key, label, confidence, rawLabel))
    }

    fun stop() {
        stopping = true

        val oldExecutor =
            executor
        executor = null

        try {
            oldExecutor?.shutdownNow()
        } catch (_: Throwable) {
        }

        synchronized(inferenceLock) {
            try {
                if (
                    recorder?.recordingState ==
                    AudioRecord.RECORDSTATE_RECORDING
                ) {
                    recorder?.stop()
                }
            } catch (_: Throwable) {
            }

            try {
                recorder?.release()
            } catch (_: Throwable) {
            }
            recorder = null

            try {
                classifier?.close()
            } catch (_: Throwable) {
            }
            classifier = null
            audioData = null
        }
    }

}
