package com.example.aidoormonitor

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.aidoormonitor.databinding.ActivityDvrCameraBinding
import com.example.aidoormonitor.net.LocalNetwork
import com.example.aidoormonitor.ai.ModelDownloader
import com.example.aidoormonitor.net.PairInfo
import com.example.aidoormonitor.net.Pairing

class DvrCameraActivity : AppCompatActivity() {

    private lateinit var b: ActivityDvrCameraBinding

    private val prefs by lazy {
        getSharedPreferences(
            "camera_settings",
            MODE_PRIVATE
        )
    }

    private var cameraChoices:
        List<CameraChoice> =
        emptyList()

    private val uiHandler =
        Handler(
            Looper.getMainLooper()
        )

    private val permissionLauncher =
        registerForActivityResult(
            ActivityResultContracts
                .RequestMultiplePermissions()
        ) { result ->
            val cameraGranted =
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) ==
                    PackageManager.PERMISSION_GRANTED

            if (!cameraGranted) {
                b.status.text =
                    "Camera permission is required."
                return@registerForActivityResult
            }

            val micGranted =
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.RECORD_AUDIO
                ) ==
                    PackageManager.PERMISSION_GRANTED

            if (!micGranted) {
                if (
                    b.soundAiArmed.isChecked
                ) {
                    b.soundAiArmed.isChecked =
                        false

                    b.soundAiDvrStatus.text =
                        "Sound AI disabled because microphone permission was not granted."
                }

                if (
                    b.recordAudioInVideos
                        .isChecked
                ) {
                    b.recordAudioInVideos
                        .isChecked =
                        false

                    b.recordAudioStatus.text =
                        "Video audio disabled because microphone permission was not granted."
                }

                prefs.edit()
                    .putBoolean(
                        "dvr_sound_ai_armed",
                        false
                    )
                    .putBoolean(
                        "dvr_record_audio",
                        false
                    )
                    .apply()
            }

            ensurePermissionsAndStart()
        }

    private val customObjectModelLauncher =
        registerForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri == null) {
                return@registerForActivityResult
            }

            try {
                val target =
                    ModelDownloader
                        .customObjectFile(this)

                contentResolver
                    .openInputStream(uri)
                    ?.use { input ->
                        target.outputStream()
                            .use { output ->
                                input.copyTo(
                                    output,
                                    256 * 1024
                                )
                            }
                    }
                    ?: throw IllegalStateException(
                        "Could not read selected model."
                    )

                if (target.length() < 100_000L) {
                    target.delete()
                    throw IllegalStateException(
                        "Selected model is unexpectedly small."
                    )
                }

                b.customObjectModelStatus.text =
                    "Custom object model: imported • ${target.length() / 1024L} KB. Restart DVR Camera to activate it."

            } catch (t: Throwable) {
                b.customObjectModelStatus.text =
                    "Custom model import failed: " +
                        (
                            t.message
                                ?: t.javaClass
                                    .simpleName
                            )
            }
        }

    private val overlayPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) {
            updateOverlayPermissionUi()

            if (canShowOverOtherApps()) {
                startDvrService()
            } else {
                b.status.text =
                    "Show over other apps permission is required for DVR Camera mode."
            }
        }

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(
            savedInstanceState
        )

        b =
            ActivityDvrCameraBinding
                .inflate(
                    layoutInflater
                )

        setContentView(
            b.root
        )

        b.root.applySystemBarInsets()

        setupCameraChoices()
        setupSettings()
        setupButtons()

        b.objectAiStatus.text =
            if (ModelDownloader.objectReady(this)) {
                "Object naming AI: READY • filenames can use detected objects/custom rules."
            } else {
                "Object naming AI: NOT DOWNLOADED • filenames fall back to Motion."
            }

        b.customObjectModelStatus.text =
            if (
                ModelDownloader
                    .customObjectReady(this)
            ) {
                "Custom object model: READY • can provide stroller/custom labels."
            } else {
                "Custom object model: not imported • stroller requires a compatible custom detector."
            }

        b.soundAiDvrStatus.text =
            if (
                ModelDownloader
                    .yamnetReady(this)
            ) {
                "Sound AI model: READY"
            } else {
                "Sound AI model: NOT DOWNLOADED"
            }

        showPairing()
        startLocalPreview()
        updateOverlayPermissionUi()
        ensurePermissionsAndStart()

        uiHandler.post(
            statusPoller
        )
    }

    private fun setupCameraChoices() {
        cameraChoices =
            try {
                CameraChoiceRepository
                    .discover(this)
            } catch (_: Throwable) {
                listOf(
                    CameraChoice(
                        CameraChoiceRepository
                            .DEFAULT_BACK_KEY,
                        "Rear camera • automatic"
                    )
                )
            }

        b.cameraSpinner.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                cameraChoices.map {
                    it.label
                }
            )

        val saved =
            prefs.getString(
                "camera_choice_key",
                CameraChoiceRepository
                    .DEFAULT_BACK_KEY
            )

        val index =
            cameraChoices
                .indexOfFirst {
                    it.key == saved
                }
                .takeIf {
                    it >= 0
                }
                ?: 0

        b.cameraSpinner
            .setSelection(index)
    }

    private fun setupSettings() {
        b.qualitySpinner.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "8K UHD / 7680×4320 • 24 fps • auto-fallback to 4K if unavailable",
                    "4K UHD / 3840×2160 • 30 fps",
                    "1080p Full HD / 1920×1080 • 30 fps"
                )
            )

        if (
            !prefs.getBoolean(
                "dvr_quality_schema_8k",
                false
            )
        ) {
            val oldQuality =
                prefs.getInt(
                    "dvr_quality",
                    0
                )
                    .coerceIn(
                        0,
                        1
                    )

            prefs.edit()
                .putInt(
                    "dvr_quality",
                    if (
                        oldQuality ==
                        0
                    ) {
                        1
                    } else {
                        2
                    }
                )
                .putBoolean(
                    "dvr_quality_schema_8k",
                    true
                )
                .apply()
        }

        b.qualitySpinner
            .setSelection(
                prefs.getInt(
                    "dvr_quality",
                    1
                )
                    .coerceIn(
                        0,
                        2
                    )
            )

        val videoBitrateValues =
            intArrayOf(
                0,
                20,
                32,
                50,
                75,
                100,
                150,
                200
            )

        b.videoBitrateSpinner.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "Auto • 100 Mbps 8K / 32 Mbps 4K / 12 Mbps 1080p",
                    "20 Mbps",
                    "32 Mbps",
                    "50 Mbps • High",
                    "75 Mbps • Very high",
                    "100 Mbps • 8K recommended",
                    "150 Mbps • Ultra",
                    "200 Mbps • Extreme"
                )
            )

        val savedVideoBitrate =
            prefs.getInt(
                "dvr_video_bitrate_mbps",
                0
            )

        b.videoBitrateSpinner
            .setSelection(
                videoBitrateValues
                    .indexOf(
                        savedVideoBitrate
                    )
                    .takeIf {
                        it >= 0
                    }
                    ?: 0
            )

        val mountRotationValues =
            intArrayOf(
                -1,
                0,
                90,
                180,
                270
            )

        b.mountRotationSpinner.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "Auto • Android sensor/display rotation",
                    "0° • UPRIGHT • top up / USB down",
                    "90° clockwise video correction",
                    "180° video correction",
                    "270° clockwise • 90° counter-clockwise"
                )
            )

        val savedMountRotation =
            prefs.getInt(
                "dvr_mount_rotation",
                -1
            )

        b.mountRotationSpinner
            .setSelection(
                mountRotationValues
                    .indexOf(
                        savedMountRotation
                    )
                    .takeIf {
                        it >= 0
                    }
                    ?: 0
            )


        val preValues =
            intArrayOf(
                5,
                10,
                15,
                20,
                30
            )

        b.preRecordSpinner.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                preValues.map {
                    "$it seconds"
                }
            )

        val pre =
            prefs.getInt(
                "dvr_pre_seconds",
                10
            )

        b.preRecordSpinner
            .setSelection(
                preValues
                    .indexOf(pre)
                    .takeIf {
                        it >= 0
                    }
                    ?: 1
            )

        val postValues =
            intArrayOf(
                10,
                20,
                30,
                60
            )

        b.postRecordSpinner.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                postValues.map {
                    "$it seconds"
                }
            )

        val post =
            prefs.getInt(
                "dvr_post_seconds",
                20
            )

        b.postRecordSpinner
            .setSelection(
                postValues
                    .indexOf(post)
                    .takeIf {
                        it >= 0
                    }
                    ?: 1
            )

        b.motionArmed.isChecked =
            prefs.getBoolean(
                "dvr_motion_armed",
                true
            )

        b.motionSensitivity.progress =
            prefs.getInt(
                "dvr_motion_sensitivity",
                65
            ).coerceIn(0, 100)

        b.recordAudioInVideos.isChecked =
            prefs.getBoolean(
                "dvr_record_audio",
                true
            )

        val audioBitrateValues =
            intArrayOf(
                64,
                96,
                128,
                192,
                256,
                320
            )

        b.audioBitrateSpinner.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "64 kbps AAC",
                    "96 kbps AAC",
                    "128 kbps AAC • Recommended",
                    "192 kbps AAC • High",
                    "256 kbps AAC • Very high",
                    "320 kbps AAC • Maximum"
                )
            )

        val savedAudioBitrate =
            prefs.getInt(
                "dvr_audio_bitrate_kbps",
                128
            )

        b.audioBitrateSpinner
            .setSelection(
                audioBitrateValues
                    .indexOf(
                        savedAudioBitrate
                    )
                    .takeIf {
                        it >= 0
                    }
                    ?: 2
            )

        val audioAdvanceValues =
            intArrayOf(
                0,
                -100,
                -250,
                -500,
                -750,
                -1000,
                -1500,
                -2000,
                -3000,
                -5000,
                100,
                250,
                500,
                1000
            )

        b.audioSyncSpinner.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "Automatic • sample-rate + timestamp correction",
                    "Audio 100 ms later",
                    "Audio 250 ms later",
                    "Audio 500 ms later",
                    "Audio 750 ms later",
                    "Audio 1000 ms later",
                    "Audio 1500 ms later",
                    "Audio 2000 ms later",
                    "Audio 3000 ms later",
                    "Audio 5000 ms later",
                    "Audio 100 ms earlier",
                    "Audio 250 ms earlier",
                    "Audio 500 ms earlier",
                    "Audio 1000 ms earlier"
                )
            )

        val savedAudioAdvance =
            prefs.getInt(
                "dvr_audio_advance_ms",
                0
            )

        b.audioSyncSpinner
            .setSelection(
                audioAdvanceValues
                    .indexOf(
                        savedAudioAdvance
                    )
                    .takeIf {
                        it >= 0
                    }
                    ?: 0
            )

        b.soundAiArmed.isChecked =
            prefs.getBoolean(
                "dvr_sound_ai_armed",
                true
            )

        b.dogSoundTrigger.isChecked =
            prefs.getBoolean(
                "dvr_trigger_dog_sounds",
                true
            )

        b.shoutingSoundTrigger.isChecked =
            prefs.getBoolean(
                "dvr_trigger_shouting",
                false
            )

        b.impactSoundTrigger.isChecked =
            prefs.getBoolean(
                "dvr_trigger_impact_sound",
                false
            )

        b.objectTriggerArmed.isChecked =
            prefs.getBoolean(
                "dvr_object_trigger_armed",
                true
            )

        b.carTrigger.isChecked =
            prefs.getBoolean(
                "dvr_trigger_car",
                true
            )

        b.bicycleTrigger.isChecked =
            prefs.getBoolean(
                "dvr_trigger_bicycle",
                true
            )

        b.strollerTrigger.isChecked =
            prefs.getBoolean(
                "dvr_trigger_stroller",
                true
            )

        updateSensitivityLabel()

        b.motionSensitivity
            .setOnSeekBarChangeListener(
                object :
                    SeekBar
                        .OnSeekBarChangeListener {

                    override fun onProgressChanged(
                        seekBar: SeekBar?,
                        progress: Int,
                        fromUser: Boolean
                    ) {
                        updateSensitivityLabel()
                    }

                    override fun onStartTrackingTouch(
                        seekBar: SeekBar?
                    ) = Unit

                    override fun onStopTrackingTouch(
                        seekBar: SeekBar?
                    ) = Unit
                }
            )
    }

    private fun updateSensitivityLabel() {
        b.sensitivityLabel.text =
            "Motion sensitivity: ${b.motionSensitivity.progress}%"
    }

    private fun setupButtons() {
        b.importCustomObjectModel
            .setOnClickListener {
                customObjectModelLauncher.launch(
                    arrayOf(
                        "application/octet-stream",
                        "application/x-tflite",
                        "*/*"
                    )
                )
            }

        b.openCustomRules.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    RuleEditorActivity::class.java
                )
            )
        }

        b.prepareAiModels.setOnClickListener {
            b.prepareAiModels.isEnabled = false
            b.objectAiStatus.text =
                "Downloading / preparing AI models…"

            ModelDownloader.prepareAll(
                this,
                onStatus = { text ->
                    runOnUiThread {
                        b.objectAiStatus.text = text
                    }
                },
                onDone = { ok, text ->
                    runOnUiThread {
                        b.prepareAiModels.isEnabled = true
                        b.objectAiStatus.text = text

                        if (ok) {
                            b.objectAiStatus.text =
                                "Object naming AI ready. Restart DVR Camera to activate it."
                        }
                    }
                }
            )
        }

        b.grantOverlayPermission.setOnClickListener {
            requestShowOverOtherAppsPermission()
        }

        b.saveRestart.setOnClickListener {
            saveSettings()
            restartDvrService()
        }

        b.saveEventNow.setOnClickListener {
            saveSettings()

            ContextCompat.startForegroundService(
                this,
                Intent(
                    this,
                    DvrCamera2Service::class.java
                ).apply {
                    action =
                        DvrCamera2Service
                            .ACTION_SAVE_EVENT
                }
            )
        }

        b.stopDvr.setOnClickListener {
            try {
                startService(
                    Intent(
                        this,
                        DvrCamera2Service::class.java
                    ).apply {
                        action =
                            DvrCamera2Service
                                .ACTION_STOP
                    }
                )
            } catch (_: Throwable) {
                stopService(
                    Intent(
                        this,
                        DvrCamera2Service::class.java
                    )
                )
            }

            finish()
        }
    }

    private fun saveSettings() {
        val preValues =
            intArrayOf(
                5,
                10,
                15,
                20,
                30
            )

        val postValues =
            intArrayOf(
                10,
                20,
                30,
                60
            )

        val cameraChoice =
            cameraChoices.getOrNull(
                b.cameraSpinner
                    .selectedItemPosition
            )

        prefs.edit()
            .putString(
                "camera_choice_key",
                cameraChoice?.key
                    ?: CameraChoiceRepository
                        .DEFAULT_BACK_KEY
            )
            .putInt(
                "dvr_quality",
                b.qualitySpinner
                    .selectedItemPosition
                    .coerceIn(
                        0,
                        2
                    )
            )
            .putBoolean(
                "dvr_quality_schema_8k",
                true
            )
            .putInt(
                "dvr_video_bitrate_mbps",
                intArrayOf(
                    0,
                    20,
                    32,
                    50,
                    75,
                    100,
                    150,
                    200
                )[
                    b.videoBitrateSpinner
                        .selectedItemPosition
                        .coerceIn(
                            0,
                            7
                        )
                ]
            )
            .putInt(
                "dvr_mount_rotation",
                intArrayOf(
                    -1,
                    0,
                    90,
                    180,
                    270
                )[
                    b.mountRotationSpinner
                        .selectedItemPosition
                        .coerceIn(
                            0,
                            4
                        )
                ]
            )
            .putInt(
                "dvr_audio_bitrate_kbps",
                intArrayOf(
                    64,
                    96,
                    128,
                    192,
                    256,
                    320
                )[
                    b.audioBitrateSpinner
                        .selectedItemPosition
                        .coerceIn(
                            0,
                            5
                        )
                ]
            )
            .putInt(
                "dvr_audio_advance_ms",
                intArrayOf(
                    0,
                    -100,
                    -250,
                    -500,
                    -750,
                    -1000,
                    -1500,
                    -2000,
                    -3000,
                    -5000,
                    100,
                    250,
                    500,
                    1000
                )[
                    b.audioSyncSpinner
                        .selectedItemPosition
                        .coerceIn(
                            0,
                            13
                        )
                ]
            )
            .putBoolean(
                "dvr_record_audio",
                b.recordAudioInVideos
                    .isChecked
            )
            .putBoolean(
                "dvr_sound_ai_armed",
                b.soundAiArmed.isChecked
            )
            .putBoolean(
                "dvr_trigger_dog_sounds",
                b.dogSoundTrigger.isChecked
            )
            .putBoolean(
                "dvr_trigger_shouting",
                b.shoutingSoundTrigger.isChecked
            )
            .putBoolean(
                "dvr_trigger_impact_sound",
                b.impactSoundTrigger.isChecked
            )
            .putBoolean(
                "dvr_object_trigger_armed",
                b.objectTriggerArmed.isChecked
            )
            .putBoolean(
                "dvr_trigger_car",
                b.carTrigger.isChecked
            )
            .putBoolean(
                "dvr_trigger_bicycle",
                b.bicycleTrigger.isChecked
            )
            .putBoolean(
                "dvr_trigger_stroller",
                b.strollerTrigger.isChecked
            )
            .putBoolean(
                "dvr_motion_armed",
                b.motionArmed.isChecked
            )
            .putInt(
                "dvr_motion_sensitivity",
                b.motionSensitivity.progress
            )
            .putInt(
                "dvr_pre_seconds",
                preValues[
                    b.preRecordSpinner
                        .selectedItemPosition
                        .coerceIn(
                            0,
                            preValues.lastIndex
                        )
                ]
            )
            .putInt(
                "dvr_post_seconds",
                postValues[
                    b.postRecordSpinner
                        .selectedItemPosition
                        .coerceIn(
                            0,
                            postValues.lastIndex
                        )
                ]
            )
            .apply()
    }

    private fun canShowOverOtherApps(): Boolean =
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            true
        } else {
            Settings.canDrawOverlays(this)
        }

    private fun updateOverlayPermissionUi() {
        if (!::b.isInitialized) return

        val granted =
            canShowOverOtherApps()

        b.overlayPermissionStatus.text =
            if (granted) {
                "Show over other apps: ALLOWED"
            } else {
                "Show over other apps: NOT ALLOWED"
            }

        b.grantOverlayPermission.text =
            if (granted) {
                "SHOW OVER OTHER APPS IS ALLOWED"
            } else {
                "ALLOW SHOW OVER OTHER APPS"
            }

        b.grantOverlayPermission.isEnabled =
            !granted
    }

    private fun requestShowOverOtherAppsPermission() {
        if (canShowOverOtherApps()) {
            updateOverlayPermissionUi()
            return
        }

        val intent =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION
                )
            } else {
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            }

        try {
            overlayPermissionLauncher.launch(intent)
        } catch (t: Throwable) {
            b.status.text =
                "Could not open Show over other apps settings: " +
                    (t.message ?: t.javaClass.simpleName)
        }
    }

    private fun ensurePermissionsAndStart() {
        val missing =
            mutableListOf<String>()

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            missing +=
                Manifest.permission.CAMERA
        }

        if (
            (
                b.soundAiArmed.isChecked ||
                b.recordAudioInVideos
                    .isChecked
                ) &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            missing +=
                Manifest.permission.RECORD_AUDIO
        }

        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            missing +=
                Manifest.permission.POST_NOTIFICATIONS
        }

        if (missing.isNotEmpty()) {
            permissionLauncher.launch(
                missing
                    .distinct()
                    .toTypedArray()
            )
            return
        }

        if (!canShowOverOtherApps()) {
            b.status.text =
                "Enable Show over other apps for AI Door Monitor, then return here."
            requestShowOverOtherAppsPermission()
            return
        }

        startDvrService()
    }

    private fun startDvrService() {
        saveSettings()

        // Stop the legacy CameraX monitor service before the new Camera2
        // service takes ownership of camera + port 8787.
        try {
            stopService(
                Intent(
                    this,
                    DoorMonitoringService::class.java
                )
            )
        } catch (_: Throwable) {
        }

        uiHandler.postDelayed({
            try {
                ContextCompat
                    .startForegroundService(
                        this,
                        Intent(
                            this,
                            DvrCamera2Service::class.java
                        ).apply {
                            action =
                                DvrCamera2Service
                                    .ACTION_START
                        }
                    )
            } catch (t: Throwable) {
                b.status.text =
                    "DVR service start failed: " +
                        (
                            t.message
                                ?: t.javaClass
                                    .simpleName
                            )
            }
        }, 1_250L)
    }

    private fun restartDvrService() {
        try {
            ContextCompat
                .startForegroundService(
                    this,
                    Intent(
                        this,
                        DvrCamera2Service::class.java
                    ).apply {
                        action =
                            DvrCamera2Service
                                .ACTION_RESTART
                    }
                )
        } catch (t: Throwable) {
            b.status.text =
                "Restart failed: " +
                    (
                        t.message
                            ?: t.javaClass
                                .simpleName
                        )
        }
    }

    private fun startLocalPreview() {
        val pair =
            PairInfo(
                host = "127.0.0.1",
                port = 8787,
                token =
                    Pairing
                        .getOrCreateCameraToken(
                            this
                        )
            )

        b.liveView.start(
            pair
        ) { state ->
            b.previewStatus.text =
                state
        }
    }

    private fun showPairing() {
        val ip =
            LocalNetwork
                .bestIpv4Address()

        if (ip == null) {
            b.pairingAddress.text =
                "LAN IP is not available yet."
            b.pairingQr.visibility =
                View.GONE
            return
        }

        val pair =
            PairInfo(
                host = ip,
                port = 8787,
                token =
                    Pairing
                        .getOrCreateCameraToken(
                            this
                        )
            )

        b.pairingAddress.text =
            pair.pairingUri()

        try {
            b.pairingQr
                .setImageBitmap(
                    Pairing.qrBitmap(
                        pair.pairingUri(),
                        500
                    )
                )
        } catch (_: Throwable) {
        }
    }

    private val statusPoller =
        object : Runnable {
            override fun run() {
                val score =
                    String.format(
                        java.util.Locale.US,
                        "%.2f",
                        DvrCamera2Service
                            .motionScore
                    )

                b.status.text =
                    buildString {
                        append(
                            DvrCamera2Service
                                .statusText
                        )

                        val error =
                            DvrCamera2Service
                                .lastError

                        if (error.isNotBlank()) {
                            append("\n\nLast camera error: ")
                            append(error)
                        }
                    }

                b.motionStatus.text =
                    buildString {
                        append(
                            "Motion AI score: "
                        )
                        append(score)
                        append(
                            " • pre-buffer: "
                        )
                        append(
                            DvrCamera2Service
                                .completedPrebufferSeconds
                        )
                        append(" s")

                        if (
                            DvrCamera2Service
                                .eventActive
                        ) {
                            append(
                                "\nEVENT ACTIVE • pre/post recording"
                            )
                        }
                    }

                b.recordAudioStatus.text =
                    buildString {
                        append(
                            DvrCamera2Service
                                .recordingAudioStatus
                        )
                        append("\n")
                        append(
                            DvrCamera2Service
                                .activeAudioBitrateText
                        )
                        append("\n")
                        append(
                            DvrCamera2Service
                                .activeAudioSyncText
                        )
                        append("\n")
                        append(
                            DvrCamera2Service
                                .activeVideoBitrateText
                        )
                    }

                b.soundAiDvrStatus.text =
                    buildString {
                        append(
                            DvrCamera2Service
                                .audioAiStatus
                        )

                        val last =
                            DvrCamera2Service
                                .lastSoundAiEvent

                        if (last.isNotBlank()) {
                            append("\nLast sound: ")
                            append(last)
                        }
                    }

                b.carMotionFilterStatus.text =
                    buildString {
                        append(
                            DvrCamera2Service
                                .carMotionStatus
                        )

                        if (
                            DvrCamera2Service
                                .carMotionScore >
                            0f
                        ) {
                            append(
                                " • score="
                            )
                            append(
                                String.format(
                                    java.util.Locale.US,
                                    "%.2f",
                                    DvrCamera2Service
                                        .carMotionScore
                                )
                            )
                        }
                    }

                b.customObjectModelStatus.text =
                    if (
                        DvrCamera2Service
                            .customObjectAiReady
                    ) {
                        "Custom object model: ACTIVE"
                    } else if (
                        ModelDownloader
                            .customObjectReady(
                                this@DvrCameraActivity
                            )
                    ) {
                        "Custom object model: imported • restart DVR Camera to activate."
                    } else {
                        "Custom object model: not imported • stroller requires custom model."
                    }

                b.aiNamingStatus.text =
                    buildString {
                        append("AI event filename: ")
                        append(
                            DvrCamera2Service
                                .currentAiEventLabel
                        )

                        val last =
                            DvrCamera2Service
                                .lastSavedEventName

                        if (last.isNotBlank()) {
                            append("\nLast saved: ")
                            append(last)
                        }
                    }

                b.resolutionStatus.text =
                    "Recording: " +
                        (
                            DvrCamera2Service
                                .activeRecordingSize
                                .ifBlank {
                                    "starting…"
                                }
                            ) +
                        " • Analysis: " +
                        (
                            DvrCamera2Service
                                .activeAnalysisSize
                                .ifBlank {
                                    "starting…"
                                }
                            ) +
                        "\n" +
                        DvrCamera2Service
                            .activeRotationText

                uiHandler.postDelayed(
                    this,
                    500L
                )
            }
        }

    override fun onResume() {
        super.onResume()

        updateOverlayPermissionUi()

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED &&
            canShowOverOtherApps() &&
            !DvrCamera2Service.isRunning
        ) {
            startDvrService()
        }
    }

    override fun onDestroy() {
        uiHandler.removeCallbacksAndMessages(
            null
        )

        try {
            b.liveView.stop()
        } catch (_: Throwable) {
        }

        super.onDestroy()
    }
}
