package com.example.aidoormonitor.ui

import android.content.Context
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs

/**
 * Transparent gesture surface used only while local playback Zoom/Pan mode
 * is enabled.
 *
 * This view never changes the source MP4. It reports:
 * - uniform zoom scale 1x..5x
 * - normalized pan X/Y -1..1
 *
 * Media3 controls remain underneath and are usable whenever this overlay is
 * GONE.
 */
class PlaybackZoomGestureView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(
    context,
    attrs,
    defStyleAttr
) {
    private var zoomScale =
        1f

    private var panXPx =
        0f

    private var panYPx =
        0f

    private var lastX =
        0f

    private var lastY =
        0f

    private var dragging =
        false

    private val touchSlop =
        ViewConfiguration
            .get(context)
            .scaledTouchSlop
            .toFloat()

    private var downX =
        0f

    private var downY =
        0f

    private var listener:
        ((
            scale: Float,
            panX: Float,
            panY: Float
        ) -> Unit)? =
        null

    private val scaleDetector =
        ScaleGestureDetector(
            context,
            object :
                ScaleGestureDetector
                    .SimpleOnScaleGestureListener() {

                override fun onScaleBegin(
                    detector:
                        ScaleGestureDetector
                ): Boolean {
                    parent
                        ?.requestDisallowInterceptTouchEvent(
                            true
                        )

                    dragging =
                        false

                    return true
                }

                override fun onScale(
                    detector:
                        ScaleGestureDetector
                ): Boolean {
                    val oldScale =
                        zoomScale

                    zoomScale =
                        (
                            zoomScale *
                                detector
                                    .scaleFactor
                            )
                            .coerceIn(
                                1f,
                                5f
                            )

                    if (
                        zoomScale <=
                        1.001f
                    ) {
                        resetInternal()
                    } else if (
                        oldScale >
                        1.001f
                    ) {
                        // Preserve roughly the same normalized pan when the
                        // available pan range changes with zoom.
                        val oldMaxX =
                            maxPanX(
                                oldScale
                            )

                        val oldMaxY =
                            maxPanY(
                                oldScale
                            )

                        val nx =
                            if (
                                oldMaxX >
                                0f
                            ) {
                                (
                                    panXPx /
                                        oldMaxX
                                    )
                                    .coerceIn(
                                        -1f,
                                        1f
                                    )
                            } else {
                                0f
                            }

                        val ny =
                            if (
                                oldMaxY >
                                0f
                            ) {
                                (
                                    panYPx /
                                        oldMaxY
                                    )
                                    .coerceIn(
                                        -1f,
                                        1f
                                    )
                            } else {
                                0f
                            }

                        panXPx =
                            nx *
                                maxPanX(
                                    zoomScale
                                )

                        panYPx =
                            ny *
                                maxPanY(
                                    zoomScale
                                )
                    }

                    clampPan()
                    notifyChanged()

                    return true
                }
            }
        )

    private val gestureDetector =
        GestureDetector(
            context,
            object :
                GestureDetector
                    .SimpleOnGestureListener() {

                override fun onDown(
                    e: MotionEvent
                ): Boolean =
                    true

                override fun onDoubleTap(
                    e: MotionEvent
                ): Boolean {
                    resetZoomPan(
                        notify = true
                    )

                    return true
                }
            }
        )

    init {
        isClickable =
            true

        isFocusable =
            true

        setBackgroundColor(
            android.graphics.Color
                .TRANSPARENT
        )
    }

    fun setOnZoomPanChanged(
        callback:
            ((
                scale: Float,
                panX: Float,
                panY: Float
            ) -> Unit)?
    ) {
        listener =
            callback
    }

    fun currentScale():
        Float =
        zoomScale

    fun resetZoomPan(
        notify: Boolean =
            true
    ) {
        resetInternal()

        if (notify) {
            notifyChanged()
        }
    }

    private fun resetInternal() {
        zoomScale =
            1f

        panXPx =
            0f

        panYPx =
            0f

        dragging =
            false
    }

    private fun maxPanX(
        scale: Float =
            zoomScale
    ): Float =
        (
            width
                .coerceAtLeast(1)
                .toFloat() *
                (
                    scale -
                        1f
                    ) /
                2f
            )
            .coerceAtLeast(
                0f
            )

    private fun maxPanY(
        scale: Float =
            zoomScale
    ): Float =
        (
            height
                .coerceAtLeast(1)
                .toFloat() *
                (
                    scale -
                        1f
                    ) /
                2f
            )
            .coerceAtLeast(
                0f
            )

    private fun clampPan() {
        if (
            zoomScale <=
            1.001f
        ) {
            panXPx =
                0f

            panYPx =
                0f

            return
        }

        panXPx =
            panXPx.coerceIn(
                -maxPanX(),
                maxPanX()
            )

        panYPx =
            panYPx.coerceIn(
                -maxPanY(),
                maxPanY()
            )
    }

    private fun normalizedPanX():
        Float {
        val max =
            maxPanX()

        return if (
            max <= 0f
        ) {
            0f
        } else {
            (
                panXPx /
                    max
                )
                .coerceIn(
                    -1f,
                    1f
                )
        }
    }

    private fun normalizedPanY():
        Float {
        val max =
            maxPanY()

        return if (
            max <= 0f
        ) {
            0f
        } else {
            (
                panYPx /
                    max
                )
                .coerceIn(
                    -1f,
                    1f
                )
        }
    }

    private fun notifyChanged() {
        listener?.invoke(
            zoomScale,
            normalizedPanX(),
            normalizedPanY()
        )
    }

    override fun onTouchEvent(
        event: MotionEvent
    ): Boolean {
        scaleDetector
            .onTouchEvent(
                event
            )

        gestureDetector
            .onTouchEvent(
                event
            )

        when (
            event.actionMasked
        ) {
            MotionEvent
                .ACTION_DOWN -> {
                downX =
                    event.x

                downY =
                    event.y

                lastX =
                    event.x

                lastY =
                    event.y

                dragging =
                    false

                parent
                    ?.requestDisallowInterceptTouchEvent(
                        true
                    )
            }

            MotionEvent
                .ACTION_POINTER_DOWN -> {
                dragging =
                    false

                parent
                    ?.requestDisallowInterceptTouchEvent(
                        true
                    )
            }

            MotionEvent
                .ACTION_MOVE -> {
                if (
                    event.pointerCount >=
                    2 ||
                    scaleDetector
                        .isInProgress
                ) {
                    return true
                }

                if (
                    zoomScale >
                    1.001f
                ) {
                    if (
                        !dragging &&
                        (
                            abs(
                                event.x -
                                    downX
                            ) >
                            touchSlop ||
                            abs(
                                event.y -
                                    downY
                            ) >
                            touchSlop
                            )
                    ) {
                        dragging =
                            true
                    }

                    if (dragging) {
                        panXPx +=
                            event.x -
                                lastX

                        panYPx +=
                            event.y -
                                lastY

                        clampPan()
                        notifyChanged()
                    }
                }

                lastX =
                    event.x

                lastY =
                    event.y
            }

            MotionEvent
                .ACTION_POINTER_UP -> {
                dragging =
                    false

                val remainingIndex =
                    if (
                        event.actionIndex ==
                        0 &&
                        event.pointerCount >
                        1
                    ) {
                        1
                    } else {
                        0
                    }

                if (
                    remainingIndex <
                    event.pointerCount
                ) {
                    lastX =
                        event.getX(
                            remainingIndex
                        )

                    lastY =
                        event.getY(
                            remainingIndex
                        )

                    downX =
                        lastX

                    downY =
                        lastY
                }
            }

            MotionEvent
                .ACTION_UP,
            MotionEvent
                .ACTION_CANCEL -> {
                dragging =
                    false

                parent
                    ?.requestDisallowInterceptTouchEvent(
                        false
                    )

                if (
                    event.actionMasked ==
                    MotionEvent
                        .ACTION_UP
                ) {
                    performClick()
                }
            }
        }

        return true
    }

    override fun performClick():
        Boolean {
        super.performClick()
        return true
    }
}
