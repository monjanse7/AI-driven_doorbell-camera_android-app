package com.example.aidoormonitor

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.net.ConnectivityManager
import android.media.MediaMetadataRetriever
import android.net.Network
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture as CameraXVideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.example.aidoormonitor.ai.AudioAiEvent
import com.example.aidoormonitor.ai.AnimalDetection
import com.example.aidoormonitor.ai.AnimalObjectDetector
import com.example.aidoormonitor.ai.PreviewAiBridge
import com.example.aidoormonitor.ai.ModelDownloader
import com.example.aidoormonitor.ai.PoseBehaviorDetector
import com.example.aidoormonitor.ai.PoseBehaviorState
import com.example.aidoormonitor.ai.SeizureLikeMotionDetector
import com.example.aidoormonitor.ai.SimpleMotionDetector
import com.example.aidoormonitor.ai.YamNetAudioDetector
import com.example.aidoormonitor.net.LanCameraServer
import com.example.aidoormonitor.net.LanCameraEndpoint
import com.example.aidoormonitor.net.LanCameraHub
import com.example.aidoormonitor.net.LocalNetwork
import com.example.aidoormonitor.net.PairInfo
import com.example.aidoormonitor.net.Pairing
import com.example.aidoormonitor.storage.VideoRetentionManager
import com.example.aidoormonitor.storage.Mp4SegmentMerger
import com.example.aidoormonitor.store.EventStore
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.ArrayDeque
import java.util.LinkedHashSet
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.round

@OptIn(ExperimentalCamera2Interop::class)
class DoorMonitoringService : Service(), LifecycleOwner {
    companion object {
        @Volatile
        var isRunning: Boolean = false
            private set

        @Volatile
        var isCameraActivationRequested: Boolean = false
            private set

        const val ACTION_STOP =
            "com.example.aidoormonitor.action.STOP_MONITORING"
        const val ACTION_PREPARE =
            "com.example.aidoormonitor.action.PREPARE_MONITORING"
        const val ACTION_ACTIVATE_CAMERA =
            "com.example.aidoormonitor.action.ACTIVATE_BACKGROUND_CAMERA"
        const val ACTION_START_CAMERA_MODE =
            "com.example.aidoormonitor.action.START_CAMERA_MODE_SERVICE"
        private const val CHANNEL_ID = "door_monitoring"
        private const val NOTIFICATION_ID = 4201
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    private val prefs by lazy {
        getSharedPreferences("camera_settings", MODE_PRIVATE)
    }

    private val eventStore by lazy { EventStore(this) }

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var videoCapture: CameraXVideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recordingReason: String? = null

    private val latestJpeg = LanCameraHub.latestJpeg
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val aiInitExecutor = Executors.newSingleThreadExecutor()
    private val aiFrameExecutor = Executors.newSingleThreadExecutor()
    private val motionDetector = SimpleMotionDetector()
    private val seizureLikeDetector = SeizureLikeMotionDetector()

    private var poseDetector: PoseBehaviorDetector? = null
    private var audioDetector: YamNetAudioDetector? = null
    private var animalDetector: AnimalObjectDetector? = null
    private var previewAiBridge: PreviewAiBridge? = null

    private val audioAiLifecycleLock =
        Any()

    @Volatile
    private var audioAiTransitionInProgress =
        false

    private var server: LanCameraServer? = null
    private var pairInfo: PairInfo? = null

    @Volatile
    private var lanServerRetryQueued =
        false

    @Volatile
    private var lastLanServerError =
        ""

    private val handler = Handler(Looper.getMainLooper())
    private val segmentMs = 60_000L
    private var rollover = false
    @Volatile private var currentSegmentName: String? = null

    private data class PreBufferSegment(
        val file: File,
        val startMs: Long,
        val endMs: Long
    )

    private val preBufferSegments = ArrayDeque<PreBufferSegment>()
    private val protectedPreBufferPaths = mutableSetOf<String>()
    private val eventMergeExecutor = Executors.newSingleThreadExecutor()
    private val preBufferSegmentMs = 2_000L
    private var currentPreBufferFile: File? = null
    private var currentPreBufferStartedAt = 0L
    private var eventCaptureActive = false
    private var eventCaptureStartMs = 0L
    private var eventCaptureUntilMs = 0L
    private val eventCaptureLabels = LinkedHashSet<String>()
    private var lastBufferedEventTriggerAt = 0L

    private var motionRecordingUntil = 0L
    private var motionTriggerFrames = 0
    private var lastMotionMomentAt = 0L

    private var currentZoomRatio = 1f
    private var maxZoomRatio = 1f
    private var cameraZoomLinear = 0f
    private var cameraPanX = 0f
    private var cameraPanY = 0f
    private var sensorActiveArray: Rect? = null
    private var cropCoordinateArray: Rect? = null
    private var freeformCropSupported = false
    private var distortionCorrectionOffAvailable = false

    private var manualFocusSupported = false
    private var maxFocusDiopters = 0f
    private var focusManual = false
    private var focusLinear = 0f
    private var targetFpsRange: Range<Int>? = null

    @Volatile private var lastPoseVisibleAt = 0L
    @Volatile private var lastPoseMotionAt = 0L
    @Volatile private var lastPoseMotionIntensity = 0f
    @Volatile private var lastShoutAt = 0L
    @Volatile private var lastAggressiveAlertAt = 0L
    private var lastFallAlertAt = 0L
    private var lastSeizureAlertAt = 0L

    private val animalConsecutive =
        mutableMapOf<String, Int>()
    private val animalLastSeenAt =
        mutableMapOf<String, Long>()
    private val animalLastEventAt =
        mutableMapOf<String, Long>()
    private val currentRecordingSubjects =
        LinkedHashSet<String>()

    private lateinit var connectivity: ConnectivityManager
    private var networkOnline = true
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    @Volatile private var serviceStopping = false
    private var cameraRestartScheduled = false

    @Volatile private var cameraActivationRequested = false
    @Volatile private var cameraSessionStarting = false
    @Volatile private var framesSeenInSession = 0
    @Volatile private var firstRecordingStartQueued = false
    @Volatile private var latestFrameAtMs = 0L
    @Volatile private var aiStartQueued = false
    @Volatile private var cameraProviderReady = false
    @Volatile private var cameraBindCompleted = false
    @Volatile private var cameraSessionGeneration = 0L
    @Volatile private var recordingFirstMode = false
    @Volatile private var previewAiBridgeMode = false
    @Volatile private var visualAnalysisAvailable = true
    @Volatile private var recordingFirstWorkloadQueued = false
    @Volatile private var framePipelineErrorCount = 0
    @Volatile private var lastFramePipelineError = ""

    private val aiFrameBusy = AtomicBoolean(false)
    @Volatile private var lastAiFrameQueuedAtMs = 0L

    @Volatile private var sourceFps = 0f
    private var sourceFpsWindowStartNs = 0L
    private var sourceFpsFrames = 0

    @Volatile private var thermalStatus = 0
    @Volatile private var lastLivePublishedAtMs = 0L
    @Volatile private var thermalRecordingSuspended = false
    private var thermalListener: PowerManager.OnThermalStatusChangedListener? = null
    private lateinit var thermalPowerManager: PowerManager

    // Requested quality -> FHD -> HD -> live/AI-only fallback.
    private var backgroundCompatibilityLevel = 0
    private var activeBackgroundQualityName = "starting"

    override fun onCreate() {
        super.onCreate()

        isRunning = true
        isCameraActivationRequested = false

        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        createNotificationChannel()

        // Start the camera foreground service while CameraActivity is visible.
        // Use only the foreground-service types for which runtime permission is
        // currently available; this avoids a microphone-type SecurityException
        // from taking down the whole process when only camera permission exists.
        try {
            val foregroundTypes =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    var types =
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA

                    if (ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        types =
                            types or
                                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    }

                    types
                } else {
                    0
                }

            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                buildNotification("Camera monitoring starting…"),
                foregroundTypes
            )
        } catch (t: Throwable) {
            eventStore.add(
                "Camera foreground service rejected",
                t.toString()
            )
            isRunning = false
            stopSelf()
            return
        }

        prefs.edit().putBoolean("background_service_running", true).apply()
        eventStore.add(
            "Screen-off camera service started",
            "Foreground camera service active before the display is turned off."
        )

        acquireWakeLock()
        acquireWifiLock()
        registerThermalGuard()

        connectivity =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        networkOnline = connectivity.activeNetwork != null
        registerNetworkWatcher()

        updateNotification(
            "Camera service created • waiting for camera start…"
        )
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                serviceStopping = true
                isCameraActivationRequested = false

                getSharedPreferences(
                    "camera_settings",
                    MODE_PRIVATE
                )
                    .edit()
                    .putBoolean(
                        "keep_camera_dashboard_open",
                        false
                    )
                    .apply()
                eventStore.add("Screen-off camera service stopped")
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_START_CAMERA_MODE -> {
                serviceStopping = false
                cameraActivationRequested = true
                isCameraActivationRequested = true
                cameraSessionStarting = false
                cameraProviderReady = false
                cameraBindCompleted = false
                framesSeenInSession = 0
                firstRecordingStartQueued = false
                aiStartQueued = false
                recordingFirstMode = false
                visualAnalysisAvailable = true
                recordingFirstWorkloadQueued = false
                backgroundCompatibilityLevel = 0

                prefs.edit()
                    .putBoolean("background_service_running", true)
                    .putBoolean("background_handoff_pending", false)
                    .apply()

                eventStore.add(
                    "Camera Mode service activation",
                    "Direct service-owned CameraX session; no Activity-to-service hand-off is used."
                )

                updateNotification(
                    "Camera monitoring active • screen may be turned off"
                )

                try {
                    ensureLanServerStarted()

                    if (camera == null && !cameraSessionStarting) {
                        startCamera()
                    }

                    scheduleActivationWatchdog()
                } catch (t: Throwable) {
                    cameraSessionStarting = false
                    cameraProviderReady = false
                    cameraBindCompleted = false

                    eventStore.add(
                        "Camera Mode service activation failure",
                        conciseCameraError(t)
                    )

                    updateNotification(
                        "Camera service failed to open camera"
                    )
                }

                return START_NOT_STICKY
            }

            ACTION_PREPARE -> {
                serviceStopping = false
                cameraActivationRequested = false
                isCameraActivationRequested = false
                cameraSessionStarting = false
                cameraProviderReady = false
                cameraBindCompleted = false
                framesSeenInSession = 0
                firstRecordingStartQueued = false
                aiStartQueued = false
                recordingFirstMode = false
                visualAnalysisAvailable = true
                recordingFirstWorkloadQueued = false
                backgroundCompatibilityLevel = 0

                try { recording?.close() } catch (_: Exception) {}
                recording = null
                recordingReason = null

                // PREPARE is intentionally camera-neutral. ProcessCameraProvider
                // is a process singleton, so unbindAll() here would unbind the
                // still-running CameraActivity before it has finalized its MP4.
                // LanCameraHub and latestJpeg must also remain untouched so an
                // already-connected viewer keeps the same socket/frame during
                // the short ownership transfer.
                server = LanCameraHub.server()

                eventStore.add(
                    "24/7 service prepared",
                    "Foreground service ready; Activity still owns CameraX and the persistent LAN stream until ACTIVATE_CAMERA."
                )

                updateNotification(
                    "24/7 service prepared • finishing foreground camera segment…"
                )
                return START_NOT_STICKY
            }

            ACTION_ACTIVATE_CAMERA -> {
                if (serviceStopping) {
                    eventStore.add(
                        "24/7 activation ignored",
                        "Service is stopping."
                    )
                    return START_NOT_STICKY
                }

                cameraActivationRequested = true
                isCameraActivationRequested = true

                // On explicit 4K, skip the ImageAnalysis surface combination.
                // The Edge 30 Ultra binds that combination but supplies no
                // analyzer frames. Stage 2 keeps exact UHD VideoCapture and
                // obtains viewer/AI frames from an off-screen Preview surface.
                if (preserveSelected4KIn247()) {
                    // q3 stability: begin with ordinary CameraX ImageAnalysis.
                    // Do not start the custom OpenGL PreviewAiBridge.
                    backgroundCompatibilityLevel = 0
                }

                eventStore.add(
                    "24/7 activation received",
                    "Service received ACTION_ACTIVATE_CAMERA."
                )

                updateNotification(
                    "Taking over camera for 24/7 monitoring…"
                )

                try {
                    ensureLanServerStarted()
                } catch (t: Throwable) {
                    eventStore.add(
                        "LAN server startup warning",
                        conciseCameraError(t)
                    )
                }

                try {
                    if (
                        camera == null &&
                        !cameraSessionStarting
                    ) {
                        startCamera()
                    }

                    scheduleActivationWatchdog()

                } catch (t: Throwable) {
                    cameraSessionStarting = false
                    cameraProviderReady = false
                    cameraBindCompleted = false

                    eventStore.add(
                        "24/7 activation failure",
                        conciseCameraError(t)
                    )

                    updateNotification(
                        "24/7 camera activation failed • Camera Mode can remain open"
                    )
                }

                return START_NOT_STICKY
            }

            else -> {
                // Recovery/default path if Android recreates the service.
                if (!serviceStopping &&
                    prefs.getBoolean("background_service_running", false)
                ) {
                    cameraActivationRequested = true
                    isCameraActivationRequested = true

                    if (preserveSelected4KIn247()) {
                        backgroundCompatibilityLevel = 0
                    }

                    eventStore.add(
                        "24/7 service recovery",
                        "Android recreated service; requesting camera session."
                    )

                    if (camera == null && !cameraSessionStarting) {
                        startCamera()
                    }

                    scheduleActivationWatchdog()
                }
                return START_NOT_STICKY
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun scheduleActivationWatchdog() {
        val generation =
            cameraSessionGeneration

        handler.postDelayed({
            if (
                serviceStopping ||
                !cameraActivationRequested ||
                generation != cameraSessionGeneration ||
                recordingFirstMode ||
                framesSeenInSession > 0
            ) {
                return@postDelayed
            }

            // A successfully bound camera is owned by the per-session first
            // frame watchdog. Do not restart the same stage here.
            if (cameraBindCompleted) {
                return@postDelayed
            }

            eventStore.add(
                "24/7 provider/bind watchdog",
                "Camera setup did not finish • generation=$generation • providerReady=$cameraProviderReady • sessionStarting=$cameraSessionStarting"
            )

            cameraSessionStarting = false
            cameraProviderReady = false
            cameraBindCompleted = false
            firstRecordingStartQueued = false
            latestJpeg.set(null)

            try { recording?.close() } catch (_: Exception) {}
            recording = null
            recordingReason = null

            server = LanCameraHub.server()

            try { cameraProvider?.unbindAll() } catch (_: Exception) {}
            camera = null
            videoCapture = null

            startCamera()
        }, 8_000L)
    }

    private fun scheduleFirstFrameWatchdog(
        generation: Long,
        sessionLevel: Int
    ) {
        val delay =
            if (exactQuality247Mode()) 2_750L else 5_000L

        handler.postDelayed({
            if (
                serviceStopping ||
                generation != cameraSessionGeneration ||
                recordingFirstMode ||
                !cameraActivationRequested ||
                framesSeenInSession > 0 ||
                backgroundCompatibilityLevel != sessionLevel ||
                !cameraBindCompleted
            ) {
                return@postDelayed
            }

            val failedStage =
                currentCompatibilityStageLabel()

            val sourceName =
                if (previewAiBridgeMode) "Preview AI bridge"
                else "ImageAnalysis"

            eventStore.add(
                "24/7 first-frame watchdog",
                "No $sourceName frame • $failedStage • generation=$generation"
            )

            increaseCompatibilityAndRestart(
                "no first $sourceName frame at $failedStage"
            )
        }, delay)
    }

    private fun registerThermalGuard() {
        thermalPowerManager =
            getSystemService(Context.POWER_SERVICE) as PowerManager

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            thermalStatus = 0
            return
        }

        thermalStatus =
            thermalPowerManager.currentThermalStatus

        val listener =
            PowerManager.OnThermalStatusChangedListener { status ->
                handler.post {
                    applyThermalStatus(status)
                }
            }

        thermalListener = listener

        try {
            thermalPowerManager.addThermalStatusListener(
                ContextCompat.getMainExecutor(this),
                listener
            )
        } catch (_: Exception) {}
    }

    private fun thermalName(
        status: Int
    ): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return "UNAVAILABLE"
        }

        return when (status) {
            PowerManager.THERMAL_STATUS_NONE -> "NONE"
            PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
            PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
            PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
            PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
            else -> "UNKNOWN($status)"
        }
    }

    private fun applyThermalStatus(
        newStatus: Int
    ) {
        val oldStatus = thermalStatus
        thermalStatus = newStatus

        if (oldStatus != newStatus) {
            eventStore.add(
                "Thermal Guard",
                "status=${thermalName(newStatus)} • live=${effectiveLiveFps()}fps • visualAI=${effectiveAiFps()}fps • recording=${if (thermalRecordingAllowed()) "allowed" else "temporarily suspended"}"
            )
        }

        if (!thermalRecordingAllowed()) {
            if (!thermalRecordingSuspended) {
                thermalRecordingSuspended = true
                firstRecordingStartQueued = false

                if (recording != null) {
                    try {
                        recording?.stop()
                    } catch (_: Exception) {}
                }

                updateNotification(
                    "Thermal Guard ${thermalName(newStatus)} • MP4 paused • low-load live monitoring"
                )
            }
        } else {
            if (thermalRecordingSuspended) {
                thermalRecordingSuspended = false
                firstRecordingStartQueued = false

                eventStore.add(
                    "Thermal Guard recovery",
                    "Temperature state improved • continuous recording may resume automatically."
                )

                updateNotification(
                    "Thermal Guard recovered • recording can resume"
                )
                handler.postDelayed({
                    if (recording == null && videoCapture != null) {
                        if (prefs.getBoolean("continuous_recording", false))
                            startRecording("continuous_background")
                        else if (prefs.getBoolean("event_pre_record_enabled", false))
                            startPreBufferSegment()
                    }
                }, 500L)
            }
        }
    }

    private fun effectiveLiveFps(): Int {
        val cool =
            prefs.getBoolean("cool_24_7_mode", true)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return when {
                thermalStatus >= PowerManager.THERMAL_STATUS_CRITICAL -> 6
                thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE -> 12
                thermalStatus >= PowerManager.THERMAL_STATUS_MODERATE -> 20
                thermalStatus >= PowerManager.THERMAL_STATUS_LIGHT -> 24
                else -> 10
            }
        }

        return 10
    }

    private fun effectiveAiFps(): Int {
        // Normal target is 10 fps even in Cool 24/7 mode.  Thermal Guard
        // reduces inference rate only when Android reports real heat pressure.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return when {
                thermalStatus >= PowerManager.THERMAL_STATUS_CRITICAL -> 1
                thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE -> 3
                thermalStatus >= PowerManager.THERMAL_STATUS_MODERATE -> 5
                thermalStatus >= PowerManager.THERMAL_STATUS_LIGHT -> 8
                else -> 10
            }
        }

        return 10
    }

    private fun effectiveJpegQuality(): Int {
        var quality =
            previewBaseJpegQuality()

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {
            quality =
                when {
                    thermalStatus >=
                        PowerManager.THERMAL_STATUS_CRITICAL ->
                        minOf(quality, 30)

                    thermalStatus >=
                        PowerManager.THERMAL_STATUS_SEVERE ->
                        minOf(quality, 34)

                    thermalStatus >=
                        PowerManager.THERMAL_STATUS_MODERATE ->
                        minOf(quality, 38)

                    thermalStatus >=
                        PowerManager.THERMAL_STATUS_LIGHT ->
                        minOf(quality, 44)

                    else -> quality
                }
        }

        return quality.coerceIn(28, 75)
    }

    private fun effectiveLiveIntervalMs(): Long =
        (1000L / effectiveLiveFps().coerceAtLeast(1))

    private fun effectiveAiIntervalMs(): Long =
        (1000L / effectiveAiFps().coerceAtLeast(1))

    private fun thermalRecordingAllowed(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return true
        }

        return thermalStatus <
            PowerManager.THERMAL_STATUS_CRITICAL
    }

    private fun normalizedQualityIndex(): Int {
        val schema =
            prefs.getInt("quality_schema_version", 1)

        if (schema < 4) {
            val old =
                prefs.getInt("quality_index", 0)

            val migrated =
                when (schema) {
                    1 -> when (old) {
                        1 -> 2 // old 1080p
                        2 -> 3 // old 720p
                        else -> 1 // old 4K
                    }

                    2 -> when (old) {
                        0 -> 1 // 4K
                        1 -> 2 // QHD -> stable FHD
                        2 -> 2 // FHD
                        3 -> 3 // HD
                        else -> 1
                    }

                    else -> when (old) {
                        0 -> 0 // HIGHEST
                        1 -> 1 // UHD
                        2 -> 2 // QHD -> stable FHD
                        3 -> 2 // FHD
                        4 -> 3 // HD
                        else -> 1
                    }
                }

            prefs.edit()
                .putInt("quality_index", migrated)
                .putInt("quality_schema_version", 4)
                .apply()

            return migrated
        }

        return prefs.getInt(
            "quality_index",
            1
        ).coerceIn(0, 3)
    }

    private fun selectedQuality(): Quality =
        when (normalizedQualityIndex()) {
            0 -> Quality.HIGHEST
            1 -> Quality.UHD
            2 -> Quality.FHD
            3 -> Quality.HD
            else -> Quality.UHD
        }

    private fun selectedQualityName(): String =
        when (normalizedQualityIndex()) {
            0 -> "8K UHD / 4320p requested"
            1 -> "4K UHD"
            2 -> "1080p Full HD"
            3 -> "720p HD"
            else -> "4K UHD"
        }

    private fun isAtLeast8K(
        size: Size?
    ): Boolean {
        if (size == null) return false

        val longSide =
            maxOf(size.width, size.height)

        val shortSide =
            minOf(size.width, size.height)

        return longSide >= 7680 &&
            shortSide >= 4320
    }

    private fun resolutionLabel(
        size: Size?
    ): String =
        if (size == null) {
            "unknown"
        } else {
            "${size.width}×${size.height}"
        }

    private fun resolutionTierLabel(
        size: Size?
    ): String {
        if (size == null) return "unknown"

        val longSide =
            maxOf(size.width, size.height)

        val shortSide =
            minOf(size.width, size.height)

        return when {
            longSide >= 7680 &&
                shortSide >= 4320 ->
                "8K UHD"

            longSide >= 3840 &&
                shortSide >= 2160 ->
                "4K UHD"

            longSide >= 2560 &&
                shortSide >= 1440 ->
                "2K QHD"

            longSide >= 1920 &&
                shortSide >= 1080 ->
                "1080p Full HD"

            longSide >= 1280 &&
                shortSide >= 720 ->
                "720p HD"

            else ->
                "${size.width}×${size.height}"
        }
    }

    private fun qualityLabel(quality: Quality): String =
        when (quality) {
            Quality.HIGHEST -> "Highest available"
            Quality.UHD -> "4K UHD"
            Quality.FHD -> "1080p Full HD"
            Quality.HD -> "720p HD"
            Quality.SD -> "480p SD"
            else -> "Camera quality"
        }

    private fun resolvedRecordingQualityName(
        requested: Quality,
        resolved: Size?
    ): String {
        val dimensions =
            resolutionLabel(resolved)

        val tier =
            resolutionTierLabel(resolved)

        return when {
            requested == Quality.HIGHEST &&
                isAtLeast8K(resolved) ->
                "8K UHD / $dimensions"

            requested == Quality.HIGHEST ->
                "8K requested → camera max $dimensions ($tier)"

            else ->
                "${qualityLabel(requested)} • resolved=$dimensions"
        }
    }

    private fun resolvedQualityClaim(
        requested: Quality,
        resolved: Size?
    ): String =
        if (requested == Quality.HIGHEST) {
            if (isAtLeast8K(resolved)) {
                "true 8K available"
            } else {
                "8K unavailable; HIGHEST=${resolutionLabel(resolved)} (${resolutionTierLabel(resolved)})"
            }
        } else {
            "selected resolution preserved"
        }

    private fun recordingMode(): Int =
        prefs.getInt(
            "recording_mode",
            1
        ).coerceIn(0, 2)

    private fun strictRecordingQuality(): Boolean =
        recordingMode() == 0

    private fun bestSimultaneousMode(): Boolean =
        recordingMode() == 1

    /**
     * Motorola Edge 30 Ultra / 4K policy:
     * when the user explicitly selects UHD we never silently lower the
     * recording stream just to keep ImageAnalysis alive.  The service
     * preserves exact UHD and uses the off-screen Preview bridge for the
     * viewer/AI path instead.
     */
    private fun preserveSelected4KIn247(): Boolean =
        selectedQuality() == Quality.UHD

    private fun exactQuality247Mode(): Boolean =
        strictRecordingQuality() || preserveSelected4KIn247()

    private fun previewAiPriorityMode(): Boolean =
        recordingMode() == 2

    private fun recordingModeName(): String =
        when (recordingMode()) {
            0 -> "Strict Recording Quality"
            2 -> "Preview / AI Priority"
            else -> "Best Simultaneous Quality"
        }

    private fun requestedBackgroundQuality(): Quality {
        val selected =
            selectedQuality()

        if (strictRecordingQuality() || preserveSelected4KIn247()) {
            return selected
        }

        return if (
            prefs.getBoolean(
                "cool_24_7_mode",
                true
            ) &&
            (
                selected == Quality.HIGHEST ||
                selected == Quality.UHD
            )
        ) {
            Quality.FHD
        } else {
            selected
        }
    }

    private fun backgroundQualityCandidates(): List<Quality> {
        val requested =
            requestedBackgroundQuality()

        if (strictRecordingQuality()) {
            return listOf(requested)
        }

        return when (requested) {
            Quality.HIGHEST ->
                listOf(
                    Quality.HIGHEST,
                    Quality.UHD,
                    Quality.FHD,
                    Quality.HD
                )

            Quality.UHD ->
                listOf(
                    Quality.UHD,
                    Quality.FHD,
                    Quality.HD
                )

            Quality.FHD ->
                listOf(
                    Quality.FHD,
                    Quality.HD
                )

            else ->
                listOf(Quality.HD)
        }
    }

    private fun conciseCameraError(
        error: Throwable
    ): String {
        val msg =
            error.message
                ?: error.javaClass.simpleName

        return when {
            msg.contains(
                "No supported surface combination",
                ignoreCase = true
            ) ->
                "unsupported surface combination"

            msg.contains(
                "CameraException",
                ignoreCase = true
            ) ->
                "CameraX camera combination unsupported"

            else ->
                msg.lineSequence()
                    .firstOrNull()
                    ?.take(180)
                    ?: error.javaClass.simpleName
        }
    }

    private fun nonStrictStageLabel(): String {
        val quality =
            effectiveBackgroundQualityName()

        val analysis =
            if (useUltraLowAnalysisResolution())
                "320×180"
            else
                "480×270"

        return "$quality + ImageAnalysis $analysis"
    }

    private fun strictCompatibilityStage(): Int =
        backgroundCompatibilityLevel
            .coerceIn(0, 5)

    private fun strictCompatibilityStageLabel(): String {
        val quality = selectedQualityName()

        return when (strictCompatibilityStage()) {
            0 -> "$quality + ImageAnalysis 1280×720 @ target 10 fps"
            1 -> "$quality + ImageAnalysis 960×540 @ target 10 fps"
            2 -> "$quality + ImageAnalysis 640×360 @ target 10 fps"
            3 -> "$quality + ImageAnalysis 480×270 @ target 10 fps"
            4 -> "$quality + ImageAnalysis 320×180 @ target 10 fps"
            else -> "Recording-First $quality • no visual AI"
        }
    }

    private fun analysisResolutionForCurrentStage(): Size =
        if (exactQuality247Mode()) {
            when (strictCompatibilityStage()) {
                0 -> Size(1280, 720)
                1 -> Size(960, 540)
                2 -> Size(640, 360)
                3 -> Size(480, 270)
                else -> Size(320, 180)
            }
        } else {
            if (useUltraLowAnalysisResolution()) Size(320, 180)
            else Size(640, 360)
        }

    private fun currentCompatibilityStageLabel(): String =
        if (exactQuality247Mode()) {
            strictCompatibilityStageLabel()
        } else {
            nonStrictStageLabel()
        }

    private fun useUltraLowAnalysisResolution(): Boolean {
        if (exactQuality247Mode()) {
            // Exact-quality stage 0 = selected quality + 480×270 analysis
            // Strict stage 1 = exact quality + 320×180 analysis
            // Strict stages 2..4 use the off-screen Preview AI bridge at
            // progressively smaller resolutions. Stage 5 is recording-only.
            return strictCompatibilityStage() == 1
        }

        val candidates =
            backgroundQualityCandidates()

        return backgroundCompatibilityLevel ==
            candidates.size
    }

    private fun effectiveBackgroundQuality(): Quality? {
        if (exactQuality247Mode()) {
            return if (strictCompatibilityStage() <= 4) {
                requestedBackgroundQuality()
            } else {
                null
            }
        }

        val candidates =
            backgroundQualityCandidates()

        return when {
            backgroundCompatibilityLevel <
                candidates.size ->
                candidates[
                    backgroundCompatibilityLevel
                ]

            backgroundCompatibilityLevel ==
                candidates.size ->
                candidates.lastOrNull()

            else ->
                null
        }
    }

    private fun effectiveBackgroundQualityName(): String =
        when (effectiveBackgroundQuality()) {
            Quality.HIGHEST -> "8K / highest available"
            Quality.UHD -> "4K UHD"
            Quality.FHD -> "1080p Full HD"
            Quality.HD -> "720p HD"
            Quality.SD -> "480p SD"
            null -> "Live/AI compatibility mode"
            else -> "Camera quality"
        }


    private fun selectedCameraSelector(provider: ProcessCameraProvider): CameraSelector {
        val key = prefs.getString(
            "camera_choice_key",
            CameraChoiceRepository.DEFAULT_BACK_KEY
        )
        val requested = try {
            CameraChoiceRepository.selectorForKey(key)
        } catch (t: Throwable) {
            eventStore.add(
                "Camera selector warning",
                "${t.message ?: t.javaClass.simpleName} • falling back to rear automatic"
            )
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        return try {
            if (provider.hasCamera(requested)) requested
            else CameraSelector.DEFAULT_BACK_CAMERA
        } catch (_: Throwable) {
            CameraSelector.DEFAULT_BACK_CAMERA
        }
    }

    private fun startCamera() {
        if (serviceStopping || cameraSessionStarting) return

        cameraSessionGeneration++
        val sessionGeneration =
            cameraSessionGeneration

        eventStore.add(
            "Camera service start requested",
            "stage=${currentCompatibilityStageLabel()} • generation=$sessionGeneration • lifecycle=${lifecycle.currentState}"
        )

        cameraSessionStarting = true
        cameraProviderReady = false
        cameraBindCompleted = false
        recordingFirstMode = false
        previewAiBridgeMode = false
        visualAnalysisAvailable = true
        recordingFirstWorkloadQueued = false
        framesSeenInSession = 0
        firstRecordingStartQueued = false
        // Keep the last Activity-produced JPEG published while CameraX is
        // rebinding in the service. The MJPEG client keeps displaying that
        // frame until the first real service frame replaces it.
        latestFrameAtMs = 0L
        lastFramePipelineError = ""

        scheduleActivationWatchdog()

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            if (
                serviceStopping ||
                sessionGeneration != cameraSessionGeneration
            ) {
                return@addListener
            }

            val provider = try {
                future.get()
            } catch (e: Exception) {
                cameraSessionStarting = false
                eventStore.add(
                    "Camera service CameraProvider failed",
                    conciseCameraError(e)
                )
                updateNotification(
                    "CameraProvider failed • retrying…"
                )
                handler.postDelayed({
                    if (
                        !serviceStopping &&
                        sessionGeneration == cameraSessionGeneration
                    ) {
                        startCamera()
                    }
                }, 1_500L)
                return@addListener
            }

            cameraProviderReady = true

            eventStore.add(
                "Camera service CameraProvider ready",
                "Available cameras=${provider.availableCameraInfos.size}"
            )

            cameraProvider = provider
            val cameraSelector = selectedCameraSelector(provider)

            try {
                previewAiBridge?.stop()
            } catch (_: Exception) {}
            previewAiBridge = null

            try {
                provider.unbindAll()
            } catch (_: Exception) {}

            val analysisSize = analysisResolutionForCurrentStage()

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(
                    ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
                )
                // q3 stability: request ordinary YUV_420_888 buffers.
                // The previous custom NV21 + OpenGL bridge path was much more
                // device-sensitive and could terminate Camera Mode on some OEMs.
                .setTargetResolution(analysisSize)
                .build()

            analysis.setAnalyzer(analysisExecutor) { image ->
                processFrame(image)
            }

            val quality = effectiveBackgroundQuality()
            activeBackgroundQualityName =
                effectiveBackgroundQualityName()

            if (quality != null) {
                val qualitySelector =
                    if (exactQuality247Mode()) {
                        QualitySelector.from(
                            quality
                        )
                    } else {
                        QualitySelector.fromOrderedList(
                            when (quality) {
                                Quality.HIGHEST ->
                                    listOf(
                                        Quality.HIGHEST,
                                        Quality.UHD,
                                        Quality.FHD,
                                        Quality.HD,
                                        Quality.SD
                                    )

                                Quality.UHD ->
                                    listOf(
                                        Quality.UHD,
                                        Quality.FHD,
                                        Quality.HD,
                                        Quality.SD
                                    )

                                Quality.FHD ->
                                    listOf(
                                        Quality.FHD,
                                        Quality.HD,
                                        Quality.SD
                                    )

                                else ->
                                    listOf(
                                        Quality.HD,
                                        Quality.SD
                                    )
                            },
                            FallbackStrategy
                                .lowerQualityOrHigherThan(
                                    Quality.SD
                                )
                        )
                    }

                val recorder = Recorder.Builder()
                    .setQualitySelector(qualitySelector)
                    .build()

                val capture =
                    CameraXVideoCapture.withOutput(recorder)

                try {
                    camera = provider.bindToLifecycle(
                        this,
                        cameraSelector,
                        analysis,
                        capture
                    )
                    videoCapture = capture
                    cameraBindCompleted = true
                    recordingFirstMode = false
                    visualAnalysisAvailable = true

                    val resolvedResolution =
                        try {
                            QualitySelector.getResolution(
                                camera!!.cameraInfo,
                                quality
                            )
                        } catch (_: Exception) {
                            null
                        }

                    activeBackgroundQualityName =
                        resolvedRecordingQualityName(
                            quality,
                            resolvedResolution
                        )

                    eventStore.add(
                        "24/7 CameraX bind complete",
                        "${recordingModeName()} • ${currentCompatibilityStageLabel()} • active=$activeBackgroundQualityName"
                    )

                    if (bestSimultaneousMode()) {
                        eventStore.add(
                            "Best simultaneous quality selected",
                            "$activeBackgroundQualityName works with live ImageAnalysis on this camera."
                        )
                    }
                } catch (e: Exception) {
                    cameraSessionStarting = false
                    val failedStage =
                        currentCompatibilityStageLabel()

                    eventStore.add(
                        "24/7 camera compatibility fallback",
                        "$failedStage unsupported • ${conciseCameraError(e)}"
                    )

                    increaseCompatibilityAndRestart(
                        "bind failure at $failedStage"
                    )
                    return@addListener
                }
            } else {
                if (exactQuality247Mode()) {
                    // q3 stability final stage: exact recording only.
                    // No custom OpenGL PreviewAiBridge is used.
                    val exactQuality = requestedBackgroundQuality()
                    val exactSelector = QualitySelector.from(exactQuality)
                    val recorder = Recorder.Builder()
                        .setQualitySelector(exactSelector)
                        .build()
                    val capture = CameraXVideoCapture.withOutput(recorder)

                    try {
                        camera = provider.bindToLifecycle(
                            this,
                            cameraSelector,
                            capture
                        )

                        videoCapture = capture
                        cameraBindCompleted = true
                        recordingFirstMode = true
                        previewAiBridgeMode = false
                        visualAnalysisAvailable = false
                        framesSeenInSession = 0
                        latestJpeg.set(null)

                        val resolvedResolution =
                            try {
                                QualitySelector.getResolution(
                                    camera!!.cameraInfo,
                                    exactQuality
                                )
                            } catch (_: Exception) {
                                null
                            }

                        activeBackgroundQualityName =
                            resolvedRecordingQualityName(
                                exactQuality,
                                resolvedResolution
                            )

                        eventStore.add(
                            "Recording-first camera mode",
                            "Final compatibility stage • $activeBackgroundQualityName • visual AI unavailable."
                        )

                        updateNotification(
                            "Recording-first • $activeBackgroundQualityName"
                        )
                    } catch (recordingOnlyError: Exception) {
                        cameraSessionStarting = false
                        videoCapture = null
                        recordingFirstMode = false
                        previewAiBridgeMode = false
                        visualAnalysisAvailable = false

                        eventStore.add(
                            "Strict recording camera failed",
                            "${selectedQualityName()} • ${conciseCameraError(recordingOnlyError)}"
                        )

                        updateNotification(
                            "Selected recording resolution unavailable"
                        )

                        return@addListener
                    }

                } else {
                    // Non-strict last resort: preserve live Monitor/visual AI.
                    try {
                        camera =
                            provider.bindToLifecycle(
                                this,
                                cameraSelector,
                                analysis
                            )

                        videoCapture = null
                        cameraBindCompleted = true
                        recordingFirstMode = false
                        previewAiBridgeMode = false
                        visualAnalysisAvailable = true

                        eventStore.add(
                            "24/7 CameraX bind complete",
                            "ImageAnalysis only • Live/AI compatibility mode"
                        )

                        activeBackgroundQualityName =
                            "Live/AI compatibility mode"

                        eventStore.add(
                            "24/7 compatibility mode",
                            "${recordingModeName()} • no simultaneous recording quality worked • live viewer and visual AI preserved."
                        )
                    } catch (e: Exception) {
                        cameraSessionStarting = false
                        eventStore.add(
                            "Background camera failed",
                            e.message
                                ?: "unknown camera error"
                        )
                        updateNotification(
                            "Camera failed — reopen app to retry"
                        )
                        return@addListener
                    }
                }
            }

            configureCameraControls()
            startLanServer()

            cameraSessionStarting = false

            if (recordingFirstMode) {
                updateNotification(
                    "Recording-first camera ready • $activeBackgroundQualityName"
                )

                eventStore.add(
                    "24/7 camera bound",
                    "VideoCapture only • $activeBackgroundQualityName"
                )

                queueAudioAiForRecordingFirstMode()
                queueRecordingFirstWorkload()

            } else {
                updateNotification(
                    "Camera bound • waiting for visual frames • $activeBackgroundQualityName"
                )

                eventStore.add(
                    "24/7 camera bound",
                    if (previewAiBridgeMode)
                        "Waiting for Preview AI bridge frames • $activeBackgroundQualityName"
                    else
                        "Waiting for ImageAnalysis frames • $activeBackgroundQualityName"
                )
            }

            if (!recordingFirstMode) {
                scheduleFirstFrameWatchdog(
                    generation = sessionGeneration,
                    sessionLevel = backgroundCompatibilityLevel
                )
            }

        }, ContextCompat.getMainExecutor(this))
    }

    private fun increaseCompatibilityAndRestart(
        reason: String
    ) {
        if (serviceStopping) return

        // Invalidate all callbacks that belong to the old camera session.
        cameraSessionGeneration++

        if (exactQuality247Mode()) {
            if (backgroundCompatibilityLevel < 5) {
                backgroundCompatibilityLevel++
            }
        } else {
            val maxLevel =
                backgroundQualityCandidates().size

            // level == maxLevel is the ultra-low ImageAnalysis stage.
            // It must be allowed to advance once more to the final
            // ImageAnalysis-only compatibility stage instead of looping on
            // the same 720p/320x180 stage forever.
            if (
                backgroundCompatibilityLevel <=
                maxLevel
            ) {
                backgroundCompatibilityLevel++
            }
        }

        val next =
            currentCompatibilityStageLabel()

        updateNotification(
            "Camera fallback → $next"
        )

        eventStore.add(
            "24/7 camera fallback",
            "$reason • next stage=$next"
        )

        handler.postDelayed({
            if (serviceStopping) return@postDelayed

            try {
                recording?.close()
            } catch (_: Exception) {}

            recording = null
            recordingReason = null

            // Keep LAN /health and /events alive while CameraX moves
            // between compatibility stages.
            latestJpeg.set(null)

            try {
                previewAiBridge?.stop()
            } catch (_: Exception) {}
            previewAiBridge = null

            try {
                cameraProvider?.unbindAll()
            } catch (_: Exception) {}

            camera = null
            videoCapture = null
            recordingFirstMode = false
            visualAnalysisAvailable = true
            recordingFirstWorkloadQueued = false
            framesSeenInSession = 0
            firstRecordingStartQueued = false
            cameraSessionStarting = false
            cameraProviderReady = false
            cameraBindCompleted = false
            latestJpeg.set(null)

            startCamera()
        },
            when {
                strictRecordingQuality() ->
                    250L

                bestSimultaneousMode() ->
                    300L

                else ->
                    500L
            }
        )
    }

    private fun queueRecordingFirstWorkload() {
        if (
            serviceStopping ||
            !recordingFirstMode ||
            videoCapture == null ||
            recordingFirstWorkloadQueued
        ) {
            return
        }

        recordingFirstWorkloadQueued = true

        // Recorder source is already bound, but give CameraX/encoder a short
        // settle period before requesting the first MP4/pre-buffer segment.
        handler.postDelayed({
            recordingFirstWorkloadQueued = false

            if (
                serviceStopping ||
                !recordingFirstMode ||
                videoCapture == null ||
                !thermalRecordingAllowed()
            ) {
                return@postDelayed
            }

            if (
                prefs.getBoolean(
                    "continuous_recording",
                    false
                )
            ) {
                if (recording == null) {
                    eventStore.add(
                        "Recording-first start",
                        "Starting $activeBackgroundQualityName continuous MP4 without visual ImageAnalysis."
                    )
                    startRecording(
                        "continuous_background"
                    )
                }

            } else if (
                prefs.getBoolean(
                    "event_pre_record_enabled",
                    true
                )
            ) {
                if (recording == null) {
                    eventStore.add(
                        "Event pre-record armed",
                        "$activeBackgroundQualityName rolling buffer active in recording-first mode. Visual motion/pose triggers unavailable; audio events remain available."
                    )
                    startPreBufferSegment()
                }
            }
        }, 900L)
    }

    private fun recordingAudioEnabled(): Boolean =
        prefs.getBoolean(
            "recording_audio_enabled",
            true
        )

    private fun microphonePermissionGranted(): Boolean =
        ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) ==
            PackageManager.PERMISSION_GRANTED

    private fun videoRecorderOwnsMicrophoneByPolicy(): Boolean =
        recordingAudioEnabled() &&
            (
                prefs.getBoolean(
                    "continuous_recording",
                    false
                ) ||
                prefs.getBoolean(
                    "event_pre_record_enabled",
                    true
                ) ||
                recording != null
            )

    private fun suspendAudioAiForVideoRecording() {
        synchronized(
            audioAiLifecycleLock
        ) {
            if (!recordingAudioEnabled()) {
                return
            }

            audioAiTransitionInProgress =
                true

            val detector =
                audioDetector

            audioDetector =
                null

            try {
                detector?.stop()
            } catch (t: Throwable) {
                eventStore.add(
                    "Audio AI stop warning",
                    t.message
                        ?: t.javaClass.simpleName
                )
            } finally {
                audioAiTransitionInProgress =
                    false
            }

            if (detector != null) {
                eventStore.add(
                    "Microphone switched to MP4",
                    "Audio AI paused before CameraX requested microphone audio."
                )
            }
        }
    }

    private fun startAudioAiIfAvailable() {
        synchronized(
            audioAiLifecycleLock
        ) {
            if (
                serviceStopping ||
                audioAiTransitionInProgress ||
                videoRecorderOwnsMicrophoneByPolicy() ||
                !prefs.getBoolean(
                    "audio_ai_detection",
                    true
                ) ||
                !ModelDownloader.yamnetReady(
                    this
                ) ||
                !microphonePermissionGranted() ||
                audioDetector != null
            ) {
                return
            }

            audioAiTransitionInProgress =
                true

            try {
                val detector =
                    YamNetAudioDetector(
                        this,
                        ModelDownloader.yamnetFile(
                            this
                        ),
                        onEvent =
                            ::handleAudioEvent,
                        onStatus = {
                            if (
                                it.contains(
                                    "failed",
                                    true
                                ) ||
                                it.contains(
                                    "error",
                                    true
                                )
                            ) {
                                eventStore.add(
                                    "Audio AI status",
                                    it
                                )
                            }
                        }
                    )

                detector.start()

                if (
                    serviceStopping ||
                    videoRecorderOwnsMicrophoneByPolicy()
                ) {
                    try {
                        detector.stop()
                    } catch (_: Throwable) {}

                    eventStore.add(
                        "Audio AI deferred",
                        "MP4/pre-record microphone priority became active during YamNet initialization."
                    )

                    return
                }

                audioDetector =
                    detector

                eventStore.add(
                    "Audio AI active",
                    "YamNet microphone listening active while MP4 audio is idle."
                )

            } catch (t: Throwable) {
                audioDetector =
                    null

                eventStore.add(
                    "Audio AI initialization failed",
                    t.message
                        ?: t.javaClass.simpleName
                )

            } finally {
                audioAiTransitionInProgress =
                    false
            }
        }
    }

    private fun scheduleAudioAiResume() {
        if (
            !prefs.getBoolean(
                "audio_ai_detection",
                true
            )
        ) {
            return
        }

        handler.postDelayed({
            if (
                !serviceStopping &&
                !videoRecorderOwnsMicrophoneByPolicy()
            ) {
                startAudioAiIfAvailable()
            }
        }, 1_200L)
    }

    private fun queueAudioAiForRecordingFirstMode() {
        if (
            aiStartQueued ||
            serviceStopping ||
            !recordingFirstMode
        ) {
            return
        }

        aiStartQueued = true

        aiInitExecutor.execute {
            try {
                if (serviceStopping) {
                    return@execute
                }

                if (
                    videoRecorderOwnsMicrophoneByPolicy()
                ) {
                    eventStore.add(
                        "Recording-first microphone",
                        "MP4/pre-record owns the microphone • YamNet Audio AI remains paused."
                    )
                    return@execute
                }

                startAudioAiIfAvailable()

            } catch (t: Throwable) {
                eventStore.add(
                    "Recording-first Audio AI warning",
                    t.message
                        ?: t.javaClass.simpleName
                )
            }
        }
    }

    private fun configureCameraControls() {
        val cam = camera ?: return
        try {
            val info =
                Camera2CameraInfo.from(
                    cam.cameraInfo
                )

            sensorActiveArray =
                info.getCameraCharacteristic(
                    CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE
                )

            val cropType =
                info.getCameraCharacteristic(
                    CameraCharacteristics.SCALER_CROPPING_TYPE
                ) ?: CameraMetadata.SCALER_CROPPING_TYPE_CENTER_ONLY

            freeformCropSupported =
                cropType ==
                    CameraMetadata.SCALER_CROPPING_TYPE_FREEFORM

            val distortionModes =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    info.getCameraCharacteristic(
                        CameraCharacteristics
                            .DISTORTION_CORRECTION_AVAILABLE_MODES
                    ) ?: intArrayOf()
                } else {
                    intArrayOf()
                }

            distortionCorrectionOffAvailable =
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                    distortionModes.contains(
                        CaptureRequest.DISTORTION_CORRECTION_MODE_OFF
                    )

            val preCorrection =
                info.getCameraCharacteristic(
                    CameraCharacteristics
                        .SENSOR_INFO_PRE_CORRECTION_ACTIVE_ARRAY_SIZE
                )

            cropCoordinateArray =
                if (
                    distortionCorrectionOffAvailable &&
                    preCorrection != null
                ) {
                    preCorrection
                } else {
                    sensorActiveArray
                }

            maxZoomRatio =
                (
                    info.getCameraCharacteristic(
                        CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM
                    ) ?: 1f
                ).coerceAtLeast(1f)

            cameraZoomLinear =
                prefs.getFloat("camera_zoom_linear", 0f)
                    .coerceIn(0f, 1f)

            cameraPanX =
                prefs.getFloat("camera_pan_x", 0f)
                    .coerceIn(-1f, 1f)

            cameraPanY =
                prefs.getFloat("camera_pan_y", 0f)
                    .coerceIn(-1f, 1f)

            currentZoomRatio =
                1f +
                    cameraZoomLinear *
                        (maxZoomRatio - 1f)

            maxFocusDiopters =
                info.getCameraCharacteristic(
                    CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE
                ) ?: 0f

            val capabilities =
                info.getCameraCharacteristic(
                    CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES
                ) ?: intArrayOf()

            manualFocusSupported =
                maxFocusDiopters > 0f &&
                    capabilities.contains(
                        CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR
                    )

            val ranges =
                info.getCameraCharacteristic(
                    CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES
                ) ?: emptyArray()

            targetFpsRange = ranges
                .filter { it.contains(30) }
                .minWithOrNull(
                    compareBy<Range<Int>> { it.upper - it.lower }
                        .thenByDescending { it.lower }
                )

            focusManual =
                prefs.getBoolean("focus_manual", false) && manualFocusSupported
            focusLinear =
                prefs.getFloat("focus_linear", 0f).coerceIn(0f, 1f)

            eventStore.add(
                "Camera pan capability",
                if (freeformCropSupported)
                    "FREEFORM sensor crop supported."
                else
                    "CENTER_ONLY camera crop; live-view software pan fallback enabled."
            )

            applyCamera2Controls()
        } catch (e: Exception) {
            eventStore.add("Camera control warning", e.message ?: "unknown")
        }
    }

    private fun applyCamera2Controls() {
        val cam = camera ?: return
        try {
            val builder = CaptureRequestOptions.Builder()

            targetFpsRange?.let {
                builder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE,
                    it
                )
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                builder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_ZOOM_RATIO,
                    1.0f
                )
            }

            if (
                distortionCorrectionOffAvailable &&
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
            ) {
                builder.setCaptureRequestOption(
                    CaptureRequest.DISTORTION_CORRECTION_MODE,
                    CaptureRequest.DISTORTION_CORRECTION_MODE_OFF
                )
            }

            cropCoordinateArray?.let { active ->
                val zoom =
                    currentZoomRatio.coerceIn(
                        1f,
                        maxZoomRatio.coerceAtLeast(1f)
                    )

                val cropWidth =
                    (active.width() / zoom)
                        .toInt()
                        .coerceIn(2, active.width())

                val cropHeight =
                    (active.height() / zoom)
                        .toInt()
                        .coerceIn(2, active.height())

                val availableX =
                    (active.width() - cropWidth)
                        .coerceAtLeast(0)

                val availableY =
                    (active.height() - cropHeight)
                        .coerceAtLeast(0)

                val effectivePanX =
                    if (freeformCropSupported) cameraPanX else 0f

                val effectivePanY =
                    if (freeformCropSupported) cameraPanY else 0f

                val left =
                    (
                        active.left +
                            (
                                availableX *
                                    (effectivePanX + 1f) /
                                    2f
                            ).toInt()
                    ).coerceIn(
                        active.left,
                        active.right - cropWidth
                    )

                val top =
                    (
                        active.top +
                            (
                                availableY *
                                    (effectivePanY + 1f) /
                                    2f
                            ).toInt()
                    ).coerceIn(
                        active.top,
                        active.bottom - cropHeight
                    )

                builder.setCaptureRequestOption(
                    CaptureRequest.SCALER_CROP_REGION,
                    Rect(
                        left,
                        top,
                        left + cropWidth,
                        top + cropHeight
                    )
                )
            }

            if (manualFocusSupported && focusManual) {
                builder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_OFF
                )
                builder.setCaptureRequestOption(
                    CaptureRequest.LENS_FOCUS_DISTANCE,
                    focusLinear * maxFocusDiopters
                )
            } else {
                builder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                )
            }

            Camera2CameraControl
                .from(cam.cameraControl)
                .setCaptureRequestOptions(builder.build())
        } catch (_: Exception) {}
    }

    private fun setCameraView(
        linear: Float,
        panX: Float,
        panY: Float
    ) {
        cameraZoomLinear =
            linear.coerceIn(0f, 1f)

        cameraPanX =
            if (cameraZoomLinear <= 0.001f) 0f
            else panX.coerceIn(-1f, 1f)

        cameraPanY =
            if (cameraZoomLinear <= 0.001f) 0f
            else panY.coerceIn(-1f, 1f)

        currentZoomRatio =
            1f +
                cameraZoomLinear *
                    (maxZoomRatio - 1f)

        prefs.edit()
            .putFloat("camera_zoom_linear", cameraZoomLinear)
            .putFloat("camera_pan_x", cameraPanX)
            .putFloat("camera_pan_y", cameraPanY)
            .apply()

        applyCamera2Controls()
    }

    private fun previewQualityMode(): Int =
        prefs.getInt("preview_quality_mode", 0)
            .coerceIn(0, 4)

    private fun previewQualityLabel(): String =
        when (previewQualityMode()) {
            1 -> "Smooth 180p"
            2 -> "Balanced 240p"
            3 -> "Sharp 270p"
            4 -> "Max Detail 270p"
            else -> "Auto Smooth"
        }

    private fun previewMaxLongSide(): Int =
        when (previewQualityMode()) {
            1 -> 320
            2 -> 426
            3 -> 480
            4 -> 480
            else ->
                if (sourceFps > 0f && sourceFps < 20f) 320
                else 426
        }

    private fun previewBaseJpegQuality(): Int =
        when (previewQualityMode()) {
            1 -> 34
            2 -> 44
            3 -> 56
            4 -> 72
            else ->
                if (sourceFps > 0f && sourceFps < 20f) 34
                else 42
        }

    private fun setManualFocus(linear: Float) {
        if (!manualFocusSupported) return
        focusManual = true
        focusLinear = linear.coerceIn(0f, 1f)
        applyCamera2Controls()
    }

    private fun setAutoFocus() {
        focusManual = false
        applyCamera2Controls()
    }

    private fun saveFocus() {
        prefs.edit()
            .putBoolean("focus_manual", focusManual)
            .putFloat("focus_linear", focusLinear)
            .apply()
    }

    private fun processFrame(image: ImageProxy) {
        try {
            framesSeenInSession++

            // Measure the REAL CameraX source rate.
            val fpsNow = System.nanoTime()
            if (sourceFpsWindowStartNs == 0L) {
                sourceFpsWindowStartNs = fpsNow
            }
            sourceFpsFrames++

            val fpsElapsed =
                fpsNow - sourceFpsWindowStartNs

            if (fpsElapsed >= 1_000_000_000L) {
                sourceFps =
                    sourceFpsFrames.toFloat() /
                        (
                            fpsElapsed.toDouble() /
                                1_000_000_000.0
                            ).toFloat()

                sourceFpsFrames = 0
                sourceFpsWindowStartNs = fpsNow
            }

            // q3 stable live/AI path.
            // CameraX supplies the default YUV_420_888 format. We convert its
            // row/pixel-strided planes to NV21 ourselves, which is slower than
            // a direct NV21 output but substantially more compatible.
            val publishNow =
                System.currentTimeMillis()

            if (lastLivePublishedAtMs != 0L &&
                publishNow - lastLivePublishedAtMs <
                    effectiveLiveIntervalMs()
            ) {
                return
            }

            val jpeg = yuv420ImageToJpeg(
                image = image,
                quality = effectiveJpegQuality(),
                maxLongSide = previewMaxLongSide()
            )

            if (jpeg != null &&
                jpeg.isNotEmpty()
            ) {
                latestJpeg.set(jpeg)
                latestFrameAtMs =
                    System.currentTimeMillis()
                lastLivePublishedAtMs =
                    latestFrameAtMs

                if (framesSeenInSession == 1) {
                    eventStore.add(
                        "24/7 live frame active",
                        "$activeBackgroundQualityName • stable YUV ImageAnalysis stream active"
                    )

                    updateNotification(
                        "24/7 live camera active • preparing AI…"
                    )

                    queueAiStartAfterCameraFrame()
                }

                // AI gets the already-compressed visual frame at a normal target of 10 fps.
                // The CameraX ImageProxy can therefore be released without
                // waiting for an RGB conversion or pose inference.
                queueAiJpegIfDue(jpeg)
            }

            maybeStartVisualRecordingWork(
                "YUV ImageAnalysis"
            )

        } catch (e: Exception) {
            framePipelineErrorCount++
            lastFramePipelineError =
                "YUV stream: ${e.message ?: e.javaClass.simpleName}"

            if (framePipelineErrorCount == 1 ||
                framePipelineErrorCount % 100 == 0
            ) {
                eventStore.add(
                    "Frame pipeline warning",
                    lastFramePipelineError
                )
            }
        } finally {
            // KEEP_ONLY_LATEST can only stay smooth when ImageProxy is closed
            // quickly. The heavy AI work is not performed here.
            image.close()
        }
    }

    private fun processPreviewBridgeFrame(
        bitmap: Bitmap
    ) {
        try {
            framesSeenInSession++

            val nowNs =
                System.nanoTime()

            if (
                sourceFpsWindowStartNs ==
                0L
            ) {
                sourceFpsWindowStartNs =
                    nowNs
            }

            sourceFpsFrames++

            val elapsed =
                nowNs -
                    sourceFpsWindowStartNs

            if (
                elapsed >=
                1_000_000_000L
            ) {
                sourceFps =
                    sourceFpsFrames.toFloat() /
                        (
                            elapsed.toDouble() /
                                1_000_000_000.0
                            ).toFloat()

                sourceFpsFrames = 0
                sourceFpsWindowStartNs =
                    nowNs
            }

            val out =
                ByteArrayOutputStream(
                    64 * 1024
                )

            bitmap.compress(
                Bitmap.CompressFormat.JPEG,
                effectiveJpegQuality(),
                out
            )

            val jpeg =
                out.toByteArray()

            if (jpeg.isNotEmpty()) {
                latestJpeg.set(jpeg)
                latestFrameAtMs =
                    System.currentTimeMillis()
                lastLivePublishedAtMs =
                    latestFrameAtMs

                if (
                    framesSeenInSession ==
                    1
                ) {
                    eventStore.add(
                        "High-resolution visual frame active",
                        "$activeBackgroundQualityName • Preview AI bridge"
                    )

                    updateNotification(
                        "High-res recording + visual AI active • $activeBackgroundQualityName"
                    )

                    queueAiStartAfterCameraFrame()
                }

                queueAiJpegIfDue(jpeg)

                maybeStartVisualRecordingWork(
                    "Preview AI bridge"
                )
            }

        } catch (t: Throwable) {
            framePipelineErrorCount++
            lastFramePipelineError =
                "Preview bridge: ${t.message ?: t.javaClass.simpleName}"
        } finally {
            try {
                if (!bitmap.isRecycled) {
                    bitmap.recycle()
                }
            } catch (_: Exception) {}
        }
    }

    private fun maybeStartVisualRecordingWork(
        source: String
    ) {
        if (
            latestJpeg.get() == null ||
            framesSeenInSession < 3 ||
            firstRecordingStartQueued ||
            serviceStopping ||
            !thermalRecordingAllowed() ||
            videoCapture == null ||
            recording != null ||
            !(
                prefs.getBoolean(
                    "continuous_recording",
                    false
                ) ||
                prefs.getBoolean(
                    "event_pre_record_enabled",
                    true
                )
            )
        ) {
            return
        }

        firstRecordingStartQueued = true

        handler.post {
            if (
                !serviceStopping &&
                thermalRecordingAllowed() &&
                recording == null &&
                videoCapture != null &&
                latestJpeg.get() != null &&
                framesSeenInSession >= 3
            ) {
                if (
                    prefs.getBoolean(
                        "continuous_recording",
                        false
                    )
                ) {
                    eventStore.add(
                        "24/7 camera active",
                        "$source frames verified; starting $activeBackgroundQualityName recording."
                    )
                    startRecording(
                        "continuous_background"
                    )

                } else if (
                    prefs.getBoolean(
                        "event_pre_record_enabled",
                        true
                    )
                ) {
                    eventStore.add(
                        "Event pre-record armed",
                        "$source visual AI active • rolling cache active."
                    )
                    startPreBufferSegment()

                } else {
                    firstRecordingStartQueued = false
                }

            } else {
                firstRecordingStartQueued = false
            }
        }
    }

    private fun yuv420ImageToJpeg(
        image: ImageProxy,
        quality: Int,
        maxLongSide: Int
    ): ByteArray? {
        if (image.planes.size < 3) return null

        val width = image.width
        val height = image.height
        if (width <= 0 || height <= 0) return null

        val ySize = width * height
        val nv21 = ByteArray(ySize + ySize / 2)

        fun copyPlaneSample(
            plane: ImageProxy.PlaneProxy,
            row: Int,
            col: Int
        ): Byte? {
            val buffer = plane.buffer
            val index =
                buffer.position() +
                    row * plane.rowStride +
                    col * plane.pixelStride
            return if (index >= buffer.position() && index < buffer.limit()) {
                buffer.get(index)
            } else {
                null
            }
        }

        val yPlane = image.planes[0]
        var out = 0
        for (row in 0 until height) {
            for (col in 0 until width) {
                val value = copyPlaneSample(yPlane, row, col)
                    ?: return null
                nv21[out++] = value
            }
        }

        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        var chromaOut = ySize
        val chromaHeight = height / 2
        val chromaWidth = width / 2

        for (row in 0 until chromaHeight) {
            for (col in 0 until chromaWidth) {
                val v = copyPlaneSample(vPlane, row, col)
                    ?: return null
                val u = copyPlaneSample(uPlane, row, col)
                    ?: return null
                nv21[chromaOut++] = v
                nv21[chromaOut++] = u
            }
        }

        val softwarePanned =
            if (
                !freeformCropSupported &&
                cameraZoomLinear > 0.001f &&
                (
                    kotlin.math.abs(cameraPanX) >= 0.01f ||
                    kotlin.math.abs(cameraPanY) >= 0.01f
                )
            ) {
                cropNv21ForPan(
                    nv21,
                    width,
                    height,
                    cameraPanX,
                    cameraPanY,
                    cameraZoomLinear
                )
            } else {
                Nv21Frame(
                    data = nv21,
                    width = width,
                    height = height
                )
            }

        val workingNv21 = softwarePanned.data
        val workingWidth = softwarePanned.width
        val workingHeight = softwarePanned.height

        val longSide = maxOf(workingWidth, workingHeight)
        val scale =
            if (longSide > maxLongSide.coerceAtLeast(160)) {
                maxLongSide.coerceAtLeast(160).toFloat() /
                    longSide.toFloat()
            } else {
                1f
            }

        var outWidth =
            (workingWidth * scale).toInt().coerceAtLeast(2) and -2
        var outHeight =
            (workingHeight * scale).toInt().coerceAtLeast(2) and -2

        if (outWidth < 2) outWidth = 2
        if (outHeight < 2) outHeight = 2

        val outputNv21 =
            if (
                outWidth == workingWidth &&
                outHeight == workingHeight
            ) {
                workingNv21
            } else {
                downscaleNv21(
                    workingNv21,
                    workingWidth,
                    workingHeight,
                    outWidth,
                    outHeight
                )
            }

        val yuv =
            YuvImage(
                outputNv21,
                ImageFormat.NV21,
                outWidth,
                outHeight,
                null
            )

        val output =
            ByteArrayOutputStream(
                maxOf(24 * 1024, outWidth * outHeight / 3)
            )

        val ok =
            yuv.compressToJpeg(
                Rect(0, 0, outWidth, outHeight),
                quality.coerceIn(25, 90),
                output
            )

        return if (ok) output.toByteArray() else null
    }

    private data class Nv21Frame(
        val data: ByteArray,
        val width: Int,
        val height: Int
    )

    private fun cropNv21ForPan(
        src: ByteArray,
        srcWidth: Int,
        srcHeight: Int,
        panX: Float,
        panY: Float,
        zoomLinear: Float
    ): Nv21Frame {
        val extraScale =
            1f +
                zoomLinear.coerceIn(0f, 1f) *
                    0.35f

        var cropWidth =
            (srcWidth / extraScale)
                .toInt()
                .coerceIn(2, srcWidth)

        var cropHeight =
            (srcHeight / extraScale)
                .toInt()
                .coerceIn(2, srcHeight)

        cropWidth = cropWidth and -2
        cropHeight = cropHeight and -2

        if (cropWidth < 2) cropWidth = 2
        if (cropHeight < 2) cropHeight = 2

        val maxLeft =
            (srcWidth - cropWidth)
                .coerceAtLeast(0)

        val maxTop =
            (srcHeight - cropHeight)
                .coerceAtLeast(0)

        var left =
            (
                maxLeft *
                    (panX.coerceIn(-1f, 1f) + 1f) /
                    2f
            ).toInt()
                .coerceIn(0, maxLeft)

        var top =
            (
                maxTop *
                    (panY.coerceIn(-1f, 1f) + 1f) /
                    2f
            ).toInt()
                .coerceIn(0, maxTop)

        left = left and -2
        top = top and -2

        val dst =
            ByteArray(
                cropWidth *
                    cropHeight *
                    3 /
                    2
            )

        for (row in 0 until cropHeight) {
            System.arraycopy(
                src,
                (top + row) *
                    srcWidth +
                    left,
                dst,
                row * cropWidth,
                cropWidth
            )
        }

        val srcYSize =
            srcWidth * srcHeight

        val dstYSize =
            cropWidth * cropHeight

        val chromaTop =
            top / 2

        for (
            row in 0 until
                cropHeight / 2
        ) {
            System.arraycopy(
                src,
                srcYSize +
                    (chromaTop + row) *
                        srcWidth +
                    left,
                dst,
                dstYSize +
                    row *
                        cropWidth,
                cropWidth
            )
        }

        return Nv21Frame(
            data = dst,
            width = cropWidth,
            height = cropHeight
        )
    }

    private fun downscaleNv21(
        src: ByteArray,
        srcWidth: Int,
        srcHeight: Int,
        dstWidth: Int,
        dstHeight: Int
    ): ByteArray {
        val dst =
            ByteArray(
                dstWidth * dstHeight * 3 / 2
            )

        val srcYSize =
            srcWidth * srcHeight

        val dstYSize =
            dstWidth * dstHeight

        for (y in 0 until dstHeight) {
            val srcY =
                (
                    y.toLong() *
                        srcHeight /
                        dstHeight
                ).toInt()
                    .coerceIn(0, srcHeight - 1)

            val srcRow = srcY * srcWidth
            val dstRow = y * dstWidth

            for (x in 0 until dstWidth) {
                val srcX =
                    (
                        x.toLong() *
                            srcWidth /
                            dstWidth
                    ).toInt()
                        .coerceIn(0, srcWidth - 1)

                dst[dstRow + x] =
                    src[srcRow + srcX]
            }
        }

        val dstChromaHeight =
            dstHeight / 2

        val dstChromaWidthPairs =
            dstWidth / 2

        for (cy in 0 until dstChromaHeight) {
            val srcCy =
                (
                    cy.toLong() *
                        (srcHeight / 2) /
                        dstChromaHeight
                ).toInt()
                    .coerceIn(0, srcHeight / 2 - 1)

            for (cx in 0 until dstChromaWidthPairs) {
                val srcCx =
                    (
                        cx.toLong() *
                            (srcWidth / 2) /
                            dstChromaWidthPairs
                    ).toInt()
                        .coerceIn(0, srcWidth / 2 - 1)

                val srcIndex =
                    srcYSize +
                        srcCy * srcWidth +
                        srcCx * 2

                val dstIndex =
                    dstYSize +
                        cy * dstWidth +
                        cx * 2

                dst[dstIndex] =
                    src[srcIndex]

                dst[dstIndex + 1] =
                    src[srcIndex + 1]
            }
        }

        return dst
    }

    private fun queueAiJpegIfDue(
        jpeg: ByteArray
    ) {
        val now =
            System.currentTimeMillis()

        if (now - lastAiFrameQueuedAtMs <
            effectiveAiIntervalMs()
        ) {
            return
        }

        if (!aiFrameBusy.compareAndSet(
                false,
                true
            )
        ) {
            return
        }

        lastAiFrameQueuedAtMs = now

        // latestJpeg is immutable once published. Reusing the same byte array
        // does not keep CameraX/ImageProxy alive.
        aiFrameExecutor.execute {
            var bitmap: Bitmap? = null

            try {
                val options =
                    android.graphics.BitmapFactory.Options().apply {
                        // MediaPipe BitmapImageBuilder requires an ARGB_8888
                        // software bitmap. The monitor UI may still decode its
                        // own MJPEG copy as RGB_565.
                        inPreferredConfig =
                            Bitmap.Config.ARGB_8888
                        inMutable = false
                    }

                bitmap =
                    android.graphics.BitmapFactory.decodeByteArray(
                        jpeg,
                        0,
                        jpeg.size,
                        options
                    )

                if (bitmap != null) {
                    processAiFrame(bitmap)
                }
            } catch (t: Throwable) {
                framePipelineErrorCount++
                lastFramePipelineError =
                    "AI JPEG decode: ${t.message ?: t.javaClass.simpleName}"
            } finally {
                try {
                    if (bitmap != null &&
                        !bitmap.isRecycled
                    ) {
                        bitmap.recycle()
                    }
                } catch (_: Exception) {}

                aiFrameBusy.set(false)
            }
        }
    }

    private fun processAiFrame(bitmap: Bitmap) {
        var motionScore = 0f

        try {
            motionScore =
                motionDetector.score(bitmap)

            handleMotion(motionScore)
        } catch (e: Exception) {
            framePipelineErrorCount++
            lastFramePipelineError =
                "Motion: ${e.message ?: e.javaClass.simpleName}"
        }

        if (
            prefs.getBoolean(
                "animal_tracking",
                true
            )
        ) {
            try {
                val detections =
                    animalDetector
                        ?.analyze(bitmap)
                        .orEmpty()

                handleAnimalDetections(
                    detections
                )

            } catch (e: Exception) {
                framePipelineErrorCount++
                lastFramePipelineError =
                    "Animal AI: ${e.message ?: e.javaClass.simpleName}"
            }
        }

        if (prefs.getBoolean(
                "seizure_like_alert",
                false
            )
        ) {
            try {
                val now =
                    System.currentTimeMillis()

                if (seizureLikeDetector.update(
                        motionScore,
                        now
                    ) &&
                    now - lastSeizureAlertAt >
                        60_000L
                ) {
                    lastSeizureAlertAt = now

                    eventStore.add(
                        "AI alert: possible seizure-like repetitive motion",
                        aiEventContext(
                            "EXPERIMENTAL / NON-DIAGNOSTIC"
                        )
                    )
                    triggerBufferedEvent(
                        "AI alert: possible seizure-like repetitive motion",
                        "EXPERIMENTAL / NON-DIAGNOSTIC"
                    )
                }
            } catch (e: Exception) {
                framePipelineErrorCount++
                lastFramePipelineError =
                    "Seizure-like AI: ${e.message ?: e.javaClass.simpleName}"
            }
        }

        if (prefs.getBoolean(
                "fall_detection",
                true
            ) ||
            prefs.getBoolean(
                "aggressive_detection",
                true
            )
        ) {
            try {
                val poseState =
                    poseDetector?.analyze(bitmap)

                if (poseState != null) {
                    handlePoseState(poseState)
                }
            } catch (e: Exception) {
                framePipelineErrorCount++
                lastFramePipelineError =
                    "Pose AI: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    private fun handleAnimalDetections(
        detections: List<AnimalDetection>
    ) {
        val now =
            System.currentTimeMillis()

        val seen =
            detections
                .groupBy { it.label }
                .mapValues { entry ->
                    entry.value
                        .maxByOrNull {
                            it.score
                        }!!
                }

        for (
            label in
            listOf(
                "Dog",
                "Cat",
                "Bird"
            )
        ) {
            val detection =
                seen[label]

            if (detection == null) {
                val last =
                    animalLastSeenAt[label]
                        ?: 0L

                if (
                    now - last >
                    1_500L
                ) {
                    animalConsecutive[
                        label
                    ] = 0
                }
                continue
            }

            animalLastSeenAt[label] =
                now

            val count =
                (
                    animalConsecutive[
                        label
                    ] ?: 0
                ) + 1

            animalConsecutive[label] =
                count

            if (count < 2) {
                continue
            }

            currentRecordingSubjects.add(
                label
            )

            val lastEvent =
                animalLastEventAt[label]
                    ?: 0L

            if (
                now - lastEvent <
                5_000L
            ) {
                continue
            }

            animalLastEventAt[label] =
                now

            val scoreText =
                String.format(
                    Locale.US,
                    "%.2f",
                    detection.score
                )

            eventStore.add(
                "$label detected",
                "confidence=$scoreText • AI tracking active"
            )

            triggerBufferedEvent(
                label,
                "confidence=$scoreText"
            )

            if (
                !prefs.getBoolean(
                    "continuous_recording",
                    false
                ) &&
                !prefs.getBoolean(
                    "event_pre_record_enabled",
                    true
                ) &&
                recording == null &&
                videoCapture != null
            ) {
                Handler(
                    Looper.getMainLooper()
                ).post {
                    startRecording(
                        "${label.lowercase(Locale.US)}_recorded"
                    )
                }

                motionRecordingUntil =
                    now + 20_000L
            }
        }
    }

    private fun handleMotion(score: Float) {
        val now = System.currentTimeMillis()
        val sensitivity =
            prefs.getInt("motion_sensitivity", 55).coerceIn(0, 100)
        val threshold = 12f - (sensitivity / 100f * 9f)

        if (score >= threshold) {
            motionTriggerFrames++
        } else {
            motionTriggerFrames =
                (motionTriggerFrames - 1).coerceAtLeast(0)
        }

        if (score >= threshold * 1.25f) {
            lastPoseMotionAt = now
            lastPoseMotionIntensity = score / 100f
        }

        if (motionTriggerFrames >= 2) {
            motionTriggerFrames = 0
            motionRecordingUntil = now + 20_000L

            if (prefs.getBoolean("continuous_recording", false) &&
                recordingReason == "continuous_background"
            ) {
                if (now - lastMotionMomentAt > 3_000L) {
                    lastMotionMomentAt = now
                    val pre = prefs.getInt("pre_record_seconds", 10)
                    eventStore.add(
                        "Motion Moment",
                        "pre-record=${pre}s • segment=${currentSegmentName ?: "current"}"
                    )
                }
            } else if (prefs.getBoolean("event_pre_record_enabled", false) &&
                !prefs.getBoolean("continuous_recording", false)
            ) {
                triggerBufferedEvent(
                    "Motion detected",
                    if (networkOnline) "motion" else "OFFLINE • motion"
                )
            } else if (recording == null &&
                videoCapture != null &&
                prefs.getBoolean("offline_guard", false)
            ) {
                eventStore.add(
                    "Motion detected",
                    if (networkOnline)
                        "local event recording"
                    else
                        "OFFLINE • local event recording"
                )
                Handler(Looper.getMainLooper()).post {
                    startRecording("motion_background")
                }
            }
        }

        if (recordingReason == "motion_background" &&
            recording != null &&
            now >= motionRecordingUntil &&
            motionRecordingUntil > 0L
        ) {
            motionRecordingUntil = 0L
            Handler(Looper.getMainLooper()).post {
                stopRecording()
            }
        }
    }

    private fun handlePoseState(state: PoseBehaviorState) {
        val now = System.currentTimeMillis()

        if (state.personVisible) {
            lastPoseVisibleAt = now
        }
        if (state.motionIntensity > 0.028f) {
            lastPoseMotionAt = now
            lastPoseMotionIntensity = state.motionIntensity
        }

        if (state.possibleFall &&
            prefs.getBoolean("fall_detection", false) &&
            now - lastFallAlertAt > 25_000L
        ) {
            lastFallAlertAt = now
            eventStore.add(
                "AI detected: possible person fall",
                aiEventContext("Pose Landmarker + temporal posture rule • review recording")
            )
            triggerBufferedEvent("AI detected: possible person fall", "pose fall")
        }

        maybeEmitAggressiveBehavior()
    }

    private fun handleAudioEvent(event: AudioAiEvent) {
        val now = System.currentTimeMillis()

        eventStore.add(
            event.label,
            aiEventContext(
                "confidence=${String.format(Locale.US, "%.2f", event.confidence)} • model=${event.rawLabel}"
            )
        )
        triggerBufferedEvent(
            event.label,
            "audio confidence=${String.format(Locale.US, "%.2f", event.confidence)}"
        )

        if (event.key == "shouting") {
            lastShoutAt = now
            maybeEmitAggressiveBehavior()
        }
    }

    private fun maybeEmitAggressiveBehavior() {
        if (!prefs.getBoolean("aggressive_detection", false)) return

        val now = System.currentTimeMillis()
        val recentPerson = now - lastPoseVisibleAt < 2_500L
        val recentShout = now - lastShoutAt < 2_500L
        val recentFastMotion =
            now - lastPoseMotionAt < 2_500L &&
                lastPoseMotionIntensity > 0.025f

        if (recentPerson &&
            recentShout &&
            recentFastMotion &&
            now - lastAggressiveAlertAt > 20_000L
        ) {
            lastAggressiveAlertAt = now
            eventStore.add(
                "AI detected: possible aggressive behavior",
                aiEventContext(
                    "Raised voice + person pose + rapid movement; not an emotion diagnosis"
                )
            )
            triggerBufferedEvent(
                "AI detected: possible aggressive behavior",
                "raised voice + pose + rapid movement"
            )
        }
    }

    private fun aiEventContext(base: String): String {
        val pre = prefs.getInt("pre_record_seconds", 10)
        val segment = currentSegmentName ?: "no active segment"
        return "$base • pre-record=${pre}s • segment=$segment"
    }

    private fun queueAiStartAfterCameraFrame() {
        if (aiStartQueued || serviceStopping) return
        aiStartQueued = true

        aiInitExecutor.execute {
            if (serviceStopping) return@execute

            eventStore.add(
                "AI initialization",
                "Starting AI only after service camera frame was confirmed."
            )

            try {
                startAiEngines()

                eventStore.add(
                    "AI initialization complete",
                    "Camera stream was already active before MediaPipe/YamNet startup."
                )
            } catch (t: Throwable) {
                eventStore.add(
                    "AI initialization failed",
                    t.message
                        ?: t.javaClass.simpleName
                )
            }
        }
    }

    private fun startAiEngines() {
        if (!videoRecorderOwnsMicrophoneByPolicy()) {
            startAudioAiIfAvailable()
        } else {
            eventStore.add(
                "Audio AI deferred",
                "Visual AI starts normally; MP4/pre-record has microphone priority."
            )
        }

        if (
            (
                prefs.getBoolean(
                    "fall_detection",
                    true
                ) ||
                prefs.getBoolean(
                    "aggressive_detection",
                    true
                )
            ) &&
            ModelDownloader.poseReady(this)
        ) {
            poseDetector =
                PoseBehaviorDetector(
                    this,
                    ModelDownloader.poseFile(this),
                    onStatus = {
                        if (
                            it.contains("failed", true) ||
                            it.contains("error", true)
                        ) {
                            eventStore.add(
                                "Pose AI status",
                                it
                            )
                        }
                    }
                ).also { it.start() }
        }

        if (
            prefs.getBoolean(
                "animal_tracking",
                true
            ) &&
            ModelDownloader.objectReady(this)
        ) {
            animalDetector =
                AnimalObjectDetector(
                    this,
                    ModelDownloader.objectFile(this),
                    onStatus = {
                        if (
                            it.contains("failed", true) ||
                            it.contains("error", true)
                        ) {
                            eventStore.add(
                                "Animal AI status",
                                it
                            )
                        }
                    }
                ).also { it.start() }

            eventStore.add(
                "Animal tracking ready",
                "Dog / Cat / Bird detection active."
            )
        }

        if (
            !ModelDownloader.yamnetReady(this) &&
            !ModelDownloader.poseReady(this) &&
            !ModelDownloader.objectReady(this)
        ) {
            eventStore.add(
                "AI models not ready",
                "Open Camera mode and tap Prepare / download AI models while online."
            )
        }
    }

    private fun preBufferDirectory(): File =
        File(cacheDir, "event_prebuffer").apply { mkdirs() }

    private val preBufferStopRunnable = Runnable {
        if (recordingReason == "event_prebuffer_background" &&
            recording != null
        ) {
            recording?.stop()
        }
    }

    private fun startPreBufferSegment() {
        if (serviceStopping || recording != null || videoCapture == null) {
            firstRecordingStartQueued = false
            return
        }
        if (prefs.getBoolean("continuous_recording", false) ||
            !prefs.getBoolean("event_pre_record_enabled", false) ||
            !thermalRecordingAllowed()
        ) {
            firstRecordingStartQueued = false
            return
        }

        val capture = videoCapture ?: return
        val file = File(
            preBufferDirectory(),
            "buf_${System.currentTimeMillis()}.mp4"
        )
        currentPreBufferFile = file
        currentPreBufferStartedAt = System.currentTimeMillis()
        recordingReason = "event_prebuffer_background"
        currentSegmentName = file.name

        suspendAudioAiForVideoRecording()

        var pending =
            capture.output.prepareRecording(
                this,
                FileOutputOptions
                    .Builder(file)
                    .build()
            )

        if (
            recordingAudioEnabled() &&
            microphonePermissionGranted()
        ) {
            pending =
                pending.withAudioEnabled()
        }

        try {
            recording = pending.start(
                ContextCompat.getMainExecutor(this)
            ) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        handler.removeCallbacks(preBufferStopRunnable)
                        handler.postDelayed(preBufferStopRunnable, preBufferSegmentMs)
                    }

                    is VideoRecordEvent.Finalize -> {
                        handler.removeCallbacks(preBufferStopRunnable)
                        val finishedFile = currentPreBufferFile
                        val started = currentPreBufferStartedAt
                        val ended = System.currentTimeMillis()
                        recording = null
                        recordingReason = null
                        currentPreBufferFile = null
                        currentPreBufferStartedAt = 0L
                        firstRecordingStartQueued = false

                        if (event.hasError()) {
                            try { finishedFile?.delete() } catch (_: Exception) {}
                            val errorName = recordingErrorName(event.error)
                            eventStore.add(
                                "Event pre-record segment interrupted",
                                "$errorName (${event.error})"
                            )
                            if (!serviceStopping &&
                                (event.error == VideoRecordEvent.Finalize.ERROR_SOURCE_INACTIVE ||
                                 event.error == VideoRecordEvent.Finalize.ERROR_RECORDER_ERROR ||
                                 event.error == VideoRecordEvent.Finalize.ERROR_ENCODING_FAILED)
                            ) {
                                scheduleCameraSessionRestart(errorName)
                                return@start
                            }
                        } else if (finishedFile != null &&
                            finishedFile.exists() && finishedFile.length() > 0L
                        ) {
                            synchronized(preBufferSegments) {
                                preBufferSegments.addLast(
                                    PreBufferSegment(finishedFile, started, ended)
                                )
                            }
                            purgeOldPreBufferSegments()

                            if (eventCaptureActive && ended >= eventCaptureUntilMs) {
                                finalizeBufferedEvent()
                            }
                        }

                        if (!serviceStopping &&
                            !prefs.getBoolean("continuous_recording", false) &&
                            prefs.getBoolean("event_pre_record_enabled", false) &&
                            videoCapture != null &&
                            thermalRecordingAllowed()
                        ) {
                            handler.postDelayed({
                                startPreBufferSegment()
                            }, 80L)
                        }

                        scheduleAudioAiResume()
                    }
                }
            }
        } catch (e: Exception) {
            recording = null
            recordingReason = null
            firstRecordingStartQueued = false
            try { file.delete() } catch (_: Exception) {}
            eventStore.add(
                "Event pre-record start failed",
                e.message ?: "unknown"
            )
        }
    }

    private fun triggerBufferedEvent(label: String, detail: String = "") {
        if (prefs.getBoolean("continuous_recording", false) ||
            !prefs.getBoolean("event_pre_record_enabled", false)
        ) return

        val now = System.currentTimeMillis()
        val postMs = prefs.getInt("post_record_seconds", 20).coerceIn(5, 120) * 1000L

        // Motion may call this many times. Repeated triggers extend the same clip
        // rather than creating dozens of nearly identical events.
        val wasActive = eventCaptureActive
        if (!eventCaptureActive) {
            eventCaptureActive = true
            eventCaptureStartMs = now
            eventCaptureUntilMs = now + postMs
            eventCaptureLabels.clear()
        } else {
            eventCaptureUntilMs = maxOf(eventCaptureUntilMs, now + postMs)
        }
        val newLabel = eventCaptureLabels.add(label)
        val shouldLog = !wasActive || newLabel || now - lastBufferedEventTriggerAt > 5_000L
        lastBufferedEventTriggerAt = now

        if (shouldLog) {
            eventStore.add(
                "$label • event clip armed",
                "pre=${prefs.getInt("pre_record_seconds", 10)}s • post=${prefs.getInt("post_record_seconds", 20)}s${if (detail.isBlank()) "" else " • $detail"}"
            )
        }
    }

    private fun purgeOldPreBufferSegments() {
        val preMs = prefs.getInt("pre_record_seconds", 10).coerceIn(2, 60) * 1000L
        val keepAfter = if (eventCaptureActive)
            eventCaptureStartMs - preMs - 2_500L
        else
            System.currentTimeMillis() - preMs - 4_000L

        synchronized(preBufferSegments) {
            while (preBufferSegments.isNotEmpty()) {
                val first = preBufferSegments.first()
                if (first.endMs >= keepAfter ||
                    protectedPreBufferPaths.contains(first.file.absolutePath)
                ) break
                preBufferSegments.removeFirst()
                try { first.file.delete() } catch (_: Exception) {}
            }
        }
    }

    private fun finalizeBufferedEvent() {
        if (!eventCaptureActive) return

        val preMs = prefs.getInt("pre_record_seconds", 10).coerceIn(2, 60) * 1000L
        val from = eventCaptureStartMs - preMs
        val until = eventCaptureUntilMs
        val labels = eventCaptureLabels.toList()
        val eventStarted = eventCaptureStartMs

        val selected = synchronized(preBufferSegments) {
            preBufferSegments.filter {
                it.endMs >= from && it.startMs <= until + 2_500L
            }.map { it.file }
        }

        eventCaptureActive = false
        eventCaptureLabels.clear()

        if (selected.isEmpty()) {
            eventStore.add(
                "Event clip unavailable",
                "${labels.joinToString(", ")} • rolling buffer had no completed segment"
            )
            return
        }

        synchronized(protectedPreBufferPaths) {
            selected.forEach { protectedPreBufferPaths.add(it.absolutePath) }
        }

        val cleanSubjects =
            labels
                .map {
                    it
                        .replace(
                            Regex(
                                "(?i)\\s*recorded\\s*"
                            ),
                            ""
                        )
                        .replace(
                            Regex(
                                "(?i)AI detected:\\s*"
                            ),
                            ""
                        )
                        .trim()
                }
                .filter {
                    it.isNotBlank()
                }

        val subjectTitle =
            if (cleanSubjects.isEmpty()) {
                "Event"
            } else {
                cleanSubjects
                    .take(3)
                    .joinToString("_")
            }

        val safeSubject =
            subjectTitle
                .replace(
                    Regex(
                        "[^A-Za-z0-9_-]+"
                    ),
                    "_"
                )
                .trim('_')
                .take(60)
                .ifBlank {
                    "Event"
                }

        val name =
            "${safeSubject}_recorded_" +
                SimpleDateFormat(
                    "yyyyMMdd_HHmmss",
                    Locale.US
                ).format(eventStarted) +
                ".mp4"

        eventMergeExecutor.execute {
            try {
                val uri =
                    Mp4SegmentMerger
                        .mergeToMediaStore(
                            context = this,
                            segments = selected,
                            displayName = name,
                            eventFolder =
                                safeSubject
                                    .ifBlank {
                                        "Event"
                                    }
                        )
                if (uri != null) {
                    val actualResolution =
                        actualVideoResolution(
                            uri
                        )

                    eventStore.add(
                        "${if (cleanSubjects.isEmpty()) "Event" else cleanSubjects.joinToString(" + ")} recorded",
                        "pre=${prefs.getInt("pre_record_seconds", 10)}s • post=${prefs.getInt("post_record_seconds", 20)}s • actual=$actualResolution • $name"
                    )
                    applyRetention()
                } else {
                    eventStore.add(
                        "Event video merge failed",
                        labels.joinToString(" + ")
                    )
                }
            } catch (e: Exception) {
                eventStore.add(
                    "Event video merge failed",
                    "${labels.joinToString(" + ")} • ${e.message ?: e.javaClass.simpleName}"
                )
            } finally {
                synchronized(protectedPreBufferPaths) {
                    selected.forEach { protectedPreBufferPaths.remove(it.absolutePath) }
                }
                purgeOldPreBufferSegments()
            }
        }
    }

    private fun subjectRecordingName(
        subjects: Set<String>,
        timestampMs: Long =
            System.currentTimeMillis()
    ): String? {
        if (subjects.isEmpty()) {
            return null
        }

        val prefix =
            subjects
                .take(3)
                .joinToString("_") {
                    it.replace(
                        Regex(
                            "[^A-Za-z0-9_-]+"
                        ),
                        "_"
                    )
                }

        return prefix +
            "_recorded_" +
            SimpleDateFormat(
                "yyyyMMdd_HHmmss",
                Locale.US
            ).format(timestampMs) +
            ".mp4"
    }

    private fun renameMediaStoreVideo(
        uri: android.net.Uri,
        newName: String
    ) {
        if (
            uri ==
            android.net.Uri.EMPTY
        ) {
            return
        }

        try {
            val values =
                ContentValues().apply {
                    put(
                        MediaStore.Video.Media.DISPLAY_NAME,
                        newName
                    )
                }

            contentResolver.update(
                uri,
                values,
                null,
                null
            )
        } catch (e: Exception) {
            eventStore.add(
                "Recording rename warning",
                e.message
                    ?: e.javaClass.simpleName
            )
        }
    }

    private fun actualVideoHasAudio(
        uri: android.net.Uri
    ): Boolean {
        if (
            uri ==
            android.net.Uri.EMPTY
        ) {
            return false
        }

        val retriever =
            MediaMetadataRetriever()

        return try {
            retriever.setDataSource(
                this,
                uri
            )

            retriever.extractMetadata(
                MediaMetadataRetriever
                    .METADATA_KEY_HAS_AUDIO
            ) == "yes"

        } catch (_: Exception) {
            false

        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun actualVideoResolution(
        uri: android.net.Uri
    ): String {
        if (uri == android.net.Uri.EMPTY) {
            return "unknown"
        }

        val retriever =
            MediaMetadataRetriever()

        return try {
            retriever.setDataSource(
                this,
                uri
            )

            val width =
                retriever.extractMetadata(
                    MediaMetadataRetriever
                        .METADATA_KEY_VIDEO_WIDTH
                )
                    ?.toIntOrNull()

            val height =
                retriever.extractMetadata(
                    MediaMetadataRetriever
                        .METADATA_KEY_VIDEO_HEIGHT
                )
                    ?.toIntOrNull()

            if (
                width != null &&
                height != null
            ) {
                "${width}×${height}"
            } else {
                "unknown"
            }
        } catch (_: Exception) {
            "unknown"
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun startRecording(reason: String) {
        if (recording != null) return
        val capture = videoCapture ?: return

        currentRecordingSubjects.clear()

        val name = "AI_Door_" +
            SimpleDateFormat(
                "yyyyMMdd_HHmmss",
                Locale.US
            ).format(System.currentTimeMillis()) +
            "_${reason}_${activeBackgroundQualityName.replace(" ", "_").replace("/", "_")}.mp4"

        currentSegmentName = name

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    "Movies/AI Door Monitor"
                )
            }
        }

        val options = MediaStoreOutputOptions.Builder(
            contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        suspendAudioAiForVideoRecording()

        try {
            var pending =
                capture.output.prepareRecording(
                    this,
                    options
                )

            if (
                recordingAudioEnabled() &&
                microphonePermissionGranted()
            ) {
                pending =
                    pending.withAudioEnabled()
            }

            recordingReason = reason
            recording = pending.start(
                ContextCompat.getMainExecutor(this)
            ) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        eventStore.add(
                            "MP4 microphone",
                            if (
                                recordingAudioEnabled() &&
                                microphonePermissionGranted()
                            )
                                "Microphone audio enabled for this recording."
                            else
                                "Microphone audio disabled or permission unavailable."
                        )

                        if (reason == "continuous_background") {
                            updateNotification(
                                "24/7 monitoring active • $activeBackgroundQualityName recording • screen may be off"
                            )
                            eventStore.add(
                                "24/7 recording active",
                                if (recordingFirstMode)
                                    "$activeBackgroundQualityName exact background MP4 started in recording-first mode."
                                else
                                    "$activeBackgroundQualityName background MP4 started after ${framesSeenInSession} camera frames."
                            )
                            scheduleRollover()
                        }
                    }

                    is VideoRecordEvent.Finalize -> {
                        val finishedReason = recordingReason
                        recording = null
                        recordingReason = null

                        val error = event.error
                        val hadError = event.hasError()

                        if (hadError) {
                            val errorName = recordingErrorName(error)
                            eventStore.add(
                                "Recording interrupted",
                                "reason=$finishedReason • $errorName ($error)"
                            )

                            cleanupInvalidRecordingIfNeeded(event)

                            // SOURCE_INACTIVE and NO_VALID_DATA often mean that
                            // the camera/encoder source did not survive a
                            // lifecycle or ownership transition. Rebuild the
                            // CameraX session rather than immediately retrying
                            // on the same inactive Recorder source.
                            if (!serviceStopping &&
                                (error == VideoRecordEvent.Finalize.ERROR_SOURCE_INACTIVE ||
                                 error == VideoRecordEvent.Finalize.ERROR_NO_VALID_DATA ||
                                 error == VideoRecordEvent.Finalize.ERROR_RECORDER_ERROR ||
                                 error == VideoRecordEvent.Finalize.ERROR_ENCODING_FAILED)
                            ) {
                                rollover = false
                                scheduleCameraSessionRestart(errorName)
                                return@start
                            }
                        } else {
                            val savedUri =
                                event.outputResults.outputUri

                            val actualResolution =
                                actualVideoResolution(
                                    savedUri
                                )

                            val hasAudio =
                                actualVideoHasAudio(
                                    savedUri
                                )

                            val detectedSubjects =
                                currentRecordingSubjects
                                    .toSet()

                            val subjectName =
                                subjectRecordingName(
                                    detectedSubjects
                                )

                            if (
                                subjectName != null
                            ) {
                                renameMediaStoreVideo(
                                    savedUri,
                                    subjectName
                                )
                            }

                            eventStore.add(
                                if (
                                    detectedSubjects.isNotEmpty()
                                ) {
                                    "${detectedSubjects.joinToString(" + ")} recorded"
                                } else {
                                    "MP4 saved"
                                },
                                "reason=$finishedReason • requested=${selectedQualityName()} • active=$activeBackgroundQualityName • actual=$actualResolution • audio=${if (hasAudio) "present" else "absent"} • ${subjectName ?: name}"
                            )

                            currentRecordingSubjects.clear()

                            applyRetention()
                        }

                        val shouldContinue =
                            !serviceStopping &&
                            thermalRecordingAllowed() &&
                            prefs.getBoolean("continuous_recording", false) &&
                                (finishedReason == "continuous_background" ||
                                    rollover)

                        rollover = false

                        if (shouldContinue &&
                            videoCapture != null
                        ) {
                            handler.postDelayed({
                                if (!serviceStopping &&
                                    recording == null &&
                                    videoCapture != null
                                ) {
                                    startRecording("continuous_background")
                                }
                            }, 350L)
                        } else if (!serviceStopping &&
                            !prefs.getBoolean("continuous_recording", false) &&
                            prefs.getBoolean("event_pre_record_enabled", false) &&
                            videoCapture != null &&
                            thermalRecordingAllowed()
                        ) {
                            handler.postDelayed({
                                startPreBufferSegment()
                            }, 350L)
                        }

                        scheduleAudioAiResume()
                    }
                }
            }
        } catch (t: Throwable) {
            recording = null
            recordingReason = null
            eventStore.add(
                "Recording start failed",
                t.javaClass.simpleName + ": " + (t.message ?: "unknown")
            )
        }
    }

    private fun recordingErrorName(error: Int): String =
        when (error) {
            VideoRecordEvent.Finalize.ERROR_NONE ->
                "ERROR_NONE"
            VideoRecordEvent.Finalize.ERROR_UNKNOWN ->
                "ERROR_UNKNOWN"
            VideoRecordEvent.Finalize.ERROR_FILE_SIZE_LIMIT_REACHED ->
                "ERROR_FILE_SIZE_LIMIT_REACHED"
            VideoRecordEvent.Finalize.ERROR_INSUFFICIENT_STORAGE ->
                "ERROR_INSUFFICIENT_STORAGE"
            VideoRecordEvent.Finalize.ERROR_SOURCE_INACTIVE ->
                "ERROR_SOURCE_INACTIVE"
            VideoRecordEvent.Finalize.ERROR_INVALID_OUTPUT_OPTIONS ->
                "ERROR_INVALID_OUTPUT_OPTIONS"
            VideoRecordEvent.Finalize.ERROR_ENCODING_FAILED ->
                "ERROR_ENCODING_FAILED"
            VideoRecordEvent.Finalize.ERROR_RECORDER_ERROR ->
                "ERROR_RECORDER_ERROR"
            VideoRecordEvent.Finalize.ERROR_NO_VALID_DATA ->
                "ERROR_NO_VALID_DATA"
            VideoRecordEvent.Finalize.ERROR_DURATION_LIMIT_REACHED ->
                "ERROR_DURATION_LIMIT_REACHED"
            VideoRecordEvent.Finalize.ERROR_RECORDING_GARBAGE_COLLECTED ->
                "ERROR_RECORDING_GARBAGE_COLLECTED"
            else ->
                "ERROR_$error"
        }

    private fun cleanupInvalidRecordingIfNeeded(
        event: VideoRecordEvent.Finalize
    ) {
        val shouldDelete =
            event.error == VideoRecordEvent.Finalize.ERROR_UNKNOWN ||
            event.error == VideoRecordEvent.Finalize.ERROR_RECORDER_ERROR ||
            event.error == VideoRecordEvent.Finalize.ERROR_ENCODING_FAILED ||
            event.error == VideoRecordEvent.Finalize.ERROR_NO_VALID_DATA

        if (!shouldDelete) return

        val uri = event.outputResults.outputUri
        if (uri != android.net.Uri.EMPTY) {
            try {
                contentResolver.delete(uri, null, null)
            } catch (_: Exception) {}
        }
    }

    private fun scheduleCameraSessionRestart(errorName: String) {
        if (cameraRestartScheduled || serviceStopping) return
        cameraRestartScheduled = true

        updateNotification(
            "Recovering camera after $errorName…"
        )
        eventStore.add(
            "Camera session recovery",
            "Rebinding CameraX after $errorName"
        )

        handler.postDelayed({
            cameraRestartScheduled = false
            if (serviceStopping) return@postDelayed

            try { recording?.close() } catch (_: Exception) {}
            recording = null
            recordingReason = null

            server = LanCameraHub.server()

            try { cameraProvider?.unbindAll() } catch (_: Exception) {}
            camera = null
            videoCapture = null
            recordingFirstMode = false
            visualAnalysisAvailable = true
            recordingFirstWorkloadQueued = false
            framesSeenInSession = 0
            firstRecordingStartQueued = false
            cameraSessionStarting = false
            cameraProviderReady = false
            cameraBindCompleted = false
            latestJpeg.set(null)

            startCamera()
        }, 1_500L)
    }

    private fun stopRecording() {
        recording?.stop()
    }

    private val rolloverRunnable = Runnable {
        if (recordingReason == "continuous_background" &&
            recording != null &&
            prefs.getBoolean("continuous_recording", false) &&
            thermalRecordingAllowed() &&
            !serviceStopping
        ) {
            rollover = true
            stopRecording()
        }
    }

    private fun scheduleRollover() {
        handler.removeCallbacks(rolloverRunnable)
        handler.postDelayed(rolloverRunnable, segmentMs)
    }

    private fun applyRetention() {
        val maxGb = prefs.getInt("storage_max_gb", 20)
        val days = prefs.getInt("retention_days", 7)
        val minFreeGb = prefs.getInt("storage_min_free_gb", 2)

        VideoRetentionManager.cleanupAsync(
            this,
            maxGb,
            days,
            minFreeGb
        ) { result ->
            if (result.deletedFiles > 0) {
                eventStore.add(
                    "Storage cleanup",
                    "deleted=${result.deletedFiles} • freed=${formatBytes(result.freedBytes)}"
                )
            }
        }
    }

    private fun ensureLanServerStarted() {
        val ip =
            LocalNetwork.bestIpv4Address()

        if (ip == null) {
            lastLanServerError =
                "No local LAN IP"

            eventStore.add(
                "LAN monitor unavailable",
                "Local recording and AI continue without Wi-Fi."
            )
            return
        }

        val token =
            Pairing.getOrCreateCameraToken(
                this
            )

        val info =
            PairInfo(
                ip,
                8787,
                token
            )

        // Switch only the endpoint callbacks/frame producer. LanCameraHub owns
        // one process-wide ServerSocket, so an already-connected MJPEG monitor
        // is not disconnected during Activity -> Service camera hand-off.
        LanCameraHub.setEndpoint(
            object : LanCameraEndpoint {
                override fun statusJson(): String =
                    """{"ok":true,"backgroundService":true,"lanServerRunning":${LanCameraHub.isRunning()},"lanServerError":"${lastLanServerError.replace("\"", "'")}","zoomRatio":$currentZoomRatio,"maxZoom":$maxZoomRatio,"zoomLinear":$cameraZoomLinear,"panX":$cameraPanX,"panY":$cameraPanY,"previewQualityMode":${previewQualityMode()},"previewQuality":"${previewQualityLabel()}","freeformPanSupported":$freeformCropSupported,"panMode":"${if (freeformCropSupported) "sensor-freeform" else "live-software-fallback"}","recording":${recording != null},"recordingAvailable":${videoCapture != null},"strictRecordingQuality":${strictRecordingQuality()},"recordingMode":${recordingMode()},"recordingModeName":"${recordingModeName()}","recordingFirstMode":$recordingFirstMode,"previewAiBridgeMode":$previewAiBridgeMode,"visualStreamAvailable":$visualAnalysisAvailable,"animalTracking":${prefs.getBoolean("animal_tracking", false)},"recordingAudioEnabled":${recordingAudioEnabled()},"compatibilityStage":"${currentCompatibilityStageLabel()}","cameraSessionGeneration":$cameraSessionGeneration,"firstFramePending":${!recordingFirstMode && framesSeenInSession == 0},"manualFocusSupported":$manualFocusSupported,"maxFocusDiopters":$maxFocusDiopters,"focusManual":$focusManual,"focusLinear":$focusLinear,"quality":"$activeBackgroundQualityName","requestedQuality":"${selectedQualityName()}","networkOnline":$networkOnline,"audioAi":${prefs.getBoolean("audio_ai_detection", false)},"fallAi":${prefs.getBoolean("fall_detection", false)},"aggressiveAi":${prefs.getBoolean("aggressive_detection", false)},"frameReady":${latestJpeg.get() != null},"framesSeen":$framesSeenInSession,"frameAgeMs":${if (latestFrameAtMs == 0L) -1 else System.currentTimeMillis() - latestFrameAtMs},"compatibilityLevel":$backgroundCompatibilityLevel,"framePipelineErrorCount":$framePipelineErrorCount,"sourceFps":$sourceFps,"thermalStatus":"${thermalName(thermalStatus)}","thermalLiveFps":${effectiveLiveFps()},"thermalAiFps":${effectiveAiFps()},"aiNormalTargetFps":10,"cool247":${prefs.getBoolean("cool_24_7_mode", true)}}"""

                override fun eventsJson(): String =
                    eventStore.json()

                override fun onZoom(linear: Float) {
                    Handler(
                        Looper.getMainLooper()
                    ).post {
                        setCameraView(
                            linear,
                            cameraPanX,
                            cameraPanY
                        )
                    }
                }

                override fun onCameraView(
                    linear: Float,
                    panX: Float,
                    panY: Float
                ) {
                    Handler(
                        Looper.getMainLooper()
                    ).post {
                        setCameraView(
                            linear,
                            panX,
                            panY
                        )
                    }
                }

                override fun onPreviewQuality(mode: Int) {
                    prefs.edit()
                        .putInt(
                            "preview_quality_mode",
                            mode.coerceIn(0, 4)
                        )
                        .apply()

                    eventStore.add(
                        "Preview quality changed",
                        previewQualityLabel()
                    )
                }

                override fun onFocusAuto() {
                    Handler(
                        Looper.getMainLooper()
                    ).post {
                        setAutoFocus()
                    }
                }

                override fun onFocusManual(linear: Float) {
                    Handler(
                        Looper.getMainLooper()
                    ).post {
                        setManualFocus(
                            linear
                        )
                    }
                }

                override fun onFocusSave() {
                    Handler(
                        Looper.getMainLooper()
                    ).post {
                        saveFocus()
                    }
                }

                override fun onRestartCameraApp(): String {
                    eventStore.add(
                        "Remote camera app restart",
                        "Monitor phone requested background camera recovery."
                    )

                    Handler(
                        Looper.getMainLooper()
                    ).postDelayed(
                        {
                            if (serviceStopping) {
                                return@postDelayed
                            }

                            try {
                                ensureLanServerStarted()

                                if (camera == null && !cameraSessionStarting) {
                                    startCamera()
                                }

                                try {
                                    startActivity(
                                        Intent(
                                            this@DoorMonitoringService,
                                            CameraActivity::class.java
                                        ).apply {
                                            addFlags(
                                                Intent.FLAG_ACTIVITY_NEW_TASK or
                                                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                                    Intent.FLAG_ACTIVITY_SINGLE_TOP
                                            )
                                        }
                                    )
                                } catch (_: Throwable) {
                                }
                            } catch (_: Throwable) {
                            }
                        },
                        300L
                    )

                    return """{"ok":true,"supported":true,"action":"camera_app_restart","cameraEngineRestartQueued":true,"uiLaunchBestEffort":true}"""
                }

                override fun onRecordStart() {
                    Handler(
                        Looper.getMainLooper()
                    ).post {
                        try {
                            if (recording == null) {
                                startRecording(
                                    "remote"
                                )
                            }
                        } catch (t: Throwable) {
                            eventStore.add(
                                "Remote recording command failed",
                                t.javaClass.simpleName + ": " +
                                    (t.message ?: "unknown")
                            )
                        }
                    }
                }

                override fun onRecordStop() {
                    Handler(
                        Looper.getMainLooper()
                    ).post {
                        stopRecording()
                    }
                }
            }
        )

        server =
            LanCameraHub.ensureStarted(this)

        if (server?.isRunning() == true) {
            pairInfo = info
            lastLanServerError = ""
            lanServerRetryQueued = false

            eventStore.add(
                "LAN service ready",
                "$ip:8787 • persistent hand-off endpoint active."
            )
            return
        }

        lastLanServerError =
            LanCameraHub.startError()
                .ifBlank {
                    "Port 8787 bind failed"
                }

        eventStore.add(
            "LAN service bind retry",
            "Port 8787 not ready yet • $lastLanServerError"
        )

        scheduleLanServerRetry()
    }

    private fun scheduleLanServerRetry() {
        if (
            serviceStopping ||
            lanServerRetryQueued
        ) {
            return
        }

        lanServerRetryQueued =
            true

        handler.postDelayed({
            lanServerRetryQueued =
                false

            if (
                !serviceStopping &&
                cameraActivationRequested
            ) {
                ensureLanServerStarted()
            }
        }, 350L)
    }

    private fun startLanServer() {
        ensureLanServerStarted()
    }

    private fun registerNetworkWatcher() {
        val callback =
            object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    val wasOffline = !networkOnline
                    networkOnline = true
                    if (wasOffline) {
                        eventStore.add("Network restored")
                        Handler(Looper.getMainLooper()).post {
                            startLanServer()
                        }
                    }
                }

                override fun onLost(network: Network) {
                    networkOnline =
                        connectivity.activeNetwork != null

                    if (!networkOnline) {
                        eventStore.add(
                            "Network lost",
                            "24/7 local recording + AI continue on phone battery."
                        )
                        // Keep the wildcard-bound process LAN socket alive.
                        // It can resume on the new network without dropping the
                        // endpoint during camera/service transitions.
                        server = LanCameraHub.server()
                    }
                }
            }

        networkCallback = callback
        try {
            connectivity.registerDefaultNetworkCallback(callback)
        } catch (_: Exception) {}
    }

    private fun acquireWakeLock() {
        try {
            val pm =
                getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "AIDoorMonitor:ScreenOffMonitoring"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun acquireWifiLock() {
        try {
            if (wifiLock?.isHeld == true) return
            val manager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                ?: return
            wifiLock = manager.createWifiLock(
                WifiManager.WIFI_MODE_FULL_HIGH_PERF,
                "AIDoorMonitor:ScreenOffLan"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
            eventStore.add(
                "Wi-Fi screen-off lock",
                "Wi-Fi radio lock acquired by the foreground camera service."
            )
        } catch (t: Throwable) {
            wifiLock = null
            eventStore.add(
                "Wi-Fi lock warning",
                t.message ?: t.javaClass.simpleName
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AI Door Monitor",
                NotificationManager.IMPORTANCE_LOW
            )
            channel.description =
                "24/7 camera monitoring while the screen is off"
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): android.app.Notification {
        val openIntent =
            Intent(
                this,
                CameraActivity::class.java
            ).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
            }

        val openPending =
            PendingIntent.getActivity(
                this,
                1,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or
                    PendingIntent.FLAG_IMMUTABLE
            )

        val stopIntent =
            Intent(this, DoorMonitoringService::class.java)
                .setAction(ACTION_STOP)

        val stopPending = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("AI Door Monitor")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPending)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Stop",
                stopPending
            )
            .build()
    }

    private fun updateNotification(text: String) {
        val manager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(
            NOTIFICATION_ID,
            buildNotification(text)
        )
    }

    private fun formatBytes(bytes: Long): String {
        val gb = bytes.toDouble() / 1024.0 / 1024.0 / 1024.0
        return String.format(Locale.US, "%.2f GB", gb)
    }

    override fun onDestroy() {
        isRunning = false
        isCameraActivationRequested = false
        serviceStopping = true
        lanServerRetryQueued = false
        cameraRestartScheduled = false
        handler.removeCallbacksAndMessages(null)
        prefs.edit()
            .putBoolean("background_service_running", false)
            .apply()

        handler.removeCallbacksAndMessages(null)

        try { recording?.stop() } catch (_: Exception) {}
        recording = null

        // Do not close the process-wide LAN socket here. CameraActivity may
        // immediately reclaim the camera after 24/7 is stopped.
        server = LanCameraHub.server()

        try { audioDetector?.stop() } catch (_: Exception) {}
        audioDetector = null

        try { poseDetector?.stop() } catch (_: Exception) {}
        poseDetector = null

        try { animalDetector?.stop() } catch (_: Exception) {}
        animalDetector = null

        try { previewAiBridge?.stop() } catch (_: Exception) {}
        previewAiBridge = null

        networkCallback?.let {
            try {
                connectivity.unregisterNetworkCallback(it)
            } catch (_: Exception) {}
        }

        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        cameraProvider = null
        camera = null

        analysisExecutor.shutdownNow()
        aiInitExecutor.shutdownNow()
        aiFrameExecutor.shutdownNow()
        eventMergeExecutor.shutdownNow()
        handler.removeCallbacks(preBufferStopRunnable)
        try { currentPreBufferFile?.delete() } catch (_: Exception) {}
        synchronized(preBufferSegments) {
            preBufferSegments.forEach { segment ->
                if (!protectedPreBufferPaths.contains(segment.file.absolutePath)) {
                    try { segment.file.delete() } catch (_: Exception) {}
                }
            }
            preBufferSegments.clear()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            thermalListener?.let { listener ->
                try {
                    thermalPowerManager.removeThermalStatusListener(
                        listener
                    )
                } catch (_: Exception) {}
            }
        }
        thermalListener = null

        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {}
        wifiLock = null

        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}
        wakeLock = null

        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED

        super.onDestroy()
    }
}
