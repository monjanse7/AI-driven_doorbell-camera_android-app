package com.example.aidoormonitor

import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aidoormonitor.databinding.ActivityMainBinding
import com.example.aidoormonitor.store.EventStore

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.root.applySystemBarInsets()

        // Record a previous crash, but never auto-open CameraActivity from
        // MainActivity.  The old recovery loop could reopen a failing camera
        // screen indefinitely and make the whole app appear to blink.
        AIDoorMonitorApp.consumeLastCrash(this)?.let { report ->
            EventStore(this).add(
                "Previous app/service crash",
                report
            )

            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Previous camera crash detected")
                .setMessage(report)
                .setPositiveButton("Copy crash") { _, _ ->
                    val clipboard =
                        getSystemService(Context.CLIPBOARD_SERVICE)
                            as ClipboardManager
                    clipboard.setPrimaryClip(
                        ClipData.newPlainText(
                            "AI Door Monitor crash",
                            report
                        )
                    )
                }
                .setNegativeButton("Close", null)
                .show()
        }

        // Clear stale dashboard-navigation flags from older builds.  Camera
        // Mode is now allowed to remain stopped if Android or CameraX rejects
        // startup; the user stays on this menu instead of entering a loop.
        getSharedPreferences("camera_settings", MODE_PRIVATE)
            .edit()
            .putBoolean("keep_camera_dashboard_open", false)
            .putBoolean("background_handoff_pending", false)
            .apply()

        b.cameraMode.setOnClickListener {
            startActivity(Intent(this, DvrCameraActivity::class.java))
        }

        b.legacyCameraMode.setOnClickListener {
            startActivity(Intent(this, CameraActivity::class.java))
        }
        b.monitorMode.setOnClickListener {
            startActivity(Intent(this, MonitorActivity::class.java))
        }
        b.rules.setOnClickListener {
            startActivity(Intent(this, RuleEditorActivity::class.java))
        }
    }
}
