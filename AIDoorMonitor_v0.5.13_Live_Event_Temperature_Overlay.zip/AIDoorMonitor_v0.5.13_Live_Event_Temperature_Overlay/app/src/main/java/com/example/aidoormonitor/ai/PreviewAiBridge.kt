package com.example.aidoormonitor.ai

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import androidx.camera.core.Preview
import androidx.camera.core.SurfaceRequest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Off-screen CameraX Preview consumer.
 *
 * Important:
 * - CameraX Preview and high-resolution VideoCapture remain separate streams.
 * - The AI/live frame preserves the ACTUAL SurfaceRequest aspect ratio.
 * - The source is never stretched into a hard-coded 16:9 bitmap.
 *
 * outputWidth/outputHeight are maximum bounds, not a forced aspect ratio.
 */
class PreviewAiBridge(
    private val outputWidth: Int = 480,
    private val outputHeight: Int = 480,
    private val maxFps: Int = 10,
    private val onFrame: (Bitmap) -> Unit,
    private val onStatus: (String) -> Unit = {}
) : Preview.SurfaceProvider {

    private val thread =
        HandlerThread(
            "PreviewAiBridge"
        ).apply {
            start()
        }

    private val handler =
        Handler(
            thread.looper
        )

    private val handlerExecutor =
        Executor {
            handler.post(it)
        }

    private val frameBusy =
        AtomicBoolean(false)

    @Volatile
    private var stopped = false

    private var lastFrameAt = 0L
    private var rotationDegrees = 0

    private var sourceWidth = 0
    private var sourceHeight = 0

    private var renderWidth = 480
    private var renderHeight = 270

    private var eglDisplay:
        EGLDisplay =
        EGL14.EGL_NO_DISPLAY

    private var eglContext:
        EGLContext =
        EGL14.EGL_NO_CONTEXT

    private var eglSurface:
        EGLSurface =
        EGL14.EGL_NO_SURFACE

    private var eglConfig:
        EGLConfig? = null

    private var pbufferWidth = 0
    private var pbufferHeight = 0

    private var program = 0
    private var oesTexture = 0

    private var surfaceTexture:
        SurfaceTexture? = null

    private var cameraSurface:
        Surface? = null

    private val texMatrix =
        FloatArray(16)

    private val vertexBuffer:
        FloatBuffer =
        ByteBuffer
            .allocateDirect(
                4 * 4 * 4
            )
            .order(
                ByteOrder.nativeOrder()
            )
            .asFloatBuffer()
            .apply {
                put(
                    floatArrayOf(
                        -1f, -1f, 0f, 1f,
                         1f, -1f, 0f, 1f,
                        -1f,  1f, 0f, 1f,
                         1f,  1f, 0f, 1f
                    )
                )
                position(0)
            }

    private val texBuffer:
        FloatBuffer =
        ByteBuffer
            .allocateDirect(
                4 * 4 * 4
            )
            .order(
                ByteOrder.nativeOrder()
            )
            .asFloatBuffer()
            .apply {
                put(
                    floatArrayOf(
                        0f, 0f, 0f, 1f,
                        1f, 0f, 0f, 1f,
                        0f, 1f, 0f, 1f,
                        1f, 1f, 0f, 1f
                    )
                )
                position(0)
            }

    override fun onSurfaceRequested(
        request: SurfaceRequest
    ) {
        handler.post {
            if (stopped) {
                request.willNotProvideSurface()
                return@post
            }

            try {
                sourceWidth =
                    request.resolution.width
                        .coerceAtLeast(2)

                sourceHeight =
                    request.resolution.height
                        .coerceAtLeast(2)

                calculateAspectCorrectRenderSize(
                    sourceWidth,
                    sourceHeight
                )

                ensureGl(
                    renderWidth,
                    renderHeight
                )

                releaseCameraSurfaceOnly()

                val texture =
                    SurfaceTexture(
                        oesTexture
                    )

                texture.setDefaultBufferSize(
                    sourceWidth,
                    sourceHeight
                )

                surfaceTexture =
                    texture

                cameraSurface =
                    Surface(texture)

                request.setTransformationInfoListener(
                    handlerExecutor
                ) { info ->
                    rotationDegrees =
                        info.rotationDegrees
                }

                texture.setOnFrameAvailableListener(
                    {
                        scheduleFrame()
                    },
                    handler
                )

                val supplied =
                    cameraSurface
                        ?: throw IllegalStateException(
                            "Preview surface missing"
                        )

                request.provideSurface(
                    supplied,
                    handlerExecutor
                ) {
                    handler.post {
                        releaseCameraSurfaceOnly()
                    }
                }

                onStatus(
                    "Preview AI bridge active • source=${sourceWidth}×${sourceHeight} • AI=${renderWidth}×${renderHeight} • aspect preserved"
                )

            } catch (t: Throwable) {
                onStatus(
                    "Preview AI bridge failed: ${t.message ?: t.javaClass.simpleName}"
                )

                try {
                    request.willNotProvideSurface()
                } catch (_: Throwable) {}
            }
        }
    }

    private fun calculateAspectCorrectRenderSize(
        sourceW: Int,
        sourceH: Int
    ) {
        val maxW =
            outputWidth.coerceAtLeast(2)

        val maxH =
            outputHeight.coerceAtLeast(2)

        val scale =
            min(
                maxW.toFloat() /
                    sourceW.toFloat(),
                maxH.toFloat() /
                    sourceH.toFloat()
            )
                .coerceAtMost(1f)

        renderWidth =
            (sourceW * scale)
                .roundToInt()
                .coerceAtLeast(2)

        renderHeight =
            (sourceH * scale)
                .roundToInt()
                .coerceAtLeast(2)
    }

    private fun scheduleFrame() {
        if (
            stopped ||
            !frameBusy.compareAndSet(
                false,
                true
            )
        ) {
            return
        }

        val now =
            System.currentTimeMillis()

        val interval =
            1000L /
                maxFps.coerceIn(
                    1,
                    30
                )

        if (
            lastFrameAt > 0L &&
            now - lastFrameAt <
                interval
        ) {
            try {
                surfaceTexture
                    ?.updateTexImage()
            } catch (_: Exception) {}

            frameBusy.set(false)
            return
        }

        lastFrameAt = now

        try {
            renderBitmap()
        } catch (t: Throwable) {
            onStatus(
                "Preview AI bridge worker error: ${t.message ?: t.javaClass.simpleName}"
            )
        } finally {
            frameBusy.set(false)
        }
    }

    private fun renderBitmap() {
        val texture =
            surfaceTexture ?: return

        try {
            EGL14.eglMakeCurrent(
                eglDisplay,
                eglSurface,
                eglSurface,
                eglContext
            )

            texture.updateTexImage()

            texture.getTransformMatrix(
                texMatrix
            )

            GLES20.glViewport(
                0,
                0,
                renderWidth,
                renderHeight
            )

            GLES20.glClearColor(
                0f,
                0f,
                0f,
                1f
            )

            GLES20.glClear(
                GLES20.GL_COLOR_BUFFER_BIT
            )

            GLES20.glUseProgram(
                program
            )

            val positionLoc =
                GLES20.glGetAttribLocation(
                    program,
                    "aPosition"
                )

            val texLoc =
                GLES20.glGetAttribLocation(
                    program,
                    "aTexCoord"
                )

            val matrixLoc =
                GLES20.glGetUniformLocation(
                    program,
                    "uTexMatrix"
                )

            GLES20.glEnableVertexAttribArray(
                positionLoc
            )

            vertexBuffer.position(0)

            GLES20.glVertexAttribPointer(
                positionLoc,
                4,
                GLES20.GL_FLOAT,
                false,
                0,
                vertexBuffer
            )

            GLES20.glEnableVertexAttribArray(
                texLoc
            )

            texBuffer.position(0)

            GLES20.glVertexAttribPointer(
                texLoc,
                4,
                GLES20.GL_FLOAT,
                false,
                0,
                texBuffer
            )

            GLES20.glUniformMatrix4fv(
                matrixLoc,
                1,
                false,
                texMatrix,
                0
            )

            GLES20.glActiveTexture(
                GLES20.GL_TEXTURE0
            )

            GLES20.glBindTexture(
                GLES11Ext
                    .GL_TEXTURE_EXTERNAL_OES,
                oesTexture
            )

            GLES20.glDrawArrays(
                GLES20.GL_TRIANGLE_STRIP,
                0,
                4
            )

            GLES20.glFinish()

            val pixels =
                ByteBuffer
                    .allocateDirect(
                        renderWidth *
                            renderHeight *
                            4
                    )
                    .order(
                        ByteOrder.nativeOrder()
                    )

            GLES20.glReadPixels(
                0,
                0,
                renderWidth,
                renderHeight,
                GLES20.GL_RGBA,
                GLES20.GL_UNSIGNED_BYTE,
                pixels
            )

            pixels.rewind()

            val raw =
                Bitmap.createBitmap(
                    renderWidth,
                    renderHeight,
                    Bitmap.Config.ARGB_8888
                )

            raw.copyPixelsFromBuffer(
                pixels
            )

            // GL is vertically flipped. CameraX rotation is then applied.
            val matrix =
                Matrix().apply {
                    postScale(
                        1f,
                        -1f,
                        renderWidth / 2f,
                        renderHeight / 2f
                    )

                    if (
                        rotationDegrees != 0
                    ) {
                        postRotate(
                            rotationDegrees.toFloat(),
                            renderWidth / 2f,
                            renderHeight / 2f
                        )
                    }
                }

            val transformed =
                try {
                    Bitmap.createBitmap(
                        raw,
                        0,
                        0,
                        raw.width,
                        raw.height,
                        matrix,
                        true
                    )
                } catch (_: Exception) {
                    raw.copy(
                        Bitmap.Config.ARGB_8888,
                        false
                    )
                }

            if (
                transformed !== raw &&
                !raw.isRecycled
            ) {
                raw.recycle()
            }

            onFrame(
                transformed
            )

        } catch (t: Throwable) {
            onStatus(
                "Preview AI bridge frame error: ${t.message ?: t.javaClass.simpleName}"
            )
        }
    }

    private fun ensureGl(
        wantedWidth: Int,
        wantedHeight: Int
    ) {
        if (
            eglDisplay ==
            EGL14.EGL_NO_DISPLAY
        ) {
            eglDisplay =
                EGL14.eglGetDisplay(
                    EGL14.EGL_DEFAULT_DISPLAY
                )

            val version =
                IntArray(2)

            check(
                EGL14.eglInitialize(
                    eglDisplay,
                    version,
                    0,
                    version,
                    1
                )
            )

            val attributes =
                intArrayOf(
                    EGL14.EGL_RENDERABLE_TYPE,
                    EGL14.EGL_OPENGL_ES2_BIT,
                    EGL14.EGL_SURFACE_TYPE,
                    EGL14.EGL_PBUFFER_BIT,
                    EGL14.EGL_RED_SIZE,
                    8,
                    EGL14.EGL_GREEN_SIZE,
                    8,
                    EGL14.EGL_BLUE_SIZE,
                    8,
                    EGL14.EGL_ALPHA_SIZE,
                    8,
                    EGL14.EGL_NONE
                )

            val configs =
                arrayOfNulls<EGLConfig>(
                    1
                )

            val count =
                IntArray(1)

            check(
                EGL14.eglChooseConfig(
                    eglDisplay,
                    attributes,
                    0,
                    configs,
                    0,
                    1,
                    count,
                    0
                )
            )

            val config =
                configs[0]
                    ?: throw IllegalStateException(
                        "No EGL config"
                    )

            eglConfig =
                config

            eglContext =
                EGL14.eglCreateContext(
                    eglDisplay,
                    config,
                    EGL14.EGL_NO_CONTEXT,
                    intArrayOf(
                        EGL14.EGL_CONTEXT_CLIENT_VERSION,
                        2,
                        EGL14.EGL_NONE
                    ),
                    0
                )
        }

        ensurePbuffer(
            wantedWidth,
            wantedHeight
        )

        EGL14.eglMakeCurrent(
            eglDisplay,
            eglSurface,
            eglSurface,
            eglContext
        )

        if (oesTexture == 0) {
            val textures =
                IntArray(1)

            GLES20.glGenTextures(
                1,
                textures,
                0
            )

            oesTexture =
                textures[0]

            GLES20.glBindTexture(
                GLES11Ext
                    .GL_TEXTURE_EXTERNAL_OES,
                oesTexture
            )

            GLES20.glTexParameteri(
                GLES11Ext
                    .GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_MIN_FILTER,
                GLES20.GL_LINEAR
            )

            GLES20.glTexParameteri(
                GLES11Ext
                    .GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_MAG_FILTER,
                GLES20.GL_LINEAR
            )

            GLES20.glTexParameteri(
                GLES11Ext
                    .GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_WRAP_S,
                GLES20.GL_CLAMP_TO_EDGE
            )

            GLES20.glTexParameteri(
                GLES11Ext
                    .GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_WRAP_T,
                GLES20.GL_CLAMP_TO_EDGE
            )
        }

        if (program == 0) {
            val vertex =
                compileShader(
                    GLES20.GL_VERTEX_SHADER,
                    """
                    attribute vec4 aPosition;
                    attribute vec4 aTexCoord;
                    uniform mat4 uTexMatrix;
                    varying vec2 vTexCoord;

                    void main() {
                        gl_Position = aPosition;
                        vTexCoord =
                            (uTexMatrix * aTexCoord).xy;
                    }
                    """.trimIndent()
                )

            val fragment =
                compileShader(
                    GLES20.GL_FRAGMENT_SHADER,
                    """
                    #extension GL_OES_EGL_image_external : require
                    precision mediump float;
                    varying vec2 vTexCoord;
                    uniform samplerExternalOES sTexture;

                    void main() {
                        gl_FragColor =
                            texture2D(
                                sTexture,
                                vTexCoord
                            );
                    }
                    """.trimIndent()
                )

            program =
                GLES20.glCreateProgram()

            GLES20.glAttachShader(
                program,
                vertex
            )

            GLES20.glAttachShader(
                program,
                fragment
            )

            GLES20.glLinkProgram(
                program
            )

            GLES20.glDeleteShader(
                vertex
            )

            GLES20.glDeleteShader(
                fragment
            )
        }
    }

    private fun ensurePbuffer(
        wantedWidth: Int,
        wantedHeight: Int
    ) {
        if (
            eglSurface !=
            EGL14.EGL_NO_SURFACE &&
            pbufferWidth ==
                wantedWidth &&
            pbufferHeight ==
                wantedHeight
        ) {
            return
        }

        if (
            eglSurface !=
            EGL14.EGL_NO_SURFACE
        ) {
            try {
                EGL14.eglDestroySurface(
                    eglDisplay,
                    eglSurface
                )
            } catch (_: Exception) {}

            eglSurface =
                EGL14.EGL_NO_SURFACE
        }

        val config =
            eglConfig
                ?: throw IllegalStateException(
                    "EGL config unavailable"
                )

        eglSurface =
            EGL14.eglCreatePbufferSurface(
                eglDisplay,
                config,
                intArrayOf(
                    EGL14.EGL_WIDTH,
                    wantedWidth,
                    EGL14.EGL_HEIGHT,
                    wantedHeight,
                    EGL14.EGL_NONE
                ),
                0
            )

        pbufferWidth =
            wantedWidth

        pbufferHeight =
            wantedHeight
    }

    private fun compileShader(
        type: Int,
        code: String
    ): Int {
        val shader =
            GLES20.glCreateShader(
                type
            )

        GLES20.glShaderSource(
            shader,
            code
        )

        GLES20.glCompileShader(
            shader
        )

        val status =
            IntArray(1)

        GLES20.glGetShaderiv(
            shader,
            GLES20.GL_COMPILE_STATUS,
            status,
            0
        )

        if (
            status[0] ==
            GLES20.GL_FALSE
        ) {
            val log =
                GLES20.glGetShaderInfoLog(
                    shader
                )

            GLES20.glDeleteShader(
                shader
            )

            throw IllegalStateException(
                "GL shader failed: $log"
            )
        }

        return shader
    }

    private fun releaseCameraSurfaceOnly() {
        try {
            cameraSurface?.release()
        } catch (_: Exception) {}

        cameraSurface = null

        try {
            surfaceTexture?.release()
        } catch (_: Exception) {}

        surfaceTexture = null
    }

    fun stop() {
        if (stopped) return
        stopped = true

        handler.post {
            releaseCameraSurfaceOnly()

            try {
                if (
                    eglDisplay !=
                    EGL14.EGL_NO_DISPLAY &&
                    eglSurface !=
                    EGL14.EGL_NO_SURFACE
                ) {
                    EGL14.eglMakeCurrent(
                        eglDisplay,
                        eglSurface,
                        eglSurface,
                        eglContext
                    )
                }

                if (
                    oesTexture != 0
                ) {
                    GLES20.glDeleteTextures(
                        1,
                        intArrayOf(
                            oesTexture
                        ),
                        0
                    )
                }

                if (program != 0) {
                    GLES20.glDeleteProgram(
                        program
                    )
                }
            } catch (_: Exception) {}

            try {
                if (
                    eglDisplay !=
                    EGL14.EGL_NO_DISPLAY
                ) {
                    EGL14.eglMakeCurrent(
                        eglDisplay,
                        EGL14.EGL_NO_SURFACE,
                        EGL14.EGL_NO_SURFACE,
                        EGL14.EGL_NO_CONTEXT
                    )

                    if (
                        eglSurface !=
                        EGL14.EGL_NO_SURFACE
                    ) {
                        EGL14.eglDestroySurface(
                            eglDisplay,
                            eglSurface
                        )
                    }

                    if (
                        eglContext !=
                        EGL14.EGL_NO_CONTEXT
                    ) {
                        EGL14.eglDestroyContext(
                            eglDisplay,
                            eglContext
                        )
                    }

                    EGL14.eglTerminate(
                        eglDisplay
                    )
                }
            } catch (_: Exception) {}

            thread.quitSafely()
        }
    }
}
