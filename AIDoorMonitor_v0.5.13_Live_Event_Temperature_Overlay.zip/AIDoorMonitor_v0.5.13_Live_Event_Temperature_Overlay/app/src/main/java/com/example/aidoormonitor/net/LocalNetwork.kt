package com.example.aidoormonitor.net

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object LocalNetwork {
    fun bestIpv4Address(): String? {
        val candidates = mutableListOf<Pair<Int, String>>()

        return try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            interfaces.forEach { iface ->
                if (!iface.isUp || iface.isLoopback) return@forEach
                val priority = when {
                    iface.name.startsWith("wlan", ignoreCase = true) -> 0
                    iface.name.startsWith("wifi", ignoreCase = true) -> 0
                    iface.name.startsWith("eth", ignoreCase = true) -> 1
                    else -> 2
                }

                Collections.list(iface.inetAddresses).forEach { address ->
                    if (address is Inet4Address &&
                        !address.isLoopbackAddress &&
                        address.isSiteLocalAddress
                    ) {
                        candidates += priority to address.hostAddress.orEmpty()
                    }
                }
            }

            candidates
                .filter { it.second.isNotBlank() }
                .sortedWith(compareBy<Pair<Int, String>> { it.first }.thenBy { it.second })
                .firstOrNull()
                ?.second
        } catch (_: Exception) {
            null
        }
    }
}
