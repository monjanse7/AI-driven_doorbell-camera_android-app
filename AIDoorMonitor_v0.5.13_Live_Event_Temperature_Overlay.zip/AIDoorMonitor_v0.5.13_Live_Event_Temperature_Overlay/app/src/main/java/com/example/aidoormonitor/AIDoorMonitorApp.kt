package com.example.aidoormonitor

import android.app.Application
import android.content.Context

class AIDoorMonitorApp : Application() {
    override fun onCreate() {
        super.onCreate()

        val previous =
            Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler {
                thread,
                throwable ->

            try {
                val shortStack =
                    throwable.stackTrace
                        .take(8)
                        .joinToString(" | ") {
                            "${it.className}.${it.methodName}:${it.lineNumber}"
                        }

                val report =
                    buildString {
                        append(thread.name)
                        append(" • ")
                        append(
                            throwable.javaClass.simpleName
                        )

                        val message =
                            throwable.message

                        if (!message.isNullOrBlank()) {
                            append(": ")
                            append(message.take(600))
                        }

                        if (shortStack.isNotBlank()) {
                            append(" • ")
                            append(shortStack.take(1200))
                        }
                    }

                getSharedPreferences(
                    "crash_guard",
                    Context.MODE_PRIVATE
                )
                    .edit()
                    .putString(
                        "last_crash",
                        report
                    )
                    .commit()
            } catch (_: Throwable) {}

            if (previous != null) {
                previous.uncaughtException(
                    thread,
                    throwable
                )
            }
        }
    }

    companion object {
        fun consumeLastCrash(
            context: Context
        ): String? {
            val prefs =
                context.getSharedPreferences(
                    "crash_guard",
                    Context.MODE_PRIVATE
                )

            val value =
                prefs.getString(
                    "last_crash",
                    null
                )

            if (value != null) {
                prefs.edit()
                    .remove("last_crash")
                    .apply()
            }

            return value
        }
    }
}
