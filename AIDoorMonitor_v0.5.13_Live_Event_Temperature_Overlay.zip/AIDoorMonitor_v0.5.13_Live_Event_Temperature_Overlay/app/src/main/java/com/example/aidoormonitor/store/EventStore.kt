package com.example.aidoormonitor.store

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DoorEvent(
    val timestamp: Long,
    val type: String,
    val details: String
)

class EventStore(context: Context) {
    private val prefs = context.getSharedPreferences("door_events", Context.MODE_PRIVATE)

    @Synchronized
    fun add(type: String, details: String = "") {
        val items = load().toMutableList()
        items.add(0, DoorEvent(System.currentTimeMillis(), type, details))
        while (items.size > 100) items.removeLast()
        save(items)
    }

    @Synchronized
    fun load(): List<DoorEvent> {
        val raw = prefs.getString("events", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                DoorEvent(
                    o.getLong("timestamp"),
                    o.getString("type"),
                    o.optString("details", "")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun json(): String {
        val arr = JSONArray()
        load().forEach { e ->
            arr.put(JSONObject().apply {
                put("timestamp", e.timestamp)
                put("type", e.type)
                put("details", e.details)
            })
        }
        return JSONObject().put("events", arr).toString()
    }

    fun readable(limit: Int = 10): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val items = load().take(limit)
        if (items.isEmpty()) return "No saved events yet."
        return items.joinToString("\n") {
            "${fmt.format(Date(it.timestamp))} • ${it.type}" +
                if (it.details.isBlank()) "" else " • ${it.details}"
        }
    }

    private fun save(items: List<DoorEvent>) {
        val arr = JSONArray()
        items.forEach { e ->
            arr.put(JSONObject().apply {
                put("timestamp", e.timestamp)
                put("type", e.type)
                put("details", e.details)
            })
        }
        prefs.edit().putString("events", arr.toString()).apply()
    }
}
