package com.example.aidoormonitor.ai

import java.util.ArrayDeque
import kotlin.math.max

/**
 * EXPERIMENTAL, NON-DIAGNOSTIC visual pattern detector.
 *
 * This does NOT diagnose epilepsy and must not be relied upon for medical
 * decisions or emergency response. It only looks for sustained, repetitive
 * high-motion patterns that can resemble convulsive motion in a fixed camera.
 *
 * A future medically-oriented implementation would require a validated
 * temporal video model trained on appropriate seizure/non-seizure data.
 */
class SeizureLikeMotionDetector {
    private data class Sample(val t: Long, val score: Float)

    private val samples = ArrayDeque<Sample>()
    private var lastSampleAt = 0L
    private var lastAlertAt = 0L

    fun reset() {
        samples.clear()
        lastSampleAt = 0L
    }

    /**
     * Returns true when a sustained repetitive-motion pattern is observed.
     *
     * The heuristic uses:
     * - an ~8 second window
     * - repeated crossings of a dynamic high-motion threshold
     * - non-trivial average movement
     * - a cooldown to avoid repeated alerts for the same episode
     */
    fun update(score: Float, now: Long = System.currentTimeMillis()): Boolean {
        // Downsample the score history to about 10 Hz.
        if (lastSampleAt != 0L && now - lastSampleAt < 90L) return false
        lastSampleAt = now

        samples.addLast(Sample(now, score))
        val windowMs = 8_000L
        while (samples.isNotEmpty() && now - samples.first().t > windowMs) {
            samples.removeFirst()
        }

        if (samples.size < 45) return false
        val span = samples.last().t - samples.first().t
        if (span < 6_000L) return false
        if (now - lastAlertAt < 60_000L) return false

        val values = samples.map { it.score }
        val mean = values.average().toFloat()
        if (mean < 3.2f) return false

        val sorted = values.sorted()
        val p70 = sorted[(sorted.size * 0.70f).toInt().coerceIn(0, sorted.lastIndex)]
        val high = max(4.5f, p70)

        // Count high-motion bursts rather than simply "lots of movement".
        var burstCount = 0
        var inHigh = false
        var highSamples = 0
        values.forEach { v ->
            if (v >= high) {
                highSamples++
                if (!inHigh) {
                    burstCount++
                    inHigh = true
                }
            } else if (v < high * 0.72f) {
                inHigh = false
            }
        }

        val highFraction = highSamples.toFloat() / values.size.toFloat()

        // Broad range on purpose: this is only an experimental alert.
        val detected =
            burstCount in 6..45 &&
            highFraction in 0.18f..0.78f &&
            mean >= 3.2f

        if (detected) {
            lastAlertAt = now
        }
        return detected
    }
}
