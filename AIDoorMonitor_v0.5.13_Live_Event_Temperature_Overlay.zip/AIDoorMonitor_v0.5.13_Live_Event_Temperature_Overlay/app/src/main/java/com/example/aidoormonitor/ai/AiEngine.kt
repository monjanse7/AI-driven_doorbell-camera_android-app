package com.example.aidoormonitor.ai

/**
 * In the next build this interface will be fed by:
 *  - MediaPipe/LiteRT object detection: person/cat/dog/bird/etc.
 *  - custom species model: magpie
 *  - MediaPipe audio classifier: bark/impact/etc.
 *  - temporal action model: dog fighting and user-defined actions
 *  - trajectory tracker: objects moving rapidly toward the door ROI
 *
 * The rule editor is deliberately independent from the model so the user can
 * rename, enable/disable and tune events without retraining the model.
 */
interface AiEngine {
    fun start()
    fun stop()
}
