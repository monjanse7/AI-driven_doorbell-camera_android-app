package com.example.aidoormonitor

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.aidoormonitor.databinding.ActivityRulesBinding
import com.example.aidoormonitor.model.AiRule
import com.example.aidoormonitor.model.RuleType
import com.example.aidoormonitor.store.RuleStore
import java.util.UUID

class RuleEditorActivity : AppCompatActivity() {
    private lateinit var b: ActivityRulesBinding
    private lateinit var store: RuleStore
    private lateinit var rules: MutableList<AiRule>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRulesBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.root.applySystemBarInsets()

        store = RuleStore(this)
        rules = store.load()

        val types = RuleType.entries.map { it.name.replace('_', ' ') }
        b.customType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)

        b.confidence.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                b.confText.text = "Confidence: $progress%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        b.addRule.setOnClickListener {
            val name = b.customName.text.toString().trim()
            val signal = b.customSignal.text.toString().trim()
            if (name.isNotEmpty() && signal.isNotEmpty()) {
                rules.add(
                    AiRule(
                        id = UUID.randomUUID().toString(),
                        name = name,
                        enabled = true,
                        type = RuleType.entries[b.customType.selectedItemPosition],
                        signal = signal,
                        confidence = b.confidence.progress
                    )
                )
                store.save(rules)
                b.customName.text.clear()
                b.customSignal.text.clear()
                render()
            }
        }
        render()
    }

    private fun render() {
        b.ruleList.removeAllViews()
        rules.forEach { rule ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 14, 0, 14)
            }

            val enabled = CheckBox(this).apply {
                text = rule.name
                isChecked = rule.enabled
                textSize = 18f
                setOnCheckedChangeListener { _, checked ->
                    rule.enabled = checked
                    store.save(rules)
                }
            }
            row.addView(enabled)

            row.addView(TextView(this).apply {
                text = "${rule.type.name.replace('_', ' ')} • signal: ${rule.signal} • ${rule.confidence}%"
            })

            if (rule.notes.isNotBlank()) {
                row.addView(TextView(this).apply {
                    text = rule.notes
                    alpha = 0.75f
                })
            }

            val confidence = SeekBar(this).apply {
                max = 100
                progress = rule.confidence
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) {
                            rule.confidence = progress
                            store.save(rules)
                        }
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
                })
            }
            row.addView(confidence)
            b.ruleList.addView(row)
        }
    }
}
