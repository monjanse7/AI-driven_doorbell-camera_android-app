package com.example.aidoormonitor.ui

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * Gesture surface for the monitor live viewer.
 *
 * NORMAL / remote-camera mode:
 * - pinch changes the camera phone's sensor-crop zoom;
 * - one-finger drag changes the remote digital crop position.
 *
 * FULLSCREEN / local-viewer-crop mode:
 * - pinch magnifies only the already received MJPEG frame;
 * - one-finger drag pans that local crop;
 * - no camera command is sent, so panning is independent of camera zoom support.
 */
class ZoomPanFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private enum class GestureMode {
        REMOTE_CAMERA,
        LOCAL_VIEWER_CROP
    }

    private var gestureMode = GestureMode.REMOTE_CAMERA

    private var zoomLinear = 0f
    private var panX = 0f
    private var panY = 0f
    private var maxZoomRatio = 1f

    private var localViewerScale = 1f

    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var dragging = false

    private val slop =
        ViewConfiguration.get(context).scaledTouchSlop.toFloat()

    private var viewListener:
        ((Float, Float, Float) -> Unit)? = null

    private var localZoomListener:
        ((Float) -> Unit)? = null

    private fun viewer(): MjpegView? {
        for (index in 0 until childCount) {
            val child = getChildAt(index)
            if (child is MjpegView) {
                return child
            }
        }
        return null
    }

    private val scaler =
        ScaleGestureDetector(
            context,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleBegin(
                    detector: ScaleGestureDetector
                ): Boolean {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    dragging = false
                    return true
                }

                override fun onScale(
                    detector: ScaleGestureDetector
                ): Boolean {
                    if (gestureMode == GestureMode.LOCAL_VIEWER_CROP) {
                        localViewerScale =
                            viewer()
                                ?.zoomViewerBy(
                                    detector.scaleFactor,
                                    detector.focusX,
                                    detector.focusY
                                )
                                ?: localViewerScale

                        if (localViewerScale <= 1.001f) {
                            localViewerScale = 1f
                            dragging = false
                        }

                        localZoomListener?.invoke(localViewerScale)
                        return true
                    }

                    val maxRatio =
                        maxZoomRatio.coerceAtLeast(1f)

                    val currentRatio =
                        if (maxRatio <= 1.001f) 1f
                        else 1f + zoomLinear * (maxRatio - 1f)

                    val nextRatio =
                        (currentRatio * detector.scaleFactor)
                            .coerceIn(1f, maxRatio)

                    zoomLinear =
                        if (maxRatio <= 1.001f) 0f
                        else ((nextRatio - 1f) / (maxRatio - 1f))
                            .coerceIn(0f, 1f)

                    if (zoomLinear <= 0.001f) {
                        zoomLinear = 0f
                        panX = 0f
                        panY = 0f
                    }

                    notifyViewChanged()
                    return true
                }
            }
        )

    init {
        isClickable = true
        isFocusable = true
        clipChildren = true
    }

    fun setOnCameraViewChanged(
        listener: ((Float, Float, Float) -> Unit)?
    ) {
        viewListener = listener
    }

    fun setMaxZoomRatio(value: Float) {
        maxZoomRatio = value.coerceAtLeast(1f)
    }

    fun setCameraState(
        linear: Float,
        newPanX: Float,
        newPanY: Float,
        notify: Boolean = false
    ) {
        zoomLinear = linear.coerceIn(0f, 1f)
        panX =
            if (zoomLinear <= 0.001f) 0f
            else newPanX.coerceIn(-1f, 1f)
        panY =
            if (zoomLinear <= 0.001f) 0f
            else newPanY.coerceIn(-1f, 1f)

        if (notify) notifyViewChanged()
    }

    fun resetCameraView(
        notify: Boolean = true
    ) {
        zoomLinear = 0f
        panX = 0f
        panY = 0f
        dragging = false
        if (notify) notifyViewChanged()
    }

    /** Use normal gestures that control the remote camera crop. */
    fun setGestureModeRemoteCamera() {
        gestureMode = GestureMode.REMOTE_CAMERA
        localZoomListener = null
        dragging = false
    }

    /**
     * Use fullscreen local crop gestures. This never calls the remote-camera
     * listener and therefore never changes camera zoom or camera pan.
     */
    fun setGestureModeLocalViewerCrop(
        listener: ((Float) -> Unit)? = null
    ) {
        gestureMode = GestureMode.LOCAL_VIEWER_CROP
        localZoomListener = listener
        localViewerScale = viewer()?.getViewerScale() ?: 1f
        dragging = false
        listener?.invoke(localViewerScale)
    }

    fun resetLocalViewerCrop() {
        viewer()?.resetViewerTransform()
        localViewerScale = 1f
        dragging = false
        localZoomListener?.invoke(localViewerScale)
    }

    private fun notifyViewChanged() {
        viewListener?.invoke(zoomLinear, panX, panY)
    }

    override fun onInterceptTouchEvent(
        ev: MotionEvent
    ): Boolean {
        // The live-view container owns gestures that begin on the video. This
        // prevents the surrounding ScrollView from stealing one-finger pan.
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            parent?.requestDisallowInterceptTouchEvent(true)
        }

        return true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaler.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                lastX = event.x
                lastY = event.y
                dragging = false
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = false
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (
                    event.pointerCount >= 2 ||
                    scaler.isInProgress
                ) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }

                val dx = event.x - lastX
                val dy = event.y - lastY

                if (gestureMode == GestureMode.LOCAL_VIEWER_CROP) {
                    if (
                        !dragging &&
                        localViewerScale > 1.001f &&
                        (
                            abs(event.x - downX) > slop ||
                            abs(event.y - downY) > slop
                        )
                    ) {
                        dragging = true
                    }

                    if (dragging && localViewerScale > 1.001f) {
                        viewer()?.panViewerBy(dx, dy)
                        parent?.requestDisallowInterceptTouchEvent(true)
                    }

                    lastX = event.x
                    lastY = event.y
                    return true
                }

                if (
                    !dragging &&
                    zoomLinear > 0.001f &&
                    (
                        abs(event.x - downX) > slop ||
                        abs(event.y - downY) > slop
                    )
                ) {
                    dragging = true
                }

                if (dragging && zoomLinear > 0.001f) {
                    panX =
                        (
                            panX +
                                dx /
                                    width.coerceAtLeast(1).toFloat() *
                                    2f
                        ).coerceIn(-1f, 1f)

                    panY =
                        (
                            panY +
                                dy /
                                    height.coerceAtLeast(1).toFloat() *
                                    2f
                        ).coerceIn(-1f, 1f)

                    notifyViewChanged()
                    parent?.requestDisallowInterceptTouchEvent(true)
                }

                lastX = event.x
                lastY = event.y
                return true
            }

            MotionEvent.ACTION_POINTER_UP -> {
                val removed = event.actionIndex
                val remaining =
                    if (removed == 0 && event.pointerCount > 1) 1 else 0

                if (remaining < event.pointerCount) {
                    lastX = event.getX(remaining)
                    lastY = event.getY(remaining)
                    downX = lastX
                    downY = lastY
                }

                dragging = false
                return true
            }

            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                if (event.actionMasked == MotionEvent.ACTION_UP) {
                    performClick()
                }
                return true
            }
        }

        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
