package com.example.aidoormonitor.ai

import android.graphics.Bitmap
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import java.io.File
import kotlin.math.abs
import kotlin.math.hypot

data class PoseBehaviorState(
    val personVisible: Boolean,
    val motionIntensity: Float,
    val possibleFall: Boolean
)

class PoseBehaviorDetector(
    private val context: android.content.Context,
    private val modelFile: File,
    private val onStatus: (String) -> Unit = {}
) {
    private var landmarker: PoseLandmarker? = null

    private var lastRunAt = 0L
    private var lastHipY: Float? = null
    private var lastHipAt = 0L
    private var fallCandidateUntil = 0L
    private var lastFallAlertAt = 0L

    private var previousPose: List<Pair<Float, Float>>? = null

    fun start() {
        if (landmarker != null) return
        if (!modelFile.exists()) {
            onStatus("Pose AI model is not downloaded.")
            return
        }
        try {
            landmarker = PoseLandmarker.createFromFile(context, modelFile)
            onStatus("Pose AI active • MediaPipe Pose Landmarker")
        } catch (e: Exception) {
            onStatus("Pose AI failed: ${e.message}")
        }
    }

    fun analyze(bitmap: Bitmap): PoseBehaviorState? {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRunAt < 180L) return null // ~5.5 AI pose checks/s
        lastRunAt = now

        val detector = landmarker ?: return null

        var converted: Bitmap? = null

        return try {
            val poseBitmap =
                if (bitmap.config == Bitmap.Config.ARGB_8888) {
                    bitmap
                } else {
                    converted =
                        bitmap.copy(
                            Bitmap.Config.ARGB_8888,
                            false
                        )
                    converted
                        ?: return null
                }

            val mpImage =
                BitmapImageBuilder(poseBitmap).build()

            val result =
                detector.detect(mpImage)

            mpImage.close()

            if (result.landmarks().isEmpty()) {
                previousPose = null
                return PoseBehaviorState(false, 0f, false)
            }

            val pose = result.landmarks()[0]
            if (pose.size < 33) return PoseBehaviorState(true, 0f, false)

            val shoulderX = (pose[11].x() + pose[12].x()) / 2f
            val shoulderY = (pose[11].y() + pose[12].y()) / 2f
            val hipX = (pose[23].x() + pose[24].x()) / 2f
            val hipY = (pose[23].y() + pose[24].y()) / 2f

            val torsoDx = abs(hipX - shoulderX)
            val torsoDy = abs(hipY - shoulderY)
            val horizontalTorso = torsoDx > torsoDy * 1.15f

            val previousY = lastHipY
            val previousT = lastHipAt
            lastHipY = hipY
            lastHipAt = now

            if (previousY != null && previousT > 0L) {
                val dt = ((now - previousT).coerceAtLeast(1L)) / 1000f
                val downwardVelocity = (hipY - previousY) / dt
                if (downwardVelocity > 0.16f) {
                    fallCandidateUntil = now + 2_000L
                }
            }

            val lowInFrame = hipY > 0.58f
            var possibleFall =
                now <= fallCandidateUntil &&
                    horizontalTorso &&
                    lowInFrame &&
                    now - lastFallAlertAt > 25_000L

            if (possibleFall) {
                lastFallAlertAt = now
                fallCandidateUntil = 0L
            }

            val currentPose = pose.map { it.x() to it.y() }
            val prev = previousPose
            var motion = 0f
            if (prev != null && prev.size == currentPose.size) {
                val important = intArrayOf(11,12,13,14,15,16,23,24,25,26,27,28)
                var sum = 0f
                important.forEach { i ->
                    val dx = currentPose[i].first - prev[i].first
                    val dy = currentPose[i].second - prev[i].second
                    sum += hypot(dx.toDouble(), dy.toDouble()).toFloat()
                }
                motion = (sum / important.size.toFloat()).coerceIn(0f, 1f)
            }
            previousPose = currentPose

            PoseBehaviorState(
                personVisible = true,
                motionIntensity = motion,
                possibleFall = possibleFall
            )
        } catch (e: Exception) {
            onStatus("Pose AI error: ${e.message}")
            null
        } finally {
            try {
                if (converted != null &&
                    !converted!!.isRecycled
                ) {
                    converted!!.recycle()
                }
            } catch (_: Exception) {}
        }
    }

    fun stop() {
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        previousPose = null
    }
}
