# v0.5.12.1 validation notes

- XML resources parsed successfully with Python `xml.etree.ElementTree`.
- Kotlin sources were parser-checked with local `kotlinc`; Android/AndroidX/MediaPipe symbols cannot resolve without an Android SDK/Gradle dependency classpath in this environment, so a full APK build was not performed here.
- `fullscreenZoomStatus` exists in `activity_monitor.xml` and its generated-binding use is limited to `MonitorActivity`.
- `ZoomPanFrameLayout` now has explicit REMOTE_CAMERA and LOCAL_VIEWER_CROP modes; local mode never invokes the remote-camera callback.
- `MjpegView` local crop remains uniform-scale FIT_CENTER + bounded translation; no independent X/Y scaling was added.
- New sound event keys are handled by both the shared Camera2 DVR audio engine and the standalone YamNet detector, then mapped in `DvrCamera2Service` and `DvrEventLabeler`.

---

# AIDoorMonitor v0.5.11 validation

## Fullscreen monitor live view

- `activity_monitor.xml` now exposes a `FULLSCREEN` button on the existing live-view frame.
- Fullscreen controls: `fullscreenRecord`, `fullscreenAudio`, and `exitFullscreen`.
- The existing `MjpegView` remains attached to the same view hierarchy; fullscreen is implemented by resizing/hiding sibling UI rather than creating a second MJPEG reader.
- Record/stop uses the same authenticated `/record/start` and `/record/stop` remote commands as the normal Monitor Mode controls.
- Audio fullscreen control toggles the same `liveAudioEnabled` state and `LivePcmAudioPlayer` used by the normal monitor UI.
- Android Back exits fullscreen first.
- System bars are hidden with `WindowInsetsControllerCompat` and restored on fullscreen exit/destruction.
- The existing uniform-scale `MjpegView` FIT_CENTER matrix remains unchanged, preserving portrait aspect ratio.

## Static checks performed

- All Android XML resources parse successfully.
- All newly added view IDs occur exactly once in `activity_monitor.xml`.
- Kotlin parser pass reports no syntax/token errors; full Android/Gradle compilation is unavailable in this source archive because it does not bundle a Gradle wrapper or Android SDK toolchain.

---

# AIDoorMonitor v0.5.10 validation

## Remote camera restart

- Monitor Mode contains `RESTART CAMERA APP / DVR`.
- The button can use the saved/pasted pairing code even when the UI is not currently marked Connected.
- Authenticated LAN endpoint: `GET/POST /app/restart?token=...`.
- `DvrCamera2Service` handles the restart by rebuilding Camera2 + shared audio after the HTTP response is queued.
- The persistent LAN hub remains alive during the camera pipeline restart when possible.
- `DvrCamera2Service` remains `START_STICKY`.
- Camera foreground services explicitly use `android:stopWithTask="false"`, so swiping the task away does not intentionally stop them.
- `onTaskRemoved()` reasserts the LAN endpoint and camera session while the service process remains alive.
- Camera dashboard foreground launch is best-effort only because modern Android can block background Activity launches.
- Android Force stop cannot be bypassed: a force-stopped package cannot receive LAN/service/receiver work until the user opens it again.

## Static checks performed

- All Android XML resources parse successfully.
- Kotlin parser pass reports no syntax/parser errors (full Android compilation is unavailable here because this source archive has no Gradle wrapper/toolchain bundled).
- `LanCameraServer.kt` compiles independently with minimal data-class stubs; only one pre-existing nullable/elvis warning is emitted.

## Kotlin build-fix validation

- Fixed all three invalid `Map.mapValues` lambdas in `DvrEventLabeler.kt` by destructuring the single `Map.Entry` argument as `(_, items)` / `(_, evidence)`.
- `DvrEventLabeler.kt` was compiled successfully with Kotlin 1.9.0 against minimal Android/model/store stubs after the fix.
- A parser-oriented Kotlin pass over all files modified by v0.5.12 found no additional syntax/parser diagnostics.
