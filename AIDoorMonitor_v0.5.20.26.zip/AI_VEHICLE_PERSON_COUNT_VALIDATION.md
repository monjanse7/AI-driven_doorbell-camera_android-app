# AI vehicle/person-count validation notes

## Expected tests

1. Parked car: leave the same parked car visible for several minutes. `movingCarDetected` should remain false and the event name must not gain Car unless the tracked car actually changes position/scale persistently.
2. Moving car: a car driving through the frame should still accumulate four movement samples and become `Moving car`.
3. Speech-only static scene: speaking near the camera without visible scene motion must not by itself create motion evidence. The generic motion detector now requires at least 18 spatially changed luma cells for three sustained frames.
4. Moped/motorcycle: ride/roll a moped across the driveway/road region. The object model can now retain `motorcycle` detections from full-frame and rescue crops and save them in the Motorcycle folder.
5. Person count: one, two and three separated people should report `People detected: 1/2/3`; overlapping whole-frame/tile duplicates should be suppressed. Saved Person events use the maximum simultaneous count observed.

## Build environment

The supplied project does not include a Gradle wrapper and the current container has no system Gradle installation, so a full Android compile could not be run here. Source/layout changes were checked structurally and packaged as a complete Android Studio project.
