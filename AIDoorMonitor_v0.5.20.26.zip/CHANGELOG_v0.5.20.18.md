# v0.5.20.18

- Fixed MonitorActivity build error in doorbell touch alert handling.
- Doorbell alert status now uses the existing `connectionState` view binding instead of the nonexistent `status` binding.
- Keeps the v0.5.20.17 doorbell touch alert feature unchanged otherwise.
