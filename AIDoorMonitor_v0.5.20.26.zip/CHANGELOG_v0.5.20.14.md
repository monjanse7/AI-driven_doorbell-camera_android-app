# v0.5.20.14 – Thermal Watchdog + True Visual Motion Guard

- Camera-module thermal readings now drive Cooler DVR through an independent watchdog, including while Lite4 is busy or idle.
- Camera thresholds are more protective: Warm >= 40 C, Hot >= 45 C, Critical >= 50 C, with cooldown hysteresis.
- CPU-saver state is displayed on the same line as camera-module temperature.
- Motion scoring compensates whole-frame exposure/luma shifts before measuring scene movement.
- Unidentified movement requires 3 sustained visual-motion samples.
- Weak frame-difference samples are no longer inserted continuously into event evidence, preventing speech/audio-only moments from becoming Unidentified movement.
- Moving-car confirmation is stricter to reduce parked-car false events: center >= 2%, scale >= 12%, >= 900 ms track age and 3 movement confirmations.
- Saved video resolution/FPS are preserved; Cooler DVR throttles preview and AI analysis work only.
