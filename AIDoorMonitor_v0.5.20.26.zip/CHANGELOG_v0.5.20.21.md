# v0.5.20.21 — Monitor UI cleanup

- Removed the redundant **Play selected recording from camera phone** button.
- Removed the redundant **Save selected recording on monitor phone** button.
- Event recording folders now start collapsed and remain collapsed until the user opens one.
- Moved the complete **Remote Focus / Manual Focus** control directly below the live viewer and viewer zoom/reset controls.
- Keeps v0.5.20.20 back-tap doorbell, background doorbell alerts, talkback, remote lens switching, live AI info and thermal behavior.
