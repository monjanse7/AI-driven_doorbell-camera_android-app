# v0.5.20.9 – Camera2 First-Frame A/V Sync

- AUTO A/V sync now anchors video to the Camera2 `SENSOR_TIMESTAMP` of the first real frame entering each initial MediaRecorder segment instead of treating `MediaRecorder.start()` return time as the first video frame.
- The first-frame capture is armed before `MediaRecorder.start()` so vendor implementations that block during encoder startup cannot create an artificial ~1 second audio delay.
- Rolling-segment boundary time is captured immediately inside `MEDIA_RECORDER_INFO_NEXT_OUTPUT_FILE_STARTED` before posting work to the camera handler. AI/camera-handler backlog can therefore no longer become an A/V offset.
- If Camera2 reports `SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME`, the sensor timestamp is used directly in the same monotonic clock domain as AudioRecord. Devices reporting UNKNOWN use a calibrated elapsed-realtime mapping.
- The old MP4-duration boundary back-calculation remains as a fallback when no usable frame timestamp is available.
- Audio diagnostics now report the measured natural A/V offset in milliseconds after each saved event, e.g. `Audio sync: AUTO • Camera2 frame clock • measured offset +23 ms`.
- Keeps v0.5.20.8 safe audio fallback: a sync correction failure must not turn an event into video-only.
- Keeps v0.5.20.7 sensitivity controls, Lite4 driveway/far-zone AI, Tailscale remote access, battery status and fullscreen controls.

