# v0.5.20.16 — Monitor Lens + Live AI Info UI Fix

- Camera/lens choices are automatically loaded when Monitor connects.
- Monitor can select and apply camera/lens remotely using the existing Camera2 camera-choice endpoint.
- Live-view overlay now allows enough lines to show thermal, charging/battery, event, AI detection, object-AI and VPN information.
- Added an explicit `AI detection:` line using the camera service current AI event label.
- Removed the redundant single `Delete selected recording from camera phone` button; checked-recording deletion remains.
- Critical thermal profile keeps AI at full cadence as in v0.5.20.15.
