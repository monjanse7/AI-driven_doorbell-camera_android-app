# v0.5.20.20 Back-tap Doorbell validation

Implemented in the Camera2 DVR foreground service so detection remains active while the DVR owns the rear camera.

## Controls
- Back-tap doorbell enable/disable
- Double tap or triple tap
- Sensitivity 0–100%

## Detection
- Uses TYPE_LINEAR_ACCELERATION when available.
- Falls back to TYPE_ACCELEROMETER with gravity-removal filtering.
- Requires short repeated impulses (90–520 ms spacing, 900 ms sequence window).
- 2.5 second post-ring cooldown suppresses duplicate alerts.
- Automatically ignores taps unless CameraCharacteristics.LENS_FACING_BACK is active.

## Doorbell integration
Back-tap calls the same doorbell sequence used by the black-screen touch button, so existing monitor background notification, auto-live, live audio, and talkback behavior remains shared.

## Diagnostics
/health exposes lastDoorbellSource, backTapDoorbellEnabled, backTapCount, backTapSensitivity, and lastBackTapStrength.
