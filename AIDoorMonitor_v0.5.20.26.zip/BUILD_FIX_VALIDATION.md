# v0.5.20.1 Build Fix Validation

Fixed the three Kotlin compile errors reported in Android Studio:

1. `DoorMonitoringService.kt`: stale `$ip` reference replaced with `${info.host}:${info.port}`.
2. `MonitorActivity.kt`: route selection no longer keeps a nullable `pair` captured/mutated by a lambda.
3. `MonitorActivity.kt`: the successful route is resolved to stable non-null `activePair`, used by `usesRemoteVpn()` and `liveView.start()`.

Validation performed:
- No stale `$ip:8787` reference remains.
- `activePair` is only used inside the connection scope where it is defined.
- The route-selection pattern was independently compiled with the Kotlin compiler.
- v0.5.20 functionality remains intact: Lite4 Object AI, low detector threshold, terrace/far-zone scanning, Potted plant denylist, AI status overlay, Tailscale remote/mobile-data fallback, A/V sync fixes, event AI, fullscreen crop zoom, battery/power overlay.

Full Android Gradle build was not executed in the packaging environment because an Android SDK/Gradle wrapper is not available there.
