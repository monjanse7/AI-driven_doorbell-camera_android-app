# AIDoorMonitor v0.5.20.7 – Sensitivity Controls

- AI rule sliders now use **Sensitivity** instead of the confusing user-facing confidence threshold.
- Slider direction is intuitive: **0% = least sensitive**, **100% = maximum sensitivity**.
- Existing saved rule behavior is preserved by keeping `AiRule.confidence` as the internal persisted minimum-confidence threshold and mapping UI sensitivity to `100 - threshold`.
- Existing Dog threshold 65%, for example, appears as Sensitivity 35% after upgrade without changing detection behavior.
- New custom rules default to Sensitivity 70% (internal threshold 30%).
- Rule summaries update live while the slider is moved.
- All v0.5.20.6 driveway/far-zone AI, Lite4, A/V sync, Tailscale, event playback, battery and fullscreen features are retained.
