# v0.5.20.8 – Audio Sync Safe Fallback

- Manual A/V sync corrections can no longer silently force a video-only event.
- If AAC encoding with a manual earlier/later correction fails, the event is automatically retried with hardware/monotonic automatic sync.
- Manual trim is clamped so it can never skip beyond the captured PCM.
- Audio mux diagnostics now report whether automatic sync fallback was used.
- Keeps all v0.5.20.7 AI sensitivity, Lite4, driveway/far-zone, Tailscale, event playback, battery and fullscreen features.
