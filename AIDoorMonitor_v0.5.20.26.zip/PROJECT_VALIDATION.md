# v0.5.20.6 validation notes

- Kotlin parser check: no `expecting` / syntax diagnostics in modified `AnimalObjectDetector.kt` or `DvrCamera2Service.kt`.
- Lite4 far-zone rescue changed from four serial tile inferences to one rotating tile per cycle.
- Driveway/vehicle-adjacent Person rescue uses one focused full-width upper-middle band per cycle.
- Person temporal rescue window extended for Lite4 latency; strong driveway Person evidence can promote immediately.
- Version updated to 0.5.20.6 / versionCode 108.
- Full Android Gradle build was not run in this container because Android SDK/Gradle wrapper toolchain is not available here.

# Project validation – v0.5.20

Validated in this environment:

- Version bumped to `versionCode 102`, `versionName 0.5.20-object-ai-remote-access`.
- `AnimalObjectDetector` now creates MediaPipe ObjectDetector with explicit `scoreThreshold = 0.10`, `maxResults = 30`, and a `potted plant` denylist.
- EfficientDet-Lite4 can be downloaded and activated by the running DVR service without requiring a DVR restart.
- Added independent far-zone and full-width near-field/terrace rescue passes for `Person`, `Dog`, `Cat`, `Car`, `Bicycle`, and `Bird`.
- Added Object AI runtime state and measured inference-rate reporting to `/health` and the monitor live overlay.
- Pairing now supports an optional private-VPN `remoteHost` in addition to the normal LAN host.
- Camera pairing detects a Tailscale-style `100.64.0.0/10` address on VPN/tunnel interfaces and embeds it into the pairing QR when present.
- Monitor connection logic tries LAN first, then the paired VPN address, and can fail over to the alternative route after a health-check failure without changing the stored pairing definition.
- Live MJPEG, live audio, event browsing, remote recordings and control endpoints continue to use the active `PairInfo`, so they follow the selected LAN/VPN route.
- Existing v0.5.19 monotonic A/V synchronization changes are retained.
- Changed helper classes (`Pairing.kt`, `LocalNetwork.kt`, `AnimalObjectDetector.kt`, `ModelDownloader.kt`) were compiled against minimal Android/MediaPipe API stubs with warnings only and no Kotlin compile errors.
- Structural syntax/balance checks passed for the larger modified Kotlin files (`MonitorActivity.kt`, `DvrCameraActivity.kt`, `CameraActivity.kt`, `DoorMonitoringService.kt`, `DvrCamera2Service.kt`).
- All XML resources parse successfully.

A full Android/Gradle APK build was not run because this source archive does not contain a Gradle wrapper and this environment does not provide the Android SDK/Gradle toolchain.

## Remote-access requirement

Remote mobile-data access is implemented through a private VPN route (Tailscale). Install and connect Tailscale on both phones, keep both devices in the same tailnet, then regenerate/rescan the AIDoorMonitor pairing QR so it contains the camera phone's VPN address. Do not expose AIDoorMonitor port 8787 directly to the public Internet.
