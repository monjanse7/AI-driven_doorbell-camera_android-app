# v0.5.20.9 validation

## Source changes checked
- `DvrCamera2Service.kt` captures Camera2 first-frame timestamps and immediate MediaRecorder rollover timestamps.
- `Mp4SegmentMerger.kt` exposes the measured natural audio/video offset used by the automatic alignment.
- Version bumped to `versionCode 111`, `versionName 0.5.20.9-camera2-frame-av-sync`.

## Static validation
- Kotlin compiler parser pass was run on both changed Kotlin files. Only expected unresolved Android/project symbols were reported in the container environment; no `expecting` / parser syntax errors were reported.
- Project root contains `settings.gradle.kts`, root `build.gradle.kts`, `gradle.properties`, and `app/`.
- Full Android Gradle/APK compilation is not available in this container because the Android SDK/Gradle wrapper is not bundled with the project.

## Runtime test to perform on camera phone
1. Select `Automatic` A/V sync.
2. Record a new event with a sharp visible/audible sync cue (for example clap while visible).
3. Open the newly recorded MP4.
4. Confirm audio track exists and check the monitor health/status for `Audio sync: AUTO • Camera2 frame clock • measured offset ... ms`.
5. Do not use an already-recorded v0.5.20.8 MP4 to judge the new sync path.
