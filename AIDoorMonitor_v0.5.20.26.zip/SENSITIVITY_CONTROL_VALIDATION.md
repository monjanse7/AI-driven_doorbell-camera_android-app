# v0.5.20.7 Sensitivity control validation

- AI-rule UI now presents Sensitivity rather than the persisted confidence threshold.
- Mapping is `sensitivity = 100 - confidenceThreshold`.
- 100% Sensitivity maps to threshold 0%; 0% Sensitivity maps to threshold 100%.
- Existing stored thresholds are not migrated or rewritten on upgrade, so existing trigger behavior is preserved.
- XML resource parsing passed for all project XML files.
- Mapping round-trip tests passed.
