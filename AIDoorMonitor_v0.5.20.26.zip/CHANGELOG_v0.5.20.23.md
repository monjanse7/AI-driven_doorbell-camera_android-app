# v0.5.20.23 — Ignore Bench AI Labels

- COCO `bench` detections are now explicitly ignored by the DVR event labeler.
- Bench detections cannot rename motion/audio events or appear as the saved AI event class.
- Bench detections are removed from the event-naming detection list while other object AI remains unchanged.
- Carries forward v0.5.20.22 vehicle-motion filtering, motorcycle/moped detection and person counting.
