# v0.5.20.22 – Vehicle motion, moped AI and person count

- Tightens the parked-car motion gate. A car now needs a larger center/scale displacement, a longer baseline age, and four persistent movement samples before it can be named/triggered as a moving car.
- Tightens generic visual-motion evidence from 6 to 18 changed grid cells so a static scene is much less likely to become `Unidentified movement` during unrelated speech/audio. Speech itself never counts as visual movement.
- Adds the standard COCO `motorcycle` class as a built-in rule and includes it in the full-frame/tile/driveway rescue path, event triggering, naming, and Motorcycle event folder. This is intended to cover motorcycles, scooters and many mopeds.
- Adds distinct-person counting with duplicate suppression across whole-frame and rescue detections. The monitor `/health` data now exposes `personCount` and `maxPersonCountInEvent`.
- Person event names are saved with the highest simultaneous count seen during the event, e.g. `Person_x2`, while remaining inside the Person folder.
- Monitor live-view overlay now includes `People detected: N`.
- Retains the v0.5.20.21 monitor UI cleanup, collapsed folders, focus placement, back-tap doorbell, background doorbell notification and talkback.
