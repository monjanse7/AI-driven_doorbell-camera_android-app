# v0.5.20.13 – Event naming + date/time + false-positive guard

- Boat is denied at the EfficientDet detector and cannot name DVR events.
- Cat requires stronger temporal evidence (3 distinct detections) unless confidence is >= 0.85.
- A single weak Cat detection cannot start an event.
- Motion is no longer used as an event category when no object/audio class is confirmed. Such events are named `Unidentified movement`.
- Confirmed classes such as Person, Dog, Cat, Bird, Moving car, dog sounds, etc. remain in multi-label event names.
- Recording/snapshot timestamps now use `dd.MM.yyyy_kl_HH.mm.ss` in file names, e.g. `17.10.2026_kl_10.04.00`.
- The remote player renders `_kl_` as `kl: ` for human-readable display.
- Keeps v0.5.20.12 camera-module thermal sensing, adaptive Cooler DVR, and local owner-companion dog rescue.
