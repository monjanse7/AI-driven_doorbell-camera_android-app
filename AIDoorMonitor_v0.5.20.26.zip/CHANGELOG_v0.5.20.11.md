# v0.5.20.11 – Cooler DVR + Small Dog Companion Rescue

## Lower processor/GPU load
- The off-screen OpenGL preview no longer renders + glFinish'es at the full camera frame rate when no motion/JPEG sample is due. SurfaceTexture is still drained on every frame so Camera2 is not blocked.
- Normal sampling remains up to 10 fps for motion and 5 fps for LAN/AI JPEG, but expensive GPU rendering/readback now happens only when a sample is actually required.
- EfficientDet-Lite4 rescue work is reduced from two extra global rescue inferences per object-AI cycle to at most one extra rescue inference.
- YamNet Sound AI can reduce its inference cadence when the phone is thermally stressed.

## Adaptive thermal CPU saver
The saved-video resolution/FPS is not changed. Only preview/analysis work is throttled:
- Balanced: motion 10 fps, JPEG 5 fps, Object AI 500 ms, Sound AI 850 ms.
- Warm: ~7 fps motion, ~4 fps JPEG, Object AI 650 ms, Sound AI 1000 ms.
- Hot: ~5 fps motion, ~2.8 fps JPEG, Object AI 900 ms, Sound AI 1250 ms, rescue every 2 AI cycles.
- Critical: ~3 fps motion, ~1.8 fps JPEG, Object AI 1300 ms, Sound AI 1600 ms, rescue every 3 AI cycles.

The profile uses Android thermal status plus camera-phone battery temperature and is refreshed every five seconds.
The monitor's Object AI line includes `CPU saver: Balanced/Warm/Hot/Critical`.

## Small dog with owner rescue
- If the first pass sees Person but misses Dog, the next rescue inference can use a tight full-width horizontal companion band around the walkers.
- This enlarges a tiny dog walking ahead of or behind the owner without spending four crop inferences.
- The boosted Dog candidate floor is lowered to 0.10; the user's Sensitivity rule still decides whether the candidate becomes an event.
- Global far-zone and driveway rescue remain available on alternating cycles.

## Preserved
- v0.5.20.10 Sensitivity Trigger Fix.
- v0.5.20.9 Camera2 first-frame A/V sync.
- Tailscale remote access, event playback, battery/power overlay, camera-movement guard and Potted plant denylist.
