# v0.5.20.24 – Tap-sound Doorbell

- Replaces the unreliable accelerometer/IMU back-tap doorbell trigger with microphone-based tap/knock sound detection.
- Reuses the DVR shared AudioRecord stream, so no second microphone is opened.
- Requires a sharp double or triple tap within the configured window.
- Sensitivity remains adjustable and now controls acoustic transient sensitivity.
- Uses peak, sample-to-sample transient energy, crest factor, ambient-noise tracking, reverberation suppression, and cooldown to reduce speech/background false rings.
- Active only while a rear-facing camera is selected.
- The doorbell microphone is treated as an audio capture reason, so the shared mic remains active even if saved-video audio and Sound AI are disabled.
