# v0.5.20.11 validation

Checks performed in packaging environment:
- Version bumped to 52011 / 0.5.20.11-cooler-small-dog-rescue.
- Kotlin parser pass: no `expecting`, `unexpected tokens`, named-argument, or missing-argument diagnostics were emitted for the four changed Kotlin files. Android symbols are unresolved in this environment because Android SDK jars are not installed.
- DvrGpuPreview still drains SurfaceTexture every frame, but expensive FBO draw/glFinish/glReadPixels occurs only when motion or JPEG sampling is due.
- DvrSharedAudioEngine retains continuous 48 kHz capture/audio recording; only YamNet submission cadence is adaptive.
- Lite4 whole-frame inference remains; rescue budget is capped at one additional inference per object-AI cycle.
- Person-without-Dog can invoke the new full-width companion-band Dog/Cat rescue.
- Saved recording resolution and recording FPS are not altered by the thermal CPU saver.
