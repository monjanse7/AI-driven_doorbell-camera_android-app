# AIDoorMonitor v0.5.20.20 — Back-tap Doorbell

- Added rear-camera back-tap doorbell detection using Android linear-acceleration sensor with accelerometer fallback.
- Configurable Double Tap / Triple Tap trigger.
- Added Back-tap sensitivity 0–100%.
- Added 2.5 s cooldown and mechanical impulse suppression to reduce duplicate rings.
- Back-tap ringing is automatically disabled for front/external cameras and only arms for a rear-facing camera.
- Back-tap rings use the same doorbell sequence, monitor background alert, auto-live flow, and talkback path as the screen doorbell.
- `/health` now reports back-tap configuration, last trigger source, and latest tap strength for diagnostics.
