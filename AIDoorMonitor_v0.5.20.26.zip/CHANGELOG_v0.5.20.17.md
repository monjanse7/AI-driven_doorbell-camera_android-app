# v0.5.20.17 — Doorbell touch alerts

- Added an OLED-black, minimum-brightness touch surface on the camera phone.
- Tapping the surface sends a debounced doorbell event through the running DVR service.
- `/health` now exposes `doorbellSequence` and `lastDoorbellPressedAtMs`.
- The monitor detects new doorbell sequence values, shows an in-app status alert, and posts a high-priority sound/vibration notification.
- Long-press the black doorbell screen for 2 seconds to exit it.
- Android limitation: apps cannot receive touchscreen events while the physical display is truly powered off, so the doorbell surface is black/minimum-brightness rather than truly display-off.
