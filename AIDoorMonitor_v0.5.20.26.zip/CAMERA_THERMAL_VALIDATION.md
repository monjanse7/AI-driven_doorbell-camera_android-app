# Camera thermal implementation notes

Android Camera2 does not define a standard public camera-module temperature property. v0.5.20.12 therefore does not invent one. It uses a real vendor-exposed Linux thermal zone only when the app can read a zone whose name identifies a camera/image sensor. If only an ISP thermal zone is readable, it is labelled as a proxy. If neither is exposed, camera-module temperature is unavailable and the cooler falls back to Android PowerManager thermal status/headroom plus battery temperature.

The camera thermal reader is cached and rate-limited. PowerManager thermal headroom is polled at most every 10 seconds to avoid excessive calls/NaN behavior.
