# v0.5.20.6 – Driveway / Vehicle-Adjacent Person Rescue

- Fixed missed brief Person detections near parked cars and house driveways.
- Reworked Lite4 rescue scheduling so four far-zone tiles are rotated one-per-cycle instead of running as one long burst.
- Replaced the three heavy full-width rescue bands with one focused upper-middle driveway/road band on every AI cycle.
- Added a lower-latency `driveway_priority` Person pass for people partly occluded by a car door/body.
- Extended temporal rescue matching to tolerate Lite4 latency while still requiring confirmation for weak candidates.
- Strong driveway Person detections can promote immediately; weaker detections still need temporal confirmation.
- Keeps Tailscale manual fallback, A/V sync, Potted plant denylist, dog-sound AI, battery/power overlay and fullscreen crop zoom.
