# v0.5.20.25 — Monitor executor lifecycle crash fix

- Fixed `RejectedExecutionException` in `MonitorActivity.loadRemoteDvrSettings()`.
- Delayed DVR-settings refreshes can no longer submit work after `MonitorActivity.onDestroy()` has terminated the executor.
- Added `safeNetworkExecute()` lifecycle guard for all monitor network tasks.
- Marks the activity destroyed before shutting executors down, closing the race window shown in the crash dialog.
- Preserves tap-sound doorbell, AI filters, person counting, remote lens/focus, background doorbell alerts and talkback from prior builds.
