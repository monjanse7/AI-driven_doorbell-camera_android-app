# v0.5.20.26 — Softer tap-sound doorbell

- Retunes microphone-based rear-housing tap detection for a camera phone mounted in a wall holder.
- Greatly lowers absolute peak/delta thresholds so a normal finger tap can be detected without hitting the phone hard.
- Adds derivative-spike/transient-shape filtering so ordinary speech is less likely to count as a knock.
- Uses a slower adaptive ambient-noise floor and a wider double/triple-tap timing window.
- Tap-sound sensitivity label now clarifies that higher values accept softer taps.
- Keeps the monitor executor lifecycle crash fix and all features from v0.5.20.25.
