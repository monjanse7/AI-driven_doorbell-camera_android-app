# AIDoorMonitor v0.5.20.4

## Tailscale route-learning fix

- Learns the camera phone's Tailscale IPv4 on every successful `/health` poll, not only during the initial Connect action.
- Existing LAN-only pairings are upgraded automatically while the monitor is still on home Wi-Fi.
- Live overlay now shows `Remote VPN: READY • 100.x.x.x` when the camera route is available.
- When Wi-Fi is off, RFC1918 LAN addresses (`10/8`, `172.16/12`, `192.168/16`) are no longer attempted through the VPN tunnel.
- With Wi-Fi off, a saved Tailscale route is the only preferred connection route.
- If no camera Tailscale route has been learned, the monitor now fails fast with a precise setup message instead of repeatedly reconnecting to the dead LAN address.
- Existing automatic LAN -> Tailscale failover remains in place once a VPN address is learned.

## Recommended first setup

1. Turn Tailscale ON on both phones.
2. Keep both phones on the home Wi-Fi initially.
3. Connect AIDoorMonitor normally.
4. Wait until the monitor overlay says `Remote VPN: READY • 100.x.x.x`.
5. Then turn Wi-Fi off on the monitor phone and use mobile data + Tailscale.
