# AIDoorMonitor v0.5.20.12

## Local owner + small-dog rescue
- Replaced the full-width owner-companion crop with one local owner-centred crop.
- The crop keeps several person body-widths ahead/behind the owner while enlarging tiny dogs in both X and Y.
- Dog/cat candidates can receive the existing leash-evidence confidence assist.
- Keeps the one-extra-Lite4-inference budget from v0.5.20.11 to avoid restoring the previous heat load.

## Camera-module thermal telemetry
- Added best-effort discovery of readable vendor camera thermal zones under `/sys/class/thermal` / `/sys/devices/virtual/thermal`.
- A camera temperature is reported only when a camera/image-sensor thermal zone is actually readable. Battery temperature is never relabelled as camera-module temperature.
- ISP-only zones are explicitly marked as a camera thermal proxy rather than a physical module reading.
- Monitor live overlay now shows camera-module temperature separately from phone/battery temperature.
- If the vendor/SELinux does not expose a camera thermal zone, the overlay shows `Camera module: unavailable on this phone`.

## Thermal cooler improvements
- The adaptive cooler now prioritizes an available camera-module reading.
- It also uses Android thermal headroom and current thermal status, with battery temperature as fallback.
- Camera thermal thresholds: Warm >= 42 C, Hot >= 47 C, Critical >= 52 C.
- Thermal headroom escalates at 0.75 / 0.90 / 1.00.
- Added temperature hysteresis so cooler modes do not oscillate rapidly around a threshold.
- Saved video resolution/FPS remains untouched by the cooler; preview, motion sampling and AI inference are reduced first.
