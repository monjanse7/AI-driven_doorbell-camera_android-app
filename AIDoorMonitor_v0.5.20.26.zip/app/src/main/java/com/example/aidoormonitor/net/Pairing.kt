package com.example.aidoormonitor.net

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.security.SecureRandom

data class PairInfo(
    val host: String,
    val port: Int,
    val token: String,
    /** Optional encrypted-VPN address, normally the camera phone's Tailscale IPv4. */
    val remoteHost: String? = null
) {
    val baseUrl: String get() = "http://$host:$port"

    fun endpoint(path: String): String {
        val separator = if (path.contains("?")) "&" else "?"
        return "$baseUrl$path${separator}token=${Uri.encode(token)}"
    }

    /**
     * LAN is always attempted first. If the QR also contains a Tailscale/VPN
     * address the monitor can transparently fall back to that address when it
     * is on mobile data or another Wi-Fi network.
     */
    fun connectionCandidates(preferRemote: Boolean = false): List<PairInfo> {
        val primary = this.copy(remoteHost = remoteHost)
        val remote = remoteHost?.trim().orEmpty()
        val remotePair =
            remote
                .takeIf { it.isNotBlank() && !it.equals(host, ignoreCase = true) }
                ?.let {
                    PairInfo(
                        host = it,
                        port = port,
                        token = token,
                        remoteHost = null
                    )
                }

        val out = mutableListOf<PairInfo>()
        if (preferRemote && remotePair != null) {
            out += remotePair
            out += primary
        } else {
            out += primary
            if (remotePair != null) out += remotePair
        }

        return out.distinctBy { "${it.host}:${it.port}" }
    }

    fun usesRemoteVpn(): Boolean = LocalNetwork.isTailscaleIpv4(host)

    fun pairingUri(): String = Uri.Builder()
        .scheme("aidoor")
        .authority("pair")
        .appendQueryParameter("host", host)
        .appendQueryParameter("port", port.toString())
        .appendQueryParameter("token", token)
        .apply {
            remoteHost
                ?.trim()
                ?.takeIf { it.isNotBlank() && !it.equals(host, ignoreCase = true) }
                ?.let { appendQueryParameter("remoteHost", it) }
        }
        .build()
        .toString()
}

object Pairing {
    private const val PREFS = "pairing"
    private const val KEY_TOKEN = "camera_token"

    fun getOrCreateCameraToken(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getString(KEY_TOKEN, null)?.takeIf { it.length >= 24 }?.let { return it }

        val bytes = ByteArray(24)
        SecureRandom().nextBytes(bytes)
        val token = bytes.joinToString("") { "%02x".format(it) }
        prefs.edit().putString(KEY_TOKEN, token).apply()
        return token
    }

    /** Build a QR pairing record that contains LAN + optional Tailscale fallback. */
    fun localCameraPair(
        context: Context,
        port: Int = 8787
    ): PairInfo? {
        val lan = LocalNetwork.bestIpv4Address()
        val remote = LocalNetwork.bestTailscaleIpv4Address(context)
        val primary = lan ?: remote ?: return null
        return PairInfo(
            host = primary,
            port = port,
            token = getOrCreateCameraToken(context),
            remoteHost = remote?.takeIf { !it.equals(primary, ignoreCase = true) }
        )
    }

    fun parse(raw: String): PairInfo? {
        return try {
            val trimmed = raw.trim()
            val uri = Uri.parse(trimmed)
            if (uri.scheme == "aidoor" && uri.host == "pair") {
                val host = uri.getQueryParameter("host") ?: return null
                val port = uri.getQueryParameter("port")?.toIntOrNull() ?: 8787
                val token = uri.getQueryParameter("token") ?: return null
                val remoteHost =
                    uri.getQueryParameter("remoteHost")
                        ?.trim()
                        ?.takeIf { it.isNotBlank() }
                PairInfo(host, port, token, remoteHost)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    fun qrBitmap(text: String, size: Int = 600): Bitmap {
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (y in 0 until size) {
            for (x in 0 until size) {
                bitmap.setPixel(
                    x,
                    y,
                    if (matrix[x, y]) android.graphics.Color.BLACK
                    else android.graphics.Color.WHITE
                )
            }
        }
        return bitmap
    }
}
