package com.example.aidoormonitor.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import com.example.aidoormonitor.net.PairInfo
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

class MonitorTalkbackSender(private val context: Context) {
    private val running = AtomicBoolean(false)
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var worker: Thread? = null

    fun isRunning(): Boolean = running.get()

    fun start(pair: PairInfo, onState: (String) -> Unit): Boolean {
        if (running.get()) return true
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            onState("Talk: microphone permission required")
            return false
        }
        val sampleRate = 16_000
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            onState("Talk: microphone unavailable")
            return false
        }
        return try {
            val record = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuffer * 2, 8192)
            )
            if (record.state != AudioRecord.STATE_INITIALIZED) {
                record.release()
                onState("Talk: microphone initialization failed")
                return false
            }
            recorder = record
            running.set(true)
            record.startRecording()
            worker = Thread {
                val shorts = ShortArray(3200) // 200 ms at 16 kHz
                onState("Talk: ON • speaking to camera phone")
                try {
                    while (running.get()) {
                        val count = record.read(shorts, 0, shorts.size, AudioRecord.READ_BLOCKING)
                        if (count <= 0) continue
                        val pcm = ByteArray(count * 2)
                        var o = 0
                        for (i in 0 until count) {
                            val v = shorts[i].toInt()
                            pcm[o++] = (v and 0xff).toByte()
                            pcm[o++] = ((v shr 8) and 0xff).toByte()
                        }
                        postPcm(pair, sampleRate, pcm)
                    }
                } catch (t: Throwable) {
                    if (running.get()) onState("Talk stopped: ${t.message ?: "connection error"}")
                } finally {
                    running.set(false)
                    try { record.stop() } catch (_: Throwable) {}
                    try { record.release() } catch (_: Throwable) {}
                    if (recorder === record) recorder = null
                    onState("Talk: OFF")
                }
            }.apply { name = "AI-Door-Talkback"; isDaemon = true; start() }
            true
        } catch (t: Throwable) {
            running.set(false)
            onState("Talk failed: ${t.message ?: "microphone error"}")
            false
        }
    }

    fun stop() {
        running.set(false)
        try { recorder?.stop() } catch (_: Throwable) {}
        worker?.interrupt()
        worker = null
        recorder = null
    }

    private fun postPcm(pair: PairInfo, sampleRate: Int, pcm: ByteArray) {
        val conn = URL(pair.endpoint("/talk?sampleRate=$sampleRate")).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 2500
            conn.readTimeout = 2500
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setFixedLengthStreamingMode(pcm.size)
            conn.setRequestProperty("Content-Type", "audio/L16")
            conn.outputStream.use { it.write(pcm) }
            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("camera HTTP ${conn.responseCode}")
            }
            try { conn.inputStream.close() } catch (_: Throwable) {}
        } finally {
            conn.disconnect()
        }
    }
}
