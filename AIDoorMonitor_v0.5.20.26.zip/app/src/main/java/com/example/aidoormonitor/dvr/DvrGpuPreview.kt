package com.example.aidoormonitor.dvr

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * PRIVATE Camera2 preview consumer backed by SurfaceTexture + OpenGL ES.
 *
 * The camera sees this as a normal PRIVATE/preview surface rather than a YUV
 * ImageReader. Frames are downscaled on the GPU, sampled at 10 fps for motion,
 * and JPEG-compressed at ~5 fps for the LAN viewer.
 */
class DvrGpuPreview(
    inputWidth: Int,
    inputHeight: Int,
    private val outputWidth: Int,
    private val outputHeight: Int,
    private val rotationDegrees: Int,
    private val forcePortraitOutput: Boolean = true,
    private val motionIntervalMsProvider: () -> Long = { 100L },
    private val jpegIntervalMsProvider: () -> Long = { 200L },
    private val jpegQualityProvider: () -> Int = { 62 },
    private val onMotion: (Float) -> Unit,
    private val onJpeg: (ByteArray) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val thread = HandlerThread("AI-Door-DVR-GPU").apply { start() }
    private val handler = Handler(thread.looper)
    private val released = AtomicBoolean(false)

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var textureId = 0
    private var positionHandle = -1
    private var texCoordHandle = -1
    private var texMatrixHandle = -1
    private var surfaceTexture: SurfaceTexture? = null

    @Volatile
    var surface: Surface? = null
        private set

    private val texMatrix = FloatArray(16)
    private var previousGrid: IntArray? = null
    private var lastMotionAt = 0L
    private var lastJpegAt = 0L

    private val pixelBuffer: ByteBuffer =
        ByteBuffer.allocateDirect(outputWidth * outputHeight * 4)
            .order(ByteOrder.nativeOrder())

    private val vertices: FloatBuffer =
        ByteBuffer.allocateDirect(4 * 4 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(
                    floatArrayOf(
                        -1f, -1f, 0f, 1f,
                         1f, -1f, 0f, 1f,
                        -1f,  1f, 0f, 1f,
                         1f,  1f, 0f, 1f
                    )
                )
                position(0)
            }

    private val texCoords: FloatBuffer =
        ByteBuffer.allocateDirect(4 * 2 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(
                    floatArrayOf(
                        0f, 0f,
                        1f, 0f,
                        0f, 1f,
                        1f, 1f
                    )
                )
                position(0)
            }

    init {
        val latch = java.util.concurrent.CountDownLatch(1)
        var initError: Throwable? = null

        handler.post {
            try {
                initEgl()
                initProgram()
                createCameraSurface(inputWidth, inputHeight)
            } catch (t: Throwable) {
                initError = t
            } finally {
                latch.countDown()
            }
        }

        latch.await()
        initError?.let { throw it }
    }

    private fun initEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(eglDisplay != EGL14.EGL_NO_DISPLAY) { "eglGetDisplay failed" }

        val version = IntArray(2)
        check(EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) {
            "eglInitialize failed"
        }

        val configAttribs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_NONE
        )

        val configs = arrayOfNulls<EGLConfig>(1)
        val count = IntArray(1)
        check(
            EGL14.eglChooseConfig(
                eglDisplay,
                configAttribs,
                0,
                configs,
                0,
                1,
                count,
                0
            ) && count[0] > 0
        ) { "eglChooseConfig failed" }

        val config = configs[0] ?: error("No EGL config")
        val contextAttribs = intArrayOf(
            EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
            EGL14.EGL_NONE
        )

        eglContext = EGL14.eglCreateContext(
            eglDisplay,
            config,
            EGL14.EGL_NO_CONTEXT,
            contextAttribs,
            0
        )
        check(eglContext != EGL14.EGL_NO_CONTEXT) { "eglCreateContext failed" }

        val surfaceAttribs = intArrayOf(
            EGL14.EGL_WIDTH, outputWidth,
            EGL14.EGL_HEIGHT, outputHeight,
            EGL14.EGL_NONE
        )
        eglSurface = EGL14.eglCreatePbufferSurface(
            eglDisplay,
            config,
            surfaceAttribs,
            0
        )
        check(eglSurface != EGL14.EGL_NO_SURFACE) { "eglCreatePbufferSurface failed" }

        check(
            EGL14.eglMakeCurrent(
                eglDisplay,
                eglSurface,
                eglSurface,
                eglContext
            )
        ) { "eglMakeCurrent failed" }
    }

    private fun initProgram() {
        val vertexShader = compileShader(
            GLES20.GL_VERTEX_SHADER,
            """
                attribute vec4 aPosition;
                attribute vec2 aTexCoord;
                uniform mat4 uTexMatrix;
                varying vec2 vTexCoord;
                void main() {
                    gl_Position = aPosition;
                    vec4 mapped = uTexMatrix * vec4(aTexCoord, 0.0, 1.0);
                    vTexCoord = mapped.xy;
                }
            """.trimIndent()
        )

        val fragmentShader = compileShader(
            GLES20.GL_FRAGMENT_SHADER,
            """
                #extension GL_OES_EGL_image_external : require
                precision mediump float;
                varying vec2 vTexCoord;
                uniform samplerExternalOES uTexture;
                void main() {
                    gl_FragColor = texture2D(uTexture, vTexCoord);
                }
            """.trimIndent()
        )

        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertexShader)
        GLES20.glAttachShader(program, fragmentShader)
        GLES20.glLinkProgram(program)

        val linked = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linked, 0)
        if (linked[0] == 0) {
            throw IllegalStateException(
                "GL program link failed: ${GLES20.glGetProgramInfoLog(program)}"
            )
        }

        GLES20.glDeleteShader(vertexShader)
        GLES20.glDeleteShader(fragmentShader)

        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        texCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoord")
        texMatrixHandle = GLES20.glGetUniformLocation(program, "uTexMatrix")

        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]

        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_MIN_FILTER,
            GLES20.GL_LINEAR
        )
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_MAG_FILTER,
            GLES20.GL_LINEAR
        )
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_WRAP_S,
            GLES20.GL_CLAMP_TO_EDGE
        )
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
            GLES20.GL_TEXTURE_WRAP_T,
            GLES20.GL_CLAMP_TO_EDGE
        )
    }

    private fun createCameraSurface(inputWidth: Int, inputHeight: Int) {
        val st = SurfaceTexture(textureId)
        st.setDefaultBufferSize(inputWidth, inputHeight)
        st.setOnFrameAvailableListener(
            {
                if (!released.get()) {
                    renderFrame()
                }
            },
            handler
        )
        surfaceTexture = st
        surface = Surface(st)
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)

        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            throw IllegalStateException("Shader compile failed: $log")
        }
        return shader
    }

    private fun renderFrame() {
        if (released.get()) return

        try {
            EGL14.eglMakeCurrent(
                eglDisplay,
                eglSurface,
                eglSurface,
                eglContext
            )

            val st = surfaceTexture ?: return
            // Always drain SurfaceTexture so Camera2 is never back-pressured,
            // but do not render the off-screen FBO on every camera frame.
            // The old path performed glDrawArrays + glFinish at the camera FPS
            // (often 30 fps) even though motion only sampled at 10 fps and the
            // LAN JPEG at 5 fps. That wasted a large amount of GPU/CPU power.
            st.updateTexImage()

            val now = SystemClock.elapsedRealtime()
            val motionInterval = motionIntervalMsProvider().coerceIn(80L, 1_000L)
            val jpegInterval = jpegIntervalMsProvider().coerceIn(120L, 1_500L)
            val needMotion = now - lastMotionAt >= motionInterval
            val needJpeg = now - lastJpegAt >= jpegInterval
            if (!needMotion && !needJpeg) return

            st.getTransformMatrix(texMatrix)

            GLES20.glViewport(0, 0, outputWidth, outputHeight)
            GLES20.glUseProgram(program)

            vertices.position(0)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(
                positionHandle,
                4,
                GLES20.GL_FLOAT,
                false,
                0,
                vertices
            )

            texCoords.position(0)
            GLES20.glEnableVertexAttribArray(texCoordHandle)
            GLES20.glVertexAttribPointer(
                texCoordHandle,
                2,
                GLES20.GL_FLOAT,
                false,
                0,
                texCoords
            )

            GLES20.glUniformMatrix4fv(
                texMatrixHandle,
                1,
                false,
                texMatrix,
                0
            )

            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glFinish()

            pixelBuffer.clear()
            GLES20.glReadPixels(
                0,
                0,
                outputWidth,
                outputHeight,
                GLES20.GL_RGBA,
                GLES20.GL_UNSIGNED_BYTE,
                pixelBuffer
            )

            if (needMotion) {
                lastMotionAt = now
                onMotion(computeMotionScore(pixelBuffer))
            }

            if (needJpeg) {
                lastJpegAt = now
                jpegFromRgba(pixelBuffer)?.let(onJpeg)
            }
        } catch (t: Throwable) {
            onStatus(
                "GPU preview error: ${t.message ?: t.javaClass.simpleName}"
            )
        }
    }

    private fun computeMotionScore(buffer: ByteBuffer): Float {
        val portrait =
            outputHeight >
                outputWidth

        val gridW =
            if (portrait) {
                27
            } else {
                48
            }

        val gridH =
            if (portrait) {
                48
            } else {
                27
            }
        val sample = IntArray(gridW * gridH)
        var p = 0

        for (gy in 0 until gridH) {
            val y = ((gy + 0.5f) * outputHeight / gridH)
                .toInt()
                .coerceIn(0, outputHeight - 1)
            for (gx in 0 until gridW) {
                val x = ((gx + 0.5f) * outputWidth / gridW)
                    .toInt()
                    .coerceIn(0, outputWidth - 1)
                val index = (y * outputWidth + x) * 4
                val r = buffer.get(index).toInt() and 0xff
                val g = buffer.get(index + 1).toInt() and 0xff
                val b = buffer.get(index + 2).toInt() and 0xff
                sample[p++] = (r * 77 + g * 150 + b * 29) shr 8
            }
        }

        val old = previousGrid
        previousGrid = sample
        if (old == null || old.size != sample.size) return 0f

        var total = 0L
        for (i in sample.indices) {
            total += abs(sample[i] - old[i])
        }

        return (
            total.toFloat() /
                sample.size.toFloat() /
                255f *
                100f
            ).coerceIn(0f, 100f)
    }

    private fun centerCropToPortrait(
        source: Bitmap
    ): Bitmap {
        if (
            !forcePortraitOutput ||
            source.width <= 0 ||
            source.height <= 0
        ) {
            return source
        }

        val nativePortraitRatio =
            source.width
                .toFloat() /
                source.height
                    .toFloat()

        // v0.5.7 normally renders the OpenGL FBO directly at 9:16
        // (540×960 or 360×640). In that case NEVER crop/rescale the bitmap:
        // doing so again is unnecessary and can hide horizontal field of view.
        if (
            kotlin.math.abs(
                nativePortraitRatio -
                    (
                        9f /
                            16f
                        )
            ) <
            0.002f
        ) {
            return source
        }

        // Compatibility fallback only: if a non-portrait render target is
        // ever supplied, crop without stretching pixels.
        val targetWidthOverHeight =
            9f /
                16f

        val sourceRatio =
            source.width
                .toFloat() /
                source.height
                    .toFloat()

        val cropX:
            Int

        val cropY:
            Int

        val cropWidth:
            Int

        val cropHeight:
            Int

        if (
            sourceRatio >
            targetWidthOverHeight
        ) {
            cropHeight =
                source.height

            cropWidth =
                (
                    source.height *
                        targetWidthOverHeight
                    )
                    .toInt()
                    .coerceIn(
                        1,
                        source.width
                    )

            cropX =
                (
                    source.width -
                        cropWidth
                    ) /
                    2

            cropY =
                0

        } else if (
            sourceRatio <
            targetWidthOverHeight
        ) {
            cropWidth =
                source.width

            cropHeight =
                (
                    source.width /
                        targetWidthOverHeight
                    )
                    .toInt()
                    .coerceIn(
                        1,
                        source.height
                    )

            cropX =
                0

            cropY =
                (
                    source.height -
                        cropHeight
                    ) /
                    2

        } else {
            return source
        }

        val cropped =
            Bitmap.createBitmap(
                source,
                cropX,
                cropY,
                cropWidth,
                cropHeight
            )

        if (
            cropped !==
            source
        ) {
            source.recycle()
        }

        return cropped
    }

    private fun jpegFromRgba(buffer: ByteBuffer): ByteArray? {
        val pixels = IntArray(outputWidth * outputHeight)

        for (y in 0 until outputHeight) {
            val sourceY = outputHeight - 1 - y
            val sourceRow = sourceY * outputWidth * 4
            val destRow = y * outputWidth

            for (x in 0 until outputWidth) {
                val index = sourceRow + x * 4
                val r = buffer.get(index).toInt() and 0xff
                val g = buffer.get(index + 1).toInt() and 0xff
                val b = buffer.get(index + 2).toInt() and 0xff
                val a = buffer.get(index + 3).toInt() and 0xff
                pixels[destRow + x] =
                    (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        var bitmap = Bitmap.createBitmap(
            outputWidth,
            outputHeight,
            Bitmap.Config.ARGB_8888
        )
        bitmap.setPixels(
            pixels,
            0,
            outputWidth,
            0,
            0,
            outputWidth,
            outputHeight
        )

        val normalizedRotation = ((rotationDegrees % 360) + 360) % 360
        if (normalizedRotation != 0) {
            val matrix = Matrix().apply {
                postRotate(normalizedRotation.toFloat())
            }
            val rotated = Bitmap.createBitmap(
                bitmap,
                0,
                0,
                bitmap.width,
                bitmap.height,
                matrix,
                true
            )
            if (rotated !== bitmap) {
                bitmap.recycle()
                bitmap = rotated
            }
        }

        bitmap =
            centerCropToPortrait(
                bitmap
            )

        val out =
            ByteArrayOutputStream(
                bitmap.width *
                    bitmap.height /
                    3
            )

        val ok =
            bitmap.compress(
                Bitmap.CompressFormat.JPEG,
                jpegQualityProvider().coerceIn(45, 75),
                out
            )
        bitmap.recycle()
        return if (ok) out.toByteArray() else null
    }

    fun close() {
        if (!released.compareAndSet(false, true)) return

        val latch = java.util.concurrent.CountDownLatch(1)
        handler.post {
            try {
                try { surface?.release() } catch (_: Throwable) {}
                surface = null
                try { surfaceTexture?.release() } catch (_: Throwable) {}
                surfaceTexture = null

                if (textureId != 0) {
                    GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
                    textureId = 0
                }
                if (program != 0) {
                    GLES20.glDeleteProgram(program)
                    program = 0
                }

                if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(
                        eglDisplay,
                        EGL14.EGL_NO_SURFACE,
                        EGL14.EGL_NO_SURFACE,
                        EGL14.EGL_NO_CONTEXT
                    )
                    if (eglSurface != EGL14.EGL_NO_SURFACE) {
                        EGL14.eglDestroySurface(eglDisplay, eglSurface)
                    }
                    if (eglContext != EGL14.EGL_NO_CONTEXT) {
                        EGL14.eglDestroyContext(eglDisplay, eglContext)
                    }
                    EGL14.eglTerminate(eglDisplay)
                }
            } finally {
                latch.countDown()
            }
        }
        latch.await()
        thread.quitSafely()
    }
}
