package com.example.aidoormonitor.model

data class AiRule(
    val id: String,
    var name: String,
    var enabled: Boolean,
    var type: RuleType,
    var signal: String,
    // Internal/persisted minimum-confidence threshold (0..100). The rule editor
    // presents the inverse as user-facing Sensitivity so 100% means most sensitive.
    var confidence: Int,
    var minDurationMs: Long = 0,
    var notes: String = ""
)

enum class RuleType {
    OBJECT,
    AUDIO,
    TEMPORAL_VIDEO,
    TRAJECTORY,
    COMPOSITE
}
