package com.example.aidoormonitor

import android.os.SystemClock
import java.io.File
import java.util.Locale

/**
 * Best-effort reader for vendor-exposed camera thermal zones.
 *
 * Android's public SDK does not expose a standard Camera2 "module temperature"
 * property. Some devices expose named Linux thermal zones to unprivileged apps,
 * while others block them with SELinux. We only report a camera temperature when
 * a camera-related hardware zone can actually be read; battery temperature is
 * never relabelled as camera temperature.
 */
class CameraModuleThermalReader {
    data class Reading(
        val temperatureC: Float,
        val sensorName: String,
        val source: String,
        val directCameraSensor: Boolean
    )

    private data class Zone(
        val tempFile: File,
        val typeName: String,
        val score: Int,
        val direct: Boolean
    )

    private var discovered = false
    private var zones: List<Zone> = emptyList()
    private var lastReadAtMs = 0L
    private var cachedReading: Reading? = null

    fun read(nowElapsedMs: Long = SystemClock.elapsedRealtime()): Reading? {
        if (nowElapsedMs - lastReadAtMs < 2_000L) return cachedReading
        lastReadAtMs = nowElapsedMs

        if (!discovered) {
            discovered = true
            zones = discoverZones()
        }

        // Prefer a directly named camera/module sensor. If multiple camera
        // sensors are exposed, use the hottest readable one for safety.
        val readings = zones.mapNotNull { zone ->
            readTemperatureC(zone.tempFile)?.let { temp ->
                zone to temp
            }
        }

        val selected = readings
            .sortedWith(
                compareByDescending<Pair<Zone, Float>> { it.first.direct }
                    .thenByDescending { it.first.score }
                    .thenByDescending { it.second }
            )
            .firstOrNull()

        cachedReading = selected?.let { (zone, temp) ->
            Reading(
                temperatureC = temp,
                sensorName = zone.typeName,
                source = if (zone.direct) "hardware-camera-thermal-zone" else "hardware-camera-thermal-proxy",
                directCameraSensor = zone.direct
            )
        }
        return cachedReading
    }

    fun rescan() {
        discovered = false
        zones = emptyList()
        cachedReading = null
        lastReadAtMs = 0L
    }

    private fun discoverZones(): List<Zone> {
        val roots = listOf(
            File("/sys/class/thermal"),
            File("/sys/devices/virtual/thermal")
        )

        val seenPaths = HashSet<String>()
        val result = mutableListOf<Zone>()

        roots.forEach rootLoop@ { root ->
            val children = try { root.listFiles() } catch (_: Throwable) { null } ?: return@rootLoop
            children
                .filter { it.name.startsWith("thermal_zone") }
                .forEach zoneLoop@ { dir ->
                    val canonical = try { dir.canonicalPath } catch (_: Throwable) { dir.absolutePath }
                    if (!seenPaths.add(canonical)) return@zoneLoop

                    val typeFile = File(dir, "type")
                    val tempFile = File(dir, "temp")
                    val typeName = try {
                        typeFile.readText().trim()
                    } catch (_: Throwable) {
                        ""
                    }
                    if (typeName.isBlank()) return@zoneLoop

                    val match = classify(typeName) ?: return@zoneLoop
                    // Verify the zone is actually readable before keeping it.
                    if (readTemperatureC(tempFile) == null) return@zoneLoop

                    result += Zone(
                        tempFile = tempFile,
                        typeName = typeName,
                        score = match.first,
                        direct = match.second
                    )
                }
        }

        return result.sortedByDescending { it.score }
    }

    private fun classify(typeName: String): Pair<Int, Boolean>? {
        val n = typeName.lowercase(Locale.US)
            .replace('-', '_')
            .replace(' ', '_')

        // Direct/vendor names that plausibly identify a camera module or image sensor.
        val direct = when {
            "camera" in n -> 130
            "imgsensor" in n || "image_sensor" in n -> 125
            "rear_cam" in n || "front_cam" in n -> 120
            n.startsWith("cam_") || n.endsWith("_cam") -> 115
            "camtherm" in n || "cam_therm" in n -> 115
            else -> 0
        }
        if (direct > 0) {
            var score = direct
            if ("rear" in n || "main" in n || "wide" in n) score += 12
            if ("front" in n || "selfie" in n) score -= 4
            if ("battery" in n) return null
            return score to true
        }

        // ISP is camera-pipeline related, but is not guaranteed to be the
        // physical sensor module. Expose it explicitly as a proxy only.
        if ("isp" in n && "battery" !in n) {
            return 70 to false
        }

        return null
    }

    private fun readTemperatureC(file: File): Float? {
        val raw = try {
            file.readText().trim().toFloatOrNull()
        } catch (_: Throwable) {
            null
        } ?: return null

        val celsius = when {
            raw > 1_000f -> raw / 1_000f
            raw > 200f -> raw / 10f
            else -> raw
        }

        return celsius.takeIf { it in -20f..130f }
    }
}
