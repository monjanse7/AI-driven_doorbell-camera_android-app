package com.example.aidoormonitor.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object LocalNetwork {
    fun bestIpv4Address(): String? {
        val candidates = mutableListOf<Pair<Int, String>>()

        return try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            interfaces.forEach { iface ->
                if (!iface.isUp || iface.isLoopback) return@forEach
                val priority = when {
                    iface.name.startsWith("wlan", ignoreCase = true) -> 0
                    iface.name.startsWith("wifi", ignoreCase = true) -> 0
                    iface.name.startsWith("eth", ignoreCase = true) -> 1
                    else -> 2
                }

                Collections.list(iface.inetAddresses).forEach { address ->
                    if (address is Inet4Address &&
                        !address.isLoopbackAddress &&
                        address.isSiteLocalAddress
                    ) {
                        candidates += priority to address.hostAddress.orEmpty()
                    }
                }
            }

            candidates
                .filter { it.second.isNotBlank() }
                .sortedWith(compareBy<Pair<Int, String>> { it.first }.thenBy { it.second })
                .firstOrNull()
                ?.second
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Tailscale normally assigns an IPv4 in 100.64.0.0/10. Android exposes
     * the VPN interface through NetworkInterface, so no Tailscale SDK is
     * required: if the Tailscale app/VPN is connected, the address can be
     * included as a remote fallback in the camera QR code.
     */
    fun bestTailscaleIpv4Address(context: Context? = null): String? {
        return try {
            val candidates = mutableListOf<Pair<Int, String>>()

            Collections.list(NetworkInterface.getNetworkInterfaces())
                .forEach { iface ->
                    val usable =
                        try { iface.isUp && !iface.isLoopback } catch (_: Throwable) { false }
                    if (!usable) return@forEach

                    val name = iface.name.lowercase()
                    // A cellular carrier can also use CGNAT 100.64/10. Do not
                    // mistake rmnet/ccmni/wwan addresses for Tailscale.
                    val cellularLike =
                        name.startsWith("rmnet") ||
                            name.startsWith("ccmni") ||
                            name.startsWith("pdp") ||
                            name.startsWith("wwan")
                    if (cellularLike) return@forEach

                    val priority =
                        when {
                            "tailscale" in name -> 0
                            name.startsWith("tun") ||
                                name.startsWith("wg") ||
                                "vpn" in name -> 1
                            else -> 2
                        }

                    Collections.list(iface.inetAddresses)
                        .filterIsInstance<Inet4Address>()
                        .mapNotNull { it.hostAddress }
                        .filter { isTailscaleIpv4(it) }
                        .forEach { candidates += priority to it }
                }

            val interfaceResult =
                candidates
                    .sortedWith(
                        compareBy<Pair<Int, String>> { it.first }
                            .thenBy { it.second }
                    )
                    .firstOrNull()
                    ?.second

            interfaceResult ?: context?.let { bestTailscaleFromConnectivityManager(it) }
        } catch (_: Throwable) {
            context?.let { bestTailscaleFromConnectivityManager(it) }
        }
    }

    /**
     * Android can expose a VPN address through ConnectivityManager even when
     * NetworkInterface naming is vendor-specific. Prefer a TRANSPORT_VPN
     * network and only accept Tailscale's 100.64.0.0/10 range.
     */
    private fun bestTailscaleFromConnectivityManager(context: Context): String? {
        return try {
            val cm =
                context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE)
                    as ConnectivityManager

            cm.allNetworks
                .asSequence()
                .filter { network ->
                    cm.getNetworkCapabilities(network)
                        ?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
                }
                .flatMap { network ->
                    cm.getLinkProperties(network)
                        ?.linkAddresses
                        ?.asSequence()
                        ?: emptySequence()
                }
                .mapNotNull { it.address as? Inet4Address }
                .mapNotNull { it.hostAddress }
                .firstOrNull { isTailscaleIpv4(it) }
        } catch (_: Throwable) {
            null
        }
    }

    fun isPrivateLanIpv4(host: String?): Boolean {
        val parts = host
            ?.trim()
            ?.split('.')
            ?.mapNotNull { it.toIntOrNull() }
            ?: return false
        if (parts.size != 4 || parts.any { it !in 0..255 }) return false

        return when {
            parts[0] == 10 -> true
            parts[0] == 172 && parts[1] in 16..31 -> true
            parts[0] == 192 && parts[1] == 168 -> true
            else -> false
        }
    }

    fun isTailscaleIpv4(host: String?): Boolean {
        val parts = host
            ?.trim()
            ?.split('.')
            ?.mapNotNull { it.toIntOrNull() }
            ?: return false
        if (parts.size != 4 || parts.any { it !in 0..255 }) return false
        // 100.64.0.0/10 => second octet 64..127.
        return parts[0] == 100 && parts[1] in 64..127
    }
}
