package com.example.aidoormonitor

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import com.example.aidoormonitor.databinding.ActivityRemoteRecordingBinding
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class RemoteRecordingActivity :
    AppCompatActivity() {

    private lateinit var b:
        ActivityRemoteRecordingBinding

    private var remoteUrl: String = ""
    private var alternateRemoteUrls: List<String> = emptyList()
    private var recordingName: String = ""
    private var remoteRouteIndex: Int = 0

    private var player:
        ExoPlayer? =
        null

    private val worker =
        Executors.newSingleThreadExecutor()

    private val handler =
        Handler(
            Looper.getMainLooper()
        )

    private var playerGeneration = 0
    private var firstFrameRendered = false
    private var localFallbackStarted = false

    private var playbackZoomMode =
        false

    private var playbackScale =
        1f

    private var playbackPanX =
        0f

    private var playbackPanY =
        0f

    private var playbackRotationDegrees =
        0f

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(savedInstanceState)

        b =
            ActivityRemoteRecordingBinding
                .inflate(layoutInflater)

        setContentView(b.root)
        b.root.applySystemBarInsets()

        remoteUrl =
            intent.getStringExtra(
                "recording_url"
            )
                .orEmpty()

        alternateRemoteUrls =
            intent.getStringArrayListExtra(
                "recording_alternate_urls"
            )
                ?.filter { it.isNotBlank() && it != remoteUrl }
                ?.distinct()
                .orEmpty()

        recordingName =
            intent.getStringExtra(
                "recording_name"
            )
                .orEmpty()
                .ifBlank {
                    "Camera recording"
                }

        b.recordingTitle.text =
            recordingName.replace("_kl_", "_kl: ")

        b.playbackZoomGesture
            .setOnZoomPanChanged {
                    scale,
                    panX,
                    panY ->

                playbackScale =
                    scale

                playbackPanX =
                    panX

                playbackPanY =
                    panY

                applyPlaybackZoomPan()
            }

        b.togglePlaybackZoomPan
            .setOnClickListener {
                setPlaybackZoomMode(
                    !playbackZoomMode
                )
            }

        b.resetPlaybackZoomPan
            .setOnClickListener {
                resetPlaybackZoomPan()
            }

        b.rotatePlayback90
            .setOnClickListener {
                playbackRotationDegrees =
                    (
                        playbackRotationDegrees +
                            90f
                        ) %
                        360f

                applyPlaybackZoomPan()
            }

        setPlaybackZoomMode(
            false
        )

        resetPlaybackZoomPan()

        b.replay.setOnClickListener {
            player?.seekTo(0L)
            player?.play()
        }

        b.closePlayer.setOnClickListener {
            finish()
        }

        if (remoteUrl.isBlank()) {
            b.playbackStatus.text =
                "Recording URL is missing."
        } else {
            playRemote()
        }
    }

    private fun setPlaybackZoomMode(
        enabled: Boolean
    ) {
        playbackZoomMode =
            enabled

        b.playbackZoomGesture.visibility =
            if (enabled) {
                View.VISIBLE
            } else {
                View.GONE
            }

        try {
            b.playerView
                .setUseController(
                    !enabled
                )

            if (enabled) {
                b.playerView
                    .hideController()
            }
        } catch (_: Throwable) {
        }

        b.togglePlaybackZoomPan.text =
            if (enabled) {
                "DISABLE VIDEO ZOOM / PAN"
            } else {
                "ENABLE VIDEO ZOOM / PAN"
            }

        if (enabled) {
            b.playbackStatus.text =
                "Zoom/Pan mode • pinch to zoom • drag to pan • double-tap to reset."
        }
    }

    private fun resetPlaybackZoomPan() {
        playbackScale =
            1f

        playbackPanX =
            0f

        playbackPanY =
            0f

        try {
            b.playbackZoomGesture
                .resetZoomPan(
                    notify = false
                )
        } catch (_: Throwable) {
        }

        applyPlaybackZoomPan()
    }

    private fun playerVideoSurface():
        View? {
        return try {
            val method =
                b.playerView
                    .javaClass
                    .getMethod(
                        "getVideoSurfaceView"
                    )

            method.invoke(
                b.playerView
            ) as? View

        } catch (_: Throwable) {
            null
        }
    }

    private fun applyPlaybackZoomPan() {
        val surface =
            playerVideoSurface()

        if (surface == null) {
            b.playbackZoomStatus.text =
                "Playback zoom unavailable: video surface not ready."
            return
        }

        val scale =
            playbackScale
                .coerceIn(
                    1f,
                    5f
                )

        val surfaceWidth =
            surface.width
                .takeIf {
                    it > 0
                }
                ?: b.playerView
                    .width
                    .coerceAtLeast(
                        1
                    )

        val surfaceHeight =
            surface.height
                .takeIf {
                    it > 0
                }
                ?: b.playerView
                    .height
                    .coerceAtLeast(
                        1
                    )

        val maxTranslateX =
            (
                surfaceWidth
                    .toFloat() *
                    (
                        scale -
                            1f
                        ) /
                    2f
                )
                .coerceAtLeast(
                    0f
                )

        val maxTranslateY =
            (
                surfaceHeight
                    .toFloat() *
                    (
                        scale -
                            1f
                        ) /
                    2f
                )
                .coerceAtLeast(
                    0f
                )

        val translateX =
            playbackPanX
                .coerceIn(
                    -1f,
                    1f
                ) *
                maxTranslateX

        val translateY =
            playbackPanY
                .coerceIn(
                    -1f,
                    1f
                ) *
                maxTranslateY

        surface.pivotX =
            surface.width /
                2f

        surface.pivotY =
            surface.height /
                2f

        surface.scaleX =
            scale

        surface.scaleY =
            scale

        surface.translationX =
            translateX

        surface.translationY =
            translateY

        surface.rotation =
            playbackRotationDegrees

        b.playbackRotationStatus.text =
            "Playback rotation correction: " +
                playbackRotationDegrees
                    .toInt() +
                "°"

        b.playbackZoomStatus.text =
            String.format(
                Locale.US,
                "Playback zoom: %.2f× • Pan X %.0f%% • Y %.0f%%",
                scale,
                playbackPanX *
                    100f,
                playbackPanY *
                    100f
            )
    }

    private fun playRemote() {
        localFallbackStarted = false
        remoteRouteIndex = 0

        playUri(
            uri = Uri.parse(remoteUrl),
            sourceLabel =
                "Streaming directly from camera phone.",
            allowCacheFallback = true
        )
    }

    private fun playUri(
        uri: Uri,
        sourceLabel: String,
        allowCacheFallback: Boolean
    ) {
        releasePlayer()

        firstFrameRendered = false
        playerGeneration++

        val generation =
            playerGeneration

        val renderers =
            DefaultRenderersFactory(this)
                .setEnableDecoderFallback(
                    true
                )

        val exo =
            ExoPlayer.Builder(
                this,
                renderers
            )
                .build()

        player = exo
        b.playerView.player = exo

        exo.addListener(
            object : Player.Listener {
                override fun onPlaybackStateChanged(
                    playbackState: Int
                ) {
                    if (
                        generation !=
                        playerGeneration
                    ) {
                        return
                    }

                    when (playbackState) {
                        Player.STATE_BUFFERING ->
                            b.playbackStatus.text =
                                "Buffering video…"

                        Player.STATE_READY -> {
                            b.playbackStatus.text =
                                sourceLabel

                            b.playerView.post {
                                applyPlaybackZoomPan()
                            }

                            scheduleBlackFrameFallback(
                                generation,
                                allowCacheFallback
                            )
                        }

                        Player.STATE_ENDED ->
                            b.playbackStatus.text =
                                "Playback finished."
                    }
                }

                override fun onRenderedFirstFrame() {
                    if (
                        generation !=
                        playerGeneration
                    ) {
                        return
                    }

                    firstFrameRendered =
                        true

                    b.playerView.post {
                        applyPlaybackZoomPan()
                    }

                    b.playbackStatus.text =
                        if (allowCacheFallback) {
                            "Video ready • streaming from camera phone."
                        } else {
                            "Video ready • playing local cached copy."
                        }
                }

                override fun onPlayerError(
                    error: PlaybackException
                ) {
                    if (
                        generation !=
                        playerGeneration
                    ) {
                        return
                    }

                    if (
                        allowCacheFallback &&
                        tryNextRemoteRoute(
                            "Direct playback error: " +
                                error.errorCodeName
                        )
                    ) {
                        return
                    } else if (
                        allowCacheFallback &&
                        !localFallbackStarted
                    ) {
                        cacheRemoteAndRetry(
                            "Direct playback error: " +
                                error.errorCodeName
                        )
                    } else {
                        b.playbackStatus.text =
                            "Playback failed: " +
                                error.errorCodeName
                    }
                }
            }
        )

        exo.setMediaItem(
            MediaItem.fromUri(uri)
        )

        exo.prepare()
        exo.playWhenReady = true
    }

    private fun scheduleBlackFrameFallback(
        generation: Int,
        allowCacheFallback: Boolean
    ) {
        if (!allowCacheFallback) return

        handler.postDelayed({
            if (
                generation !=
                playerGeneration ||
                firstFrameRendered ||
                localFallbackStarted
            ) {
                return@postDelayed
            }

            val current =
                player ?: return@postDelayed

            // A progressing timeline with no rendered first frame is the
            // exact "audio/timeline works but video is black" case.
            if (
                current.playbackState ==
                Player.STATE_READY
            ) {
                if (!tryNextRemoteRoute(
                        "No video frame rendered from current camera route."
                    )) {
                    cacheRemoteAndRetry(
                        "No video frame rendered from direct HTTP stream."
                    )
                }
            }
        }, 4_000L)
    }

    private fun tryNextRemoteRoute(reason: String): Boolean {
        if (remoteRouteIndex >= alternateRemoteUrls.size) {
            return false
        }

        val nextUrl = alternateRemoteUrls[remoteRouteIndex++]
        if (nextUrl.isBlank() || nextUrl == remoteUrl) {
            return tryNextRemoteRoute(reason)
        }

        remoteUrl = nextUrl
        localFallbackStarted = false
        b.playbackStatus.text =
            "$reason\nTrying alternate LAN/VPN route…"

        handler.post {
            playUri(
                uri = Uri.parse(remoteUrl),
                sourceLabel = "Streaming from alternate camera route.",
                allowCacheFallback = true
            )
        }
        return true
    }

    private fun cacheRemoteAndRetry(
        reason: String
    ) {
        if (localFallbackStarted) return
        localFallbackStarted = true

        val position =
            player?.currentPosition
                ?: 0L

        b.playbackStatus.text =
            "$reason\nCaching recording locally for reliable playback…"

        worker.execute {
            var connection:
                HttpURLConnection? =
                null

            try {
                val directory =
                    File(
                        cacheDir,
                        "remote_recording_playback"
                    )
                        .apply {
                            mkdirs()
                        }

                val safeName =
                    recordingName
                        .replace(
                            Regex(
                                "[^A-Za-z0-9._-]+"
                            ),
                            "_"
                        )
                        .take(80)
                        .ifBlank {
                            "camera_recording.mp4"
                        }

                val target =
                    File(
                        directory,
                        safeName
                    )

                connection =
                    URL(remoteUrl)
                        .openConnection()
                        as HttpURLConnection

                connection.connectTimeout =
                    8_000
                connection.readTimeout =
                    30_000
                connection.useCaches =
                    false
                connection.requestMethod =
                    "GET"
                connection.connect()

                if (
                    connection.responseCode
                        !in 200..299
                ) {
                    throw IllegalStateException(
                        "HTTP ${connection.responseCode}"
                    )
                }

                val total =
                    connection.contentLengthLong

                connection.inputStream
                    .use { input ->
                        target.outputStream()
                            .buffered(
                                256 * 1024
                            )
                            .use { output ->
                                val buffer =
                                    ByteArray(
                                        256 * 1024
                                    )

                                var copied =
                                    0L
                                var lastUi =
                                    0L

                                while (true) {
                                    val read =
                                        input.read(
                                            buffer
                                        )

                                    if (read < 0) {
                                        break
                                    }

                                    output.write(
                                        buffer,
                                        0,
                                        read
                                    )

                                    copied +=
                                        read.toLong()

                                    val now =
                                        System.currentTimeMillis()

                                    if (
                                        now -
                                        lastUi >=
                                        500L
                                    ) {
                                        lastUi = now

                                        val text =
                                            if (total > 0L) {
                                                val pct =
                                                    (
                                                        copied *
                                                        100L /
                                                        total
                                                        )
                                                        .coerceIn(
                                                            0L,
                                                            100L
                                                        )

                                                "Caching local playback copy • $pct%"
                                            } else {
                                                "Caching local playback copy…"
                                            }

                                        runOnUiThread {
                                            b.playbackStatus.text =
                                                text
                                        }
                                    }
                                }

                                output.flush()
                            }
                    }

                runOnUiThread {
                    playUri(
                        uri =
                            Uri.fromFile(
                                target
                            ),
                        sourceLabel =
                            "Playing local cached copy from monitor phone.",
                        allowCacheFallback =
                            false
                    )

                    player?.seekTo(
                        position
                    )
                    player?.play()
                }

            } catch (t: Throwable) {
                runOnUiThread {
                    b.playbackStatus.text =
                        "Could not recover black playback: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                ) +
                            "\nYou can still use Save selected recording in Monitor Mode."
                }
            } finally {
                try {
                    connection?.disconnect()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun releasePlayer() {
        try {
            b.playerView.player =
                null
        } catch (_: Throwable) {
        }

        try {
            player?.release()
        } catch (_: Throwable) {
        }

        player = null
    }

    override fun onStop() {
        try {
            player?.pause()
        } catch (_: Throwable) {
        }

        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(
            null
        )

        releasePlayer()

        try {
            worker.shutdownNow()
        } catch (_: Throwable) {
        }

        super.onDestroy()
    }
}
