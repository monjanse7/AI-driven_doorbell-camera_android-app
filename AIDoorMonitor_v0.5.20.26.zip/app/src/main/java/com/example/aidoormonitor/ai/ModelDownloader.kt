package com.example.aidoormonitor.ai

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object ModelDownloader {
    const val YAMNET_URL =
        "https://storage.googleapis.com/mediapipe-models/audio_classifier/yamnet/float32/latest/yamnet.tflite"

    const val POSE_URL =
        "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task"

    /**
     * Highest-accuracy EfficientDet-Lite COCO detector in the Lite0..Lite4
     * family. Google reports Lite4 as the largest / most accurate member.
     * Keep a TFHub-compatible fallback because Google has moved model hosting
     * between TFHub/Kaggle/Google Storage over time.
     */
    val OBJECT_URLS =
        listOf(
            "https://tfhub.dev/tensorflow/lite-model/efficientdet/lite4/detection/metadata/2?lite-format=tflite",
            "https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite4/int8/latest/efficientdet_lite4.tflite"
        )

    private val executor = Executors.newSingleThreadExecutor()

    fun modelDir(context: Context): File =
        File(context.filesDir, "ai_models").apply { mkdirs() }

    fun yamnetFile(context: Context): File =
        File(modelDir(context), "yamnet.tflite")

    fun poseFile(context: Context): File =
        File(modelDir(context), "pose_landmarker_lite.task")

    fun objectFile(context: Context): File =
        File(modelDir(context), "efficientdet_lite4.tflite")

    fun customObjectFile(context: Context): File =
        File(
            modelDir(context),
            "custom_object_detector.tflite"
        )

    fun customObjectReady(context: Context): Boolean =
        customObjectFile(context).length() >
            100_000L

    fun yamnetReady(context: Context): Boolean =
        yamnetFile(context).length() > 1_000_000L

    fun poseReady(context: Context): Boolean =
        poseFile(context).length() > 1_000_000L

    fun objectReady(context: Context): Boolean =
        isValidLite4Model(objectFile(context))

    fun modelsReady(context: Context): Boolean =
        yamnetReady(context) &&
            poseReady(context) &&
            objectReady(context)


    /** Download/validate only the large COCO object model. Used by the DVR
     * foreground service so Object AI can become active without an app/service
     * restart when upgrading from Lite0 or when Lite4 is missing. */
    fun prepareObject(
        context: Context,
        onStatus: (String) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        executor.execute {
            try {
                val o = objectFile(context)
                if (!isValidLite4Model(o)) {
                    if (o.exists()) o.delete()
                    onStatus("Object AI: DOWNLOADING EfficientDet-Lite4…")
                    downloadFirstAvailable(OBJECT_URLS, o)
                }

                val ready = objectReady(context)
                onDone(
                    ready,
                    if (ready) {
                        "Object AI: Lite4 model ready"
                    } else {
                        "Object AI: NOT READY"
                    }
                )
            } catch (e: Exception) {
                onDone(
                    false,
                    "Object AI: DOWNLOAD FAILED • ${e.message ?: e.javaClass.simpleName}"
                )
            }
        }
    }

    fun prepareAll(
        context: Context,
        onStatus: (String) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        executor.execute {
            try {
                val y = yamnetFile(context)
                if (y.length() <= 1_000_000L) {
                    onStatus("Downloading YamNet audio AI model…")
                    download(YAMNET_URL, y)
                }

                val p = poseFile(context)
                if (p.length() <= 1_000_000L) {
                    onStatus("Downloading MediaPipe Pose Landmarker model…")
                    download(POSE_URL, p)
                }

                val o = objectFile(context)
                if (!isValidLite4Model(o)) {
                    if (o.exists()) o.delete()
                    onStatus("Downloading EfficientDet-Lite4 COCO object detector…")
                    downloadFirstAvailable(OBJECT_URLS, o)
                }

                onDone(
                    modelsReady(context),
                    if (modelsReady(context))
                        "AI models ready for offline use."
                    else
                        "AI model download did not complete."
                )
            } catch (e: Exception) {
                onDone(false, "AI model download failed: ${e.message}")
            }
        }
    }

    private fun downloadFirstAvailable(
        urls: List<String>,
        target: File
    ) {
        var lastError: Throwable? = null

        urls.forEach { url ->
            try {
                download(url, target)
                if (isValidLite4Model(target)) return
                lastError = IllegalStateException(
                    "Downloaded file is not a valid EfficientDet-Lite4 TFLite model"
                )
                try { target.delete() } catch (_: Throwable) {}
            } catch (t: Throwable) {
                lastError = t
                try { target.delete() } catch (_: Throwable) {}
            }
        }

        throw IllegalStateException(
            "Could not download EfficientDet-Lite4 from any official Google model endpoint",
            lastError
        )
    }

    /**
     * TFLite flatbuffers contain the ASCII identifier TFL3 at byte offsets 4..7.
     * Lite4 is about 20 MB when integer quantized, so a 10 MB lower bound also
     * rejects HTML/error pages that may be returned by a redirected model URL.
     */
    private fun isValidLite4Model(file: File): Boolean {
        if (!file.exists() || file.length() < 10_000_000L) return false

        return try {
            val header = ByteArray(8)
            file.inputStream().use { input ->
                if (input.read(header) < header.size) return false
            }
            header[4] == 'T'.code.toByte() &&
                header[5] == 'F'.code.toByte() &&
                header[6] == 'L'.code.toByte() &&
                header[7] == '3'.code.toByte()
        } catch (_: Throwable) {
            false
        }
    }

    private fun download(url: String, target: File) {
        val temp = File(target.parentFile, "${target.name}.part")
        if (temp.exists()) temp.delete()

        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = true
            conn.connect()

            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${conn.responseCode}")
            }

            conn.inputStream.use { input ->
                temp.outputStream().use { output ->
                    input.copyTo(output, 256 * 1024)
                }
            }

            if (temp.length() < 1_000_000L) {
                throw IllegalStateException("Downloaded model is unexpectedly small")
            }

            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
        } finally {
            conn.disconnect()
        }
    }
}
