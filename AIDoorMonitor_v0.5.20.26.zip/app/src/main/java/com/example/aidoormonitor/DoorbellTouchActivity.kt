package com.example.aidoormonitor

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Ultra-dark touch surface for using the camera phone itself as the doorbell button.
 *
 * Android does not deliver app touch events while the panel is truly powered off.
 * This activity therefore keeps the display technically awake at minimum brightness,
 * shows a black OLED-friendly surface, and treats a deliberate tap as a doorbell press.
 */
class DoorbellTouchActivity : AppCompatActivity() {
    private var lastPressAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply {
            screenBrightness = 0.01f
        }

        val view = TextView(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            setTextColor(android.graphics.Color.rgb(90, 90, 90))
            textSize = 13f
            gravity = android.view.Gravity.CENTER
            text = "Tap screen to ring doorbell\n\nLong-press 2 seconds to exit"
            systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        }
        setContentView(view)

        var downAt = 0L
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downAt = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val duration = System.currentTimeMillis() - downAt
                    if (duration >= 2_000L) {
                        finish()
                    } else {
                        ringDoorbell()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun ringDoorbell() {
        val now = System.currentTimeMillis()
        if (now - lastPressAt < 900L) return
        lastPressAt = now

        val intent = Intent(this, DvrCamera2Service::class.java).apply {
            action = DvrCamera2Service.ACTION_DOORBELL_PRESS
        }
        try {
            ContextCompat.startForegroundService(this, intent)
        } catch (_: Throwable) {
            startService(intent)
        }

        // Tiny visual confirmation while keeping the panel effectively black.
        (window.decorView.findViewById<View>(android.R.id.content) as? android.view.ViewGroup)
            ?.getChildAt(0)
            ?.let { child ->
                if (child is TextView) {
                    child.text = "Doorbell rung"
                    child.postDelayed({
                        child.text = "Tap screen to ring doorbell\n\nLong-press 2 seconds to exit"
                    }, 900L)
                }
            }
    }
}
