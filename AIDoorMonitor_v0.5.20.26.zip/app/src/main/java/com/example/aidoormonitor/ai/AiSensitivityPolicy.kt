package com.example.aidoormonitor.ai

import android.content.Context
import com.example.aidoormonitor.model.BuiltInRules
import com.example.aidoormonitor.store.RuleStore

/**
 * Converts the user-facing Sensitivity slider into the *actual* detector/event
 * trigger threshold used by the camera pipeline.
 *
 * AiRule.confidence is retained as the persisted inverse representation for
 * backwards compatibility: sensitivity = 100 - confidence.
 *
 * The mapping is deliberately calibrated around each built-in rule's old
 * behaviour. At the built-in default sensitivity, [baseThreshold] is returned.
 * Moving toward 100% smoothly lowers the threshold to [minimumThreshold].
 * Moving toward 0% raises it toward [maximumThreshold].
 */
class AiSensitivityPolicy(context: Context) {
    private val store = RuleStore(context.applicationContext)

    private val defaultsById =
        BuiltInRules.defaults().associateBy { it.id }

    @Volatile
    private var cachedAtMs = 0L

    @Volatile
    private var cachedRules = emptyMap<String, com.example.aidoormonitor.model.AiRule>()

    private fun rulesSnapshot(): Map<String, com.example.aidoormonitor.model.AiRule> {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - cachedAtMs <= 350L && cachedRules.isNotEmpty()) {
            return cachedRules
        }

        synchronized(this) {
            val again = android.os.SystemClock.elapsedRealtime()
            if (again - cachedAtMs > 350L || cachedRules.isEmpty()) {
                cachedRules = store.load().associateBy { it.id }
                cachedAtMs = again
            }
            return cachedRules
        }
    }

    /** Returns null when the corresponding AI rule is disabled. */
    fun threshold(
        ruleId: String,
        baseThreshold: Float,
        minimumThreshold: Float,
        maximumThreshold: Float = 0.90f
    ): Float? {
        val rule = rulesSnapshot()[ruleId] ?: defaultsById[ruleId] ?: return baseThreshold
        if (!rule.enabled) return null

        val sensitivity = (100 - rule.confidence.coerceIn(0, 100)).toFloat()
        val defaultRule = defaultsById[ruleId]
        val defaultSensitivity =
            (100 - (defaultRule?.confidence ?: rule.confidence).coerceIn(0, 100))
                .toFloat()
                .coerceIn(1f, 99f)

        val base = baseThreshold.coerceIn(minimumThreshold, maximumThreshold)
        val min = minimumThreshold.coerceAtMost(base)
        val max = maximumThreshold.coerceAtLeast(base)

        val result =
            if (sensitivity >= defaultSensitivity) {
                val t =
                    ((sensitivity - defaultSensitivity) / (100f - defaultSensitivity))
                        .coerceIn(0f, 1f)
                base + (min - base) * t
            } else {
                val t = (sensitivity / defaultSensitivity).coerceIn(0f, 1f)
                max + (base - max) * t
            }

        return result.coerceIn(min, max)
    }

    fun sensitivity(ruleId: String): Int? {
        val rule = rulesSnapshot()[ruleId] ?: defaultsById[ruleId] ?: return null
        return 100 - rule.confidence.coerceIn(0, 100)
    }
}
