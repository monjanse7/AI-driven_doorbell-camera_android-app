package com.example.aidoormonitor.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

data class AnimalDetection(
    val label: String,
    val score: Float,
    val box: RectF,
    /** full = normal whole-frame pass, tile = small-object rescue pass. */
    val source: String = "full",
    /** 0..1 lightweight visual evidence for a thin leash-like line. */
    val leashEvidence: Float = 0f
)

class AnimalObjectDetector(
    private val context: Context,
    private val modelFile: File,
    private val onStatus: (String) -> Unit = {}
) {
    private var detector: ObjectDetector? = null
    private var mappedModel: MappedByteBuffer? = null
    private var lastRunAt = 0L
    private var lastSmallPetBoostAt = 0L
    private var lastPriorityTileBoostAt = 0L
    private var lastNearFieldBoostAt = 0L
    private var lastCompanionBoostAt = 0L
    private var priorityTileIndex = 0

    @Volatile private var inferenceFpsValue = 0f
    private var inferenceWindowStartedAt = 0L
    private var inferenceCountInWindow = 0

    fun isActive(): Boolean = detector != null
    fun inferenceFps(): Float = inferenceFpsValue

    fun start() {
        if (detector != null) return
        if (!modelFile.exists()) {
            onStatus("Animal AI model is not downloaded.")
            return
        }

        try {
            // createFromFile() inherits the model metadata threshold. That can
            // discard a distant Person/Dog before our own temporal threshold
            // logic sees it. Build explicit options and keep a low detector
            // floor; the DVR service performs the stricter confirmation.
            val mapped = FileInputStream(modelFile).channel.use { channel ->
                channel.map(
                    FileChannel.MapMode.READ_ONLY,
                    0L,
                    channel.size()
                )
            }
            mappedModel = mapped

            val baseOptions =
                BaseOptions.builder()
                    .setModelAssetBuffer(mapped)
                    .build()

            val options =
                ObjectDetector.ObjectDetectorOptions.builder()
                    .setBaseOptions(baseOptions)
                    .setScoreThreshold(0.10f)
                    .setMaxResults(30)
                    .setCategoryDenylist(listOf("potted plant", "boat"))
                    .build()

            detector =
                ObjectDetector.createFromOptions(
                    context,
                    options
                )
            onStatus(
                "Object AI: Lite4 ACTIVE • threshold 0.10 • max 30 • potted plant OFF • boat OFF"
            )
        } catch (e: Exception) {
            mappedModel = null
            onStatus("Animal AI failed: ${e.message}")
        }
    }

    fun analyze(bitmap: Bitmap): List<AnimalDetection> {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRunAt < 240L) return emptyList()
        lastRunAt = now

        return detectBitmap(
            bitmap = bitmap,
            source = "full",
            offsetX = 0f,
            offsetY = 0f,
            scaleX = 1f,
            scaleY = 1f,
            boostedPetThresholds = false
        )
    }

    /**
     * Full-scene small-object rescue. Unlike the older pet boost this does NOT
     * require Person to have been found first. Four overlapping crops cover
     * the entire portrait frame, so distant Person/Dog/Cat/Car/Bicycle/Bird
     * objects in the road can still be detected when the whole-frame pass
     * shrinks them too much.
     *
     * The DVR service temporally confirms these permissive tile detections
     * before they are allowed to name an event.
     */
    fun analyzePriorityTiles(bitmap: Bitmap): List<AnimalDetection> {
        val now = SystemClock.elapsedRealtime()
        if (now - lastPriorityTileBoostAt < 600L) return emptyList()
        lastPriorityTileBoostAt = now

        val task = detector ?: return emptyList()
        if (bitmap.width < 64 || bitmap.height < 64) return emptyList()

        val cropW = (bitmap.width * 0.64f).toInt().coerceIn(48, bitmap.width)
        val cropH = (bitmap.height * 0.64f).toInt().coerceIn(48, bitmap.height)
        val maxLeft = (bitmap.width - cropW).coerceAtLeast(0)
        val maxTop = (bitmap.height - cropH).coerceAtLeast(0)

        val rects =
            listOf(
                Rect(0, 0, cropW, cropH),
                Rect(maxLeft, 0, maxLeft + cropW, cropH),
                Rect(0, maxTop, cropW, maxTop + cropH),
                Rect(maxLeft, maxTop, maxLeft + cropW, maxTop + cropH)
            ).distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }

        if (rects.isEmpty()) return emptyList()

        // Lite4 is much heavier than Lite0. Running all four crops in one
        // burst can block object AI for several seconds and miss a person who
        // is visible only briefly while entering a parked car. Rotate one crop
        // per AI cycle instead. The whole frame still runs every cycle.
        val cropRect = rects[priorityTileIndex % rects.size]
        priorityTileIndex = (priorityTileIndex + 1) % rects.size

        val priority =
            setOf("person", "dog", "cat", "car", "bicycle", "motorcycle", "bird")

        var crop: Bitmap? = null
        return try {
            crop = Bitmap.createBitmap(
                bitmap,
                cropRect.left,
                cropRect.top,
                cropRect.width(),
                cropRect.height()
            )

            detectBitmap(
                bitmap = crop,
                source = "tile_priority",
                offsetX = cropRect.left.toFloat(),
                offsetY = cropRect.top.toFloat(),
                scaleX = 1f,
                scaleY = 1f,
                boostedPetThresholds = true,
                taskOverride = task
            )
                .filter { it.label.lowercase(Locale.US) in priority }
                .sortedByDescending { it.score }
                .take(8)
        } catch (_: Throwable) {
            emptyList()
        } finally {
            try { crop?.recycle() } catch (_: Throwable) {}
        }
    }

    /**
     * Full-width horizontal rescue bands. The four corner tiles are good for
     * distant objects, but a Person/Dog near the centre line can be split
     * across tile boundaries. These bands keep the full scene width and enlarge
     * the upper road/middle/lower terrace regions vertically.
     */
    fun analyzeNearFieldBands(bitmap: Bitmap): List<AnimalDetection> {
        val now = SystemClock.elapsedRealtime()
        if (now - lastNearFieldBoostAt < 520L) return emptyList()
        lastNearFieldBoostAt = now

        val task = detector ?: return emptyList()
        if (bitmap.width < 64 || bitmap.height < 96) return emptyList()

        // Fixed door-camera priority band: the road/driveway and parked-car
        // area usually sits in the upper-middle part of a portrait frame. A
        // narrower full-width crop makes a partly occluded person beside/inside
        // a car substantially larger for Lite4 without assuming left or right.
        val top = (bitmap.height * 0.17f).toInt().coerceIn(0, bitmap.height - 1)
        val bottom = (bitmap.height * 0.63f).toInt().coerceIn(top + 1, bitmap.height)
        val bandH = bottom - top
        if (bandH < 64) return emptyList()

        val priority = setOf("person", "dog", "cat", "car", "bicycle", "motorcycle", "bird")
        var crop: Bitmap? = null

        return try {
            crop = Bitmap.createBitmap(
                bitmap,
                0,
                top,
                bitmap.width,
                bandH
            )

            detectBitmap(
                bitmap = crop,
                source = "driveway_priority",
                offsetX = 0f,
                offsetY = top.toFloat(),
                scaleX = 1f,
                scaleY = 1f,
                boostedPetThresholds = true,
                taskOverride = task
            )
                .filter { it.label.lowercase(Locale.US) in priority }
                .sortedByDescending { it.score }
                .take(10)
        } catch (_: Throwable) {
            emptyList()
        } finally {
            try { crop?.recycle() } catch (_: Throwable) {}
        }
    }

    /**
     * Owner-companion rescue. If the whole-frame pass sees a Person but misses
     * Dog/Cat, use one local owner-centred crop. This makes a tiny distant pet
     * substantially larger in both dimensions while retaining several body
     * widths ahead/behind the owner.
     */
    fun analyzeCompanionBand(
        bitmap: Bitmap,
        people: List<AnimalDetection>
    ): List<AnimalDetection> {
        if (people.isEmpty()) return emptyList()

        val now = SystemClock.elapsedRealtime()
        if (now - lastCompanionBoostAt < 380L) return emptyList()
        lastCompanionBoostAt = now

        val task = detector ?: return emptyList()
        if (bitmap.width < 64 || bitmap.height < 96) return emptyList()

        val valid = people.filter {
            it.box.width() > 1f && it.box.height() > 1f
        }
        if (valid.isEmpty()) return emptyList()

        // v0.5.20.12: use ONE local crop around the most useful owner instead
        // of a full-width horizontal band. In a portrait door-camera frame a
        // distant white dog can be only a handful of pixels wide. Keeping the
        // whole frame width barely enlarges it. A local owner-centred crop
        // increases both horizontal and vertical model resolution while still
        // leaving several body-widths ahead/behind for dogs on a leash.
        val owner = valid
            .sortedWith(
                compareByDescending<AnimalDetection> { it.score }
                    .thenByDescending { it.box.height() }
            )
            .first()

        val personH = owner.box.height()
            .coerceAtLeast(bitmap.height * 0.035f)
        val centerX = (owner.box.left + owner.box.right) * 0.5f

        val minCropW = bitmap.width * 0.34f
        val desiredCropW = max(minCropW, personH * 6.2f)
            .coerceAtMost(bitmap.width * 0.72f)
        val cropW = desiredCropW.toInt().coerceIn(64, bitmap.width)

        var left = (centerX - cropW * 0.5f).toInt()
        left = left.coerceIn(0, (bitmap.width - cropW).coerceAtLeast(0))
        val right = (left + cropW).coerceAtMost(bitmap.width)

        var top = (owner.box.top - personH * 0.45f).toInt()
        var bottom = (owner.box.bottom + personH * 1.05f).toInt()
        top = top.coerceIn(0, bitmap.height - 1)
        bottom = bottom.coerceIn(top + 1, bitmap.height)

        val minCropH = (bitmap.height * 0.20f).toInt().coerceAtLeast(72)
        val maxCropH = (bitmap.height * 0.46f).toInt().coerceAtLeast(minCropH)
        var cropH = bottom - top
        if (cropH < minCropH) {
            val centerY = ((top + bottom) / 2).coerceIn(0, bitmap.height - 1)
            top = (centerY - minCropH / 2).coerceAtLeast(0)
            bottom = (top + minCropH).coerceAtMost(bitmap.height)
            top = (bottom - minCropH).coerceAtLeast(0)
        } else if (cropH > maxCropH) {
            val centerY = ((top + bottom) / 2).coerceIn(0, bitmap.height - 1)
            top = (centerY - maxCropH / 2).coerceAtLeast(0)
            bottom = (top + maxCropH).coerceAtMost(bitmap.height)
            top = (bottom - maxCropH).coerceAtLeast(0)
        }
        cropH = bottom - top
        if (right - left < 64 || cropH < 64) return emptyList()

        var crop: Bitmap? = null
        return try {
            crop = Bitmap.createBitmap(
                bitmap,
                left,
                top,
                right - left,
                cropH
            )

            detectBitmap(
                bitmap = crop,
                source = "companion_local",
                offsetX = left.toFloat(),
                offsetY = top.toFloat(),
                scaleX = 1f,
                scaleY = 1f,
                boostedPetThresholds = true,
                taskOverride = task
            )
                .filter {
                    val n = it.label.lowercase(Locale.US)
                    n == "dog" || n == "cat"
                }
                .map { pet ->
                    val leash =
                        if (plausibleCompanionDistance(
                                owner.box,
                                pet.box,
                                bitmap.width,
                                bitmap.height
                            )
                        ) {
                            estimateThinLeashEvidence(
                                bitmap,
                                owner.box,
                                pet.box
                            )
                        } else {
                            0f
                        }

                    pet.copy(
                        score = (pet.score + leash * 0.12f).coerceAtMost(1f),
                        leashEvidence = leash
                    )
                }
                .sortedByDescending { it.score }
                .take(6)
        } catch (_: Throwable) {
            emptyList()
        } finally {
            try { crop?.recycle() } catch (_: Throwable) {}
        }
    }

    /**
     * Second-pass rescue for small pets that disappear when a full portrait
     * frame is resized for EfficientDet. The crops cover the whole image with
     * overlap rather than assuming the pet is at the owner's feet; this also
     * catches dogs walking ahead of or behind their owner.
     *
     * This is deliberately rate-limited because it can run four extra model
     * inferences. It should normally be called only when Person is present but
     * Dog/Cat was absent from the first pass.
     */
    fun analyzeSmallPetBoost(
        bitmap: Bitmap,
        people: List<AnimalDetection>
    ): List<AnimalDetection> {
        if (people.isEmpty()) return emptyList()

        val now = SystemClock.elapsedRealtime()
        if (now - lastSmallPetBoostAt < 850L) return emptyList()
        lastSmallPetBoostAt = now

        val task = detector ?: return emptyList()
        if (bitmap.width < 64 || bitmap.height < 64) return emptyList()

        // 64% x 64% crops at each corner => useful overlap through the centre.
        // A small distant pet therefore occupies substantially more pixels in
        // at least one pass without requiring knowledge of walking direction.
        val cropW = (bitmap.width * 0.64f).toInt().coerceIn(48, bitmap.width)
        val cropH = (bitmap.height * 0.64f).toInt().coerceIn(48, bitmap.height)
        val maxLeft = (bitmap.width - cropW).coerceAtLeast(0)
        val maxTop = (bitmap.height - cropH).coerceAtLeast(0)

        val rects =
            listOf(
                Rect(0, 0, cropW, cropH),
                Rect(maxLeft, 0, maxLeft + cropW, cropH),
                Rect(0, maxTop, cropW, maxTop + cropH),
                Rect(maxLeft, maxTop, maxLeft + cropW, maxTop + cropH)
            )
                .distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }

        val candidates = mutableListOf<AnimalDetection>()

        rects.forEach { cropRect ->
            var crop: Bitmap? = null
            try {
                crop = Bitmap.createBitmap(
                    bitmap,
                    cropRect.left,
                    cropRect.top,
                    cropRect.width(),
                    cropRect.height()
                )

                // The ObjectDetector accepts arbitrary image dimensions and
                // internally preprocesses them for the model.
                candidates +=
                    detectBitmap(
                        bitmap = crop,
                        source = "tile",
                        offsetX = cropRect.left.toFloat(),
                        offsetY = cropRect.top.toFloat(),
                        scaleX = 1f,
                        scaleY = 1f,
                        boostedPetThresholds = true,
                        taskOverride = task
                    )
                        .filter {
                            val n = it.label.lowercase(Locale.US)
                            n == "dog" || n == "cat"
                        }
            } catch (_: Throwable) {
                // A rescue pass must never break the main DVR pipeline.
            } finally {
                try {
                    crop?.recycle()
                } catch (_: Throwable) {}
            }
        }

        return candidates
            .map { pet ->
                val nearestPerson =
                    people.minByOrNull { person ->
                        boxDistance(person.box, pet.box)
                    }

                val leash =
                    if (nearestPerson != null &&
                        plausibleCompanionDistance(
                            nearestPerson.box,
                            pet.box,
                            bitmap.width,
                            bitmap.height
                        )
                    ) {
                        estimateThinLeashEvidence(
                            bitmap,
                            nearestPerson.box,
                            pet.box
                        )
                    } else {
                        0f
                    }

                // Leash evidence is only a modest confidence assist. It can
                // rescue an already dog/cat-shaped candidate; it can never
                // create an animal detection by itself.
                pet.copy(
                    score =
                        (pet.score + leash * 0.11f)
                            .coerceAtMost(1f),
                    leashEvidence = leash
                )
            }
            .sortedByDescending { it.score }
            .distinctBy {
                val cx = ((it.box.left + it.box.right) * 0.5f / 40f).toInt()
                val cy = ((it.box.top + it.box.bottom) * 0.5f / 40f).toInt()
                "${it.label}:$cx:$cy"
            }
            .take(6)
    }

    private fun detectBitmap(
        bitmap: Bitmap,
        source: String,
        offsetX: Float,
        offsetY: Float,
        scaleX: Float,
        scaleY: Float,
        boostedPetThresholds: Boolean,
        taskOverride: ObjectDetector? = null
    ): List<AnimalDetection> {
        val task = taskOverride ?: detector ?: return emptyList()
        var converted: Bitmap? = null

        return try {
            val input =
                if (bitmap.config == Bitmap.Config.ARGB_8888) {
                    bitmap
                } else {
                    converted =
                        bitmap.copy(
                            Bitmap.Config.ARGB_8888,
                            false
                        )
                    converted ?: return emptyList()
                }

            val image = BitmapImageBuilder(input).build()
            val result = task.detect(image)
            image.close()
            noteInference()

            result.detections()
                .mapNotNull { detection ->
                    val category =
                        detection.categories()
                            .maxByOrNull { it.score() }
                            ?: return@mapNotNull null

                    val raw =
                        category.categoryName()
                            .lowercase(Locale.US)

                    if (raw.isBlank()) return@mapNotNull null

                    // User-disabled COCO class. Static vegetation should never
                    // consume event-label evidence or appear in the monitor.
                    if (raw == "potted plant" || raw == "potted_plant") {
                        return@mapNotNull null
                    }

                    val minimumScore =
                        if (boostedPetThresholds) {
                            when (raw) {
                                // The tile pass is intentionally permissive;
                                // the DVR service temporally confirms weak
                                // candidates before using them as event labels.
                                "dog" -> 0.10f
                                "cat" -> 0.14f
                                "person" -> 0.14f
                                "car" -> 0.18f
                                "bicycle" -> 0.20f
                                "bird" -> 0.20f
                                else -> 0.50f
                            }
                        } else {
                            when (raw) {
                                "dog" -> 0.28f
                                "cat" -> 0.30f
                                "bird" -> 0.30f
                                "person" -> 0.24f
                                "bicycle" -> 0.34f
                                else -> 0.42f
                            }
                        }

                    if (category.score() < minimumScore) {
                        return@mapNotNull null
                    }

                    val box = detection.boundingBox()

                    AnimalDetection(
                        label =
                            raw.replaceFirstChar {
                                it.uppercase()
                            },
                        score = category.score(),
                        box =
                            RectF(
                                offsetX + box.left.toFloat() * scaleX,
                                offsetY + box.top.toFloat() * scaleY,
                                offsetX + box.right.toFloat() * scaleX,
                                offsetY + box.bottom.toFloat() * scaleY
                            ),
                        source = source
                    )
                }
                .sortedByDescending { it.score }
                .take(if (boostedPetThresholds) 8 else 12)
        } catch (e: Exception) {
            onStatus("Animal AI error: ${e.message}")
            emptyList()
        } finally {
            try {
                if (converted != null && !converted!!.isRecycled) {
                    converted!!.recycle()
                }
            } catch (_: Exception) {}
        }
    }

    @Synchronized
    private fun noteInference() {
        val now = SystemClock.elapsedRealtime()
        if (inferenceWindowStartedAt == 0L) {
            inferenceWindowStartedAt = now
        }
        inferenceCountInWindow++
        val elapsed = now - inferenceWindowStartedAt
        if (elapsed >= 1_000L) {
            inferenceFpsValue =
                inferenceCountInWindow.toFloat() /
                    (elapsed.toFloat() / 1_000f)
            inferenceCountInWindow = 0
            inferenceWindowStartedAt = now
        }
    }

    private fun boxDistance(a: RectF, b: RectF): Float {
        val ax = (a.left + a.right) * 0.5f
        val ay = (a.top + a.bottom) * 0.5f
        val bx = (b.left + b.right) * 0.5f
        val by = (b.top + b.bottom) * 0.5f
        return hypot(ax - bx, ay - by)
    }

    private fun plausibleCompanionDistance(
        person: RectF,
        pet: RectF,
        frameWidth: Int,
        frameHeight: Int
    ): Boolean {
        val distance = boxDistance(person, pet)
        val personH = person.height().coerceAtLeast(1f)
        val diagonal = hypot(frameWidth.toFloat(), frameHeight.toFloat())

        // Allows a dog several body-widths in front/behind while rejecting a
        // pet candidate on the opposite side of a very wide scene.
        return distance <= max(personH * 2.9f, diagonal * 0.34f)
    }

    /**
     * Very small, dependency-free leash heuristic. Samples the corridor from
     * the person's lower torso/hand region to the pet and looks for a thin,
     * locally contrasting line that persists across multiple points.
     *
     * It is deliberately weak evidence: roads, branches and shadows can also
     * contain thin lines, so this score only boosts an existing pet candidate.
     */
    private fun estimateThinLeashEvidence(
        bitmap: Bitmap,
        person: RectF,
        pet: RectF
    ): Float {
        if (bitmap.width < 8 || bitmap.height < 8) return 0f

        val starts =
            listOf(
                Pair(
                    person.left + person.width() * 0.30f,
                    person.top + person.height() * 0.62f
                ),
                Pair(
                    person.left + person.width() * 0.70f,
                    person.top + person.height() * 0.62f
                ),
                Pair(
                    person.left + person.width() * 0.50f,
                    person.top + person.height() * 0.78f
                )
            )

        val endX = (pet.left + pet.right) * 0.5f
        val endY = pet.top + pet.height() * 0.38f

        return starts.maxOfOrNull { (startX, startY) ->
            thinLineScore(
                bitmap,
                startX,
                startY,
                endX,
                endY
            )
        } ?: 0f
    }

    private fun thinLineScore(
        bitmap: Bitmap,
        x0: Float,
        y0: Float,
        x1: Float,
        y1: Float
    ): Float {
        val dx = x1 - x0
        val dy = y1 - y0
        val length = hypot(dx, dy)
        if (length < 20f) return 0f

        val nx = -dy / length
        val ny = dx / length
        val samples = 28
        var contrastHits = 0
        var longestRun = 0
        var run = 0

        for (i in 3 until samples - 2) {
            val t = i.toFloat() / (samples - 1).toFloat()
            val x = x0 + dx * t
            val y = y0 + dy * t

            val centre = gray(bitmap, x, y) ?: continue
            val sideA = gray(bitmap, x + nx * 3.5f, y + ny * 3.5f) ?: continue
            val sideB = gray(bitmap, x - nx * 3.5f, y - ny * 3.5f) ?: continue
            val surroundings = (sideA + sideB) * 0.5f
            val contrast = abs(centre - surroundings)

            if (contrast >= 24f) {
                contrastHits++
                run++
                longestRun = max(longestRun, run)
            } else {
                run = 0
            }
        }

        val usable = (samples - 5).coerceAtLeast(1)
        val density = contrastHits.toFloat() / usable.toFloat()
        val continuity = (longestRun.toFloat() / 7f).coerceIn(0f, 1f)

        return (density * 0.60f + continuity * 0.40f)
            .coerceIn(0f, 1f)
    }

    private fun gray(bitmap: Bitmap, x: Float, y: Float): Float? {
        val ix = x.toInt()
        val iy = y.toInt()
        if (ix !in 0 until bitmap.width || iy !in 0 until bitmap.height) {
            return null
        }
        val c = bitmap.getPixel(ix, iy)
        val r = (c shr 16) and 0xff
        val g = (c shr 8) and 0xff
        val b = c and 0xff
        return (r * 0.299f + g * 0.587f + b * 0.114f)
    }

    fun stop() {
        try { detector?.close() } catch (_: Exception) {}
        detector = null
    }
}
