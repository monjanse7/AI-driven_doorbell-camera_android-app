package com.example.aidoormonitor

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraSelector
import java.util.Locale

data class CameraChoice(
    val key: String,
    val label: String
)

/**
 * Conservative camera selection.  This deliberately avoids CameraX's
 * experimental physical-camera-id selector.  Motorola/OEM camera IDs that
 * CameraX exposes as independent logical devices can still be selected.
 */
@OptIn(ExperimentalCamera2Interop::class)
object CameraChoiceRepository {
    const val DEFAULT_BACK_KEY = "default_back"
    const val DEFAULT_FRONT_KEY = "default_front"

    fun discover(context: Context): List<CameraChoice> {
        val result = mutableListOf(
            CameraChoice(DEFAULT_BACK_KEY, "Rear camera • automatic"),
            CameraChoice(DEFAULT_FRONT_KEY, "Front camera • automatic")
        )
        val seen = result.mapTo(linkedSetOf()) { it.key }

        val manager = try {
            context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        } catch (_: Throwable) {
            null
        } ?: return result

        val ids = try { manager.cameraIdList.toList() } catch (_: Throwable) { emptyList() }
        for (id in ids) {
            val c = try { manager.getCameraCharacteristics(id) } catch (_: Throwable) { continue }
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            val facingText = when (facing) {
                CameraCharacteristics.LENS_FACING_BACK -> "Rear"
                CameraCharacteristics.LENS_FACING_FRONT -> "Front"
                CameraCharacteristics.LENS_FACING_EXTERNAL -> "External"
                else -> "Camera"
            }
            val focal = try {
                c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                    ?.filter { it > 0f }
                    ?.minOrNull()
            } catch (_: Throwable) { null }
            val focalText = if (focal != null)
                String.format(Locale.US, "%.1f mm", focal)
            else
                "lens"
            val lensKind = when {
                facing == CameraCharacteristics.LENS_FACING_FRONT -> "Front"
                facing == CameraCharacteristics.LENS_FACING_BACK && focal != null && focal <= 2.5f -> "Ultra-wide"
                facing == CameraCharacteristics.LENS_FACING_BACK && focal != null && focal >= 6.0f -> "Tele"
                facing == CameraCharacteristics.LENS_FACING_BACK -> "Wide / main"
                else -> facingText
            }
            val key = "camera_id:$id"
            if (seen.add(key)) {
                result += CameraChoice(key, "$lensKind • $focalText • camera ID $id")
            }
        }
        return result
    }

    fun selectorForKey(key: String?): CameraSelector {
        if (key.isNullOrBlank() || key == DEFAULT_BACK_KEY) return CameraSelector.DEFAULT_BACK_CAMERA
        if (key == DEFAULT_FRONT_KEY) return CameraSelector.DEFAULT_FRONT_CAMERA

        if (key.startsWith("camera_id:")) {
            val wanted = key.removePrefix("camera_id:")
            if (wanted.isNotBlank()) {
                return CameraSelector.Builder()
                    .addCameraFilter { infos ->
                        infos.filter { info ->
                            try {
                                Camera2CameraInfo.from(info).cameraId == wanted
                            } catch (_: Throwable) {
                                false
                            }
                        }
                    }
                    .build()
            }
        }
        return CameraSelector.DEFAULT_BACK_CAMERA
    }
}
