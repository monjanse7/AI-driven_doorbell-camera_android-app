package com.example.aidoormonitor.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack

/** Plays short PCM16 mono talkback packets on the camera phone speaker. */
class CameraTalkbackPlayer {
    private val lock = Any()
    private var track: AudioTrack? = null
    private var currentSampleRate = 0

    fun play(sampleRate: Int, pcm16le: ByteArray): Boolean {
        if (pcm16le.isEmpty()) return false
        val rate = sampleRate.coerceIn(8_000, 48_000)
        synchronized(lock) {
            try {
                if (track == null || currentSampleRate != rate) {
                    releaseLocked()
                    val minBuffer = AudioTrack.getMinBufferSize(
                        rate,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    ).coerceAtLeast(rate / 2)
                    track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(rate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(minBuffer * 2)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build()
                    currentSampleRate = rate
                    track?.play()
                }
                val t = track ?: return false
                t.write(pcm16le, 0, pcm16le.size, AudioTrack.WRITE_BLOCKING)
                return true
            } catch (_: Throwable) {
                releaseLocked()
                return false
            }
        }
    }

    fun release() = synchronized(lock) { releaseLocked() }

    private fun releaseLocked() {
        try { track?.pause() } catch (_: Throwable) {}
        try { track?.flush() } catch (_: Throwable) {}
        try { track?.release() } catch (_: Throwable) {}
        track = null
        currentSampleRate = 0
    }
}
