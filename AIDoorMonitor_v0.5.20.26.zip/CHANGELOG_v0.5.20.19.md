# v0.5.20.19

- Fixes manual-focus capability detection: adjustable focus no longer incorrectly requires Camera2 MANUAL_SENSOR.
- Un-mirrors front-camera live view on the monitor while preserving zoom/pan.
- Adds a monitor-side persistent doorbell listener foreground service, so ring alerts can arrive while MonitorActivity is closed.
- Doorbell notifications use a high-priority/full-screen intent and open MonitorActivity directly into live view when Android permits it.
- Adds two-way monitor-to-camera talkback using 16 kHz PCM and a START/STOP TALK button.
- Doorbell launch automatically enables camera live audio.
