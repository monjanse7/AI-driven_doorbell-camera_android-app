# v0.5.20.10 – Sensitivity Trigger Fix

- Fixes AI Sensitivity so it controls the actual DVR trigger gate, not only final event naming.
- 100% Sensitivity now maps to safe practical floors: Person/Dog 10%, Car 14%, Cat/Bird/Bicycle 12%.
- Dog bark/growl/whine/yelp/howl raw YamNet candidates are admitted from 10%; the configured AI rule sensitivity decides whether they trigger an event.
- Disabled rules remain disabled even at high sensitivity.
- Keeps v0.5.20.9 Camera2 first-frame A/V sync.
