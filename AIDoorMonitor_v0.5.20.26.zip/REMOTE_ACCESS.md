# Remote mobile-data access

AIDoorMonitor v0.5.20 supports remote monitoring through a private Tailscale network.

## Setup

1. Install Tailscale on both Android phones.
2. Sign both phones into the same Tailscale account/tailnet.
3. Turn Tailscale on on the camera phone.
4. Open AIDoorMonitor DVR Camera Mode and view **Viewer pairing**.
5. Confirm the text says **Remote mobile-data access: READY via Tailscale** and shows a `100.x.x.x` address.
6. Scan the AIDoorMonitor QR on the monitor phone once.
7. Turn Wi-Fi off on the monitor phone and leave mobile data + Tailscale on.
8. Connect in Monitor Mode. It should display **REMOTE VPN** when the fallback route is used.

## What works remotely

- Live MJPEG camera view
- Fullscreen crop zoom/pan
- Live camera audio
- Record / stop-record controls
- Camera restart command while Android allows the camera foreground service to respond
- Temperature, battery, power-deficit and AI status
- Event log
- Event/recording browser, thumbnails, playback, download and deletion
- Remote zoom/focus/preview/DVR settings

## Important

Do not forward port 8787 on your home router. The AIDoorMonitor camera endpoint uses HTTP plus a long pairing token and is designed for LAN or an encrypted private VPN such as Tailscale, not for direct exposure to the public Internet.

If remote access is not detected, connect Tailscale on the camera phone and reopen the DVR Camera screen so the pairing QR is regenerated with the VPN address.
