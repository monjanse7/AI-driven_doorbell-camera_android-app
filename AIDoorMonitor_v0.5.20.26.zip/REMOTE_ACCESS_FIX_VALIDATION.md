# v0.5.20.3 Remote Mobile Route Fix validation

Changes checked:

- `/health` wraps existing health JSON and advertises `lanHost`, `remoteHost`, `remoteAccessReady`, and `serverPort`.
- Monitor learns a valid Tailscale 100.64.0.0/10 address from camera health and persists an upgraded pairing URI.
- With no usable Wi-Fi transport, monitor orders the VPN candidate before the LAN candidate.
- Existing LAN-first behavior remains when Wi-Fi is available.
- Connection failure text distinguishes a missing saved VPN address from a saved address whose Tailscale route is offline.
- Recording rows now launch playback directly.
- Remote recording player receives alternate route URLs and attempts route failover before local-cache fallback.

Static checks:

- Changed Kotlin files have balanced braces/parentheses.
- `kotlinc` parser pass reported no syntax/parser errors in MonitorActivity.kt, RemoteRecordingActivity.kt, or LanCameraServer.kt; unresolved Android/project references are expected without the Android Gradle classpath.
- Project version bumped to 0.5.20.3 / versionCode 105.
