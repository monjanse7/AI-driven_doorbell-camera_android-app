# Tailscale manual fallback

If the monitor only shows the camera LAN address (for example 192.168.x.x) even though Tailscale is connected:

1. Open Tailscale on the CAMERA phone.
2. Find the CAMERA phone's own IPv4 address in the 100.64.0.0/10 range.
3. In AI Door Monitor on the MONITOR phone, enter that address in `Camera Tailscale IP`.
4. Tap `Save / test camera Tailscale IP`.
5. A successful test shows `Remote VPN: READY`.
6. You can then disable Wi-Fi on the monitor and use mobile data + Tailscale.

Do not enter the monitor phone's own Tailscale address.
