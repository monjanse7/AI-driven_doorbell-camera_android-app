# v0.5.20.3 Remote Mobile Route Fix

- Camera `/health` now advertises current LAN and Tailscale IPv4 routes.
- Monitor automatically learns/saves the camera Tailscale route while connected at home.
- When no Wi-Fi is available, monitor tries the saved Tailscale route before the LAN IP.
- Clear diagnostics distinguish missing saved VPN address from Tailscale being offline.
- Event/recording rows open playback directly, not only thumbnail taps.
- Remote recording player receives alternate LAN/VPN URLs and can fail over between them.
- Keeps v0.5.20.2 project-root/build fixes and all v0.5.20 AI/A/V-sync features.
