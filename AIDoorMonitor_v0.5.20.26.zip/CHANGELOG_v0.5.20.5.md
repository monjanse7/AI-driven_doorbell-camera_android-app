# AI Door Monitor v0.5.20.5

## Tailscale VPN detection + manual fallback

- Camera-side Tailscale discovery now uses two paths:
  1. NetworkInterface enumeration.
  2. ConnectivityManager TRANSPORT_VPN LinkProperties fallback.
- `/health` advertises the camera Tailscale IPv4 when either path finds it.
- Monitor adds `Camera Tailscale IP (100.x.x.x, optional)`.
- `Save / test camera Tailscale IP` persists and directly probes `/health` over the entered VPN address.
- A valid manual Tailscale address is injected into the pairing URI and used first when Wi-Fi is unavailable.
- Remote overlay distinguishes automatically advertised VPN from a saved fallback route.
- Existing v0.5.20.4 LAN/Tailscale failover, Lite4 AI, A/V sync, event playback fallback and DVR features are retained.
