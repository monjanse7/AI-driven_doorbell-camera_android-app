# v0.5.20.15 – Remote Lens Selection + Critical Full AI

- Monitor can load and remotely select every camera ID exposed by Android, including front camera and OEM-exposed wide/ultra-wide rear lenses.
- Camera list labels use focal length heuristics to mark ultra-wide, wide/main, tele and front lenses.
- Switching lens restarts only the DVR camera pipeline while keeping the LAN service available.
- Critical thermal mode no longer reduces object/audio AI cadence or rescue cycles. It reports `CPU saver: Critical • AI FULL`.
- Critical cooling still reduces motion sampling/JPEG quality and relies on the existing recording/thermal safeguards.
