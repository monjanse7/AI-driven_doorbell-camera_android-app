# v0.5.20.10 Sensitivity Trigger Fix validation

Expected mapping examples:
- Person: default Sensitivity 35% => ~0.40 trigger threshold; 100% => 0.10.
- Dog: default Sensitivity 35% => ~0.38 trigger threshold; 100% => 0.10.
- Car: default Sensitivity 45% => ~0.55 trigger threshold; 100% => 0.12 (moving-car requirement remains).
- Dog barking: default Sensitivity 40% => ~0.25 YamNet threshold; 100% => 0.08.

100% sensitivity intentionally does not mean a literal 0.00 score threshold because both EfficientDet and YamNet always produce low-probability background classes. A small practical floor avoids continuous false events.
