# Small Animal / Terrace validation

Test cases:
1. Dog head or partial dog visible over terrace/balcony railing should receive periodic terrace rescue passes.
2. Small/far bird should receive lower rescue threshold and temporal confirmation.
3. Dog beside owner should continue to use local companion rescue.
4. Dog with no nearby person and no leash-like evidence may be labelled `Loose dog candidate`.
5. Horse/sheep/cow/elephant/bear/zebra/giraffe detections from the standard COCO model can trigger and name events.
6. Stationary-car movement guard, bench ignore, person counting, tap-sound doorbell and Critical AI FULL remain enabled.

Note: collar/no-collar classification is not supported by the current COCO EfficientDet model.
