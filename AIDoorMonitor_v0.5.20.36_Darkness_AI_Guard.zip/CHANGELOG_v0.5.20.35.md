# v0.5.20.35 — Rule Disable Hard Filter

- Removed Elephant, Bear, Zebra and Giraffe from built-in AI rules and rescue class lists.
- Existing installs automatically purge those retired built-in rules from saved rule JSON.
- Fixed disabled Object AI rules still appearing in active-event names.
- The Edit AI Events enabled/disabled state now gates both event triggering and event naming/upgrading.
- The Moving car checkbox is now authoritative for both triggers and naming: when disabled, car/truck/bus detections cannot create or rename an event.
- Bench and retired exotic classes are hard-filtered as a final safety net.
- Keeps v0.5.20.34 terrace/person rescue and v0.5.20.33 aggressive dog rescue.
