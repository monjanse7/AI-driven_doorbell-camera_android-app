# v0.5.20.30 — Audio-Guided Multi-Dog Rescue

- Dog barking/growling/whining/yelping/howling now primes visual dog detection for 8 seconds.
- Audio is only a search hint: `Dog_xN` still requires a real EfficientDet dog detection.
- Added six overlapping high-resolution dog rescue crops to improve detection of small/distant dogs and several dogs around one person.
- Audio-guided rescue has priority over generic rescue while dog audio is active.
- Multiple visually confirmed dogs continue to upgrade active event metadata through the existing `Dog_xN` counter.
- Keeps v0.5.20.29 instant doorbell, wake-screen, auto live view/talkback, near-person rescue and moving-vehicle rescue.
