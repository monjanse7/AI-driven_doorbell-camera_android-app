# v0.5.20.33 — Aggressive Dog + Edge Companion Rescue

- Adds maximum-sensitivity visual Dog rescue while a Person is visible but Dog is missing.
- Runs the Dog rescue every available AI rescue cycle instead of alternating it with generic companion passes.
- Uses dense overlapping 3x2 crops over the outdoor scene plus explicit left/right frame-edge companion crops.
- Edge crops extend below a partly clipped owner so a dog walking just outside/inside the frame edge is still searched.
- Allows up to 9 dog-focused crop inferences per aggressive rescue and up to 12 distinct dog candidates.
- Lowers the temporally-confirmed rescue floor specifically for `dog_aggressive` candidates from 0.24 to 0.18.
- A strong dog-focused crop result (>=0.34) can promote immediately; weaker candidates still require temporal confirmation.
- Dog labels are never fabricated from owner context, movement or leash evidence: EfficientDet must itself emit `dog`.
- Keeps face recognition, learned Unidentified-motion labels, audio-guided dog rescue, loose-dog candidate logic, vehicle motion gating and Critical = AI FULL behavior.

## Thermal note
This version deliberately spends substantially more inference work on dogs. On phones already at thermal Critical it can increase sustained AI load and temperature. This is intentional because maximum dog sensitivity was requested.
