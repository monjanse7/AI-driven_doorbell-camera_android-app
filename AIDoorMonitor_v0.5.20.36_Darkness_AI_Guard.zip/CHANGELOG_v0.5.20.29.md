# v0.5.20.29 — Instant Doorbell + Auto Live Talk + Near Person/Vehicle Rescue

- Doorbell listener polling reduced to 500 ms and remembers the last working LAN/VPN host.
- Foreground listener now holds a partial CPU wake lock and high-performance Wi-Fi lock while enabled to prevent multi-minute screen-off polling delays.
- Doorbell alert wakes the monitor display.
- Notification/full-screen intent opens Monitor directly into live view.
- Live camera audio is enabled automatically and monitor talkback starts automatically when RECORD_AUDIO permission is already granted.
- Added near-camera person/animal rescue priority during otherwise unidentified motion events.
- Moving car confirmation now has a fast path for large real bounding-box displacement while remaining resistant to stationary detector jitter.
- Car motion tracking also covers truck/bus classes, useful for vans and larger vehicles.
- Stationary car/truck/bus detections remain excluded from event naming.
