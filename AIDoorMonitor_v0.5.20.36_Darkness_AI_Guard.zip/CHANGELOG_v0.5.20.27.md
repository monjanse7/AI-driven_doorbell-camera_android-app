# AI Door Monitor v0.5.20.27

- Added terrace/balcony animal rescue crop for small or partially hidden animals peeking over railings.
- Expanded animal classes supported by the standard COCO EfficientDet model: horse, sheep, cow, elephant, bear, zebra and giraffe, in addition to dog, cat and bird.
- Lowered rescue thresholds for small birds and other animals while retaining temporal confirmation in the DVR service.
- Added multi-animal rescue participation to far/driveway/terrace passes.
- Added `Loose dog candidate` heuristic. A real Dog detection can be promoted to this label when no nearby person and no leash-like evidence are found.
- The loose-dog heuristic does NOT claim that a collar is absent; the current EfficientDet model cannot reliably inspect collars at door-camera distance.
- Kept Critical thermal mode at full AI and uses targeted rescue crops instead of permanently raising global full-frame inference load.
