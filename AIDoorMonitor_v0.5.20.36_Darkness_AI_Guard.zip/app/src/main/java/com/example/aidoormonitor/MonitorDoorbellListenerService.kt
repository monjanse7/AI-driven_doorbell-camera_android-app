package com.example.aidoormonitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.net.wifi.WifiManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.aidoormonitor.net.LocalNetwork
import com.example.aidoormonitor.net.Pairing
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Persistent monitor-side listener. It keeps only a lightweight /health poll
 * running so a doorbell press can be delivered even when MonitorActivity is
 * not open. It does NOT keep the MJPEG viewer or live audio running.
 */
class MonitorDoorbellListenerService : Service() {
    companion object {
        private const val SERVICE_CHANNEL = "doorbell_listener_service"
        private const val ALERT_CHANNEL = "doorbell_alerts"
        private const val SERVICE_ID = 52018
        private const val ALERT_ID = 52016

        fun ensureRunning(context: Context) {
            val i = Intent(context, MonitorDoorbellListenerService::class.java)
            androidx.core.content.ContextCompat.startForegroundService(context, i)
        }
    }

    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    private var cpuWakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var lastGoodHost: String? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        val notification = serviceNotification("Doorbell listener ready")
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this,
                SERVICE_ID,
                notification,
                if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
            )
        } else {
            startForeground(SERVICE_ID, notification)
        }
        acquireListenerLocks()
        startWorker()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startWorker()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running.set(false)
        worker?.interrupt()
        worker = null
        releaseListenerLocks()
        super.onDestroy()
    }

    private fun startWorker() {
        if (!running.compareAndSet(false, true)) return
        worker = Thread {
            while (running.get()) {
                try {
                    pollOnce()
                } catch (_: Throwable) {
                }
                try { Thread.sleep(500L) } catch (_: InterruptedException) { }
            }
        }.apply { name = "AI-Door-Doorbell-Listener"; isDaemon = true; start() }
    }

    private fun pollOnce() {
        val prefs = getSharedPreferences("monitor_pair", MODE_PRIVATE)
        if (!prefs.getBoolean("keep_monitor_connected", false)) return
        val raw = prefs.getString("last_pair", "").orEmpty()
        val pair = Pairing.parse(raw) ?: return
        val preferRemote = !isWifiAvailable()
        var health: JSONObject? = null
        val candidates = pair.connectionCandidates(preferRemote).toMutableList()
        lastGoodHost?.let { good ->
            candidates.sortBy { if (it.host == good) 0 else 1 }
        }
        for (candidate in candidates) {
            try {
                health = JSONObject(get(candidate.endpoint("/health")))
                lastGoodHost = candidate.host
                break
            } catch (_: Throwable) { }
        }
        val h = health ?: return
        val seq = h.optLong("doorbellSequence", 0L)
        val pressed = h.optLong("lastDoorbellPressedAtMs", 0L)
        val state = getSharedPreferences("doorbell_listener_state", MODE_PRIVATE)
        val last = state.getLong("last_sequence", -1L)
        if (last < 0L) {
            state.edit().putLong("last_sequence", seq).apply()
            return
        }
        if (seq <= last) return
        state.edit().putLong("last_sequence", seq).apply()
        showAlert(seq, pressed)
    }

    private fun isWifiAvailable(): Boolean {
        return try {
            val cm = getSystemService(android.net.ConnectivityManager::class.java)
            cm.allNetworks.any { network ->
                cm.getNetworkCapabilities(network)
                    ?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
            }
        } catch (_: Throwable) { false }
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 1200
            c.readTimeout = 1200
            c.useCaches = false
            c.requestMethod = "GET"
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun showAlert(sequence: Long, pressedAtMs: Long) {
        val time = if (pressedAtMs > 0L) {
            SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(pressedAtMs))
        } else "now"
        val open = Intent(this, MonitorActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("doorbell_auto_live", true)
            putExtra("doorbell_auto_talk", true)
            putExtra("doorbell_wake_screen", true)
            putExtra("doorbell_sequence", sequence)
        }
        val pi = PendingIntent.getActivity(
            this, 52019, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        wakeMonitorScreen()

        val n = NotificationCompat.Builder(this, ALERT_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Doorbell")
            .setContentText("Someone rang the doorbell • $time")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .addAction(android.R.drawable.ic_menu_view, "OPEN LIVE VIEW", pi)
            .setVibrate(longArrayOf(0, 300, 150, 500, 150, 500))
            .build()
        (getSystemService(NotificationManager::class.java)).notify(ALERT_ID, n)

        // Best effort: devices that allow background activity starts (for
        // example when full-screen intent/overlay access is granted) can jump
        // straight into the live viewer. Android may block this; the full-screen
        // / heads-up notification remains the reliable fallback.
        try {
            startActivity(open)
        } catch (_: Throwable) {
        }
    }

    @Suppress("DEPRECATION")
    private fun acquireListenerLocks() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            cpuWakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "AIDoorMonitor:DoorbellListenerCpu"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Throwable) { }

        try {
            val wm = applicationContext.getSystemService(WifiManager::class.java)
            wifiLock = wm.createWifiLock(
                WifiManager.WIFI_MODE_FULL_HIGH_PERF,
                "AIDoorMonitor:DoorbellListenerWifi"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Throwable) { }
    }

    private fun releaseListenerLocks() {
        try { if (cpuWakeLock?.isHeld == true) cpuWakeLock?.release() } catch (_: Throwable) { }
        cpuWakeLock = null
        try { if (wifiLock?.isHeld == true) wifiLock?.release() } catch (_: Throwable) { }
        wifiLock = null
    }

    @Suppress("DEPRECATION")
    private fun wakeMonitorScreen() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            val wake = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                    PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    PowerManager.ON_AFTER_RELEASE,
                "AIDoorMonitor:DoorbellScreenWake"
            )
            wake.acquire(10_000L)
        } catch (_: Throwable) { }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(SERVICE_CHANNEL, "Doorbell background listener", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps doorbell alerts active while the monitor app is closed"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(ALERT_CHANNEL, "Doorbell alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Doorbell ring alerts"
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }

    private fun serviceNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 52018,
            Intent(this, MonitorActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, SERVICE_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("AI Door Monitor")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }
}
