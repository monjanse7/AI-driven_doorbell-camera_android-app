package com.example.aidoormonitor.net

import android.content.Context
import org.json.JSONObject
import java.io.InputStream
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.atomic.AtomicLong

/**
 * Process-wide LAN endpoint used by both CameraActivity and DoorMonitoringService.
 *
 * The important property is that the ServerSocket and /stream client sockets do
 * not change during the Activity -> 24/7 foreground-service camera hand-off.
 * Only the active endpoint callbacks and the producer writing latestJpeg change.
 */
data class LiveAudioPacket(
    val sequence: Long,
    val sampleRate: Int,
    val channelCount: Int,
    val pcm16le: ByteArray
)

data class RemoteRecordingSource(
    val displayName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val openInputStream: (offset: Long) -> InputStream
)

interface LanCameraEndpoint {
    fun statusJson(): String
    fun eventsJson(): String

    fun recordingsJson(): String =
        """{"recordings":[]}"""

    fun openRecording(
        id: String
    ): RemoteRecordingSource? =
        null

    fun recordingThumbnailJpeg(
        id: String,
        width: Int,
        height: Int
    ): ByteArray? =
        null

    fun deleteRecording(
        id: String
    ): Boolean =
        false

    fun faceProfilesJson(): String = """{"ok":true,"faces":[]}"""
    fun enrollFace(name: String): String = """{"ok":false}"""
    fun renameFace(oldName: String, newName: String): String = """{"ok":false}"""
    fun deleteFace(name: String): String = """{"ok":false}"""
    fun learnedVisualLabelsJson(): String = """{"ok":true,"labels":[]}"""
    fun teachRecordingLabel(id: String, label: String): String = """{"ok":false}"""

    fun remoteDvrSettingsJson():
        String =
        "{}"

    fun applyRemoteDvrSettings(
        quality: Int?,
        videoBitrateMbps: Int?,
        audioBitrateKbps: Int?,
        audioSampleRateHz: Int?,
        audioSyncMs: Int?
    ): String =
        """{"ok":false}"""

    fun remoteCameraChoicesJson(): String =
        """{"ok":false,"choices":[]}"""

    fun applyRemoteCameraChoice(key: String): String =
        """{"ok":false,"reason":"remote_camera_choice_unsupported"}"""

    fun onZoom(linear: Float)
    fun onCameraView(linear: Float, panX: Float, panY: Float)
    fun onPreviewQuality(mode: Int)
    fun onFocusAuto()
    fun onFocusManual(linear: Float)
    fun onFocusSave()
    fun onRecordStart()
    fun onRecordStop()

    /** PCM16 mono audio sent from the monitor phone to the camera speaker. */
    fun onTalkPcm16(sampleRate: Int, pcm16le: ByteArray): Boolean = false

    /**
     * Best-effort remote recovery hook. Implementations should restart the
     * camera/DVR engine and may also request that the camera dashboard is
     * brought back to the foreground.
     */
    fun onRestartCameraApp(): String =
        """{"ok":false,"supported":false,"reason":"remote_restart_unsupported"}"""
}

object LanCameraHub {
    val latestJpeg = AtomicReference<ByteArray?>(null)

    val latestAudioPacket =
        AtomicReference<LiveAudioPacket?>(null)

    private val liveAudioSequence =
        AtomicLong(0L)

    fun publishLivePcm16Mono(
        samples: ShortArray,
        sampleRate: Int
    ) {
        if (
            samples.isEmpty() ||
            sampleRate <= 0
        ) {
            return
        }

        val bytes =
            ByteArray(
                samples.size * 2
            )

        var out =
            0

        samples.forEach {
                sample ->

            val value =
                sample.toInt()

            bytes[out++] =
                (
                    value and
                        0xFF
                    )
                    .toByte()

            bytes[out++] =
                (
                    value shr
                        8
                    )
                    .toByte()
        }

        latestAudioPacket.set(
            LiveAudioPacket(
                sequence =
                    liveAudioSequence
                        .incrementAndGet(),
                sampleRate =
                    sampleRate,
                channelCount =
                    1,
                pcm16le =
                    bytes
            )
        )
    }

    fun clearLiveAudio() {
        latestAudioPacket.set(
            null
        )
    }

    @Volatile
    private var endpoint: LanCameraEndpoint? = null

    @Volatile
    private var server: LanCameraServer? = null

    @Volatile
    private var lastError: String = ""

    fun setEndpoint(value: LanCameraEndpoint?) {
        endpoint = value
    }

    fun activeEndpoint(): LanCameraEndpoint? = endpoint

    @Synchronized
    fun ensureStarted(context: Context, port: Int = 8787): LanCameraServer? {
        val existing = server
        if (existing?.isRunning() == true) {
            return existing
        }

        val token = Pairing.getOrCreateCameraToken(context.applicationContext)

        val candidate = LanCameraServer(
            context = context.applicationContext,
            port = port,
            token = token,
            latestJpeg = latestJpeg,
            latestAudioPacket =
                latestAudioPacket,
            statusJson = {
                val baseStatus =
                    endpoint?.statusJson()
                        ?: """{"ok":true,"handoff":true,"visualStreamAvailable":true,"frameReady":${latestJpeg.get() != null}}"""

                try {
                    val battery =
                        CameraPhoneBatteryReader.read(
                            context.applicationContext
                        )

                    JSONObject(baseStatus)
                        .apply {
                            put(
                                "cameraPhoneBatteryPercent",
                                battery.percent
                                    ?: JSONObject.NULL
                            )
                            put(
                                "cameraPhoneBatteryStatus",
                                battery.status
                            )
                            put(
                                "cameraPhoneBatteryPlugged",
                                battery.plugged
                            )
                            put(
                                "cameraPhoneBatteryCharging",
                                battery.charging
                            )
                            put(
                                "cameraPhoneBatteryCurrentNowMa",
                                battery.currentNowMa
                                    ?: JSONObject.NULL
                            )
                            put(
                                "cameraPhoneBatteryCurrentAverageMa",
                                battery.currentAverageMa
                                    ?: JSONObject.NULL
                            )
                            put(
                                "cameraPhoneBatteryVoltageV",
                                battery.voltageV
                                    ?: JSONObject.NULL
                            )
                            put(
                                "cameraPhoneBatteryNetPowerW",
                                battery.netPowerW
                                    ?: JSONObject.NULL
                            )
                            put(
                                "cameraPhoneBatteryPowerFlow",
                                battery.powerFlow
                            )
                            put(
                                "cameraPhonePowerDeficitWarning",
                                battery.powerDeficitWarning
                            )
                            put(
                                "cameraPhonePowerDeficitSeconds",
                                battery.powerDeficitSeconds
                            )
                        }
                        .toString()
                } catch (_: Throwable) {
                    baseStatus
                }
            },
            eventsJson = {
                endpoint?.eventsJson() ?: "[]"
            },
            recordingsJson = {
                endpoint?.recordingsJson()
                    ?: """{"recordings":[]}"""
            },
            openRecording = { id ->
                endpoint?.openRecording(id)
            },
            recordingThumbnailJpeg = {
                    id,
                    width,
                    height ->
                endpoint?.recordingThumbnailJpeg(
                    id,
                    width,
                    height
                )
            },
            deleteRecording = { id ->
                endpoint?.deleteRecording(
                    id
                ) ?: false
            },
            faceProfilesJson = { endpoint?.faceProfilesJson() ?: """{"ok":true,"faces":[]}""" },
            enrollFace = { name -> endpoint?.enrollFace(name) ?: """{"ok":false}""" },
            renameFace = { oldName, newName -> endpoint?.renameFace(oldName, newName) ?: """{"ok":false}""" },
            deleteFace = { name -> endpoint?.deleteFace(name) ?: """{"ok":false}""" },
            learnedVisualLabelsJson = { endpoint?.learnedVisualLabelsJson() ?: """{"ok":true,"labels":[]}""" },
            teachRecordingLabel = { id, label -> endpoint?.teachRecordingLabel(id, label) ?: """{"ok":false}""" },
            remoteDvrSettingsJson = {
                endpoint
                    ?.remoteDvrSettingsJson()
                    ?: "{}"
            },
            applyRemoteDvrSettings = {
                    quality,
                    videoMbps,
                    audioKbps,
                    audioHz,
                    audioSyncMs ->
                endpoint
                    ?.applyRemoteDvrSettings(
                        quality,
                        videoMbps,
                        audioKbps,
                        audioHz,
                        audioSyncMs
                    )
                    ?: """{"ok":false}"""
            },
            remoteCameraChoicesJson = {
                endpoint?.remoteCameraChoicesJson()
                    ?: """{"ok":false,"choices":[]}"""
            },
            applyRemoteCameraChoice = { key ->
                endpoint?.applyRemoteCameraChoice(key)
                    ?: """{"ok":false,"reason":"camera_endpoint_unavailable"}"""
            },
            onRestartCameraApp = {
                endpoint
                    ?.onRestartCameraApp()
                    ?: """{"ok":false,"supported":false,"reason":"camera_endpoint_unavailable"}"""
            },
            onZoom = { linear ->
                endpoint?.onZoom(linear)
            },
            onCameraView = { linear, panX, panY ->
                endpoint?.onCameraView(linear, panX, panY)
            },
            onPreviewQuality = { mode ->
                endpoint?.onPreviewQuality(mode)
            },
            onFocusAuto = {
                endpoint?.onFocusAuto()
            },
            onFocusManual = { linear ->
                endpoint?.onFocusManual(linear)
            },
            onFocusSave = {
                endpoint?.onFocusSave()
            },
            onRecordStart = {
                endpoint?.onRecordStart()
            },
            onRecordStop = {
                endpoint?.onRecordStop()
            },
            onTalkPcm16 = { sampleRate, pcm ->
                endpoint?.onTalkPcm16(sampleRate, pcm) ?: false
            }
        )

        return if (candidate.start()) {
            server = candidate
            lastError = ""
            candidate
        } else {
            lastError = candidate.startError() ?: "Port $port bind failed"
            try {
                candidate.stop()
            } catch (_: Exception) {}
            null
        }
    }

    fun server(): LanCameraServer? = server

    fun isRunning(): Boolean = server?.isRunning() == true

    fun startError(): String = lastError

    @Synchronized
    fun stop(clearFrame: Boolean = true) {
        try {
            server?.stop()
        } catch (_: Exception) {}
        server = null
        endpoint = null
        if (clearFrame) {
            latestJpeg.set(null)
        }

        clearLiveAudio()
    }
}
