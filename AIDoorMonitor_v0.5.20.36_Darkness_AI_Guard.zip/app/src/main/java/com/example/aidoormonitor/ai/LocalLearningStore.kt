package com.example.aidoormonitor.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.media.FaceDetector
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.sqrt

/**
 * Lightweight, fully-local learning store for a fixed door camera.
 * No biometric/template data leaves the camera phone.
 *
 * Face matching is intentionally conservative and is meant as a convenience
 * label, not identity proof. Profiles are editable/deletable by the user.
 */
class LocalLearningStore(context: Context) {
    private val prefs = context.getSharedPreferences("local_ai_learning", Context.MODE_PRIVATE)

    data class Match(val name: String, val score: Float)

    fun faceProfilesJson(): String {
        val arr = JSONArray()
        loadMap("faces_json").forEach { (name, _) -> arr.put(name) }
        return JSONObject().put("ok", true).put("faces", arr).toString()
    }

    fun visualLabelsJson(): String {
        val arr = JSONArray()
        loadMap("visual_labels_json").forEach { (name, _) -> arr.put(name) }
        return JSONObject().put("ok", true).put("labels", arr).toString()
    }

    fun enrollFace(name: String, jpeg: ByteArray): Boolean {
        val bitmap = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return false
        return try {
            val d = faceDescriptor(bitmap) ?: return false
            val map = loadMap("faces_json").toMutableMap()
            map[sanitizeName(name)] = d
            saveMap("faces_json", map)
            true
        } finally { try { bitmap.recycle() } catch (_: Throwable) {} }
    }

    fun renameFace(oldName: String, newName: String): Boolean {
        val map = loadMap("faces_json").toMutableMap()
        val v = map.remove(oldName) ?: return false
        map[sanitizeName(newName)] = v
        saveMap("faces_json", map)
        return true
    }

    fun deleteFace(name: String): Boolean {
        val map = loadMap("faces_json").toMutableMap()
        if (map.remove(name) == null) return false
        saveMap("faces_json", map)
        return true
    }

    fun recognizeFace(bitmap: Bitmap): Match? {
        val probe = faceDescriptor(bitmap) ?: return null
        return bestMatch(probe, loadMap("faces_json"), 0.90f)
    }

    fun teachVisualLabel(name: String, jpeg: ByteArray): Boolean {
        val bitmap = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return false
        return try {
            val d = sceneDescriptor(bitmap)
            val map = loadMap("visual_labels_json").toMutableMap()
            map[sanitizeName(name)] = d
            saveMap("visual_labels_json", map)
            true
        } finally { try { bitmap.recycle() } catch (_: Throwable) {} }
    }

    fun matchLearnedVisual(bitmap: Bitmap): Match? =
        bestMatch(sceneDescriptor(bitmap), loadMap("visual_labels_json"), 0.935f)

    private fun sanitizeName(raw: String): String = raw.trim().replace(Regex("[\\r\\n\\t]+"), " ").take(48)

    private fun faceDescriptor(src: Bitmap): FloatArray? {
        if (src.width < 80 || src.height < 80) return null
        val maxW = 640
        val scale = if (src.width > maxW) maxW.toFloat() / src.width else 1f
        val w = (src.width * scale).toInt().coerceAtLeast(80)
        val h0 = (src.height * scale).toInt().coerceAtLeast(80)
        // FaceDetector requires even width and RGB_565.
        val h = h0
        val evenW = if (w % 2 == 0) w else w - 1
        var scaled: Bitmap? = null
        var rgb: Bitmap? = null
        return try {
            scaled = Bitmap.createScaledBitmap(src, evenW, h, true)
            rgb = scaled.copy(Bitmap.Config.RGB_565, false)
            val faces = arrayOfNulls<FaceDetector.Face>(4)
            val count = FaceDetector(rgb.width, rgb.height, faces.size).findFaces(rgb, faces)
            if (count <= 0) return null
            val face = faces.take(count).filterNotNull().maxByOrNull { it.eyesDistance() } ?: return null
            val mid = PointF(); face.getMidPoint(mid)
            val eye = face.eyesDistance().coerceAtLeast(8f)
            val left = (mid.x - eye * 1.35f).toInt().coerceIn(0, rgb.width - 1)
            val right = (mid.x + eye * 1.35f).toInt().coerceIn(left + 1, rgb.width)
            val top = (mid.y - eye * 1.25f).toInt().coerceIn(0, rgb.height - 1)
            val bottom = (mid.y + eye * 1.75f).toInt().coerceIn(top + 1, rgb.height)
            val crop = Bitmap.createBitmap(rgb, left, top, right-left, bottom-top)
            try { blockDescriptor(crop, 10, 12) } finally { crop.recycle() }
        } catch (_: Throwable) { null }
        finally {
            try { rgb?.recycle() } catch (_: Throwable) {}
            try { if (scaled !== rgb) scaled?.recycle() } catch (_: Throwable) {}
        }
    }

    private fun sceneDescriptor(src: Bitmap): FloatArray = blockDescriptor(src, 12, 16)

    private fun blockDescriptor(src: Bitmap, gx: Int, gy: Int): FloatArray {
        val tiny = Bitmap.createScaledBitmap(src, gx, gy, true)
        try {
            val out = FloatArray(gx * gy)
            var mean = 0f
            var i = 0
            for (y in 0 until gy) for (x in 0 until gx) {
                val c = tiny.getPixel(x, y)
                val lum = (((c shr 16) and 255) * 0.299f + ((c shr 8) and 255) * 0.587f + (c and 255) * 0.114f) / 255f
                out[i++] = lum; mean += lum
            }
            mean /= out.size
            var norm = 0f
            for (j in out.indices) { out[j] -= mean; norm += out[j] * out[j] }
            norm = sqrt(norm).coerceAtLeast(1e-6f)
            for (j in out.indices) out[j] /= norm
            return out
        } finally { tiny.recycle() }
    }

    private fun bestMatch(probe: FloatArray, map: Map<String, FloatArray>, threshold: Float): Match? {
        var best: Match? = null
        for ((name, d) in map) {
            if (d.size != probe.size) continue
            var dot = 0f
            for (i in probe.indices) dot += probe[i] * d[i]
            if (dot >= threshold && (best == null || dot > best!!.score)) best = Match(name, dot)
        }
        return best
    }

    private fun loadMap(key: String): Map<String, FloatArray> {
        return try {
            val root = JSONObject(prefs.getString(key, "{}") ?: "{}")
            buildMap {
                val it = root.keys()
                while (it.hasNext()) {
                    val name = it.next(); val a = root.optJSONArray(name) ?: continue
                    put(name, FloatArray(a.length()) { idx -> a.optDouble(idx, 0.0).toFloat() })
                }
            }
        } catch (_: Throwable) { emptyMap() }
    }

    private fun saveMap(key: String, map: Map<String, FloatArray>) {
        val root = JSONObject()
        map.forEach { (name, d) ->
            val a = JSONArray(); d.forEach { a.put(it.toDouble()) }; root.put(name, a)
        }
        prefs.edit().putString(key, root.toString()).apply()
    }
}
