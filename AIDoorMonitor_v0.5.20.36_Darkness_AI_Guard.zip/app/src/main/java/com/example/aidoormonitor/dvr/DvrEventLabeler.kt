package com.example.aidoormonitor.dvr

import android.content.Context
import com.example.aidoormonitor.model.BuiltInRules
import com.example.aidoormonitor.model.RuleType
import com.example.aidoormonitor.store.RuleStore
import java.util.ArrayDeque
import java.util.Locale

data class DvrAiSignal(
    val signal: String,
    val confidence: Float,
    val atMs: Long
)

data class DvrEventName(
    val displayLabel: String,
    val filenameLabel: String,
    val matchedSignals: List<String>,
    val evidenceSummary: String = ""
)

class DvrEventLabeler(
    context: Context
) {
    private val ruleStore = RuleStore(context)
    private val recentSignals = ArrayDeque<DvrAiSignal>()
    private val eventSignals = mutableListOf<DvrAiSignal>()
    private var eventStartedAt = 0L

    private val builtInIds =
        BuiltInRules.defaults()
            .map { it.id }
            .toSet()

    @Synchronized
    fun recordSignal(
        rawSignal: String,
        confidence: Float,
        atMs: Long = System.currentTimeMillis()
    ) {
        val signal =
            normalizeSignal(rawSignal)

        if (signal.isBlank()) return

        // Explicitly disabled COCO class: static potted plants are not useful
        // door events and were creating noisy false labels.
        if (signal in setOf(
            "potted_plant",
            "pottedplant",
            "boat",
            "bench"
        )) return

        val item =
            DvrAiSignal(
                signal = signal,
                confidence = confidence.coerceIn(0f, 1f),
                atMs = atMs
            )

        recentSignals.addLast(item)

        val recentCutoff = atMs - 15_000L
        while (
            recentSignals.isNotEmpty() &&
            recentSignals.first().atMs < recentCutoff
        ) {
            recentSignals.removeFirst()
        }

        if (eventStartedAt > 0L) {
            eventSignals += item
        }
    }

    @Synchronized
    fun beginEvent(
        preRecordSeconds: Int,
        manual: Boolean
    ) {
        val now = System.currentTimeMillis()
        eventStartedAt = now
        eventSignals.clear()

        val cutoff =
            now -
                preRecordSeconds.coerceAtLeast(1) *
                1_000L

        recentSignals
            .filter { it.atMs >= cutoff }
            .forEach {
                eventSignals += it
            }

        if (manual) {
            eventSignals +=
                DvrAiSignal(
                    signal = "manual",
                    confidence = 1f,
                    atMs = now
                )
        }
    }

    @Synchronized
    fun endEventAndChooseName(): DvrEventName {
        val signals =
            eventSignals.toList()

        eventSignals.clear()
        eventStartedAt = 0L

        if (signals.isEmpty()) {
            return DvrEventName(
                displayLabel = "Unidentified movement",
                filenameLabel = "Unidentified_movement",
                matchedSignals = emptyList(),
                evidenceSummary = ""
            )
        }

        data class Evidence(
            val maxConfidence: Float,
            val hitCount: Int,
            val distinctTimes: Int
        )

        val groupedSignals =
            signals.groupBy {
                it.signal
            }

        val evidenceBySignal =
            groupedSignals
                .mapValues { (_, items) ->

                    Evidence(
                        maxConfidence =
                            items.maxOf {
                                it.confidence
                            },
                        hitCount =
                            items.size,
                        distinctTimes =
                            items
                                .map {
                                    // Object naming AI runs around 2 fps.
                                    // Quantizing by 300 ms avoids counting two
                                    // boxes from the same frame as many
                                    // temporal confirmations while still
                                    // allowing two simultaneous dogs to add
                                    // useful evidence through hitCount.
                                    it.atMs /
                                        300L
                                }
                                .distinct()
                                .size
                    )
                }

        val strongestBySignal =
            evidenceBySignal
                .mapValues { (_, evidence) ->
                    evidence.maxConfidence
                }

        val rules =
            try {
                ruleStore.load()
            } catch (_: Throwable) {
                mutableListOf()
            }

        data class Candidate(
            val name: String,
            val signal: String,
            val score: Float,
            val confidence: Float,
            val hitCount: Int,
            val custom: Boolean
        )

        val candidates =
            mutableListOf<Candidate>()

        rules
            .filter { it.enabled }
            .forEach { rule ->
                val matchingSignal =
                    strongestBySignal.keys
                        .firstOrNull { detected ->
                            ruleMatchesSignal(
                                rule.type,
                                rule.signal,
                                detected
                            )
                        }
                        ?: return@forEach

                val evidence =
                    evidenceBySignal[
                        matchingSignal
                    ]
                        ?: return@forEach

                val confidence =
                    evidence.maxConfidence

                // v0.5.20.13: Cat is a common COCO false positive in
                // shrubs, shadows and small distant objects. Require real
                // temporal persistence, unless the detector is exceptionally
                // confident. Sensitivity still controls the score threshold,
                // but cannot turn a one-frame Cat guess into an event name.
                if (
                    normalizeSignal(matchingSignal) == "cat" &&
                    evidence.distinctTimes < 3 &&
                    confidence < 0.85f
                ) {
                    return@forEach
                }

                val isCustom =
                    rule.id !in
                        builtInIds

                val persistentObjectMinimum =
                    minimumDisplayConfidence(
                        matchingSignal
                    )

                val meetsConfiguredConfidence =
                    confidence *
                        100f >=
                        rule.confidence
                            .toFloat()

                // Built-in OBJECT labels may also qualify through persistent
                // evidence. This is important for small dogs beside a much
                // larger person: a 35-55% dog seen repeatedly should not be
                // erased merely because Person reached 80-90%.
                val persistentBuiltInObject =
                    !isCustom &&
                        rule.type ==
                        RuleType.OBJECT &&
                        confidence >=
                        persistentObjectMinimum &&
                        evidence.distinctTimes >=
                            2

                if (
                    !meetsConfiguredConfidence &&
                    !persistentBuiltInObject
                ) {
                    return@forEach
                }

                val persistenceBonus =
                    (
                        (
                            evidence.distinctTimes -
                                1
                            )
                            .coerceAtLeast(
                                0
                            ) *
                            0.045f +
                            (
                                evidence.hitCount -
                                    evidence.distinctTimes
                                )
                                .coerceAtLeast(
                                    0
                                ) *
                                0.020f
                        )
                        .coerceAtMost(
                            0.18f
                        )

                candidates +=
                    Candidate(
                        name =
                            rule.name,
                        signal =
                            matchingSignal,
                        score =
                            confidence +
                                persistenceBonus +
                                if (isCustom) {
                                    0.35f
                                } else {
                                    0f
                                },
                        confidence =
                            confidence,
                        hitCount =
                            evidence.hitCount,
                        custom =
                            isCustom
                    )
            }

        // User-taught visual labels can name an event even without a built-in rule.
        evidenceBySignal.forEach { (signal, evidence) ->
            if (signal.startsWith("learned_") && evidence.maxConfidence >= 0.935f) {
                val learnedName = signal.substringAfter("learned_").replace('_', ' ').trim()
                if (learnedName.isNotBlank()) candidates += Candidate(
                    name = learnedName, signal = signal,
                    score = evidence.maxConfidence + 0.40f, confidence = evidence.maxConfidence,
                    hitCount = evidence.hitCount, custom = true
                )
            }
        }

        val sorted =
            candidates
                .sortedWith(
                    compareByDescending<Candidate> {
                        it.custom
                    }.thenByDescending {
                        it.score
                    }
                )

        val chosenNames =
            if (sorted.isNotEmpty()) {
                // Preserve multiple independently supported categories.
                //
                // Old behavior only kept a second name if its score was within
                // 0.12 of the strongest label. That caused Person to suppress
                // Dog whenever the owner was large/close and the dogs were
                // smaller/farther away.
                sorted
                    .filter {
                        normalizeSignal(it.signal) != "motion" &&
                        it.confidence >=
                            minimumDisplayConfidence(
                                it.signal
                            )
                    }
                    .map {
                        it.name
                    }
                    .distinct()
                    .take(4)
                    .ifEmpty {
                        listOf("Unidentified movement")
                    }

            } else {
                evidenceBySignal
                    .entries
                    .sortedWith(
                        compareByDescending<
                            Map.Entry<
                                String,
                                Evidence
                            >
                        > {
                            it.value
                                .distinctTimes
                        }.thenByDescending {
                            it.value
                                .maxConfidence
                        }
                    )
                    .mapNotNull {
                            entry ->

                        val signal =
                            entry.key

                        val evidence =
                            entry.value

                        val minimum =
                            minimumDisplayConfidence(
                                signal
                            )

                        if (
                            evidence
                                .maxConfidence <
                            minimum
                        ) {
                            null
                        } else if (
                            normalizeSignal(signal) == "cat" &&
                            evidence.distinctTimes < 3 &&
                            evidence.maxConfidence < 0.85f
                        ) {
                            null
                        } else {
                            if (signal.startsWith("known_face_")) null else fallbackDisplayName(
                                signal
                            )
                        }
                    }
                    .distinct()
                    .take(4)
                    .ifEmpty {
                        listOf("Unidentified movement")
                    }
            }

        val display =
            chosenNames.joinToString(" + ")

        val evidenceSummary =
            evidenceBySignal
                .entries
                .sortedByDescending {
                    it.value
                        .maxConfidence
                }
                .take(12)
                .joinToString(
                    "; "
                ) {
                        entry ->

                    val evidence =
                        entry.value

                    buildString {
                        append(
                            entry.key
                        )
                        append(
                            "="
                        )
                        append(
                            String.format(
                                Locale.US,
                                "%.2f",
                                evidence
                                    .maxConfidence
                            )
                        )
                        append(
                            "×"
                        )
                        append(
                            evidence
                                .hitCount
                        )
                        append(
                            "/"
                        )
                        append(
                            evidence
                                .distinctTimes
                        )
                    }
                }

        return DvrEventName(
            displayLabel =
                display,
            filenameLabel =
                sanitizeFilenamePart(
                    display
                )
                    .ifBlank {
                        "Unidentified_movement"
                    },
            matchedSignals =
                strongestBySignal.keys
                    .sorted(),
            evidenceSummary =
                evidenceSummary
        )
    }

    @Synchronized
    fun hasRecentSignal(
        rawSignal: String,
        withinMs: Long,
        now: Long = System.currentTimeMillis()
    ): Boolean {
        val wanted = normalizeSignal(rawSignal)
        val cutoff = now - withinMs.coerceAtLeast(0L)
        return recentSignals.any {
            it.atMs >= cutoff &&
                normalizeSignal(it.signal) == wanted
        }
    }

    /**
     * Drops recent visual/object/trajectory evidence produced while the
     * physical camera phone was moving. Audio and manual evidence are kept.
     */
    @Synchronized
    fun discardVisualSignalsSince(sinceMs: Long) {
        fun shouldDiscard(item: DvrAiSignal): Boolean =
            item.atMs >= sinceMs &&
                !isAudioOrManualSignal(item.signal)

        val keptRecent =
            recentSignals.filterNot { shouldDiscard(it) }
        recentSignals.clear()
        keptRecent.forEach { recentSignals.addLast(it) }

        eventSignals.removeAll { shouldDiscard(it) }
    }

    @Synchronized
    fun currentBestLabel(): String {
        val now = System.currentTimeMillis()
        val cutoff = now - 4_500L

        data class LiveEvidence(
            val maxConfidence: Float,
            val hitCount: Int,
            val distinctTimes: Int
        )

        // The monitor overlay describes what is happening NOW. Do not keep a
        // one-frame Cat/Person/etc. label for the full 30-60 second recording.
        val evidence =
            eventSignals
                .filter { it.atMs >= cutoff }
                .groupBy { it.signal }
                .mapValues { (_, items) ->
                    LiveEvidence(
                        maxConfidence = items.maxOf { it.confidence },
                        hitCount = items.size,
                        distinctTimes =
                            items
                                .map { it.atMs / 300L }
                                .distinct()
                                .size
                    )
                }

        return evidence
            .entries
            .filter { entry ->
                val normalized = normalizeSignal(entry.key)
                val e = entry.value
                val minimum = minimumDisplayConfidence(normalized)

                if (e.maxConfidence < minimum) {
                    false
                } else if (isAudioOrManualSignal(normalized)) {
                    true
                } else if (normalized == "motion") {
                    false
                } else if (
                    normalized == "cat" &&
                    e.distinctTimes < 3 &&
                    e.maxConfidence < 0.85f
                ) {
                    false
                } else {
                    // Low/medium visual detections need temporal confirmation.
                    // A very strong object can still appear immediately.
                    e.distinctTimes >= 2 ||
                        e.maxConfidence >= 0.72f
                }
            }
            .sortedWith(
                compareByDescending<
                    Map.Entry<String, LiveEvidence>
                > {
                    it.value.distinctTimes
                }.thenByDescending {
                    it.value.maxConfidence
                }
            )
            .mapNotNull {
                fallbackDisplayName(it.key)
            }
            .distinct()
            .take(4)
            .joinToString(" + ")
            .ifBlank { "Analyzing movement" }
    }

    private fun isAudioOrManualSignal(signal: String): Boolean =
        when (normalizeSignal(signal)) {
            "manual",
            "dog_barking",
            "bark",
            "bow_wow",
            "dog_growling",
            "growl",
            "growling",
            "dog_whining",
            "whimper",
            "whimpering",
            "whine",
            "whining",
            "dog_yelping",
            "yelp",
            "yelping",
            "yip",
            "yipping",
            "dog_howling",
            "howl",
            "howling",
            "shouting",
            "impact" -> true
            else -> false
        }

    private fun ruleMatchesSignal(
        type: RuleType,
        ruleSignal: String,
        detectedSignal: String
    ): Boolean {
        val normalizedRule =
            ruleSignal
                .lowercase(Locale.US)

        val detected =
            normalizeSignal(detectedSignal)

        if (detected.isBlank()) return false

        // Exact/word match lets custom rules use signals such as dog, cat,
        // person, bird, car, package, motion or fast_toward_door.
        val tokens =
            normalizedRule
                .replace("yamnet:", "")
                .split(
                    Regex("[^a-z0-9_]+")
                )
                .filter {
                    it.isNotBlank()
                }

        return when (type) {
            RuleType.OBJECT ->
                detected in tokens ||
                    normalizedRule.trim() == detected

            RuleType.TRAJECTORY ->
                detected in tokens ||
                    normalizedRule.trim() == detected

            RuleType.TEMPORAL_VIDEO,
            RuleType.COMPOSITE,
            RuleType.AUDIO ->
                detected in tokens
        }
    }

    private fun minimumDisplayConfidence(
        signal: String
    ): Float =
        when (normalizeSignal(signal)) {
            // Small-pet tiled rescue emits first-frame candidates below this
            // floor and promotes them only after temporal confirmation.
            "dog" -> 0.22f
            "cat" -> 0.38f
            "bird" -> 0.27f
            "loose_dog" -> 0.24f
            "horse", "sheep", "cow" -> 0.30f
            "person" -> 0.24f
            "car" -> 0.32f
            "bicycle" -> 0.30f
            "motorcycle" -> 0.30f

            // Sound-AI events use the same practical floors as their
            // on-device YamNet trigger. This prevents a real whimper/yip/howl
            // trigger from being renamed to generic Motion at save time.
            "dog_whining",
            "whimper",
            "whimpering",
            "whine",
            "whining" -> 0.20f

            "dog_yelping",
            "yelp",
            "yelping",
            "yip",
            "yipping" -> 0.22f

            "dog_howling",
            "howl",
            "howling" -> 0.25f

            "dog_barking",
            "bark",
            "bow_wow" -> 0.25f

            "dog_growling",
            "growl",
            "growling" -> 0.25f

            "shouting" -> 0.33f
            "impact" -> 0.36f
            else -> 0.42f
        }

    private fun normalizeSignal(value: String): String =
        value
            .trim()
            .lowercase(Locale.US)
            .replace(' ', '_')
            .replace('-', '_')
            .replace(
                Regex("[^a-z0-9_]+"),
                ""
            )

    private fun fallbackDisplayName(
        signal: String
    ): String? =
        when (normalizeSignal(signal)) {
            "elephant", "bear", "zebra", "giraffe", "bench" -> null
            "dog" -> "Dog"
            "loose_dog" -> "Loose dog candidate"
            "horse" -> "Horse"
            "sheep" -> "Sheep"
            "cow" -> "Cow"
            "dog_barking",
            "bark" -> "Dog barking"
            "dog_growling",
            "growl",
            "growling" -> "Dog growling"
            "dog_whining",
            "whimper",
            "whimpering",
            "whine",
            "whining" -> "Dog whining / whimpering"
            "dog_yelping",
            "yelp",
            "yelping",
            "yip",
            "yipping" -> "Dog yelping / yipping"
            "dog_howling",
            "howl",
            "howling" -> "Dog howling"
            "cat" -> "Cat"
            "bird" -> "Bird"
            "person" -> "Person"
            "car" -> "Car"
            "bicycle" -> "Bicycle"
            "stroller",
            "pram",
            "pushchair",
            "baby_carriage" -> "Stroller"
            "motorcycle" -> "Motorcycle"
            "truck" -> "Truck"
            "package" -> "Package"
            "backpack" -> "Backpack"
            "handbag" -> "Handbag"
            "suitcase" -> "Suitcase"
            "fast_toward_door" ->
                "Something thrown at the door"
            "motion" -> null
            "manual" -> "Manual"
            else ->
                signal
                    .replace('_', ' ')
                    .trim()
                    .takeIf { it.isNotBlank() }
                    ?.replaceFirstChar {
                        it.uppercase()
                    }
        }

    companion object {
        fun sanitizeFilenamePart(
            input: String
        ): String =
            input
                .trim()
                .replace(
                    Regex("[\\\\/:*?\"<>|]+"),
                    "_"
                )
                .replace(
                    Regex("\\s+"),
                    "_"
                )
                .replace(
                    Regex("_+"),
                    "_"
                )
                .trim('_')
                .take(64)
    }
}
