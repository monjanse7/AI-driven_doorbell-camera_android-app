package com.example.aidoormonitor

import android.Manifest
import android.media.RingtoneManager
import android.app.PendingIntent
import android.app.NotificationManager
import android.app.NotificationChannel
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.CheckBox
import android.widget.TextView
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.aidoormonitor.databinding.ActivityMonitorBinding
import com.example.aidoormonitor.net.LocalNetwork
import com.example.aidoormonitor.net.PairInfo
import com.example.aidoormonitor.net.Pairing
import com.example.aidoormonitor.ui.LivePcmAudioPlayer
import com.example.aidoormonitor.ui.MonitorTalkbackSender
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

class MonitorActivity : AppCompatActivity() {
    private lateinit var b: ActivityMonitorBinding

    private val networkExecutor = Executors.newSingleThreadExecutor()

    @Volatile
    private var activityDestroyed = false

    /**
     * Submit monitor network work only while this Activity still owns its
     * executor. Delayed UI callbacks can otherwise fire after onDestroy()
     * and throw RejectedExecutionException against the terminated pool.
     */
    private fun safeNetworkExecute(block: () -> Unit) {
        if (activityDestroyed || networkExecutor.isShutdown || networkExecutor.isTerminated) {
            return
        }

        try {
            networkExecutor.execute {
                if (!activityDestroyed) {
                    block()
                }
            }
        } catch (_: RejectedExecutionException) {
            // Activity/executor was torn down between the guard and submit.
        }
    }
    private val recordingTransferExecutor =
        Executors.newSingleThreadExecutor()

    private val recordingThumbnailExecutor =
        Executors.newFixedThreadPool(2)

    private data class RemoteRecordingItem(
        val id: String,
        val name: String,
        val sizeBytes: Long,
        val durationMs: Long,
        val dateAddedMs: Long,
        val eventFolder: String
    )

    private var remoteRecordings:
        List<RemoteRecordingItem> =
        emptyList()

    private val selectedRecordingIds =
        linkedSetOf<String>()

    private val openRecordingFolders =
        linkedSetOf<String>()

    private val preferredFolderOrder =
        listOf(
            "Dog",
            "Cat",
            "Car",
            "Person",
            "Bicycle",
            "Motorcycle",
            "Truck",
            "Bird",
            "Stroller",
            "Package",
            "Sound",
            "Motion",
            "Manual"
        )

    private var pendingRecordingDownloadId:
        String? =
        null

    private var currentPair: PairInfo? = null
    private var remoteCameraChoiceKeys: List<String> = emptyList()
    /** Original QR definition containing LAN + optional remote VPN host. */
    private var configuredPair: PairInfo? = null
    private var connected = false
    private var connectionAttemptInProgress = false
    private var monitorTransportPausedForPlayer = false

    private var liveViewerFullscreen = false
    private var remoteManualRecordingRequested = false
    private val fullscreenSavedChildVisibility =
        linkedMapOf<View, Int>()
    private var normalLiveViewerLayoutParams:
        ViewGroup.LayoutParams? = null
    private var normalContentPadding =
        intArrayOf(0, 0, 0, 0)
    private var normalScrollPadding =
        intArrayOf(0, 0, 0, 0)

    private val liveAudioPlayer =
        LivePcmAudioPlayer()

    private val talkbackSender by lazy { MonitorTalkbackSender(this) }
    private var pendingDoorbellAutoLive = false
    private var pendingDoorbellAutoTalk = false

    private var remoteManualFocusSupported = false

    private var remoteMaxZoomRatio = 1f
    private var remoteZoomLinear = 0f
    private var remotePanX = 0f
    private var remotePanY = 0f
    private var remotePanMode = "unknown"

    private val cameraViewHandler =
        Handler(Looper.getMainLooper())

    private var cameraViewSendScheduled = false
    private var pendingViewLinear = 0f
    private var pendingViewPanX = 0f
    private var pendingViewPanY = 0f

    private var ignorePreviewQualityCallback = false

    private val connectionHealthHandler =
        Handler(Looper.getMainLooper())

    private var healthPollRunning = false
    private var lastVisualStreamAvailable: Boolean? = null
    private var lastCompatibilityStage = ""
    private var lastDoorbellSequence = -1L
    private var lastDoorbellPressedAtMs = 0L
    private var lastDoorbellSource = ""

    private var lastHealthStreamKickAt =
        0L

    private val recordingPlayerLauncher =
        registerForActivityResult(
            ActivityResultContracts
                .StartActivityForResult()
        ) {
            monitorTransportPausedForPlayer =
                false

            resumeMonitorTransportAfterPlayer()
        }

    private val storagePermission =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                val pendingId =
                    pendingRecordingDownloadId

                pendingRecordingDownloadId =
                    null

                if (pendingId != null) {
                    remoteRecordings
                        .firstOrNull {
                            it.id == pendingId
                        }
                        ?.let {
                            downloadRemoteRecording(
                                it
                            )
                        }
                } else {
                    saveSnapshot()
                }
            } else {
                pendingRecordingDownloadId =
                    null
                toast(
                    "Storage permission was not granted."
                )
            }
        }

    private val monitorMicPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startTalkback()
            } else {
                toast("Microphone permission is required for talkback.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent?.getBooleanExtra("doorbell_wake_screen", false) == true ||
            intent?.getBooleanExtra("doorbell_auto_live", false) == true) {
            if (Build.VERSION.SDK_INT >= 27) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                @Suppress("DEPRECATION")
                window.addFlags(
                    android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                )
            }
        }
        b = ActivityMonitorBinding.inflate(layoutInflater)
        setContentView(b.root)
        ensureDoorbellNotificationChannel()
        requestNotificationPermissionIfNeeded()
        b.root.applySystemBarInsets()

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (liveViewerFullscreen) {
                        exitLiveViewerFullscreen()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        )

        val prefs = getSharedPreferences("monitor_pair", MODE_PRIVATE)
        b.pairingCode.setText(prefs.getString("last_pair", "").orEmpty())
        try { MonitorDoorbellListenerService.ensureRunning(this) } catch (_: Throwable) {}
        handleDoorbellLaunchIntent(intent)
        b.remoteVpnHost.setText(prefs.getString("manual_remote_host", "").orEmpty())

        b.liveAudioEnabled.isChecked =
            prefs.getBoolean(
                "live_audio_enabled",
                false
            )

        b.talkButton.setOnClickListener {
            if (talkbackSender.isRunning()) {
                stopTalkback()
            } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startTalkback()
            } else {
                monitorMicPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }

        b.liveAudioEnabled
            .setOnCheckedChangeListener {
                    _,
                    enabled ->

                prefs.edit()
                    .putBoolean(
                        "live_audio_enabled",
                        enabled
                    )
                    .apply()

                if (
                    enabled &&
                    connected &&
                    !monitorTransportPausedForPlayer
                ) {
                    startLiveAudioIfEnabled()
                } else {
                    liveAudioPlayer.stop()

                    if (!enabled) {
                        b.liveAudioStatus.text =
                            "Live audio: OFF"
                    }
                }

                updateFullscreenControls()
            }

        b.fullscreenToggle.setOnClickListener {
            enterLiveViewerFullscreen()
        }

        b.exitFullscreen.setOnClickListener {
            exitLiveViewerFullscreen()
        }

        b.fullscreenAudio.setOnClickListener {
            b.liveAudioEnabled.isChecked =
                !b.liveAudioEnabled.isChecked
            updateFullscreenControls()
        }

        b.fullscreenRecord.setOnClickListener {
            if (!requireConnection()) {
                return@setOnClickListener
            }

            if (remoteManualRecordingRequested) {
                requestRemoteRecordingStop()
            } else {
                requestRemoteRecordingStart()
            }
        }

        updateFullscreenControls()

        b.liveGesture.setOnCameraViewChanged {
                linear,
                panX,
                panY ->

            remoteZoomLinear = linear
            remotePanX = panX
            remotePanY = panY

            if (!b.remoteZoom.isPressed) {
                b.remoteZoom.progress =
                    (linear * 1000f).toInt().coerceIn(0, 1000)
            }

            updateCameraViewLabel()
            scheduleCameraViewCommand(linear, panX, panY)
        }

        b.resetViewerPanZoom.setOnClickListener {
            remoteZoomLinear = 0f
            remotePanX = 0f
            remotePanY = 0f
            b.liveGesture.resetCameraView(notify = true)
        }

        setupPreviewQualityUi()
        setupRemoteDvrSettingsUi()
        setupRemoteCameraChoiceUi()

        b.openRules.setOnClickListener {
            startActivity(Intent(this, RuleEditorActivity::class.java))
        }

        b.scanQr.setOnClickListener { scanCameraQr() }

        b.saveRemoteVpnHost.setOnClickListener {
            saveAndTestManualRemoteHost()
        }

        b.connectButton.setOnClickListener {
            if (connected) disconnect() else connectFromField()
        }

        b.restartCameraApp.setOnClickListener {
            restartRemoteCameraApp()
        }

        b.remoteZoom.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    val linear = progress / 1000f
                    val ratio =
                        1f + linear * (remoteMaxZoomRatio - 1f)

                    b.zoomValue.text =
                        String.format(
                            Locale.US,
                            "Camera zoom: %.1f×",
                            ratio
                        )

                    if (fromUser) {
                        remoteZoomLinear = linear

                        if (linear <= 0.001f) {
                            remotePanX = 0f
                            remotePanY = 0f
                        }

                        b.liveGesture.setCameraState(
                            remoteZoomLinear,
                            remotePanX,
                            remotePanY,
                            notify = false
                        )

                        updateCameraViewLabel()

                        if (connected) {
                            scheduleCameraViewCommand(
                                remoteZoomLinear,
                                remotePanX,
                                remotePanY
                            )
                        }
                    }
                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) = Unit

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) = Unit
            }
        )

        b.remoteFocus.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar?,
                progress: Int,
                fromUser: Boolean
            ) {
                val pct = progress / 10
                b.remoteFocusValue.text =
                    if (progress == 0) "Manual focus: Infinity"
                    else "Manual focus: $pct% toward Near"

                if (fromUser && connected && remoteManualFocusSupported) {
                    sendCommand(
                        "/focus?mode=manual&linear=${progress / 1000f}",
                        silent = true
                    )
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        b.remoteAutoFocus.setOnClickListener {
            if (requireConnection()) {
                sendCommand("/focus?mode=auto", successMessage = "Auto Focus enabled.")
            }
        }

        b.remoteFocusFar.setOnClickListener { stepRemoteFocus(-25) }
        b.remoteFocusNear.setOnClickListener { stepRemoteFocus(25) }

        b.remoteSaveFocus.setOnClickListener {
            if (requireConnection()) {
                sendCommand("/focus/save", successMessage = "Camera focus default saved.")
            }
        }

        b.startRemoteRecording.setOnClickListener {
            if (requireConnection()) {
                requestRemoteRecordingStart()
            }
        }

        b.stopRemoteRecording.setOnClickListener {
            if (requireConnection()) {
                requestRemoteRecordingStop()
            }
        }

        b.saveSnapshot.setOnClickListener {
            if (!requireConnection()) return@setOnClickListener

            if (Build.VERSION.SDK_INT <= 28 &&
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            } else {
                saveSnapshot()
            }
        }

        b.refreshEvents.setOnClickListener {
            if (requireConnection()) refreshRemoteEvents()
        }

        b.recordingSort.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "Newest first",
                    "Oldest first",
                    "AI / filename A → Z",
                    "AI / filename Z → A",
                    "Longest first",
                    "Largest first"
                )
            )

        b.recordingSort.setSelection(
            getSharedPreferences(
                "monitor_pair",
                MODE_PRIVATE
            )
                .getInt(
                    "recording_sort_mode",
                    0
                )
                .coerceIn(
                    0,
                    5
                )
        )

        b.recordingSort.onItemSelectedListener =
            object :
                android.widget.AdapterView
                    .OnItemSelectedListener {

                override fun onItemSelected(
                    parent:
                        android.widget.AdapterView<*>?,
                    view:
                        android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    getSharedPreferences(
                        "monitor_pair",
                        MODE_PRIVATE
                    )
                        .edit()
                        .putInt(
                            "recording_sort_mode",
                            position.coerceIn(
                                0,
                                5
                            )
                        )
                        .apply()

                    if (
                        remoteRecordings
                            .isNotEmpty()
                    ) {
                        remoteRecordings =
                            sortRemoteRecordings(
                                remoteRecordings
                            )

                        renderRecordingThumbnailList()

                        if (
                            remoteRecordings
                                .isNotEmpty()
                        ) {
                            updateSelectedRecordingInfo(
                                0
                            )
                        }
                    }
                }

                override fun onNothingSelected(
                    parent:
                        android.widget.AdapterView<*>?
                ) = Unit
            }

        b.refreshRecordings.setOnClickListener {
            if (requireConnection()) {
                refreshRemoteRecordings()
                refreshFaceProfiles()
            }
        }

        b.enrollCurrentFace.setOnClickListener {
            if (!requireConnection()) return@setOnClickListener
            val name = b.faceName.text?.toString()?.trim().orEmpty()
            if (name.isBlank()) { toast("Enter a face name first."); return@setOnClickListener }
            val enc = java.net.URLEncoder.encode(name, "UTF-8")
            sendCommand("/faces/enroll?name=$enc", "Face profile saved.", onSuccess = { refreshFaceProfiles() })
        }

        b.renameFace.setOnClickListener {
            if (!requireConnection()) return@setOnClickListener
            val oldName = b.faceOldName.text?.toString()?.trim().orEmpty()
            val newName = b.faceNewName.text?.toString()?.trim().orEmpty()
            if (oldName.isBlank() || newName.isBlank()) { toast("Enter both old and new face names."); return@setOnClickListener }
            sendCommand("/faces/rename?old=${java.net.URLEncoder.encode(oldName,"UTF-8")}&new=${java.net.URLEncoder.encode(newName,"UTF-8")}", "Face renamed.", onSuccess = { refreshFaceProfiles() })
        }

        b.deleteFace.setOnClickListener {
            if (!requireConnection()) return@setOnClickListener
            val name = b.faceOldName.text?.toString()?.trim().orEmpty()
            if (name.isBlank()) { toast("Enter the face name to delete."); return@setOnClickListener }
            sendCommand("/faces/delete?name=${java.net.URLEncoder.encode(name,"UTF-8")}", "Face deleted.", onSuccess = { refreshFaceProfiles() })
        }

        b.teachSelectedEvent.setOnClickListener {
            if (!requireConnection()) return@setOnClickListener
            val item = selectedRemoteRecording() ?: run { toast("Select a recording first."); return@setOnClickListener }
            val label = b.learnedEventName.text?.toString()?.trim().orEmpty()
            if (label.isBlank()) { toast("Enter what the unidentified motion was."); return@setOnClickListener }
            val path = "/learning/teach?id=${java.net.URLEncoder.encode(item.id,"UTF-8")}&label=${java.net.URLEncoder.encode(label,"UTF-8")}"
            sendCommand(path, "AI learned '$label' from the selected event.")
        }

        b.selectAllRecordings
            .setOnClickListener {
                selectedRecordingIds.clear()
                selectedRecordingIds.addAll(
                    remoteRecordings.map {
                        it.id
                    }
                )
                renderRecordingThumbnailList()
                updateRecordingSelectionUi()
            }

        b.clearRecordingSelection
            .setOnClickListener {
                selectedRecordingIds.clear()
                renderRecordingThumbnailList()
                updateRecordingSelectionUi()
            }

        b.downloadCheckedRecordings
            .setOnClickListener {
                if (requireConnection()) {
                    downloadCheckedRecordings()
                }
            }

        b.deleteCheckedRecordings
            .setOnClickListener {
                if (requireConnection()) {
                    confirmDeleteCheckedRecordings()
                }
            }

        b.recordingsSpinner.onItemSelectedListener =
            object :
                android.widget.AdapterView
                    .OnItemSelectedListener {

                override fun onItemSelected(
                    parent:
                        android.widget.AdapterView<*>?,
                    view:
                        android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    updateSelectedRecordingInfo(
                        position
                    )
                }

                override fun onNothingSelected(
                    parent:
                        android.widget.AdapterView<*>?
                ) = Unit
            }

        updateRecordingControls()
        updateRemoteFocusEnabled(false)

        if (
            prefs.getBoolean(
                "keep_monitor_connected",
                false
            ) &&
            b.pairingCode
                .text
                .toString()
                .isNotBlank()
        ) {
            b.root.post {
                if (
                    !connected &&
                    !connectionAttemptInProgress
                ) {
                    connectFromField()
                }
            }
        }
    }

    private fun enterLiveViewerFullscreen() {
        if (liveViewerFullscreen) {
            return
        }

        liveViewerFullscreen = true

        val content = b.monitorContent
        fullscreenSavedChildVisibility.clear()

        for (index in 0 until content.childCount) {
            val child = content.getChildAt(index)
            if (child !== b.liveViewerFrame) {
                fullscreenSavedChildVisibility[child] = child.visibility
                child.visibility = View.GONE
            }
        }

        normalLiveViewerLayoutParams = b.liveViewerFrame.layoutParams
        normalContentPadding = intArrayOf(
            content.paddingLeft,
            content.paddingTop,
            content.paddingRight,
            content.paddingBottom
        )
        normalScrollPadding = intArrayOf(
            b.monitorScrollView.paddingLeft,
            b.monitorScrollView.paddingTop,
            b.monitorScrollView.paddingRight,
            b.monitorScrollView.paddingBottom
        )

        content.setPadding(0, 0, 0, 0)
        b.monitorScrollView.setPadding(0, 0, 0, 0)
        b.monitorScrollView.scrollTo(0, 0)

        b.liveViewerFrame.layoutParams =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                b.monitorRoot.height.coerceAtLeast(1)
            ).apply {
                setMargins(0, 0, 0, 0)
            }

        // Fullscreen gestures are local viewer crop gestures. They magnify
        // the received MJPEG bitmap and never alter the camera phone's zoom.
        b.liveView.resetViewerTransform()
        b.liveGesture.setGestureModeLocalViewerCrop { scale ->
            b.fullscreenZoomStatus.text =
                String.format(
                    Locale.US,
                    "VIEW CROP %.1f× • PINCH ZOOM • DRAG PAN",
                    scale
                )
        }

        b.fullscreenToggle.visibility = View.GONE
        b.fullscreenZoomStatus.visibility = View.VISIBLE
        b.fullscreenControls.visibility = View.VISIBLE

        val controller = WindowCompat.getInsetsController(
            window,
            b.monitorRoot
        )
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())

        updateFullscreenControls()

        // Resize once more after the system bars have disappeared. The same
        // MjpegView stays attached, so entering fullscreen never creates a
        // second stream or intentionally disconnects the active stream.
        b.monitorRoot.post {
            if (!liveViewerFullscreen) {
                return@post
            }

            val lp = b.liveViewerFrame.layoutParams
                as? LinearLayout.LayoutParams
                ?: return@post

            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            lp.height = b.monitorRoot.height.coerceAtLeast(1)
            lp.setMargins(0, 0, 0, 0)
            b.liveViewerFrame.layoutParams = lp
        }
    }

    private fun exitLiveViewerFullscreen() {
        if (!liveViewerFullscreen) {
            return
        }

        liveViewerFullscreen = false

        // Do not leave a local crop applied in the normal viewer. Restore the
        // original remote-camera gesture mode without changing remote zoom.
        b.liveGesture.resetLocalViewerCrop()
        b.liveGesture.setGestureModeRemoteCamera()

        b.fullscreenControls.visibility = View.GONE
        b.fullscreenZoomStatus.visibility = View.GONE
        b.fullscreenToggle.visibility = View.VISIBLE

        normalLiveViewerLayoutParams?.let {
            b.liveViewerFrame.layoutParams = it
        }

        b.monitorContent.setPadding(
            normalContentPadding[0],
            normalContentPadding[1],
            normalContentPadding[2],
            normalContentPadding[3]
        )
        b.monitorScrollView.setPadding(
            normalScrollPadding[0],
            normalScrollPadding[1],
            normalScrollPadding[2],
            normalScrollPadding[3]
        )

        fullscreenSavedChildVisibility.forEach { (view, visibility) ->
            view.visibility = visibility
        }
        fullscreenSavedChildVisibility.clear()

        WindowCompat.getInsetsController(
            window,
            b.monitorRoot
        ).show(WindowInsetsCompat.Type.systemBars())

        // Returning from fullscreen only restores layout. The live video and
        // audio transports remain the same active monitor session.
        b.monitorScrollView.post {
            b.monitorScrollView.scrollTo(0, 0)
        }
    }

    private fun updateFullscreenControls() {
        b.fullscreenAudio.text =
            if (b.liveAudioEnabled.isChecked) {
                "AUDIO: ON"
            } else {
                "AUDIO: OFF"
            }

        b.fullscreenRecord.text =
            if (remoteManualRecordingRequested) {
                "STOP RECORDING"
            } else {
                "RECORD"
            }

        b.fullscreenRecord.isEnabled = connected
    }

    private fun requestRemoteRecordingStart() {
        val previous = remoteManualRecordingRequested
        remoteManualRecordingRequested = true
        updateFullscreenControls()
        sendCommand(
            "/record/start",
            successMessage = "Recording command sent.",
            onFailure = {
                remoteManualRecordingRequested = previous
                updateFullscreenControls()
            }
        )
    }

    private fun requestRemoteRecordingStop() {
        val previous = remoteManualRecordingRequested
        remoteManualRecordingRequested = false
        updateFullscreenControls()
        sendCommand(
            "/record/stop",
            successMessage = "Stop/save command sent.",
            onFailure = {
                remoteManualRecordingRequested = previous
                updateFullscreenControls()
            }
        )
    }

    private fun startLiveAudioIfEnabled() {
        val pair =
            currentPair
                ?: return

        if (
            !connected ||
            monitorTransportPausedForPlayer ||
            !b.liveAudioEnabled
                .isChecked
        ) {
            return
        }

        liveAudioPlayer.start(
            pair
        ) {
                state ->

            runOnUiThread {
                if (
                    connected &&
                    !monitorTransportPausedForPlayer &&
                    b.liveAudioEnabled
                        .isChecked
                ) {
                    b.liveAudioStatus.text =
                        state
                }
            }
        }
    }

    private fun pauseMonitorTransportForPlayer() {
        if (!connected) {
            return
        }

        monitorTransportPausedForPlayer =
            true

        stopConnectionHealthPolling()

        b.liveView.stop()

        liveAudioPlayer.stop()

        b.connectionState.text =
            "Connected • recording player open • live view paused"
    }

    private fun resumeMonitorTransportAfterPlayer() {
        if (
            !connected ||
            monitorTransportPausedForPlayer
        ) {
            return
        }

        val pair =
            currentPair
                ?: Pairing.parse(
                    getSharedPreferences(
                        "monitor_pair",
                        MODE_PRIVATE
                    )
                        .getString(
                            "last_pair",
                            ""
                        )
                        .orEmpty()
                )
                    ?.also {
                        currentPair =
                            it
                    }
                ?: return

        if (
            lastVisualStreamAvailable !=
            false
        ) {
            b.liveView.start(
                pair
            ) {
                    state ->
                b.connectionState.text =
                    state
            }
        }

        startConnectionHealthPolling()

        startLiveAudioIfEnabled()
    }

    private fun stepRemoteFocus(delta: Int) {
        if (!connected || !remoteManualFocusSupported) return
        val next = (b.remoteFocus.progress + delta).coerceIn(0, 1000)
        b.remoteFocus.progress = next
        sendCommand(
            "/focus?mode=manual&linear=${next / 1000f}",
            silent = true
        )
    }

    private fun setupRemoteCameraChoiceUi() {
        b.remoteCameraChoice.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("Load camera choices first")
        )
        b.loadRemoteCameraChoices.setOnClickListener {
            if (requireConnection()) loadRemoteCameraChoices()
        }
        b.applyRemoteCameraChoice.setOnClickListener {
            if (requireConnection()) applyRemoteCameraChoice()
        }
    }

    private fun loadRemoteCameraChoices() {
        val pair = currentPair ?: return
        b.remoteCameraChoiceStatus.text = "Loading camera/lens list…"
        safeNetworkExecute {
            try {
                val raw = getBytes(pair.endpoint("/camera-choice"))
                    .toString(Charsets.UTF_8)
                val json = JSONObject(raw)
                val array = json.optJSONArray("choices") ?: org.json.JSONArray()
                val keys = mutableListOf<String>()
                val labels = mutableListOf<String>()
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val key = item.optString("key")
                    val label = item.optString("label", key)
                    if (key.isNotBlank()) {
                        keys += key
                        labels += label
                    }
                }
                val selected = json.optString("selectedKey")
                runOnUiThread {
                    remoteCameraChoiceKeys = keys
                    b.remoteCameraChoice.adapter = ArrayAdapter(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        if (labels.isEmpty()) listOf("No selectable cameras reported") else labels
                    )
                    val idx = keys.indexOf(selected)
                    if (idx >= 0) b.remoteCameraChoice.setSelection(idx)
                    b.remoteCameraChoiceStatus.text =
                        "Available: ${keys.size} • includes front and OEM-exposed wide/ultra-wide lenses"
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    b.remoteCameraChoiceStatus.text =
                        "Could not load camera/lens list: ${t.message ?: t.javaClass.simpleName}"
                }
            }
        }
    }

    private fun applyRemoteCameraChoice() {
        val pair = currentPair ?: return
        val key = remoteCameraChoiceKeys.getOrNull(b.remoteCameraChoice.selectedItemPosition)
        if (key.isNullOrBlank()) {
            b.remoteCameraChoiceStatus.text = "Load the camera/lens list first."
            return
        }
        b.remoteCameraChoiceStatus.text = "Switching camera/lens and restarting DVR…"
        safeNetworkExecute {
            var conn: HttpURLConnection? = null
            try {
                val encoded = java.net.URLEncoder.encode(key, "UTF-8")
                conn = URL(pair.endpoint("/camera-choice?key=$encoded")).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 8_000
                conn.readTimeout = 8_000
                conn.useCaches = false
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                runOnUiThread {
                    b.remoteCameraChoiceStatus.text = if (json.optBoolean("ok", false))
                        "Camera/lens selected. DVR is restarting; live view should return shortly."
                    else
                        "Camera/lens switch failed: ${json.optString("reason", "unknown")}"
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    b.remoteCameraChoiceStatus.text =
                        "Camera/lens switch failed: ${t.message ?: t.javaClass.simpleName}"
                }
            } finally {
                try { conn?.disconnect() } catch (_: Throwable) {}
            }
        }
    }

    private fun setupRemoteDvrSettingsUi() {
        b.remoteDvrQuality.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "8K UHD / 7680×4320",
                    "4K UHD / 3840×2160",
                    "1080p / 1920×1080"
                )
            )

        b.remoteVideoBitrate.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "Auto",
                    "20 Mbps",
                    "32 Mbps",
                    "50 Mbps",
                    "75 Mbps",
                    "100 Mbps",
                    "150 Mbps",
                    "200 Mbps"
                )
            )

        b.remoteAudioSampleRate.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "44.1 kHz",
                    "48 kHz"
                )
            )

        b.remoteAudioBitrate.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "64 kbps",
                    "96 kbps",
                    "128 kbps",
                    "192 kbps",
                    "256 kbps",
                    "320 kbps"
                )
            )

        b.remoteAudioSync.adapter =
            ArrayAdapter(
                this,
                android.R.layout
                    .simple_spinner_dropdown_item,
                listOf(
                    "Automatic / 0 ms",
                    "Audio 250 ms later",
                    "Audio 500 ms later",
                    "Audio 1000 ms later",
                    "Audio 2000 ms later",
                    "Audio 3000 ms later",
                    "Audio 5000 ms later",
                    "Audio 250 ms earlier",
                    "Audio 500 ms earlier",
                    "Audio 1000 ms earlier"
                )
            )

        b.loadRemoteDvrSettings
            .setOnClickListener {
                if (requireConnection()) {
                    loadRemoteDvrSettings()
                }
            }

        b.applyRemoteDvrSettings
            .setOnClickListener {
                if (requireConnection()) {
                    applyRemoteDvrSettings()
                }
            }
    }

    private fun selectedRemoteVideoBitrateMbps():
        Int =
        intArrayOf(
            0,
            20,
            32,
            50,
            75,
            100,
            150,
            200
        )[
            b.remoteVideoBitrate
                .selectedItemPosition
                .coerceIn(
                    0,
                    7
                )
        ]

    private fun selectedRemoteAudioBitrateKbps():
        Int =
        intArrayOf(
            64,
            96,
            128,
            192,
            256,
            320
        )[
            b.remoteAudioBitrate
                .selectedItemPosition
                .coerceIn(
                    0,
                    5
                )
        ]

    private fun selectedRemoteAudioSampleRateHz():
        Int =
        if (
            b.remoteAudioSampleRate
                .selectedItemPosition ==
            0
        ) {
            44_100
        } else {
            48_000
        }

    private fun selectedRemoteAudioSyncMs():
        Int =
        intArrayOf(
            0,
            -250,
            -500,
            -1000,
            -2000,
            -3000,
            -5000,
            250,
            500,
            1000
        )[
            b.remoteAudioSync
                .selectedItemPosition
                .coerceIn(
                    0,
                    9
                )
        ]

    private fun loadRemoteDvrSettings() {
        val pair =
            currentPair ?: return

        b.remoteDvrSettingsStatus.text =
            "Loading camera DVR settings…"

        safeNetworkExecute {
            try {
                val raw =
                    getBytes(
                        pair.endpoint(
                            "/dvr-settings"
                        )
                    )
                        .toString(
                            Charsets.UTF_8
                        )

                val json =
                    JSONObject(
                        raw
                    )

                runOnUiThread {
                    b.remoteDvrQuality
                        .setSelection(
                            json.optInt(
                                "quality",
                                1
                            )
                                .coerceIn(
                                    0,
                                    2
                                )
                        )

                    val videoValues =
                        intArrayOf(
                            0,
                            20,
                            32,
                            50,
                            75,
                            100,
                            150,
                            200
                        )

                    b.remoteVideoBitrate
                        .setSelection(
                            videoValues
                                .indexOf(
                                    json.optInt(
                                        "videoBitrateMbps",
                                        0
                                    )
                                )
                                .coerceAtLeast(
                                    0
                                )
                        )

                    b.remoteAudioSampleRate
                        .setSelection(
                            if (
                                json.optInt(
                                    "audioSampleRateHz",
                                    48_000
                                ) ==
                                44_100
                            ) {
                                0
                            } else {
                                1
                            }
                        )

                    val audioValues =
                        intArrayOf(
                            64,
                            96,
                            128,
                            192,
                            256,
                            320
                        )

                    b.remoteAudioBitrate
                        .setSelection(
                            audioValues
                                .indexOf(
                                    json.optInt(
                                        "audioBitrateKbps",
                                        128
                                    )
                                )
                                .coerceAtLeast(
                                    0
                                )
                        )

                    val syncValues =
                        intArrayOf(
                            0,
                            -250,
                            -500,
                            -1000,
                            -2000,
                            -3000,
                            -5000,
                            250,
                            500,
                            1000
                        )

                    b.remoteAudioSync
                        .setSelection(
                            syncValues
                                .indexOf(
                                    json.optInt(
                                        "audioSyncMs",
                                        0
                                    )
                                )
                                .coerceAtLeast(
                                    0
                                )
                        )

                    b.remoteDvrSettingsStatus.text =
                        buildString {
                            append(
                                "Camera active: "
                            )
                            append(
                                json.optString(
                                    "activeRecordingSize",
                                    "unknown"
                                )
                            )
                            append(
                                " @ "
                            )
                            append(
                                json.optInt(
                                    "activeRecordingFps",
                                    0
                                )
                            )
                            append(
                                " fps"
                            )

                            val fallback =
                                json.optString(
                                    "qualityFallback",
                                    ""
                                )

                            if (
                                fallback.isNotBlank()
                            ) {
                                append(
                                    "\\n"
                                )
                                append(
                                    fallback
                                )
                            }
                        }
                }

            } catch (
                t: Throwable
            ) {
                runOnUiThread {
                    b.remoteDvrSettingsStatus.text =
                        "Could not load camera settings: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )
                }
            }
        }
    }

    private fun applyRemoteDvrSettings() {
        val pair =
            currentPair ?: return

        val path =
            "/dvr-settings" +
                "?quality=" +
                b.remoteDvrQuality
                    .selectedItemPosition
                    .coerceIn(
                        0,
                        2
                    ) +
                "&videoBitrateMbps=" +
                selectedRemoteVideoBitrateMbps() +
                "&audioBitrateKbps=" +
                selectedRemoteAudioBitrateKbps() +
                "&audioSampleRateHz=" +
                selectedRemoteAudioSampleRateHz() +
                "&audioSyncMs=" +
                selectedRemoteAudioSyncMs()

        b.remoteDvrSettingsStatus.text =
            "Applying settings and restarting camera DVR…"

        safeNetworkExecute {
            var conn:
                HttpURLConnection? =
                null

            try {
                conn =
                    URL(
                        pair.endpoint(
                            path
                        )
                    )
                        .openConnection()
                        as HttpURLConnection

                conn.requestMethod =
                    "POST"
                conn.connectTimeout =
                    8_000
                conn.readTimeout =
                    8_000
                conn.useCaches =
                    false
                conn.connect()

                val response =
                    conn.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                JSONObject(
                    response
                )

                runOnUiThread {
                    b.remoteDvrSettingsStatus.text =
                        "Settings applied. Camera DVR is restarting…"

                    Handler(
                        Looper
                            .getMainLooper()
                    )
                        .postDelayed(
                            {
                                if (connected) {
                                    loadRemoteDvrSettings()
                                }
                            },
                            3_000L
                        )
                }

            } catch (
                t: Throwable
            ) {
                runOnUiThread {
                    b.remoteDvrSettingsStatus.text =
                        "Remote DVR settings failed: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )
                }

            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun setupPreviewQualityUi() {
        val labels =
            listOf(
                "Auto Smooth (recommended)",
                "Smooth • 180p / low bitrate",
                "Balanced • 240p",
                "Sharp • 270p",
                "Max Detail • 270p / high JPEG"
            )

        b.previewQuality.adapter =
            ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                labels
            )

        b.previewQuality.setSelection(0)

        b.previewQuality.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {
                    updatePreviewQualityInfo(position)

                    if (
                        !ignorePreviewQualityCallback &&
                        connected
                    ) {
                        sendCommand(
                            "/preview?mode=$position",
                            silent = true
                        )
                    }
                }

                override fun onNothingSelected(
                    parent: android.widget.AdapterView<*>?
                ) = Unit
            }
    }

    private fun updatePreviewQualityInfo(mode: Int) {
        b.previewQualityInfo.text =
            when (mode) {
                1 ->
                    "Smooth: 320×180 and low JPEG bitrate. Best if FPS collapses during fast motion."
                2 ->
                    "Balanced: about 426×240 with moderate bitrate."
                3 ->
                    "Sharp: native 9:16 portrait render with more detail."
                4 ->
                    "Max Detail: native 9:16 portrait GPU render with high JPEG quality; uses the most Wi-Fi/CPU."
                else ->
                    "Auto Smooth: lowers bitrate when source FPS or thermal headroom drops."
            }
    }

    private fun updateCameraViewLabel() {
        val ratio =
            1f + remoteZoomLinear * (remoteMaxZoomRatio - 1f)

        val panText =
            when (remotePanMode) {
                "sensor-freeform" ->
                    "sensor pan"
                "live-software-fallback" ->
                    "live-view pan fallback"
                "center-only" ->
                    "center zoom"
                else ->
                    "camera pan"
            }

        b.viewerZoomStatus.text =
            String.format(
                Locale.US,
                "Camera view: %.1f× • pan X %.0f%% / Y %.0f%% • %s",
                ratio,
                remotePanX * 100f,
                remotePanY * 100f,
                panText
            )
    }

    private fun scheduleCameraViewCommand(
        linear: Float,
        panX: Float,
        panY: Float
    ) {
        pendingViewLinear = linear.coerceIn(0f, 1f)
        pendingViewPanX = panX.coerceIn(-1f, 1f)
        pendingViewPanY = panY.coerceIn(-1f, 1f)

        if (cameraViewSendScheduled) return

        cameraViewSendScheduled = true

        cameraViewHandler.postDelayed(
            {
                cameraViewSendScheduled = false

                if (!connected) {
                    return@postDelayed
                }

                sendCommand(
                    "/view?linear=$pendingViewLinear" +
                        "&panX=$pendingViewPanX" +
                        "&panY=$pendingViewPanY",
                    silent = true
                )
            },
            35L
        )
    }

    private fun scanCameraQr() {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .enableAutoZoom()
            .build()

        val scanner = GmsBarcodeScanning.getClient(this, options)

        b.connectionState.text = "Opening QR scanner…"

        scanner.startScan()
            .addOnSuccessListener { barcode ->
                val raw = barcode.rawValue.orEmpty()
                val pair = Pairing.parse(raw)
                if (pair == null) {
                    b.connectionState.text =
                        "That QR is not an AI Door Monitor pairing code."
                } else {
                    b.pairingCode.setText(raw)
                    pair.remoteHost
                        ?.takeIf { LocalNetwork.isTailscaleIpv4(it) }
                        ?.let {
                            b.remoteVpnHost.setText(it)
                            getSharedPreferences("monitor_pair", MODE_PRIVATE)
                                .edit()
                                .putString("manual_remote_host", it)
                                .apply()
                        }
                    b.connectionState.text =
                        "Camera QR read. Tap Connect live stream."
                }
            }
            .addOnCanceledListener {
                b.connectionState.text = "QR scan canceled."
            }
            .addOnFailureListener { e ->
                b.connectionState.text =
                    "QR scanner failed: ${e.message}. You can paste the pairing code instead."
            }
    }

    private fun formatElapsedEventTime(
        elapsedMs: Long
    ): String {
        val totalSeconds =
            (elapsedMs / 1_000L)
                .coerceAtLeast(0L)
        val minutes =
            totalSeconds / 60L
        val seconds =
            totalSeconds % 60L

        return String.format(
            Locale.US,
            "%02d:%02d",
            minutes,
            seconds
        )
    }

    private fun updateLiveCameraInfo(
        temperatureC: Double,
        thermalStatus: String,
        cameraModuleTemperatureC: Double?,
        cameraModuleTemperatureSensor: String,
        cameraModuleTemperatureDirect: Boolean,
        thermalHeadroom: Double?,
        thermalLoadMode: String,
        batteryPercent: Int?,
        batteryStatus: String,
        batteryPlugged: String,
        batteryCurrentMa: Double?,
        batteryNetPowerW: Double?,
        batteryPowerFlow: String,
        powerDeficitWarning: Boolean,
        powerDeficitSeconds: Long,
        eventRecordingActive: Boolean,
        eventRecordingLabel: String,
        eventRecordingElapsedMs: Long,
        dvrRecording: Boolean,
        cameraMovementGuardActive: Boolean,
        cameraMovementGuardRemainingMs: Long,
        currentAiEventLabel: String,
        personCount: Int,
        objectAiStatus: String,
        objectAiInferenceFps: Double,
        remoteAccessReady: Boolean,
        remoteHost: String
    ) {
        val temperatureText =
            if (temperatureC.isFinite()) {
                String.format(
                    Locale.US,
                    "%.1f°C",
                    temperatureC
                )
            } else {
                "--.-°C"
            }

        val thermal =
            thermalStatus
                .trim()
                .ifBlank {
                    "Unavailable"
                }

        val cameraModuleText =
            cameraModuleTemperatureC
                ?.takeIf { it.isFinite() }
                ?.let { value ->
                    val label =
                        if (cameraModuleTemperatureDirect) {
                            "Camera module"
                        } else {
                            "Camera thermal proxy"
                        }
                    val sensor = cameraModuleTemperatureSensor.trim()
                    buildString {
                        append(label)
                        append(": ")
                        append(String.format(Locale.US, "%.1f°C", value))
                        if (sensor.isNotBlank()) {
                            append(" • ")
                            append(sensor)
                        }
                    }
                }
                ?: "Camera module: unavailable on this phone"

        val headroomText =
            thermalHeadroom
                ?.takeIf { it.isFinite() && it >= 0.0 }
                ?.let { String.format(Locale.US, " • Headroom %.2f", it) }
                .orEmpty()

        val coolingText =
            thermalLoadMode.trim().ifBlank { "CPU saver: --" }

        val batteryPercentText =
            batteryPercent
                ?.coerceIn(0, 100)
                ?.let { "$it%" }
                ?: "--%"

        val batteryState =
            batteryStatus
                .trim()
                .ifBlank {
                    "Unavailable"
                }

        val batteryPower =
            batteryPlugged
                .trim()

        val batteryText =
            buildString {
                append("Battery: ")
                append(batteryPercentText)
                append(" • ")
                append(batteryState)

                if (batteryPower.isNotBlank()) {
                    append(" • ")
                    append(batteryPower)
                }
            }

        val signedCurrent =
            batteryCurrentMa?.let {
                String.format(Locale.US, "%+.2f A", it / 1000.0)
            }

        val signedPower =
            batteryNetPowerW?.let {
                String.format(Locale.US, "%+.1f W", it)
            }

        val flow =
            batteryPowerFlow
                .trim()
                .ifBlank { "Unavailable" }

        val netBatteryText =
            if (signedCurrent != null) {
                buildString {
                    append("Net battery: ")
                    append(signedCurrent)
                    if (signedPower != null) {
                        append(" • ")
                        append(signedPower)
                    }
                    append(" • ")
                    if (powerDeficitWarning) {
                        append("⚠ POWER DEFICIT ")
                        append(formatElapsedEventTime(powerDeficitSeconds * 1000L))
                    } else {
                        append(flow)
                    }
                }
            } else {
                "Net battery: unavailable on camera phone"
            }

        val eventText =
            if (cameraMovementGuardActive) {
                val settling =
                    (cameraMovementGuardRemainingMs / 1_000.0)
                        .coerceAtLeast(0.0)
                if (eventRecordingActive) {
                    val label =
                        eventRecordingLabel
                            .trim()
                            .ifBlank { "Motion" }
                    "EVENT REC ${formatElapsedEventTime(eventRecordingElapsedMs)} • $label • Camera moved: visual AI paused ${String.format(Locale.US, "%.1fs", settling)}"
                } else {
                    "AI paused: camera moving/settling ${String.format(Locale.US, "%.1fs", settling)} • DVR buffer active"
                }
            } else if (eventRecordingActive) {
                val label =
                    eventRecordingLabel
                        .trim()
                        .ifBlank {
                            "Motion"
                        }

                "EVENT REC ${formatElapsedEventTime(eventRecordingElapsedMs)} • $label"
            } else if (dvrRecording) {
                "AI event: waiting • DVR pre-record buffer active"
            } else {
                "AI event: waiting • recorder starting"
            }

        val aiDetectionText =
            buildString {
                append("AI detection: ")
                val label = currentAiEventLabel.trim()
                if (label.isNotBlank()) {
                    append(label)
                    append(if (eventRecordingActive) " • ACTIVE EVENT" else " • last/current label")
                } else {
                    append("waiting for detection")
                }
            }

        val peopleCountText =
            if (personCount > 0) {
                "People detected: $personCount"
            } else {
                "People detected: 0"
            }

        val objectAiText =
            buildString {
                append(
                    objectAiStatus
                        .trim()
                        .ifBlank { "Object AI: status unavailable" }
                )
                if (objectAiInferenceFps.isFinite() && objectAiInferenceFps > 0.01) {
                    append(" • ")
                    append(
                        String.format(
                            Locale.US,
                            "%.1f infer/s",
                            objectAiInferenceFps
                        )
                    )
                }
            }

        val savedRemoteHost =
            remoteHost
                .takeIf { remoteAccessReady && LocalNetwork.isTailscaleIpv4(it) }
                ?: configuredPair?.remoteHost
                    ?.takeIf { LocalNetwork.isTailscaleIpv4(it) }
                ?: b.remoteVpnHost.text.toString().trim()
                    .takeIf { LocalNetwork.isTailscaleIpv4(it) }

        val remoteAccessText =
            if (savedRemoteHost != null) {
                if (remoteAccessReady && savedRemoteHost == remoteHost) {
                    "Remote VPN: READY • $savedRemoteHost"
                } else {
                    "Remote VPN: READY (saved fallback) • $savedRemoteHost"
                }
            } else {
                "Remote VPN: NOT READY • enter camera Tailscale IP"
            }

        b.liveCameraInfo.text =
            "$cameraModuleText • $coolingText\nPhone/battery sensor: $temperatureText • Thermal: $thermal$headroomText\n$batteryText\n$netBatteryText\n$eventText\n$aiDetectionText\n$objectAiText\n$remoteAccessText"
    }

    private fun resetLiveCameraInfo() {
        b.liveCameraInfo.text =
            "Camera module: --.-°C\nPhone/battery sensor: --.-°C • Thermal: --\nBattery: --% • --\nNet battery: --\nAI event: waiting for connection\nAI detection: waiting for connection\nObject AI: waiting for connection • CPU saver: --\nRemote VPN: waiting for camera"
    }

    private fun startConnectionHealthPolling() {
        if (healthPollRunning) return
        healthPollRunning = true

        connectionHealthHandler.post(
            object : Runnable {
                override fun run() {
                    if (!healthPollRunning || !connected) return
                    pollConnectionHealth()
                    connectionHealthHandler.postDelayed(this, 1_000L)
                }
            }
        )
    }

    private fun stopConnectionHealthPolling() {
        healthPollRunning = false
        connectionHealthHandler.removeCallbacksAndMessages(null)
    }

    private fun pollConnectionHealth() {
        val pair = currentPair ?: return

        safeNetworkExecute {
            try {
                val raw =
                    getBytes(pair.endpoint("/health"))
                        .toString(Charsets.UTF_8)

                val health = JSONObject(raw)

                // Keep learning the camera's VPN route on every successful
                // health poll. This matters when Tailscale is enabled AFTER
                // the original QR scan/connection: the old 192.168/10.x pair
                // is upgraded automatically before the monitor leaves Wi-Fi.
                learnRemoteRouteFromHealth(
                    requestedPair = configuredPair ?: pair,
                    activePair = pair,
                    health = health
                )

                val visualAvailable =
                    health.optBoolean("visualStreamAvailable", true)
                val recordingFirst =
                    health.optBoolean("recordingFirstMode", false)
                val stage =
                    health.optString("compatibilityStage", "")
                val firstFramePending =
                    health.optBoolean(
                        "firstFramePending",
                        false
                    )

                val activeQuality =
                    health.optString(
                        "quality",
                        "recording quality"
                    )

                val requestedQuality =
                    health.optString(
                        "requestedQuality",
                        ""
                    )

                val recordingModeName =
                    health.optString(
                        "recordingModeName",
                        ""
                    )

                val frameReady =
                    health.optBoolean(
                        "frameReady",
                        false
                    )

                val frameAgeMs =
                    health.optLong(
                        "frameAgeMs",
                        -1L
                    )

                val lanServerRunning =
                    health.optBoolean(
                        "lanServerRunning",
                        true
                    )

                val lanServerError =
                    health.optString(
                        "lanServerError",
                        ""
                    )

                val cameraPhoneTemperatureC =
                    if (
                        health.has(
                            "cameraPhoneTemperatureC"
                        ) &&
                        !health.isNull(
                            "cameraPhoneTemperatureC"
                        )
                    ) {
                        health.optDouble(
                            "cameraPhoneTemperatureC",
                            Double.NaN
                        )
                    } else {
                        Double.NaN
                    }

                val cameraPhoneThermalStatus =
                    health.optString(
                        "cameraPhoneThermalStatus",
                        "Unavailable"
                    )

                val cameraModuleTemperatureC =
                    if (health.has("cameraModuleTemperatureC") && !health.isNull("cameraModuleTemperatureC")) {
                        health.optDouble("cameraModuleTemperatureC", Double.NaN)
                            .takeIf { it.isFinite() }
                    } else {
                        null
                    }
                val cameraModuleTemperatureSensor =
                    health.optString("cameraModuleTemperatureSensor", "")
                val cameraModuleTemperatureDirect =
                    health.optBoolean("cameraModuleTemperatureDirect", false)
                val cameraPhoneThermalHeadroom =
                    if (health.has("cameraPhoneThermalHeadroom") && !health.isNull("cameraPhoneThermalHeadroom")) {
                        health.optDouble("cameraPhoneThermalHeadroom", Double.NaN)
                            .takeIf { it.isFinite() && it >= 0.0 }
                    } else {
                        null
                    }
                val thermalLoadMode =
                    health.optString("thermalLoadMode", "")

                val cameraPhoneBatteryPercent =
                    if (
                        health.has(
                            "cameraPhoneBatteryPercent"
                        ) &&
                        !health.isNull(
                            "cameraPhoneBatteryPercent"
                        )
                    ) {
                        health.optInt(
                            "cameraPhoneBatteryPercent",
                            -1
                        )
                            .takeIf { it >= 0 }
                    } else {
                        null
                    }

                val cameraPhoneBatteryStatus =
                    health.optString(
                        "cameraPhoneBatteryStatus",
                        "Unavailable"
                    )

                val cameraPhoneBatteryPlugged =
                    health.optString(
                        "cameraPhoneBatteryPlugged",
                        ""
                    )

                fun optionalHealthDouble(key: String): Double? =
                    if (health.has(key) && !health.isNull(key)) {
                        health.optDouble(key, Double.NaN)
                            .takeIf { it.isFinite() }
                    } else {
                        null
                    }

                val cameraPhoneBatteryCurrentMa =
                    optionalHealthDouble(
                        "cameraPhoneBatteryCurrentAverageMa"
                    ) ?: optionalHealthDouble(
                        "cameraPhoneBatteryCurrentNowMa"
                    )

                val cameraPhoneBatteryNetPowerW =
                    optionalHealthDouble(
                        "cameraPhoneBatteryNetPowerW"
                    )

                val cameraPhoneBatteryPowerFlow =
                    health.optString(
                        "cameraPhoneBatteryPowerFlow",
                        "Unavailable"
                    )

                val cameraPhonePowerDeficitWarning =
                    health.optBoolean(
                        "cameraPhonePowerDeficitWarning",
                        false
                    )

                val cameraPhonePowerDeficitSeconds =
                    health.optLong(
                        "cameraPhonePowerDeficitSeconds",
                        0L
                    )

                val eventRecordingActive =
                    health.optBoolean(
                        "eventRecordingActive",
                        health.optBoolean(
                            "eventActive",
                            false
                        )
                    )

                val eventRecordingLabel =
                    health.optString(
                        "eventRecordingLabel",
                        health.optString(
                            "currentAiEventLabel",
                            "Motion"
                        )
                    )

                val eventRecordingElapsedMs =
                    health.optLong(
                        "eventRecordingElapsedMs",
                        0L
                    )

                val cameraMovementGuardActive =
                    health.optBoolean(
                        "cameraMovementGuardActive",
                        false
                    )

                val cameraMovementGuardRemainingMs =
                    health.optLong(
                        "cameraMovementGuardRemainingMs",
                        0L
                    )

                val currentAiEventLabel =
                    health.optString(
                        "currentAiEventLabel",
                        health.optString("eventRecordingLabel", "")
                    )

                val personCount =
                    health.optInt(
                        "personCount",
                        0
                    )

                val objectAiStatus =
                    health.optString(
                        "objectAiStatus",
                        if (health.optBoolean("objectNamingAiReady", false)) {
                            "Object AI: ACTIVE"
                        } else {
                            "Object AI: NOT READY"
                        }
                    )

                val objectAiInferenceFps =
                    health.optDouble(
                        "objectAiInferenceFps",
                        0.0
                    )

                val remoteHost =
                    health.optString("remoteHost", "")
                        .trim()
                val remoteAccessReady =
                    health.optBoolean(
                        "remoteAccessReady",
                        LocalNetwork.isTailscaleIpv4(remoteHost)
                    )

                val dvrRecording =
                    health.optBoolean(
                        "recording",
                        false
                    )

                val doorbellSequence =
                    health.optLong("doorbellSequence", 0L)
                val doorbellPressedAtMs =
                    health.optLong("lastDoorbellPressedAtMs", 0L)
                val doorbellSource =
                    health.optString("lastDoorbellSource", "screen touch")

                runOnUiThread {
                    if (!connected || currentPair != pair) {
                        return@runOnUiThread
                    }

                    b.liveView.setMirrorHorizontally(
                        health.optBoolean("cameraFacingFront", false)
                    )

                    handleDoorbellStatus(
                        sequence = doorbellSequence,
                        pressedAtMs = doorbellPressedAtMs,
                        source = doorbellSource
                    )

                    updateLiveCameraInfo(
                        temperatureC =
                            cameraPhoneTemperatureC,
                        thermalStatus =
                            cameraPhoneThermalStatus,
                        cameraModuleTemperatureC =
                            cameraModuleTemperatureC,
                        cameraModuleTemperatureSensor =
                            cameraModuleTemperatureSensor,
                        cameraModuleTemperatureDirect =
                            cameraModuleTemperatureDirect,
                        thermalHeadroom =
                            cameraPhoneThermalHeadroom,
                        thermalLoadMode =
                            thermalLoadMode,
                        batteryPercent =
                            cameraPhoneBatteryPercent,
                        batteryStatus =
                            cameraPhoneBatteryStatus,
                        batteryPlugged =
                            cameraPhoneBatteryPlugged,
                        batteryCurrentMa =
                            cameraPhoneBatteryCurrentMa,
                        batteryNetPowerW =
                            cameraPhoneBatteryNetPowerW,
                        batteryPowerFlow =
                            cameraPhoneBatteryPowerFlow,
                        powerDeficitWarning =
                            cameraPhonePowerDeficitWarning,
                        powerDeficitSeconds =
                            cameraPhonePowerDeficitSeconds,
                        eventRecordingActive =
                            eventRecordingActive,
                        eventRecordingLabel =
                            eventRecordingLabel,
                        eventRecordingElapsedMs =
                            eventRecordingElapsedMs,
                        dvrRecording =
                            dvrRecording,
                        cameraMovementGuardActive =
                            cameraMovementGuardActive,
                        cameraMovementGuardRemainingMs =
                            cameraMovementGuardRemainingMs,
                        currentAiEventLabel =
                            currentAiEventLabel,
                        personCount =
                            personCount,
                        objectAiStatus =
                            objectAiStatus,
                        objectAiInferenceFps =
                            objectAiInferenceFps,
                        remoteAccessReady =
                            remoteAccessReady,
                        remoteHost =
                            remoteHost
                    )

                    val visualChanged =
                        lastVisualStreamAvailable != visualAvailable
                    val stageChanged =
                        lastCompatibilityStage != stage

                    lastVisualStreamAvailable = visualAvailable
                    lastCompatibilityStage = stage

                    if (!visualAvailable) {
                        b.liveView.stop()
                        b.liveView.clearFrame()

                        b.liveUnavailableOverlay.visibility =
                            android.view.View.VISIBLE

                        b.liveUnavailableOverlay.text =
                            if (recordingFirst) {
                                buildString {
                                    append("RECORDING-FIRST\n\n")
                                    append(activeQuality)
                                    append("\n\nMP4 recording / pre-record is active.")
                                    append("\nVisual preview is unavailable.")

                                    if (
                                        requestedQuality.startsWith("8K") &&
                                        activeQuality.contains("camera max")
                                    ) {
                                        append("\n\n8K was requested; the camera maximum is shown above.")
                                    }
                                }
                            } else {
                                "Visual preview unavailable\n\n$stage"
                            }

                        b.connectionState.text =
                            if (recordingFirst) {
                                "Connected • RECORDING-FIRST • $activeQuality • MP4 active • visual preview unavailable"
                            } else {
                                "Connected • $stage • visual stream unavailable"
                            }
                    } else if (visualChanged && visualAvailable) {
                        b.liveUnavailableOverlay.visibility =
                            android.view.View.GONE
                        b.liveView.clearFrame()

                        b.liveView.start(pair) { state ->
                            b.connectionState.text = state
                        }
                    } else if (firstFramePending && stageChanged) {
                        b.connectionState.text =
                            "Connected • $recordingModeName • trying $stage • waiting for first frame…"
                    }

                    if (
                        visualAvailable &&
                        frameReady &&
                        frameAgeMs in 0L..3_000L &&
                        !b.liveView.hasRecentFrame(4_500L)
                    ) {
                        val now =
                            android.os.SystemClock
                                .elapsedRealtime()

                        if (
                            now - lastHealthStreamKickAt >
                            8_000L
                        ) {
                            lastHealthStreamKickAt =
                                now

                            // Camera /health is fresh, but this monitor has not
                            // received a MJPEG frame recently. Only in that
                            // actual stale-reader case do we restart the reader.
                            b.liveView.start(
                                pair
                            ) { state ->
                                b.connectionState.text =
                                    state
                            }
                        }
                    } else if (!lanServerRunning) {
                        b.connectionState.text =
                            "Camera/AI service active • LAN stream restarting${if (lanServerError.isNotBlank()) " • $lanServerError" else ""}"
                    }
                }
            } catch (_: Exception) {
                // If the monitor leaves home Wi-Fi, the saved LAN address
                // becomes unreachable. Transparently try the VPN address from
                // the same QR and move every transport to it when available.
                tryRemoteRouteFailover(pair)
            }
        }
    }

    private fun tryRemoteRouteFailover(failedPair: PairInfo) {
        val definition = configuredPair ?: return
        val alternatives =
            connectionCandidatesForCurrentNetwork(definition)
                .filter {
                    !it.host.equals(
                        failedPair.host,
                        ignoreCase = true
                    )
                }

        if (alternatives.isEmpty()) {
            runOnUiThread {
                if (connected) {
                    b.connectionState.text =
                        "Remote VPN route not ready • Tailscale camera address was not learned. Turn Tailscale ON on the CAMERA phone, reconnect once on home Wi-Fi, and wait until the overlay says Remote VPN: READY."
                }
            }
            return
        }

        for (candidate in alternatives) {
            try {
                getBytes(candidate.endpoint("/health"))
                currentPair = candidate

                runOnUiThread {
                    if (!connected) return@runOnUiThread

                    b.liveView.stop()
                    b.liveView.clearFrame()
                    if (lastVisualStreamAvailable != false) {
                        b.liveView.start(candidate) { state ->
                            b.connectionState.text = state
                        }
                    }

                    liveAudioPlayer.stop()
                    startLiveAudioIfEnabled()

                    b.connectionState.text =
                        if (candidate.usesRemoteVpn()) {
                            "Connected • REMOTE VPN • switched from Wi-Fi/LAN"
                        } else {
                            "Connected • LAN • route restored"
                        }
                }

                refreshRemoteEvents()
                refreshRemoteRecordings()
                return
            } catch (_: Throwable) {
                // Try the next route if one exists.
            }
        }
    }


    /** Prefer the encrypted VPN route immediately when the monitor has no Wi-Fi.
     * This avoids waiting for the private 192.168/10.x home address to time out
     * before trying Tailscale on mobile data.
     */
    private fun connectionCandidatesForCurrentNetwork(
        pair: PairInfo
    ): List<PairInfo> {
        val wifiAvailable = hasUsableWifiNetwork()
        val candidates =
            pair.connectionCandidates(
                preferRemote = !wifiAvailable
            )

        // A home RFC1918 address cannot normally be reached after Wi-Fi is
        // switched off. Do not accidentally send 192.168/10.x traffic through
        // the Tailscale tunnel and then loop forever reconnecting to it.
        if (!wifiAvailable) {
            val vpnCandidates = candidates.filter { it.usesRemoteVpn() }
            if (vpnCandidates.isNotEmpty()) {
                return vpnCandidates
            }

            if (!pair.usesRemoteVpn() && LocalNetwork.isPrivateLanIpv4(pair.host)) {
                return emptyList()
            }
        }

        return candidates
    }

    private fun hasUsableWifiNetwork(): Boolean {
        return try {
            val cm =
                getSystemService(CONNECTIVITY_SERVICE)
                    as ConnectivityManager

            cm.allNetworks.any { network ->
                val caps = cm.getNetworkCapabilities(network)
                caps != null &&
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            }
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Learn the camera phone's Tailscale address from /health while LAN still
     * works. This fixes old QR/pairing records that only contained a LAN IP.
     */
    private fun learnRemoteRouteFromHealth(
        requestedPair: PairInfo,
        activePair: PairInfo,
        health: JSONObject
    ) {
        val advertisedRemote =
            health.optString("remoteHost", "")
                .trim()
                .takeIf { LocalNetwork.isTailscaleIpv4(it) }

        val advertisedLan =
            health.optString("lanHost", "")
                .trim()
                .takeIf { it.isNotBlank() && !LocalNetwork.isTailscaleIpv4(it) }

        val existing = configuredPair ?: requestedPair
        val remote =
            advertisedRemote
                ?: existing.remoteHost?.takeIf { LocalNetwork.isTailscaleIpv4(it) }
                ?: activePair.host.takeIf { activePair.usesRemoteVpn() }
                ?: return

        val primaryHost =
            when {
                !existing.usesRemoteVpn() -> existing.host
                advertisedLan != null -> advertisedLan
                else -> existing.host
            }

        val updated =
            PairInfo(
                host = primaryHost,
                port = existing.port,
                token = existing.token,
                remoteHost = remote.takeIf {
                    !it.equals(primaryHost, ignoreCase = true)
                }
            )

        configuredPair = updated

        val encoded = updated.pairingUri()
        getSharedPreferences("monitor_pair", MODE_PRIVATE)
            .edit()
            .putString("last_pair", encoded)
            .putString("manual_remote_host", remote)
            .apply()

        runOnUiThread {
            // Keep both the pairing URI and the explicit fallback field in sync.
            if (b.pairingCode.text.toString() != encoded) {
                b.pairingCode.setText(encoded)
            }
            if (b.remoteVpnHost.text.toString().trim() != remote) {
                b.remoteVpnHost.setText(remote)
            }
        }
    }

    private fun saveAndTestManualRemoteHost() {
        val host = b.remoteVpnHost.text.toString().trim()
        if (!LocalNetwork.isTailscaleIpv4(host)) {
            toast("Enter the CAMERA phone Tailscale IPv4 address, normally 100.x.x.x.")
            return
        }

        val parsed = Pairing.parse(b.pairingCode.text.toString().trim())
        if (parsed == null) {
            toast("Scan/paste the camera pairing QR first, then enter its Tailscale IP.")
            return
        }

        val updated = parsed.copy(remoteHost = host)
        configuredPair = updated
        val encoded = updated.pairingUri()
        b.pairingCode.setText(encoded)
        getSharedPreferences("monitor_pair", MODE_PRIVATE)
            .edit()
            .putString("last_pair", encoded)
            .putString("manual_remote_host", host)
            .apply()

        b.connectionState.text = "Testing camera Tailscale route $host:${updated.port}…"

        safeNetworkExecute {
            val remotePair = PairInfo(
                host = host,
                port = updated.port,
                token = updated.token
            )
            try {
                getBytes(remotePair.endpoint("/health"))
                runOnUiThread {
                    b.connectionState.text =
                        "Remote VPN: READY • camera reachable at $host:${updated.port}"
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    b.connectionState.text =
                        "Camera Tailscale IP saved, but test failed: ${t.message}. Check Tailscale is Connected on BOTH phones and that this is the CAMERA phone's 100.x address."
                }
            }
        }
    }

    private fun connectFromField() {
        if (connectionAttemptInProgress) {
            return
        }

        val raw = b.pairingCode.text.toString().trim()
        val parsedPair: PairInfo =
            Pairing.parse(raw)
                ?: run {
                    toast("Scan the camera QR or paste a valid pairing code.")
                    return
                }

        val manualRemote =
            b.remoteVpnHost.text.toString().trim()
                .takeIf { LocalNetwork.isTailscaleIpv4(it) }

        val requestedPair: PairInfo =
            if (manualRemote != null) {
                parsedPair.copy(remoteHost = manualRemote)
            } else {
                parsedPair
            }

        if (manualRemote != null) {
            val upgradedUri = requestedPair.pairingUri()
            if (b.pairingCode.text.toString() != upgradedUri) {
                b.pairingCode.setText(upgradedUri)
            }
            getSharedPreferences("monitor_pair", MODE_PRIVATE)
                .edit()
                .putString("manual_remote_host", manualRemote)
                .putString("last_pair", upgradedUri)
                .apply()
        }

        configuredPair = requestedPair
        currentPair = requestedPair
        connectionAttemptInProgress =
            true

        getSharedPreferences(
            "monitor_pair",
            MODE_PRIVATE
        )
            .edit()
            .putString(
                "last_pair",
                requestedPair.pairingUri()
            )
            .putBoolean(
                "keep_monitor_connected",
                true
            )
            .apply()

        b.connectionState.text = "Checking camera…"

        safeNetworkExecute {
            try {
                var selectedPair: PairInfo? = null
                var healthRaw: String? = null
                var lastConnectError: Throwable? = null

                val connectionCandidates =
                    connectionCandidatesForCurrentNetwork(requestedPair)

                if (connectionCandidates.isEmpty()) {
                    throw IllegalStateException(
                        "Wi-Fi is off and no camera Tailscale address is saved. Turn Tailscale ON on the camera phone, connect once on home Wi-Fi, and wait for Remote VPN: READY before leaving Wi-Fi."
                    )
                }

                for (candidate in connectionCandidates) {
                    try {
                        healthRaw =
                            getBytes(candidate.endpoint("/health"))
                                .toString(Charsets.UTF_8)
                        selectedPair = candidate
                        break
                    } catch (t: Throwable) {
                        lastConnectError = t
                    }
                }

                val resolvedHealth: String =
                    healthRaw
                        ?: throw IllegalStateException(
                            lastConnectError?.message
                                ?: "Camera is unreachable on LAN and remote VPN"
                        )

                // Stable non-null value: Kotlin cannot smart-cast a nullable
                // variable that is modified inside a lambda/closure.
                val activePair: PairInfo =
                    selectedPair
                        ?: throw IllegalStateException(
                            "Camera health replied without a selected route"
                        )

                // Every later endpoint (/stream, /audio-stream, /events,
                // /recordings, control commands) now uses the route that
                // actually answered the health probe.
                currentPair = activePair
                val health = JSONObject(resolvedHealth)
                learnRemoteRouteFromHealth(
                    requestedPair = requestedPair,
                    activePair = activePair,
                    health = health
                )

                remoteManualFocusSupported =
                    health.optBoolean("manualFocusSupported", false)
                val focusLinear =
                    health.optDouble("focusLinear", 0.0)
                        .toFloat().coerceIn(0f, 1f)

                val maxFocusDiopters =
                    health.optDouble("maxFocusDiopters", 0.0)
                        .toFloat().coerceAtLeast(0f)

                val focusManual =
                    health.optBoolean("focusManual", false)

                val maxZoom =
                    health.optDouble("maxZoom", 1.0)
                        .toFloat().coerceAtLeast(1f)

                val zoomRatio =
                    health.optDouble(
                        "appliedZoomRatio",
                        health.optDouble(
                            "zoomRatio",
                            1.0
                        )
                    )
                        .toFloat()
                        .coerceIn(
                            1f,
                            maxZoom
                        )

                val zoomLinear =
                    if (maxZoom <= 1.001f) 0f
                    else ((zoomRatio - 1f) / (maxZoom - 1f))
                        .coerceIn(0f, 1f)

                val panX =
                    health.optDouble("panX", 0.0)
                        .toFloat().coerceIn(-1f, 1f)

                val panY =
                    health.optDouble("panY", 0.0)
                        .toFloat().coerceIn(-1f, 1f)

                val previewMode =
                    health.optInt("previewQualityMode", 0)
                        .coerceIn(0, 4)

                val panMode =
                    health.optString(
                        "panMode",
                        "unknown"
                    )
                val zoomControlMode =
                    health.optString(
                        "zoomControlMode",
                        "unknown"
                    )

                val recordingFirstMode =
                    health.optBoolean(
                        "recordingFirstMode",
                        false
                    )

                val visualStreamAvailable =
                    health.optBoolean(
                        "visualStreamAvailable",
                        true
                    )

                val compatibilityStage =
                    health.optString(
                        "compatibilityStage",
                        ""
                    )

                val recordingModeName =
                    health.optString(
                        "recordingModeName",
                        ""
                    )

                runOnUiThread {
                    connectionAttemptInProgress =
                        false

                    // A user may have pressed Disconnect while the health
                    // request was still in flight.
                    if (
                        !getSharedPreferences(
                            "monitor_pair",
                            MODE_PRIVATE
                        )
                            .getBoolean(
                                "keep_monitor_connected",
                                true
                            )
                    ) {
                        connected =
                            false
                        return@runOnUiThread
                    }

                    connected = true
                    b.connectButton.text = "Disconnect"
                    b.liveView.setMirrorHorizontally(health.optBoolean("cameraFacingFront", false))
                    updateFullscreenControls()
                    loadRemoteCameraChoices()

                    lastVisualStreamAvailable = visualStreamAvailable
                    lastCompatibilityStage = compatibilityStage

                    if (visualStreamAvailable) {
                        b.liveUnavailableOverlay.visibility =
                            android.view.View.GONE

                        val transport =
                            if (activePair.usesRemoteVpn()) {
                                "REMOTE VPN • mobile-data ready"
                            } else {
                                "LAN"
                            }

                        b.connectionState.text =
                            "Connected • $transport • $recordingModeName • ${health.optString("quality", "camera")} • live stream active"

                        b.liveView.start(activePair) { state ->
                            b.connectionState.text = state
                        }
                        if (pendingDoorbellAutoLive) {
                            b.liveViewerFrame.postDelayed({
                                enterDoorbellLiveMode()
                            }, 250L)
                        }
                    } else {
                        b.liveView.stop()
                        b.liveView.clearFrame()

                        val activeQuality =
                            health.optString(
                                "quality",
                                "recording quality"
                            )

                        val requestedQuality =
                            health.optString(
                                "requestedQuality",
                                ""
                            )

                        b.liveUnavailableOverlay.visibility =
                            android.view.View.VISIBLE

                        b.liveUnavailableOverlay.text =
                            buildString {
                                append("RECORDING-FIRST\n\n")
                                append(activeQuality)
                                append("\n\nMP4 recording / pre-record is active.")
                                append("\nVisual preview is unavailable in this camera combination.")

                                if (
                                    requestedQuality.startsWith("8K") &&
                                    activeQuality.contains("camera max")
                                ) {
                                    append("\n\nThe 8K request resolved to the camera maximum shown above.")
                                }
                            }

                        b.connectionState.text =
                            "Connected • RECORDING-FIRST • $activeQuality • visual preview unavailable"
                    }

                    remoteMaxZoomRatio = maxZoom
                    remoteZoomLinear = zoomLinear
                    remotePanX = panX
                    remotePanY = panY
                    remotePanMode = panMode

                    b.liveGesture.setMaxZoomRatio(maxZoom)
                    b.liveGesture.setCameraState(
                        zoomLinear,
                        panX,
                        panY,
                        notify = false
                    )

                    b.remoteZoom.progress =
                        (zoomLinear * 1000f).toInt().coerceIn(0, 1000)

                    updateCameraViewLabel()

                    b.zoomValue.text =
                        String.format(
                            Locale.US,
                            "Camera zoom: %.2f× • %s",
                            zoomRatio,
                            zoomControlMode
                        )

                    ignorePreviewQualityCallback = true
                    b.previewQuality.setSelection(previewMode)
                    updatePreviewQualityInfo(previewMode)
                    ignorePreviewQualityCallback = false

                    if (
                        panMode ==
                        "live-software-fallback"
                    ) {
                        b.previewQualityInfo.text =
                            b.previewQualityInfo.text.toString() +
                                "\nPan: camera reports CENTER_ONLY cropping, so drag-pan uses a live-view software fallback."
                    } else if (
                        panMode ==
                        "center-only"
                    ) {
                        b.previewQualityInfo.text =
                            b.previewQualityInfo.text.toString() +
                                "\nZoom: remote Camera2 sensor crop is active. This lens reports CENTER_ONLY crop, so remote zoom works but off-center sensor pan is not available."
                    }

                    b.remoteFocus.progress = (focusLinear * 1000f).toInt()
                    updateRemoteFocusEnabled(remoteManualFocusSupported)

                    b.remoteFocusStatus.text =
                        if (remoteManualFocusSupported) {
                            if (focusManual) {
                                val diopters =
                                    focusLinear * maxFocusDiopters
                                "Remote manual focus active • ${String.format(java.util.Locale.US, "%.2f", diopters)} D"
                            } else {
                                "Manual focus supported • Auto Focus currently active."
                            }
                        } else {
                            "Selected camera/lens reports no adjustable Camera2 manual focus."
                        }

                    if (health.optBoolean("uhdSupported", false)) {
                        b.saveInfo.text =
                            "Camera reports 4K UHD support.\nMP4 saves on camera phone → Movies/AI Door Monitor."
                    }

                    if (recordingFirstMode) {
                        b.saveInfo.text =
                            "Strict Recording Resolution is prioritizing exact ${health.optString("quality", "selected")} MP4. This phone cannot expose visual ImageAnalysis at the same time, so live preview/motion/pose AI are disabled in this session. Continuous recording and Event Pre-Record still run; audio AI can still trigger event clips."
                    } else if (!health.optBoolean("recordingAvailable", true)) {
                        b.saveInfo.text =
                            "Live stream is active, but MP4 is unavailable in this non-strict compatibility session."
                    }

                    startConnectionHealthPolling()

                    startLiveAudioIfEnabled()
                }

                refreshRemoteEvents()
                refreshRemoteRecordings()
            } catch (e: Exception) {
                runOnUiThread {
                    connectionAttemptInProgress =
                        false

                    connected = false
                    resetLiveCameraInfo()
                    liveAudioPlayer.stop()
                    updateRemoteFocusEnabled(false)
                    updateFullscreenControls()
                    val remoteSaved =
                        configuredPair?.remoteHost?.isNotBlank() == true ||
                            configuredPair?.usesRemoteVpn() == true

                    b.connectionState.text =
                        if (remoteSaved) {
                            "Could not connect: ${e.message}. Mobile access address is saved; make sure Tailscale is ON on BOTH phones and both are signed into the same tailnet."
                        } else {
                            "Could not connect: ${e.message}. No camera VPN address is saved yet. Connect once on home Wi-Fi with Tailscale ON on the camera phone (or rescan its QR), then mobile-data access can work."
                        }
                }
            }
        }
    }

    private fun updateRemoteFocusEnabled(enabled: Boolean) {
        b.remoteFocus.isEnabled = enabled
        b.remoteFocusFar.isEnabled = enabled
        b.remoteFocusNear.isEnabled = enabled
        b.remoteSaveFocus.isEnabled = enabled
    }

    private fun disconnect() {
        getSharedPreferences(
            "monitor_pair",
            MODE_PRIVATE
        )
            .edit()
            .putBoolean(
                "keep_monitor_connected",
                false
            )
            .apply()

        connected = false
        connectionAttemptInProgress = false
        monitorTransportPausedForPlayer = false
        remoteManualFocusSupported = false
        remoteManualRecordingRequested = false
        updateFullscreenControls()

        liveAudioPlayer.stop()

        b.liveAudioStatus.text =
            if (
                b.liveAudioEnabled
                    .isChecked
            ) {
                "Live audio: waiting for connection"
            } else {
                "Live audio: OFF"
            }
        stopConnectionHealthPolling()
        lastVisualStreamAvailable = null
        lastCompatibilityStage = ""
        lastHealthStreamKickAt = 0L
        b.liveView.stop()
        b.liveView.clearFrame()
        b.liveUnavailableOverlay.visibility =
            android.view.View.GONE

        b.connectButton.text = "Connect live stream"
        b.connectionState.text = "Disconnected"
        resetLiveCameraInfo()

        remoteRecordings =
            emptyList()
        selectedRecordingIds.clear()
        openRecordingFolders.clear()

        try {
            b.recordingsThumbnailList
                .removeAllViews()
        } catch (_: Throwable) {
        }

        updateRecordingControls()

        updateRemoteFocusEnabled(false)
    }

    private fun requireConnection(): Boolean {
        if (!connected || currentPair == null) {
            toast("Connect to the camera phone first.")
            return false
        }
        return true
    }

    private fun restartRemoteCameraApp() {
        val pair =
            currentPair
                ?: Pairing.parse(
                    b.pairingCode.text
                        .toString()
                        .trim()
                )

        if (pair == null) {
            toast(
                "Scan the camera QR or paste a valid pairing code first."
            )
            return
        }

        currentPair = pair
        b.remoteRestartStatus.text =
            "Remote restart: sending command…"

        safeNetworkExecute {
            try {
                val raw =
                    getBytes(
                        pair.endpoint(
                            "/app/restart"
                        )
                    )
                        .toString(
                            Charsets.UTF_8
                        )

                val result =
                    JSONObject(raw)

                if (!result.optBoolean("ok", false)) {
                    throw IllegalStateException(
                        result.optString(
                            "reason",
                            "Camera rejected restart"
                        )
                    )
                }

                runOnUiThread {
                    b.remoteRestartStatus.text =
                        "Remote restart: camera/DVR restart requested"

                    toast(
                        "Camera restart command sent."
                    )

                    // The persistent LAN service normally stays connected
                    // while the camera pipeline restarts. Kick health/stream
                    // again shortly in case the old MJPEG socket went stale.
                    connectionHealthHandler.postDelayed(
                        {
                            if (
                                currentPair == pair &&
                                !monitorTransportPausedForPlayer
                            ) {
                                if (connected) {
                                    b.liveView.start(
                                        pair
                                    ) { state ->
                                        b.connectionState.text =
                                            state
                                    }

                                    startLiveAudioIfEnabled()
                                    pollConnectionHealth()
                                } else {
                                    connectFromField()
                                }
                            }
                        },
                        2_000L
                    )
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.remoteRestartStatus.text =
                        "Remote restart failed: ${e.message ?: "camera unreachable"}"

                    toast(
                        "Restart failed: ${e.message ?: "camera unreachable"}"
                    )
                }
            }
        }
    }

    private fun sendCommand(
        path: String,
        successMessage: String? = null,
        silent: Boolean = false,
        onSuccess: (() -> Unit)? = null,
        onFailure: (() -> Unit)? = null
    ) {
        val pair = currentPair ?: return

        safeNetworkExecute {
            try {
                getBytes(pair.endpoint(path))
                runOnUiThread {
                    if (!silent && successMessage != null) {
                        toast(successMessage)
                    }
                    onSuccess?.invoke()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!silent) {
                        toast("Command failed: ${e.message}")
                    }
                    onFailure?.invoke()
                }
            }
        }
    }

    private fun refreshFaceProfiles() {
        val pair = currentPair ?: return
        safeNetworkExecute {
            try {
                val root = JSONObject(getBytes(pair.endpoint("/faces")).toString(Charsets.UTF_8))
                val arr = root.optJSONArray("faces") ?: JSONArray()
                val names = (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
                runOnUiThread {
                    b.faceProfilesStatus.text = if (names.isEmpty()) "No saved face profiles." else "Saved faces: " + names.joinToString(", ")
                }
            } catch (e: Exception) {
                runOnUiThread { b.faceProfilesStatus.text = "Could not load face profiles: ${e.message}" }
            }
        }
    }

    private fun refreshRemoteRecordings() {
        val pair =
            currentPair ?: return

        runOnUiThread {
            b.recordingsStatus.text =
                "Reading recordings from camera phone…"
        }

        safeNetworkExecute {
            try {
                val raw =
                    getBytes(
                        pair.endpoint(
                            "/recordings"
                        )
                    )
                        .toString(
                            Charsets.UTF_8
                        )

                val root =
                    JSONObject(raw)

                val array =
                    root.optJSONArray(
                        "recordings"
                    )
                        ?: JSONArray()

                val items =
                    mutableListOf<
                        RemoteRecordingItem
                    >()

                for (
                    i in 0 until
                        array.length()
                ) {
                    val item =
                        array.optJSONObject(i)
                            ?: continue

                    val id =
                        item.optString("id")

                    if (id.isBlank()) {
                        continue
                    }

                    items +=
                        RemoteRecordingItem(
                            id = id,
                            name =
                                item.optString(
                                    "name",
                                    "Camera recording"
                                ),
                            sizeBytes =
                                item.optLong(
                                    "sizeBytes",
                                    0L
                                ),
                            durationMs =
                                item.optLong(
                                    "durationMs",
                                    0L
                                ),
                            dateAddedMs =
                                item.optLong(
                                    "dateAddedMs",
                                    0L
                                ),
                            eventFolder =
                                item.optString(
                                    "eventFolder",
                                    "Other"
                                )
                                    .ifBlank {
                                        "Other"
                                    }
                        )
                }

                runOnUiThread {
                    remoteRecordings =
                        sortRemoteRecordings(
                            items
                        )

                    selectedRecordingIds
                        .retainAll(
                            items.map {
                                it.id
                            }.toSet()
                        )

                    val labels =
                        if (items.isEmpty()) {
                            listOf(
                                "No camera recordings"
                            )
                        } else {
                            remoteRecordings.map {
                                recordingSpinnerLabel(
                                    it
                                )
                            }
                        }

                    b.recordingsSpinner.adapter =
                        ArrayAdapter(
                            this,
                            android.R.layout
                                .simple_spinner_dropdown_item,
                            labels
                        )

                    b.recordingsStatus.text =
                        if (items.isEmpty()) {
                            root.optString(
                                "error"
                            )
                                .takeIf {
                                    it.isNotBlank()
                                }
                                ?.let {
                                    "Could not list recordings: $it"
                                }
                                ?: "No saved AI Door Monitor recordings on camera phone."
                        } else {
                            "${items.size} recording(s) available on camera phone."
                        }

                    updateRecordingControls()
                    renderRecordingThumbnailList()

                    if (items.isNotEmpty()) {
                        updateSelectedRecordingInfo(
                            0
                        )
                    }
                }

            } catch (t: Throwable) {
                runOnUiThread {
                    remoteRecordings =
                        emptyList()

                    b.recordingsStatus.text =
                        "Could not read camera recordings: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )

                    updateRecordingControls()
                }
            }
        }
    }

    private fun sortRemoteRecordings(
        items:
            List<RemoteRecordingItem>
    ): List<RemoteRecordingItem> {
        val mode =
            if (
                ::b.isInitialized
            ) {
                b.recordingSort
                    .selectedItemPosition
                    .coerceIn(
                        0,
                        5
                    )
            } else {
                0
            }

        return when (mode) {
            1 ->
                items.sortedBy {
                    it.dateAddedMs
                }

            2 ->
                items.sortedBy {
                    it.name
                        .lowercase(
                            Locale.US
                        )
                }

            3 ->
                items.sortedByDescending {
                    it.name
                        .lowercase(
                            Locale.US
                        )
                }

            4 ->
                items.sortedByDescending {
                    it.durationMs
                }

            5 ->
                items.sortedByDescending {
                    it.sizeBytes
                }

            else ->
                items.sortedByDescending {
                    it.dateAddedMs
                }
        }
    }

    private fun confirmDeleteCheckedRecordings() {
        val items =
            remoteRecordings
                .filter {
                    selectedRecordingIds
                        .contains(
                            it.id
                        )
                }

        if (items.isEmpty()) {
            toast(
                "Check one or more recordings first."
            )
            return
        }

        confirmDeleteRecordings(
            items
        )
    }

    private fun confirmDeleteRecordings(
        items:
            List<RemoteRecordingItem>
    ) {
        if (items.isEmpty()) {
            return
        }

        val message =
            if (
                items.size ==
                1
            ) {
                "Delete ${items.first().name} from the camera phone? This removes the original recording."
            } else {
                "Delete ${items.size} checked recordings from the camera phone? This removes the original recordings."
            }

        androidx.appcompat.app
            .AlertDialog
            .Builder(this)
            .setTitle(
                "Delete camera recording?"
            )
            .setMessage(
                message
            )
            .setNegativeButton(
                "Cancel",
                null
            )
            .setPositiveButton(
                "Delete"
            ) {
                    _,
                    _ ->
                deleteRemoteRecordings(
                    items
                )
            }
            .show()
    }

    private fun deleteRemoteRecordings(
        items:
            List<RemoteRecordingItem>
    ) {
        val pair =
            currentPair
                ?: return

        b.recordingsStatus.text =
            "Deleting ${items.size} recording(s) from camera phone…"

        recordingTransferExecutor.execute {
            var deleted =
                0

            val failed =
                mutableListOf<String>()

            items.forEach {
                    item ->

                var conn:
                    HttpURLConnection? =
                    null

                try {
                    val path =
                        "/recording?id=" +
                            Uri.encode(
                                item.id
                            )

                    conn =
                        URL(
                            pair.endpoint(
                                path
                            )
                        )
                            .openConnection()
                            as HttpURLConnection

                    conn.connectTimeout =
                        8_000
                    conn.readTimeout =
                        12_000
                    conn.useCaches =
                        false
                    conn.requestMethod =
                        "DELETE"
                    conn.connect()

                    if (
                        conn.responseCode
                            in 200..299
                    ) {
                        deleted++
                    } else {
                        failed +=
                            item.name
                    }

                } catch (_: Throwable) {
                    failed +=
                        item.name
                } finally {
                    try {
                        conn?.disconnect()
                    } catch (_: Throwable) {
                    }
                }
            }

            runOnUiThread {
                items.forEach {
                    selectedRecordingIds
                        .remove(
                            it.id
                        )
                }

                b.recordingsStatus.text =
                    buildString {
                        append(
                            "Deleted "
                        )
                        append(
                            deleted
                        )
                        append(
                            " recording(s) from camera phone."
                        )

                        if (
                            failed.isNotEmpty()
                        ) {
                            append(
                                " Failed: "
                            )
                            append(
                                failed.size
                            )
                        }
                    }

                refreshRemoteRecordings()
            }
        }
    }

    private fun renderRecordingThumbnailList() {
        if (!::b.isInitialized) return

        b.recordingsThumbnailList
            .removeAllViews()

        val grouped =
            remoteRecordings
                .groupBy {
                    it.eventFolder
                        .ifBlank {
                            "Other"
                        }
                }

        val folders =
            grouped.keys
                .sortedWith(
                    compareBy<String> {
                        val index =
                            preferredFolderOrder
                                .indexOf(it)

                        if (index >= 0) {
                            index
                        } else {
                            1_000
                        }
                    }.thenBy {
                        it.lowercase(
                            Locale.US
                        )
                    }
                )

        if (folders.isEmpty()) {
            b.recordingsThumbnailList
                .addView(
                    TextView(this).apply {
                        text =
                            "No event folders."
                        setPadding(
                            8,
                            12,
                            8,
                            12
                        )
                    }
                )

            return
        }

        folders.forEach {
                folder ->

            val folderItems =
                sortRemoteRecordings(
                    grouped[
                        folder
                    ].orEmpty()
                )

            val checkedCount =
                folderItems.count {
                    selectedRecordingIds
                        .contains(
                            it.id
                        )
                }

            val expanded =
                openRecordingFolders
                    .contains(
                        folder
                    )

            val header =
                android.widget.Button(
                    this
                ).apply {
                    isAllCaps =
                        false

                    text =
                        buildString {
                            append(
                                if (expanded) {
                                    "📂 "
                                } else {
                                    "📁 "
                                }
                            )
                            append(folder)
                            append(" (")
                            append(
                                folderItems.size
                            )
                            append(")")

                            if (
                                checkedCount >
                                0
                            ) {
                                append(" • ")
                                append(
                                    checkedCount
                                )
                                append(
                                    " checked"
                                )
                            }
                        }

                    setOnClickListener {
                        if (
                            openRecordingFolders
                                .contains(
                                    folder
                                )
                        ) {
                            openRecordingFolders
                                .remove(
                                    folder
                                )
                        } else {
                            openRecordingFolders
                                .add(
                                    folder
                                )
                        }

                        renderRecordingThumbnailList()
                    }
                }

            b.recordingsThumbnailList
                .addView(
                    header
                )

            if (!expanded) {
                return@forEach
            }

            val actions =
                android.widget.LinearLayout(
                    this
                ).apply {
                    orientation =
                        android.widget
                            .LinearLayout
                            .HORIZONTAL

                    setPadding(
                        20,
                        4,
                        0,
                        4
                    )
                }

            val checkFolder =
                android.widget.Button(
                    this
                ).apply {
                    isAllCaps =
                        false
                    text =
                        "Check folder"

                    setOnClickListener {
                        folderItems
                            .forEach {
                                selectedRecordingIds
                                    .add(
                                        it.id
                                    )
                            }

                        updateRecordingSelectionUi()
                        renderRecordingThumbnailList()
                    }
                }

            val clearFolder =
                android.widget.Button(
                    this
                ).apply {
                    isAllCaps =
                        false
                    text =
                        "Clear folder"

                    setOnClickListener {
                        folderItems
                            .forEach {
                                selectedRecordingIds
                                    .remove(
                                        it.id
                                    )
                            }

                        updateRecordingSelectionUi()
                        renderRecordingThumbnailList()
                    }
                }

            actions.addView(
                checkFolder,
                android.widget
                    .LinearLayout
                    .LayoutParams(
                        0,
                        android.widget
                            .LinearLayout
                            .LayoutParams
                            .WRAP_CONTENT,
                        1f
                    )
            )

            actions.addView(
                clearFolder,
                android.widget
                    .LinearLayout
                    .LayoutParams(
                        0,
                        android.widget
                            .LinearLayout
                            .LayoutParams
                            .WRAP_CONTENT,
                        1f
                    )
            )

            b.recordingsThumbnailList
                .addView(
                    actions
                )

            folderItems.forEach {
                    item ->

                val globalIndex =
                    remoteRecordings
                        .indexOfFirst {
                            it.id ==
                                item.id
                        }

                val row =
                    layoutInflater.inflate(
                        R.layout
                            .item_remote_recording,
                        b.recordingsThumbnailList,
                        false
                    )

                row.setPadding(
                    row.paddingLeft +
                        28,
                    row.paddingTop,
                    row.paddingRight,
                    row.paddingBottom
                )

                val image =
                    row.findViewById<ImageView>(
                        R.id.recordingThumbnail
                    )

                val checkbox =
                    row.findViewById<CheckBox>(
                        R.id.recordingCheckbox
                    )

                val title =
                    row.findViewById<TextView>(
                        R.id.recordingItemTitle
                    )

                val meta =
                    row.findViewById<TextView>(
                        R.id.recordingItemMeta
                    )

                title.text =
                    item.name

                val dateText =
                    if (
                        item.dateAddedMs >
                        0L
                    ) {
                        SimpleDateFormat(
                            "yyyy-MM-dd HH:mm:ss",
                            Locale.getDefault()
                        )
                            .format(
                                Date(
                                    item.dateAddedMs
                                )
                            )
                    } else {
                        "Unknown time"
                    }

                meta.text =
                    "$dateText • " +
                        formatDurationMs(
                            item.durationMs
                        ) +
                        " • " +
                        formatFileSize(
                            item.sizeBytes
                        )

                image.tag =
                    item.id

                image.setImageResource(
                    android.R.drawable
                        .ic_menu_gallery
                )

                checkbox.setOnCheckedChangeListener(
                    null
                )

                checkbox.isChecked =
                    selectedRecordingIds
                        .contains(
                            item.id
                        )

                checkbox.setOnCheckedChangeListener {
                        _,
                        checked ->

                    if (checked) {
                        selectedRecordingIds
                            .add(
                                item.id
                            )
                    } else {
                        selectedRecordingIds
                            .remove(
                                item.id
                            )
                    }

                    updateRecordingSelectionUi()
                    renderRecordingThumbnailList()
                }

                row.setOnClickListener {
                    if (
                        globalIndex >=
                        0
                    ) {
                        b.recordingsSpinner
                            .setSelection(
                                globalIndex
                            )

                        updateSelectedRecordingInfo(
                            globalIndex
                        )
                    }

                    // The entire event/recording row now opens playback, not
                    // only the small thumbnail image.
                    playRemoteRecording(item)
                }

                image.setOnClickListener {
                    if (
                        globalIndex >=
                        0
                    ) {
                        b.recordingsSpinner
                            .setSelection(
                                globalIndex
                            )

                        updateSelectedRecordingInfo(
                            globalIndex
                        )
                    }

                    playRemoteRecording(
                        item
                    )
                }

                b.recordingsThumbnailList
                    .addView(
                        row
                    )

                loadRemoteRecordingThumbnail(
                    item,
                    image
                )
            }
        }
    }

    private fun loadRemoteRecordingThumbnail(
        item: RemoteRecordingItem,
        image: ImageView
    ) {
        val pair =
            currentPair ?: return

        recordingThumbnailExecutor.execute {
            var connection:
                HttpURLConnection? =
                null

            try {
                val path =
                    "/recording-thumbnail?id=" +
                        Uri.encode(
                            item.id
                        ) +
                        "&w=320&h=180"

                connection =
                    URL(
                        pair.endpoint(path)
                    )
                        .openConnection()
                        as HttpURLConnection

                connection.connectTimeout =
                    4_000
                connection.readTimeout =
                    8_000
                connection.useCaches =
                    true
                connection.requestMethod =
                    "GET"
                connection.connect()

                if (
                    connection.responseCode
                        !in 200..299
                ) {
                    return@execute
                }

                val bitmap =
                    connection.inputStream
                        .use { input ->
                            BitmapFactory
                                .decodeStream(input)
                        }
                        ?: return@execute

                runOnUiThread {
                    if (
                        image.tag ==
                        item.id
                    ) {
                        image.setImageBitmap(
                            bitmap
                        )
                    } else {
                        try {
                            bitmap.recycle()
                        } catch (_: Throwable) {
                        }
                    }
                }

            } catch (_: Throwable) {
                // Keep the placeholder if a thumbnail cannot be generated.
            } finally {
                try {
                    connection?.disconnect()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun updateRecordingSelectionUi() {
        if (!::b.isInitialized) return

        val checked =
            selectedRecordingIds.size

        b.recordingSelectionStatus.text =
            if (checked == 1) {
                "1 recording checked"
            } else {
                "$checked recordings checked"
            }

        val available =
            connected &&
                remoteRecordings
                    .isNotEmpty()

        b.selectAllRecordings.isEnabled =
            available

        b.clearRecordingSelection.isEnabled =
            checked > 0

        b.downloadCheckedRecordings.isEnabled =
            connected &&
                checked > 0

        b.deleteCheckedRecordings.isEnabled =
            connected &&
                checked > 0

    }

    private fun downloadCheckedRecordings() {
        val items =
            remoteRecordings
                .filter {
                    selectedRecordingIds
                        .contains(
                            it.id
                        )
                }

        if (items.isEmpty()) {
            toast(
                "Check one or more recordings first."
            )
            return
        }

        b.recordingsStatus.text =
            "Queued ${items.size} checked recording(s) for download…"

        items.forEach { item ->
            downloadRemoteRecording(
                item
            )
        }
    }

    private fun recordingSpinnerLabel(
        item: RemoteRecordingItem
    ): String {
        val whenText =
            if (item.dateAddedMs > 0L) {
                SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss",
                    Locale.getDefault()
                )
                    .format(
                        Date(
                            item.dateAddedMs
                        )
                    )
            } else {
                "unknown time"
            }

        return item.name +
            " • " +
            whenText
    }

    private fun updateSelectedRecordingInfo(
        position: Int
    ) {
        val item =
            remoteRecordings
                .getOrNull(position)

        if (item == null) {
            b.selectedRecordingInfo.text =
                "No recording selected."
            return
        }

        val duration =
            formatDurationMs(
                item.durationMs
            )

        val size =
            formatFileSize(
                item.sizeBytes
            )

        val whenText =
            if (item.dateAddedMs > 0L) {
                SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss",
                    Locale.getDefault()
                )
                    .format(
                        Date(
                            item.dateAddedMs
                        )
                    )
            } else {
                "Unknown recording time"
            }

        b.selectedRecordingInfo.text =
            "${item.name}\n$whenText • $duration • $size"
    }

    private fun selectedRemoteRecording():
        RemoteRecordingItem? =
        remoteRecordings
            .getOrNull(
                b.recordingsSpinner
                    .selectedItemPosition
            )

    private fun updateRecordingControls() {
        val available =
            connected &&
                remoteRecordings
                    .isNotEmpty()

        b.recordingsSpinner.isEnabled =
            available
        updateRecordingSelectionUi()

        if (!available) {
            b.selectedRecordingInfo.text =
                if (connected) {
                    "No recording selected."
                } else {
                    "Connect to camera phone first."
                }
        }
    }

    private fun playSelectedRecording() {
        val item =
            selectedRemoteRecording()
                ?: run {
                    toast(
                        "Select a recording first."
                    )
                    return
                }

        playRemoteRecording(
            item
        )
    }

    private fun playRemoteRecording(
        item: RemoteRecordingItem
    ) {
        val pair =
            currentPair ?: return

        val path =
            "/recording?id=" +
                Uri.encode(
                    item.id
                )

        val url =
            pair.endpoint(path)

        val alternateUrls =
            (configuredPair ?: pair)
                .connectionCandidates(preferRemote = !hasUsableWifiNetwork())
                .map { it.endpoint(path) }
                .filter { it != url }
                .distinct()

        pauseMonitorTransportForPlayer()

        recordingPlayerLauncher.launch(
            Intent(
                this,
                RemoteRecordingActivity::class.java
            ).apply {
                putExtra(
                    "recording_url",
                    url
                )
                putExtra(
                    "recording_name",
                    item.name
                )
                putStringArrayListExtra(
                    "recording_alternate_urls",
                    ArrayList(alternateUrls)
                )
            }
        )
    }

    private fun requestDownloadSelectedRecording() {
        val item =
            selectedRemoteRecording()
                ?: run {
                    toast(
                        "Select a recording first."
                    )
                    return
                }

        if (
            Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission
                    .WRITE_EXTERNAL_STORAGE
            ) != PackageManager
                .PERMISSION_GRANTED
        ) {
            pendingRecordingDownloadId =
                item.id

            storagePermission.launch(
                Manifest.permission
                    .WRITE_EXTERNAL_STORAGE
            )
            return
        }

        downloadRemoteRecording(
            item
        )
    }

    private fun downloadRemoteRecording(
        item: RemoteRecordingItem
    ) {
        val pair =
            currentPair ?: return

        b.recordingsStatus.text =
            "Downloading ${item.name}…"

        recordingTransferExecutor.execute {
            var conn:
                HttpURLConnection? =
                null

            var targetUri:
                android.net.Uri? =
                null

            try {
                val path =
                    "/recording?id=" +
                        Uri.encode(
                            item.id
                        )

                conn =
                    URL(
                        pair.endpoint(path)
                    )
                        .openConnection()
                        as HttpURLConnection

                conn.connectTimeout =
                    8_000
                conn.readTimeout =
                    30_000
                conn.useCaches =
                    false
                conn.requestMethod =
                    "GET"
                conn.connect()

                if (
                    conn.responseCode !in
                    200..299
                ) {
                    val error =
                        try {
                            conn.errorStream
                                ?.bufferedReader()
                                ?.use {
                                    it.readText()
                                }
                        } catch (_: Throwable) {
                            null
                        }

                    throw IllegalStateException(
                        "HTTP ${conn.responseCode}" +
                            if (
                                error.isNullOrBlank()
                            ) {
                                ""
                            } else {
                                ": $error"
                            }
                    )
                }

                val safeName =
                    item.name
                        .ifBlank {
                            "AI_Door_Remote_" +
                                System.currentTimeMillis() +
                                ".mp4"
                        }

                val values =
                    ContentValues().apply {
                        put(
                            MediaStore.Video.Media
                                .DISPLAY_NAME,
                            safeName
                        )
                        put(
                            MediaStore.Video.Media
                                .MIME_TYPE,
                            "video/mp4"
                        )

                        if (
                            Build.VERSION.SDK_INT >=
                            Build.VERSION_CODES.Q
                        ) {
                            put(
                                MediaStore.Video.Media
                                    .RELATIVE_PATH,
                                "Movies/AI Door Monitor/Camera Phone"
                            )
                            put(
                                MediaStore.Video.Media
                                    .IS_PENDING,
                                1
                            )
                        }
                    }

                targetUri =
                    contentResolver.insert(
                        MediaStore.Video.Media
                            .EXTERNAL_CONTENT_URI,
                        values
                    )
                        ?: throw IllegalStateException(
                            "Could not create video on monitor phone."
                        )

                val total =
                    if (
                        item.sizeBytes > 0L
                    ) {
                        item.sizeBytes
                    } else {
                        conn.contentLengthLong
                    }

                contentResolver
                    .openOutputStream(
                        targetUri
                    )
                    ?.use { output ->
                        conn.inputStream
                            .use { input ->
                                val buffer =
                                    ByteArray(
                                        256 * 1024
                                    )

                                var copied =
                                    0L

                                var lastUi =
                                    0L

                                while (true) {
                                    val read =
                                        input.read(
                                            buffer
                                        )

                                    if (read < 0) {
                                        break
                                    }

                                    output.write(
                                        buffer,
                                        0,
                                        read
                                    )

                                    copied +=
                                        read.toLong()

                                    val now =
                                        System.currentTimeMillis()

                                    if (
                                        now - lastUi >=
                                        500L
                                    ) {
                                        lastUi = now

                                        val status =
                                            if (total > 0L) {
                                                val pct =
                                                    (
                                                        copied *
                                                        100L /
                                                        total
                                                        )
                                                        .coerceIn(
                                                            0L,
                                                            100L
                                                        )

                                                "Downloading ${item.name} • $pct%"
                                            } else {
                                                "Downloading ${item.name} • ${formatFileSize(copied)}"
                                            }

                                        runOnUiThread {
                                            b.recordingsStatus.text =
                                                status
                                        }
                                    }
                                }

                                output.flush()
                            }
                    }
                        ?: throw IllegalStateException(
                            "Could not write monitor video."
                        )

                if (
                    Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.Q
                ) {
                    val done =
                        ContentValues().apply {
                            put(
                                MediaStore.Video.Media
                                    .IS_PENDING,
                                0
                            )
                        }

                    contentResolver.update(
                        targetUri,
                        done,
                        null,
                        null
                    )
                }

                runOnUiThread {
                    b.recordingsStatus.text =
                        "Saved on monitor phone → Movies/AI Door Monitor/Camera Phone/${item.name}"
                    toast(
                        "Recording saved on monitor phone."
                    )
                }

            } catch (t: Throwable) {
                if (targetUri != null) {
                    try {
                        contentResolver.delete(
                            targetUri,
                            null,
                            null
                        )
                    } catch (_: Throwable) {
                    }
                }

                runOnUiThread {
                    b.recordingsStatus.text =
                        "Recording download failed: " +
                            (
                                t.message
                                    ?: t.javaClass
                                        .simpleName
                                )
                }
            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun formatFileSize(
        bytes: Long
    ): String {
        if (bytes <= 0L) {
            return "unknown size"
        }

        val mb =
            bytes.toDouble() /
                1024.0 /
                1024.0

        return if (mb >= 1024.0) {
            String.format(
                Locale.US,
                "%.2f GB",
                mb / 1024.0
            )
        } else {
            String.format(
                Locale.US,
                "%.1f MB",
                mb
            )
        }
    }

    private fun formatDurationMs(
        durationMs: Long
    ): String {
        if (durationMs <= 0L) {
            return "unknown duration"
        }

        val totalSeconds =
            durationMs / 1_000L

        val hours =
            totalSeconds / 3_600L
        val minutes =
            (
                totalSeconds %
                3_600L
                ) /
                60L
        val seconds =
            totalSeconds %
                60L

        return if (hours > 0L) {
            String.format(
                Locale.US,
                "%d:%02d:%02d",
                hours,
                minutes,
                seconds
            )
        } else {
            String.format(
                Locale.US,
                "%d:%02d",
                minutes,
                seconds
            )
        }
    }

    private fun refreshRemoteEvents() {
        val pair = currentPair ?: return
        safeNetworkExecute {
            try {
                val raw = getBytes(pair.endpoint("/events")).toString(Charsets.UTF_8)
                val arr = JSONObject(raw).optJSONArray("events")
                val lines = mutableListOf<String>()

                if (arr != null) {
                    val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    for (i in 0 until minOf(arr.length(), 15)) {
                        val o = arr.getJSONObject(i)
                        val whenText = fmt.format(Date(o.optLong("timestamp")))
                        val type = o.optString("type")
                        val details = o.optString("details")
                        lines += "$whenText • $type" +
                            if (details.isBlank()) "" else " • $details"
                    }
                }

                runOnUiThread {
                    b.remoteEvents.text =
                        if (lines.isEmpty()) "No saved camera events."
                        else lines.joinToString("\n")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.remoteEvents.text = "Could not read event log: ${e.message}"
                }
            }
        }
    }

    private fun saveSnapshot() {
        if (lastVisualStreamAvailable == false) {
            toast(
                "No live visual frame is available in Recording-First mode."
            )
            return
        }

        val pair = currentPair ?: return

        b.saveInfo.text = "Saving snapshot…"

        safeNetworkExecute {
            try {
                val jpeg = getBytes(pair.endpoint("/snapshot"))

                val name = "AI_Door_Monitor_" +
                    SimpleDateFormat("dd.MM.yyyy_'kl'_HH.mm.ss", Locale.US)
                        .format(System.currentTimeMillis()) +
                    ".jpg"

                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(
                            MediaStore.Images.Media.RELATIVE_PATH,
                            "Pictures/AI Door Monitor"
                        )
                    }
                }

                val uri = contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    values
                ) ?: throw IllegalStateException("MediaStore insert failed")

                contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(jpeg)
                } ?: throw IllegalStateException("Could not open MediaStore output")

                runOnUiThread {
                    b.saveInfo.text =
                        "Snapshot saved on monitor phone → Gallery/Pictures/AI Door Monitor"
                    toast("Snapshot saved.")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.saveInfo.text = "Snapshot save failed: ${e.message}"
                }
            }
        }
    }

    private fun getBytes(url: String): ByteArray {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 6_000
            conn.readTimeout = 10_000
            conn.useCaches = false
            conn.requestMethod = "GET"
            conn.connect()

            if (conn.responseCode !in 200..299) {
                val body = try {
                    conn.errorStream?.readBytes()?.toString(Charsets.UTF_8)
                } catch (_: Exception) {
                    null
                }
                throw IllegalStateException(
                    "HTTP ${conn.responseCode}${body?.let { ": $it" } ?: ""}"
                )
            }

            return conn.inputStream.use { it.readBytes() }
        } finally {
            conn.disconnect()
        }
    }

    private fun startTalkback() {
        val pair = currentPair ?: run {
            toast("Connect to the camera first.")
            return
        }
        val ok = talkbackSender.start(pair) { state ->
            runOnUiThread {
                b.talkStatus.text = state
                b.talkButton.text = if (talkbackSender.isRunning()) "STOP TALKING" else "START TALK TO DOOR"
            }
        }
        if (ok) {
            b.talkButton.text = "STOP TALKING"
            b.talkStatus.text = "Talk: ON"
        }
    }

    private fun stopTalkback() {
        talkbackSender.stop()
        b.talkButton.text = "START TALK TO DOOR"
        b.talkStatus.text = "Talk: OFF"
    }

    private fun handleDoorbellLaunchIntent(source: Intent?) {
        if (source?.getBooleanExtra("doorbell_auto_live", false) != true) return
        pendingDoorbellAutoLive = true
        pendingDoorbellAutoTalk = source.getBooleanExtra("doorbell_auto_talk", true)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        val prefs = getSharedPreferences("monitor_pair", MODE_PRIVATE)
        prefs.edit().putBoolean("keep_monitor_connected", true).apply()
    }

    private fun enterDoorbellLiveMode() {
        if (!connected) return
        pendingDoorbellAutoLive = false
        b.liveAudioEnabled.isChecked = true
        if (!liveViewerFullscreen) {
            enterLiveViewerFullscreen()
        }

        if (pendingDoorbellAutoTalk) {
            pendingDoorbellAutoTalk = false
            if (!talkbackSender.isRunning()) {
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    startTalkback()
                } else {
                    monitorMicPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDoorbellLaunchIntent(intent)
        if (pendingDoorbellAutoLive) {
            if (connected) {
                enterDoorbellLiveMode()
            } else if (!connectionAttemptInProgress) {
                connectFromField()
            }
        }
    }

    private fun handleDoorbellStatus(sequence: Long, pressedAtMs: Long, source: String) {
        if (lastDoorbellSequence < 0L) {
            lastDoorbellSequence = sequence
            lastDoorbellPressedAtMs = pressedAtMs
            lastDoorbellSource = source
            return
        }

        if (sequence <= lastDoorbellSequence) return
        lastDoorbellSequence = sequence
        lastDoorbellPressedAtMs = pressedAtMs
        lastDoorbellSource = source

        val timeText = if (pressedAtMs > 0L) {
            SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(Date(pressedAtMs))
        } else {
            "now"
        }

        val sourceText = when {
            source.contains("double", true) -> "visitor double-tapped camera phone"
            source.contains("triple", true) -> "visitor triple-tapped camera phone"
            else -> "visitor pressed camera screen"
        }
        b.connectionState.text = "DOORBELL • $sourceText at $timeText"
        showDoorbellNotification(timeText)
    }

    private fun ensureDoorbellNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            "doorbell_alerts",
            "Doorbell alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alerts when the camera phone screen is used as a doorbell button"
            enableVibration(true)
        }
        manager.createNotificationChannel(channel)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                52016
            )
        }
    }

    private fun showDoorbellNotification(timeText: String) {
        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        val openMonitor = PendingIntent.getActivity(
            this,
            52016,
            Intent(this, MonitorActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("doorbell_auto_live", true)
                putExtra("doorbell_auto_talk", true)
                putExtra("doorbell_wake_screen", true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, "doorbell_alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Doorbell")
            .setContentText("Someone pressed the camera phone screen • $timeText")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setAutoCancel(true)
            .setContentIntent(openMonitor)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            .setVibrate(longArrayOf(0, 250, 140, 400))
            .build()

        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(52016, notification)
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onResume() {
        super.onResume()

        if (monitorTransportPausedForPlayer) {
            return
        }

        if (pendingDoorbellAutoLive && connected) {
            enterDoorbellLiveMode()
        }

        val prefs =
            getSharedPreferences(
                "monitor_pair",
                MODE_PRIVATE
            )

        if (
            connected
        ) {
            resumeMonitorTransportAfterPlayer()
        } else if (
            !connectionAttemptInProgress &&
            prefs.getBoolean(
                "keep_monitor_connected",
                false
            )
        ) {
            val raw =
                prefs.getString(
                    "last_pair",
                    ""
                )
                    .orEmpty()

            if (
                raw.isNotBlank()
            ) {
                b.pairingCode.setText(
                    raw
                )

                connectFromField()
            }
        }
    }

    override fun onDestroy() {
        activityDestroyed = true
        if (liveViewerFullscreen) {
            WindowCompat.getInsetsController(
                window,
                b.monitorRoot
            ).show(WindowInsetsCompat.Type.systemBars())
        }

        stopConnectionHealthPolling()
        liveAudioPlayer.stop()
        talkbackSender.stop()
        b.liveView.stop()
        networkExecutor.shutdownNow()
        recordingTransferExecutor.shutdownNow()
        recordingThumbnailExecutor.shutdownNow()
        super.onDestroy()
    }
}
