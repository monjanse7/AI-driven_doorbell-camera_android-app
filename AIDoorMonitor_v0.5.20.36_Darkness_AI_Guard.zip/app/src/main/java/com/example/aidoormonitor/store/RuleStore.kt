package com.example.aidoormonitor.store

import android.content.Context
import com.example.aidoormonitor.model.AiRule
import com.example.aidoormonitor.model.BuiltInRules
import com.example.aidoormonitor.model.RuleType
import org.json.JSONArray
import org.json.JSONObject

class RuleStore(context: Context) {
    private val retiredRuleIds = setOf("elephant", "bear", "zebra", "giraffe")
    private val prefs = context.getSharedPreferences("ai_rules", Context.MODE_PRIVATE)

    fun load(): MutableList<AiRule> {
        val raw = prefs.getString("rules", null) ?: return BuiltInRules.defaults().also { save(it) }
        return try {
            val arr = JSONArray(raw)
            val loaded = MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                AiRule(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    enabled = o.getBoolean("enabled"),
                    type = RuleType.valueOf(o.getString("type")),
                    signal = o.getString("signal"),
                    confidence = o.getInt("confidence"),
                    minDurationMs = o.optLong("minDurationMs", 0L),
                    notes = o.optString("notes", "")
                )
            }

            // Merge newly introduced built-in rules on app upgrades without
            // overwriting the user's existing rule settings.
            // v0.5.20.35: permanently remove retired classes even from an
            // existing installation whose JSON still contains old built-ins.
            loaded.removeAll { it.id in retiredRuleIds }

            val existingIds = loaded.map { it.id }.toMutableSet()
            BuiltInRules.defaults().forEach { builtIn ->
                if (builtIn.id !in existingIds) {
                    loaded.add(builtIn)
                    existingIds.add(builtIn.id)
                }
            }
            save(loaded)
            loaded
        } catch (_: Exception) {
            BuiltInRules.defaults().also { save(it) }
        }
    }

    fun save(rules: List<AiRule>) {
        val arr = JSONArray()
        rules.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("name", r.name)
                put("enabled", r.enabled)
                put("type", r.type.name)
                put("signal", r.signal)
                put("confidence", r.confidence)
                put("minDurationMs", r.minDurationMs)
                put("notes", r.notes)
            })
        }
        prefs.edit().putString("rules", arr.toString()).apply()
    }
}
