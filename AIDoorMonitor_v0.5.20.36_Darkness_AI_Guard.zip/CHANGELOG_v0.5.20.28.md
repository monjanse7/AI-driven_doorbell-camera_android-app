# v0.5.20.28 — Wide Companion Rescue

- Adds a wide tiled small-pet rescue every third rescue cycle when Person is visible but Dog is missing.
- Keeps the tight owner-centred companion crop on the other rescue cycles.
- Allows dogs several metres to the side/ahead/behind an owner to be recovered instead of assuming the dog is at the person's feet.
- Adds distinct dog counting and live event labels such as `Person_x1 + Dog_x1` when both are supported.
- Active event labels can upgrade after recording has already started when a later dog detection is confirmed.
- Retains terrace/balcony rescue, other-animal detection, loose-dog candidate logic and Critical = AI FULL behavior.
