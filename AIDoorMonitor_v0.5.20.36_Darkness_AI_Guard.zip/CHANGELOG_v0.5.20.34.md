# v0.5.20.34 — Terrace Person Rescue

- Fixed a concrete bug where `analyzeTerraceBand()` could detect a person but then discarded the result because the terrace filter only allowed animal classes.
- Terrace/balcony rescue now accepts `person` in addition to animals.
- Strong terrace-person detections can be promoted immediately; weaker ones use temporal confirmation with a lower terrace-specific floor.
- During an active unidentified-motion event, rescue cycles now alternate between very-close-person rescue and terrace/balcony rescue so distant balcony visitors are not starved.
- Keeps the aggressive dog/edge-companion scan and all v0.5.20.33 features.
