# v0.5.20.36 — Darkness AI Guard

- Automatically pauses visual/object AI when the camera image is too dark for reliable classification.
- Uses sparse frame luminance plus usable-image-area measurement so isolated lights do not keep object AI active.
- Pause threshold: 8%, sustained for 3 seconds.
- Resume threshold: 13%, sustained for 2 seconds (hysteresis prevents rapid toggling).
- Audio AI remains active while visual AI is paused.
- DVR recording and event pre-record buffer remain active.
- `/health` exposes darkness pause state, measured brightness and thresholds.
- Live monitor Object AI status reports `PAUSED • TOO DARK` and current brightness.
- Critical thermal mode still keeps AI FULL whenever the scene is bright enough for visual AI.
