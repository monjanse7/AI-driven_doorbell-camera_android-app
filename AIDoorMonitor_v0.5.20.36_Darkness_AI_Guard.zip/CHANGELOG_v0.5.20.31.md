# v0.5.20.32

- Adds a stronger very-close Person/Dog/Cat rescue path for visitors filling or clipping the camera frame.
- Adds fully local, user-enrolled face profile matching. Profiles can be scanned from the current live camera frame, renamed, listed and deleted from the monitor phone.
- Recognized face names are shown as convenience labels alongside Person events. Face matching is conservative and must not be treated as proof of identity.
- Adds user-taught visual labels for unidentified motion. Select a recording, type what it was, and teach the camera; later visually similar otherwise-unidentified events can reuse that label.
- Face templates and learned visual descriptors are stored only in camera-phone app preferences and are never uploaded by this feature.
- Keeps v0.5.20.30 audio-guided multi-dog rescue, instant doorbell, auto talkback, vehicle motion filtering, animal rescue and Critical = AI FULL behavior.
