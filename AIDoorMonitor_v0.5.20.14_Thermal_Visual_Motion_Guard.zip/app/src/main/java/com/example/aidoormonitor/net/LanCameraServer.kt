package com.example.aidoormonitor.net

import android.content.Context
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class LanCameraServer(
    private val context: Context,
    private val port: Int,
    private val token: String,
    private val latestJpeg: AtomicReference<ByteArray?>,
    private val latestAudioPacket:
        AtomicReference<LiveAudioPacket?>,
    private val statusJson: () -> String,
    private val eventsJson: () -> String,
    private val recordingsJson: () -> String,
    private val openRecording: (String) -> RemoteRecordingSource?,
    private val recordingThumbnailJpeg:
        (String, Int, Int) -> ByteArray?,
    private val deleteRecording:
        (String) -> Boolean,
    private val remoteDvrSettingsJson:
        () -> String,
    private val applyRemoteDvrSettings:
        (
            Int?,
            Int?,
            Int?,
            Int?,
            Int?
        ) -> String,
    private val onRestartCameraApp:
        () -> String,
    private val onZoom: (Float) -> Unit,
    private val onCameraView: (Float, Float, Float) -> Unit,
    private val onPreviewQuality: (Int) -> Unit,
    private val onFocusAuto: () -> Unit,
    private val onFocusManual: (Float) -> Unit,
    private val onFocusSave: () -> Unit,
    private val onRecordStart: () -> Unit,
    private val onRecordStop: () -> Unit
) {
    @Volatile
    private var running = false

    @Volatile
    private var lastStartError: String? = null

    private var serverSocket: ServerSocket? = null

    private var clientPool =
        Executors.newCachedThreadPool()

    private var acceptThread: Thread? = null

    @Synchronized
    fun start(): Boolean {
        if (
            running &&
            serverSocket?.isBound == true &&
            serverSocket?.isClosed == false
        ) {
            return true
        }

        lastStartError = null

        if (clientPool.isShutdown) {
            clientPool =
                Executors.newCachedThreadPool()
        }

        val socket =
            ServerSocket()

        return try {
            // Important: set reuse BEFORE bind. The foreground service takes
            // over the same port immediately after CameraActivity releases it.
            socket.reuseAddress =
                true

            socket.bind(
                InetSocketAddress(
                    port
                )
            )

            serverSocket =
                socket

            running =
                true

            acceptThread =
                Thread {
                    try {
                        while (running) {
                            val accepted =
                                try {
                                    serverSocket
                                        ?.accept()
                                } catch (_: Exception) {
                                    null
                                }
                                    ?: break

                            try {
                                clientPool.execute {
                                    try {
                                        handleClient(
                                            accepted
                                        )
                                    } catch (_: Throwable) {
                                        try {
                                            accepted.close()
                                        } catch (_: Exception) {}
                                    }
                                }
                            } catch (_: Throwable) {
                                try {
                                    accepted.close()
                                } catch (_: Exception) {}
                            }
                        }
                    } finally {
                        running =
                            false
                    }
                }
                    .apply {
                        name =
                            "AI-Door-LAN-Acceptor"

                        isDaemon =
                            true

                        start()
                    }

            true

        } catch (t: Throwable) {
            lastStartError =
                t.message
                    ?: t.javaClass.simpleName

            running =
                false

            try {
                socket.close()
            } catch (_: Exception) {}

            serverSocket =
                null

            false
        }
    }

    fun isRunning(): Boolean =
        running &&
            serverSocket?.isBound == true &&
            serverSocket?.isClosed == false

    fun startError(): String? =
        lastStartError

    @Synchronized
    fun stop() {
        running = false

        try {
            serverSocket?.close()
        } catch (_: Exception) {}

        serverSocket = null

        try {
            clientPool.shutdownNow()
        } catch (_: Exception) {}
    }

    private fun handleClient(socket: Socket) {
        socket.tcpNoDelay = true
        socket.soTimeout = 10_000

        val input = BufferedInputStream(socket.getInputStream(), 16 * 1024)
        val output = BufferedOutputStream(socket.getOutputStream(), 64 * 1024)

        val requestLine = readAsciiLine(input) ?: run {
            socket.close()
            return
        }

        val parts = requestLine.split(" ")
        if (
            parts.size < 2 ||
            (
                parts[0] != "GET" &&
                parts[0] != "HEAD" &&
                parts[0] != "DELETE" &&
                parts[0] != "POST"
            )
        ) {
            writeText(output, 405, "Method Not Allowed")
            socket.close()
            return
        }

        val method = parts[0]
        val headers =
            mutableMapOf<String, String>()

        while (true) {
            val line = readAsciiLine(input) ?: break
            if (line.isEmpty()) break

            val separator =
                line.indexOf(':')

            if (separator > 0) {
                headers[
                    line.substring(
                        0,
                        separator
                    )
                        .trim()
                        .lowercase()
                ] =
                    line.substring(
                        separator + 1
                    )
                        .trim()
            }
        }

        val uri = try {
            URI("http://localhost${parts[1]}")
        } catch (_: Exception) {
            writeText(output, 400, "Bad Request")
            socket.close()
            return
        }

        val query = parseQuery(uri.rawQuery.orEmpty())
        if (query["token"] != token) {
            writeText(output, 403, "Pairing token rejected")
            socket.close()
            return
        }

        when (uri.path) {
            "/audio-stream" -> {
                streamLiveAudio(
                    socket,
                    output
                )
            }

            "/health" -> {
                writeJson(output, 200, healthJsonWithNetworkRoutes())
                socket.close()
            }

            "/events" -> {
                writeJson(output, 200, eventsJson())
                socket.close()
            }

            "/recordings" -> {
                writeJson(
                    output,
                    200,
                    recordingsJson()
                )
                socket.close()
            }

            "/recording-thumbnail" -> {
                val id =
                    query["id"]

                if (id.isNullOrBlank()) {
                    writeText(
                        output,
                        400,
                        "Missing recording id"
                    )
                    socket.close()
                } else {
                    val width =
                        query["w"]
                            ?.toIntOrNull()
                            ?.coerceIn(
                                120,
                                640
                            )
                            ?: 320

                    val height =
                        query["h"]
                            ?.toIntOrNull()
                            ?.coerceIn(
                                68,
                                360
                            )
                            ?: 180

                    val jpeg =
                        try {
                            recordingThumbnailJpeg(
                                id,
                                width,
                                height
                            )
                        } catch (_: Throwable) {
                            null
                        }

                    if (jpeg == null) {
                        writeText(
                            output,
                            404,
                            "Thumbnail unavailable"
                        )
                    } else {
                        writeBinary(
                            output,
                            200,
                            "image/jpeg",
                            jpeg
                        )
                    }

                    socket.close()
                }
            }

            "/recording" -> {
                val id =
                    query["id"]

                if (id.isNullOrBlank()) {
                    writeText(
                        output,
                        400,
                        "Missing recording id"
                    )
                    socket.close()
                } else if (
                    method ==
                    "DELETE"
                ) {
                    val deleted =
                        try {
                            deleteRecording(
                                id
                            )
                        } catch (_: Throwable) {
                            false
                        }

                    if (deleted) {
                        writeJson(
                            output,
                            200,
                            """{"ok":true,"deleted":true,"id":"$id"}"""
                        )
                    } else {
                        writeText(
                            output,
                            404,
                            "Recording not found or could not be deleted"
                        )
                    }

                    socket.close()
                } else {
                    val source =
                        try {
                            openRecording(id)
                        } catch (_: Throwable) {
                            null
                        }

                    if (source == null) {
                        writeText(
                            output,
                            404,
                            "Recording not found"
                        )
                        socket.close()
                    } else {
                        streamRecording(
                            socket = socket,
                            out = output,
                            source = source,
                            rangeHeader =
                                headers["range"],
                            headOnly =
                                method == "HEAD"
                        )
                    }
                }
            }

            "/snapshot" -> {
                val jpeg = latestJpeg.get()
                if (jpeg == null) writeText(output, 503, "No camera frame yet")
                else writeBinary(output, 200, "image/jpeg", jpeg)
                socket.close()
            }

            "/dvr-settings" -> {
                if (
                    method ==
                    "GET"
                ) {
                    writeJson(
                        output,
                        200,
                        remoteDvrSettingsJson()
                    )
                } else if (
                    method ==
                    "POST"
                ) {
                    writeJson(
                        output,
                        200,
                        applyRemoteDvrSettings(
                            query[
                                "quality"
                            ]?.toIntOrNull(),
                            query[
                                "videoBitrateMbps"
                            ]?.toIntOrNull(),
                            query[
                                "audioBitrateKbps"
                            ]?.toIntOrNull(),
                            query[
                                "audioSampleRateHz"
                            ]?.toIntOrNull(),
                            query[
                                "audioSyncMs"
                            ]?.toIntOrNull()
                        )
                    )
                } else {
                    writeText(
                        output,
                        405,
                        "Method Not Allowed"
                    )
                }

                socket.close()
            }

            "/app/restart" -> {
                if (
                    method != "GET" &&
                    method != "POST"
                ) {
                    writeText(
                        output,
                        405,
                        "Method Not Allowed"
                    )
                } else {
                    val result =
                        try {
                            onRestartCameraApp()
                        } catch (t: Throwable) {
                            val reason =
                                (
                                    t.message
                                        ?: t.javaClass.simpleName
                                )
                                    .replace("\\", "/")
                                    .replace("\"", "'")

                            """{"ok":false,"supported":true,"reason":"$reason"}"""
                        }

                    writeJson(
                        output,
                        202,
                        result
                    )
                }

                socket.close()
            }

            "/zoom" -> {
                val linear = query["linear"]?.toFloatOrNull()?.coerceIn(0f, 1f)
                if (linear == null) writeText(output, 400, "Missing linear zoom")
                else {
                    onZoom(linear)
                    writeJson(output, 200, """{"ok":true,"linear":$linear}""")
                }
                socket.close()
            }

            "/view" -> {
                val linear =
                    query["linear"]?.toFloatOrNull()?.coerceIn(0f, 1f)
                val panX =
                    query["panX"]?.toFloatOrNull()?.coerceIn(-1f, 1f)
                val panY =
                    query["panY"]?.toFloatOrNull()?.coerceIn(-1f, 1f)

                if (linear == null || panX == null || panY == null) {
                    writeText(output, 400, "Missing linear/panX/panY")
                } else {
                    onCameraView(linear, panX, panY)
                    writeJson(
                        output,
                        200,
                        """{"ok":true,"linear":$linear,"panX":$panX,"panY":$panY}"""
                    )
                }
                socket.close()
            }

            "/preview" -> {
                val mode =
                    query["mode"]?.toIntOrNull()?.coerceIn(0, 4)

                if (mode == null) {
                    writeText(output, 400, "Missing preview quality mode")
                } else {
                    onPreviewQuality(mode)
                    writeJson(
                        output,
                        200,
                        """{"ok":true,"previewQualityMode":$mode}"""
                    )
                }
                socket.close()
            }

            "/focus" -> {
                when (query["mode"]) {
                    "auto" -> {
                        onFocusAuto()
                        writeJson(output, 200, """{"ok":true,"focus":"auto"}""")
                    }
                    "manual" -> {
                        val linear = query["linear"]?.toFloatOrNull()?.coerceIn(0f, 1f)
                        if (linear == null) {
                            writeText(output, 400, "Missing manual focus linear value")
                        } else {
                            onFocusManual(linear)
                            writeJson(output, 200, """{"ok":true,"focus":"manual","linear":$linear}""")
                        }
                    }
                    else -> writeText(output, 400, "Missing focus mode")
                }
                socket.close()
            }

            "/focus/save" -> {
                onFocusSave()
                writeJson(output, 200, """{"ok":true,"saved":true}""")
                socket.close()
            }

            "/record/start" -> {
                onRecordStart()
                writeJson(output, 202, """{"ok":true,"action":"record_start"}""")
                socket.close()
            }

            "/record/stop" -> {
                onRecordStop()
                writeJson(output, 202, """{"ok":true,"action":"record_stop"}""")
                socket.close()
            }

            "/stream" -> streamMjpeg(socket, output)

            else -> {
                writeText(output, 404, "Not Found")
                socket.close()
            }
        }
    }

    private data class ByteRange(
        val start: Long,
        val endInclusive: Long
    )

    private fun parseByteRange(
        raw: String?,
        size: Long
    ): ByteRange? {
        if (
            raw.isNullOrBlank() ||
            !raw.startsWith(
                "bytes=",
                ignoreCase = true
            )
        ) {
            return null
        }

        val value =
            raw.substringAfter('=')
                .substringBefore(',')
                .trim()

        val dash =
            value.indexOf('-')

        if (dash < 0) {
            return null
        }

        val left =
            value.substring(
                0,
                dash
            )
                .trim()

        val right =
            value.substring(
                dash + 1
            )
                .trim()

        if (left.isBlank()) {
            val suffix =
                right.toLongOrNull()
                    ?: return null

            if (suffix <= 0L) {
                return null
            }

            val length =
                suffix.coerceAtMost(size)

            return ByteRange(
                start =
                    (size - length)
                        .coerceAtLeast(0L),
                endInclusive =
                    (size - 1L)
                        .coerceAtLeast(0L)
            )
        }

        val start =
            left.toLongOrNull()
                ?: return null

        if (
            start < 0L ||
            start >= size
        ) {
            return ByteRange(
                start = size,
                endInclusive = size
            )
        }

        val requestedEnd =
            if (right.isBlank()) {
                size - 1L
            } else {
                right.toLongOrNull()
                    ?: return null
            }

        val end =
            requestedEnd
                .coerceAtMost(
                    size - 1L
                )

        if (end < start) {
            return ByteRange(
                start = size,
                endInclusive = size
            )
        }

        return ByteRange(
            start = start,
            endInclusive = end
        )
    }

    private fun streamRecording(
        socket: Socket,
        out: BufferedOutputStream,
        source: RemoteRecordingSource,
        rangeHeader: String?,
        headOnly: Boolean
    ) {
        socket.soTimeout = 0

        val size =
            source.sizeBytes
                .coerceAtLeast(0L)

        if (size <= 0L) {
            writeText(
                out,
                503,
                "Recording size unavailable"
            )
            try {
                socket.close()
            } catch (_: Throwable) {
            }
            return
        }

        val requested =
            parseByteRange(
                rangeHeader,
                size
            )

        if (
            requested != null &&
            requested.start >= size
        ) {
            val header =
                buildString {
                    append(
                        "HTTP/1.1 416 Range Not Satisfiable\r\n"
                    )
                    append(
                        "Content-Range: bytes */$size\r\n"
                    )
                    append(
                        "Content-Length: 0\r\n"
                    )
                    append(
                        "Connection: close\r\n\r\n"
                    )
                }

            out.write(
                header.toByteArray(
                    StandardCharsets.US_ASCII
                )
            )
            out.flush()

            try {
                socket.close()
            } catch (_: Throwable) {
            }
            return
        }

        val range =
            requested
                ?: ByteRange(
                    0L,
                    size - 1L
                )

        val partial =
            requested != null

        val length =
            range.endInclusive -
                range.start +
                1L

        val encodedName =
            URLEncoder.encode(
                source.displayName,
                StandardCharsets.UTF_8.name()
            )
                .replace(
                    "+",
                    "%20"
                )

        val header =
            buildString {
                append(
                    if (partial) {
                        "HTTP/1.1 206 Partial Content\r\n"
                    } else {
                        "HTTP/1.1 200 OK\r\n"
                    }
                )

                append(
                    "Content-Type: ${source.mimeType}\r\n"
                )
                append(
                    "Content-Length: $length\r\n"
                )
                append(
                    "Accept-Ranges: bytes\r\n"
                )

                if (partial) {
                    append(
                        "Content-Range: bytes ${range.start}-${range.endInclusive}/$size\r\n"
                    )
                }

                append(
                    "Content-Disposition: inline; filename*=UTF-8''$encodedName\r\n"
                )
                append(
                    "Cache-Control: private, no-store\r\n"
                )
                append(
                    "Connection: close\r\n\r\n"
                )
            }

        try {
            out.write(
                header.toByteArray(
                    StandardCharsets.US_ASCII
                )
            )

            if (!headOnly) {
                source.openInputStream(
                    range.start
                ).use { input ->
                    val buffer =
                        ByteArray(
                            256 * 1024
                        )

                    var remaining =
                        length

                    while (remaining > 0L) {
                        val wanted =
                            minOf(
                                buffer.size.toLong(),
                                remaining
                            )
                                .toInt()

                        val read =
                            input.read(
                                buffer,
                                0,
                                wanted
                            )

                        if (read < 0) {
                            break
                        }

                        out.write(
                            buffer,
                            0,
                            read
                        )

                        remaining -=
                            read.toLong()
                    }
                }
            }

            out.flush()

        } catch (_: Throwable) {
        } finally {
            try {
                socket.close()
            } catch (_: Throwable) {
            }
        }
    }


    /**
     * Advertise both the current home-LAN address and the current Tailscale
     * address on every health reply. The monitor stores the VPN address while
     * it is still at home, so later mobile-data connections do not depend on
     * the QR having been regenerated at exactly the right time.
     */
    private fun healthJsonWithNetworkRoutes(): String {
        val raw = statusJson()
        return try {
            val json = JSONObject(raw)
            val lanHost = LocalNetwork.bestIpv4Address()
            val remoteHost = LocalNetwork.bestTailscaleIpv4Address(context)

            if (lanHost.isNullOrBlank()) {
                json.put("lanHost", JSONObject.NULL)
            } else {
                json.put("lanHost", lanHost)
            }

            if (remoteHost.isNullOrBlank()) {
                json.put("remoteHost", JSONObject.NULL)
            } else {
                json.put("remoteHost", remoteHost)
            }

            json.put("remoteAccessReady", !remoteHost.isNullOrBlank())
            json.put("serverPort", port)
            json.toString()
        } catch (_: Throwable) {
            raw
        }
    }

    private fun streamLiveAudio(
        socket: Socket,
        out: BufferedOutputStream
    ) {
        socket.soTimeout =
            0

        // Wait briefly for the shared AudioRecord engine to publish its first
        // packet. This avoids opening a second microphone just for live view.
        val waitUntil =
            System.currentTimeMillis() +
                5_000L

        var first =
            latestAudioPacket.get()

        while (
            running &&
            !socket.isClosed &&
            first == null &&
            System.currentTimeMillis() <
            waitUntil
        ) {
            Thread.sleep(
                10L
            )

            first =
                latestAudioPacket.get()
        }

        val initial =
            first

        if (initial == null) {
            writeText(
                out,
                503,
                "Live audio unavailable"
            )

            try {
                socket.close()
            } catch (_: Throwable) {
            }

            return
        }

        val sampleRate =
            initial.sampleRate
                .coerceAtLeast(
                    8_000
                )

        val channels =
            initial.channelCount
                .coerceAtLeast(
                    1
                )

        val header =
            buildString {
                append(
                    "HTTP/1.1 200 OK\r\n"
                )
                append(
                    "Cache-Control: no-cache, no-store, must-revalidate\r\n"
                )
                append(
                    "Pragma: no-cache\r\n"
                )
                append(
                    "Connection: close\r\n"
                )
                append(
                    "Content-Type: application/octet-stream\r\n"
                )
                append(
                    "X-Audio-Format: PCM_S16LE\r\n"
                )
                append(
                    "X-Audio-Sample-Rate: $sampleRate\r\n"
                )
                append(
                    "X-Audio-Channels: $channels\r\n"
                )
                append(
                    "\r\n"
                )
            }

        out.write(
            header.toByteArray(
                StandardCharsets.US_ASCII
            )
        )

        out.flush()

        var lastSequence =
            initial.sequence -
                1L

        try {
            while (
                running &&
                !socket.isClosed
            ) {
                val packet =
                    latestAudioPacket.get()

                if (
                    packet == null ||
                    packet.sequence <=
                    lastSequence
                ) {
                    Thread.sleep(
                        2L
                    )
                    continue
                }

                // A remote audio-quality restart can change sample rate.
                // End this HTTP stream so the monitor reconnects and reads the
                // new format headers instead of playing PCM at the old rate.
                if (
                    packet.sampleRate !=
                    sampleRate ||
                    packet.channelCount !=
                    channels
                ) {
                    break
                }

                val skipped =
                    (
                        packet.sequence -
                            lastSequence -
                            1L
                        )
                        .coerceIn(
                            0L,
                            5L
                        )
                        .toInt()

                // latestAudioPacket intentionally keeps only the newest block.
                // If Wi-Fi stalls long enough to skip one producer block,
                // insert equal-duration silence so the audio clock does not
                // suddenly run ahead of the live video.
                if (skipped > 0) {
                    val silence =
                        ByteArray(
                            packet.pcm16le.size
                        )

                    repeat(
                        skipped
                    ) {
                        out.write(
                            silence
                        )
                    }
                }

                out.write(
                    packet.pcm16le
                )

                out.flush()

                lastSequence =
                    packet.sequence
            }

        } catch (_: Throwable) {
        } finally {
            try {
                socket.close()
            } catch (_: Throwable) {
            }
        }
    }

    private fun streamMjpeg(
        socket: Socket,
        out: BufferedOutputStream
    ) {
        socket.soTimeout = 0

        val header = buildString {
            append("HTTP/1.1 200 OK\r\n")
            append("Cache-Control: no-cache, no-store, must-revalidate\r\n")
            append("Pragma: no-cache\r\n")
            append("Connection: close\r\n")
            append(
                "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n\r\n"
            )
        }

        out.write(
            header.toByteArray(
                StandardCharsets.US_ASCII
            )
        )
        out.flush()

        // Important: latestJpeg is replaced only when CameraX produced a new
        // real frame. Do not resend the same ByteArray object just to make an
        // artificial 30-fps packet count.
        var lastSentFrame: ByteArray? = null
        var lastSendNs = 0L
        val minimumFrameIntervalNs =
            1_000_000_000L / 30L

        try {
            while (running && !socket.isClosed) {
                var candidate = latestJpeg.get()

                if (candidate == null ||
                    candidate === lastSentFrame
                ) {
                    Thread.sleep(2L)
                    continue
                }

                // Cap network delivery at ~30 fps while always preferring the
                // newest available CameraX frame.
                val now = System.nanoTime()
                val remaining =
                    minimumFrameIntervalNs -
                        (now - lastSendNs)

                if (lastSendNs != 0L &&
                    remaining > 0L
                ) {
                    val sleepMs =
                        (remaining / 1_000_000L)
                            .coerceAtLeast(1L)

                    Thread.sleep(sleepMs)

                    // Re-read after the pacing wait so we send the freshest
                    // CameraX frame available.
                    val newer = latestJpeg.get()
                    if (newer != null) {
                        candidate = newer
                    }

                    if (candidate === lastSentFrame) {
                        continue
                    }
                }

                // candidate is still ByteArray? because it is mutable. Freeze
                // it into a non-null local value before using .size/write().
                val frame: ByteArray = candidate ?: continue

                if (frame === lastSentFrame) {
                    continue
                }

                val partHeader = buildString {
                    append("--frame\r\n")
                    append("Content-Type: image/jpeg\r\n")
                    append(
                        "Content-Length: ${frame.size}\r\n\r\n"
                    )
                }

                out.write(
                    partHeader.toByteArray(
                        StandardCharsets.US_ASCII
                    )
                )
                out.write(frame)
                out.write(
                    "\r\n".toByteArray(
                        StandardCharsets.US_ASCII
                    )
                )
                out.flush()

                lastSentFrame = frame
                lastSendNs = System.nanoTime()
            }
        } catch (_: Exception) {
        } finally {
            try {
                socket.close()
            } catch (_: Exception) {}
        }
    }

    private fun readAsciiLine(input: BufferedInputStream): String? {
        val bytes = ArrayList<Byte>(128)
        while (true) {
            val value = input.read()
            if (value == -1) {
                return if (bytes.isEmpty()) null
                else bytes.toByteArray().toString(StandardCharsets.US_ASCII)
            }
            if (value == '\n'.code) {
                if (bytes.isNotEmpty() && bytes.last() == '\r'.code.toByte()) bytes.removeAt(bytes.lastIndex)
                return bytes.toByteArray().toString(StandardCharsets.US_ASCII)
            }
            bytes.add(value.toByte())
        }
    }

    private fun parseQuery(raw: String): Map<String, String> {
        if (raw.isBlank()) return emptyMap()
        return raw.split("&").mapNotNull { pair ->
            val idx = pair.indexOf('=')
            if (idx < 0) decode(pair) to ""
            else decode(pair.substring(0, idx)) to decode(pair.substring(idx + 1))
        }.toMap()
    }

    private fun decode(value: String): String =
        URLDecoder.decode(value, StandardCharsets.UTF_8.name())

    private fun writeText(out: BufferedOutputStream, code: Int, text: String) =
        writeResponse(out, code, "text/plain; charset=utf-8", text.toByteArray(StandardCharsets.UTF_8))

    private fun writeJson(out: BufferedOutputStream, code: Int, json: String) =
        writeResponse(out, code, "application/json; charset=utf-8", json.toByteArray(StandardCharsets.UTF_8))

    private fun writeBinary(out: BufferedOutputStream, code: Int, type: String, bytes: ByteArray) =
        writeResponse(out, code, type, bytes)

    private fun writeResponse(out: BufferedOutputStream, code: Int, type: String, body: ByteArray) {
        val reason = when (code) {
            200 -> "OK"; 202 -> "Accepted"; 206 -> "Partial Content"
            400 -> "Bad Request"; 403 -> "Forbidden"; 404 -> "Not Found"
            405 -> "Method Not Allowed"; 416 -> "Range Not Satisfiable"
            503 -> "Service Unavailable"
            else -> "OK"
        }
        val header = buildString {
            append("HTTP/1.1 $code $reason\r\n")
            append("Content-Type: $type\r\n")
            append("Content-Length: ${body.size}\r\n")
            append("Cache-Control: no-store\r\n")
            append("Connection: close\r\n\r\n")
        }
        out.write(header.toByteArray(StandardCharsets.US_ASCII))
        out.write(body)
        out.flush()
    }
}
