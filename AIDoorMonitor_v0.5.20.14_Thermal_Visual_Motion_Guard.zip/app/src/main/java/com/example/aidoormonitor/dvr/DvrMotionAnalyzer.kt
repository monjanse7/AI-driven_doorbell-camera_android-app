package com.example.aidoormonitor.dvr

import android.media.Image
import kotlin.math.abs

/**
 * Lightweight local motion analyzer for DVR triggering.
 *
 * It samples the Y (luma) plane directly, so no Bitmap/ML model is needed
 * for the 10 fps motion trigger. Higher sensitivity means a lower trigger
 * threshold.
 */
class DvrMotionAnalyzer(
    private val gridWidth: Int = 40,
    private val gridHeight: Int = 24
) {
    private var previous: IntArray? = null

    fun reset() {
        previous = null
    }

    fun score(image: Image): Float {
        if (image.planes.isEmpty()) return 0f

        val plane = image.planes[0]
        val buffer = plane.buffer
        val width = image.width.coerceAtLeast(1)
        val height = image.height.coerceAtLeast(1)

        val sample = IntArray(gridWidth * gridHeight)
        var out = 0

        for (gy in 0 until gridHeight) {
            val y =
                ((gy + 0.5f) * height / gridHeight)
                    .toInt()
                    .coerceIn(0, height - 1)

            for (gx in 0 until gridWidth) {
                val x =
                    ((gx + 0.5f) * width / gridWidth)
                        .toInt()
                        .coerceIn(0, width - 1)

                val index =
                    buffer.position() +
                        y * plane.rowStride +
                        x * plane.pixelStride

                sample[out++] =
                    if (index >= buffer.position() && index < buffer.limit()) {
                        buffer.get(index).toInt() and 0xff
                    } else {
                        0
                    }
            }
        }

        val old = previous
        previous = sample
        if (old == null || old.size != sample.size) return 0f

        // Compensate for whole-frame brightness changes before calculating
        // motion. Auto exposure / anti-flicker can shift nearly every sampled
        // pixel by the same amount even when nothing in the scene moved.
        // Treating that as motion was one way ordinary speech/audio-only
        // moments could end up with an "Unidentified movement" event.
        var signedTotal = 0L
        for (i in sample.indices) {
            signedTotal += sample[i] - old[i]
        }
        val globalLumaShift =
            signedTotal.toFloat() / sample.size.toFloat()

        var residualTotal = 0f
        var spatiallyChangedCells = 0
        for (i in sample.indices) {
            val residual =
                kotlin.math.abs(
                    (sample[i] - old[i]).toFloat() - globalLumaShift
                )
            residualTotal += residual
            if (residual >= 9f) spatiallyChangedCells++
        }

        // A real scene change should affect a spatial subset of the image, not
        // merely apply the same luma shift everywhere. Six cells is only 0.6%
        // of the 40x24 grid, so ordinary people/vehicles still pass easily.
        if (spatiallyChangedCells < 6) return 0f

        val avgResidual = residualTotal / sample.size.toFloat()
        return (avgResidual / 255f * 100f).coerceIn(0f, 100f)
    }

    fun thresholdForSensitivity(sensitivity: Int): Float {
        val s = sensitivity.coerceIn(0, 100) / 100f
        // Approx. 10% at minimum sensitivity, 2% at maximum sensitivity.
        return 10f - (8f * s)
    }
}
